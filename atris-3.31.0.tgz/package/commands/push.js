const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { loadCredentials } = require('../utils/auth');
const { apiRequestJson } = require('../utils/api');
const { loadBusinesses, saveBusinesses, businessMatchesSlug } = require('./business');
const { loadManifest, saveManifest, buildManifest, computeLocalHashes, isIgnoredSyncPath, filterSyncFiles } = require('../lib/manifest');
const { normalizeWikiOnlyPrefix } = require('../lib/wiki');
const { emitSyncEvent, startTimer } = require('../lib/sync-telemetry');
const { assertSafeWorkspaceRoot } = require('../lib/workspace-safety');

function resolvePushSourceDir({ slug, argv = process.argv, cwd = process.cwd() }) {
  const fromIdx = argv.indexOf('--from');
  if (fromIdx !== -1 && argv[fromIdx + 1]) {
    return path.resolve(cwd, argv[fromIdx + 1]);
  }

  if (fs.existsSync(path.join(cwd, '.atris', 'business.json'))) {
    // A pulled business folder is the workspace root. Its cloud paths include
    // the top-level `atris/` directory, so pushing from `<business>/atris`
    // strips that prefix and makes a force push look like "delete atris/* and
    // recreate everything at root". Keep the business folder itself as root.
    return cwd;
  }

  const atrisDir = path.join(cwd, 'atris', slug);
  const cwdDir = path.join(cwd, slug);
  if (fs.existsSync(atrisDir)) return atrisDir;
  if (fs.existsSync(cwdDir)) return cwdDir;

  return null;
}

function canonicalWorkspaceRoot(dir) {
  try {
    return fs.realpathSync(dir);
  } catch {
    return path.resolve(dir);
  }
}

function basenameOfManifestPath(filePath) {
  const cleaned = String(filePath || '').replace(/\/+$/, '');
  const idx = cleaned.lastIndexOf('/');
  return idx === -1 ? cleaned : cleaned.slice(idx + 1);
}

function isBusinessWorkspaceRoot(dir) {
  return fs.existsSync(path.join(dir, '.atris', 'business.json')) && fs.existsSync(path.join(dir, 'atris'));
}

function pathInScope(filePath, onlyPrefixes) {
  if (!onlyPrefixes) return true;
  return onlyPrefixes.some(prefix => filePath.startsWith(prefix));
}

function buildPushChangePlan({
  localFiles = {},
  baseFiles = {},
  onlyPrefixes = null,
  readFileContent,
  isLocalFilePresent,
} = {}) {
  const filesToPush = [];
  const deletedPaths = [];

  for (const [filePath, fileInfo] of Object.entries(localFiles)) {
    if (!pathInScope(filePath, onlyPrefixes)) continue;
    const baseHash = baseFiles[filePath] ? baseFiles[filePath].hash : null;
    if (!baseHash || fileInfo.hash !== baseHash) {
      try {
        const content = readFileContent ? readFileContent(filePath) : '';
        filesToPush.push({ path: filePath, content });
      } catch {
        // File moved or became unreadable while planning; skip this cycle.
      }
    }
  }

  for (const filePath of Object.keys(baseFiles)) {
    if (!pathInScope(filePath, onlyPrefixes)) continue;
    if (basenameOfManifestPath(filePath).startsWith('.')) continue;
    if (isIgnoredSyncPath(filePath)) continue;
    if (!localFiles[filePath]) {
      if (isLocalFilePresent && isLocalFilePresent(filePath)) continue;
      deletedPaths.push(filePath);
    }
  }

  const filteredLocalCount = Object.keys(localFiles).filter(filePath => pathInScope(filePath, onlyPrefixes)).length;
  const unchangedCount = Math.max(0, filteredLocalCount - filesToPush.length);
  return { filesToPush, deletedPaths, unchangedCount };
}

function shouldRetrySyncIndividually(result, filesToPush) {
  if (!result || result.ok) return false;
  if (!Array.isArray(filesToPush) || filesToPush.length <= 1) return false;
  return result.status !== 403 && result.status !== 409;
}

function isMassDeletePlan({ deletedPaths = [], filesToPush = [], unchangedCount = 0 } = {}) {
  const deleteCount = deletedPaths.length;
  if (deleteCount === 0) return false;
  const survivingCount = filesToPush.length + unchangedCount;
  if (deleteCount >= 10 && survivingCount === 0) return true;
  if (deleteCount >= 25) return true;
  return deleteCount >= 10 && deleteCount > survivingCount;
}

function cleanManifestPath(filePath) {
  const s = String(filePath || '').replace(/\\/g, '/');
  return s.startsWith('/') ? s : `/${s}`;
}

function buildCloudHashMap(files = []) {
  const cloudHashes = {};
  for (const f of files) {
    const normalizedPath = f && f.path ? cleanManifestPath(f.path) : null;
    if (normalizedPath && f.hash) cloudHashes[normalizedPath] = f.hash;
  }
  return cloudHashes;
}

function isSyncReviewArtifactPath(filePath) {
  const cleaned = cleanManifestPath(filePath);
  return ['.remote', '.local', '.base', '.cloud'].some((suffix) => cleaned.endsWith(suffix));
}

function isNestedWorkspacePollutionPath(filePath, slug) {
  const cleaned = cleanManifestPath(filePath);
  const cleanSlug = String(slug || '').trim().replace(/^\/+|\/+$/g, '');
  if (!cleanSlug) return false;
  return cleaned === `/${cleanSlug}` || cleaned.startsWith(`/${cleanSlug}/`);
}

function analyzePushSafety({
  filesToPush = [],
  deletedPaths = [],
  unchangedCount = 0,
  onlyPrefixes = null,
  slug = null,
  allowBroadWorkspace = false,
  allowNestedWorkspace = false,
  allowSyncArtifacts = false,
} = {}) {
  const changedPaths = [
    ...filesToPush.map((file) => cleanManifestPath(file.path)),
    ...deletedPaths.map((filePath) => cleanManifestPath(filePath)),
  ];
  const changeCount = changedPaths.length;
  const rootChanged = changedPaths.filter((filePath) => filePath.split('/').filter(Boolean).length === 1);
  const topLevels = new Set(changedPaths.map((filePath) => filePath.split('/').filter(Boolean)[0]).filter(Boolean));
  const nestedWorkspacePaths = changedPaths.filter((filePath) => isNestedWorkspacePollutionPath(filePath, slug));
  const syncArtifactPaths = changedPaths.filter(isSyncReviewArtifactPath);
  const reasons = [];

  if (nestedWorkspacePaths.length > 0 && !allowNestedWorkspace) {
    reasons.push(`nested workspace folder detected (${nestedWorkspacePaths.length} path${nestedWorkspacePaths.length === 1 ? '' : 's'})`);
  }
  if (syncArtifactPaths.length > 0 && !allowSyncArtifacts) {
    reasons.push(`sync review artifacts detected (${syncArtifactPaths.length} path${syncArtifactPaths.length === 1 ? '' : 's'})`);
  }
  if (!onlyPrefixes && !allowBroadWorkspace) {
    if (changeCount >= 25) {
      reasons.push(`large unscoped workspace change (${changeCount} paths)`);
    } else if (rootChanged.length >= 5) {
      reasons.push(`many root files changed (${rootChanged.length} paths)`);
    } else if (topLevels.size >= 8 && changeCount >= 10) {
      reasons.push(`many top-level areas changed (${topLevels.size} areas)`);
    }
  }

  return {
    ok: reasons.length === 0,
    reasons,
    changedPaths,
    changeCount,
    unchangedCount,
    rootChanged,
    topLevelCount: topLevels.size,
    nestedWorkspacePaths,
    syncArtifactPaths,
  };
}

function renderPushSafetyBlock(report, slug) {
  const lines = [];
  lines.push('');
  lines.push('  Quest gate: review before publish');
  lines.push('  ✗ Refusing unsafe workspace push.');
  lines.push('');
  lines.push(`    Planned change: ${report.changeCount} path${report.changeCount === 1 ? '' : 's'}, ${report.unchangedCount} unchanged.`);
  for (const reason of report.reasons) {
    lines.push(`    Reason: ${reason}.`);
  }
  const examples = [
    ...report.nestedWorkspacePaths,
    ...report.syncArtifactPaths,
    ...report.changedPaths,
  ];
  const uniqueExamples = [...new Set(examples)].slice(0, 8);
  if (uniqueExamples.length > 0) {
    lines.push('');
    lines.push('    First paths to review:');
    uniqueExamples.forEach((filePath) => lines.push(`      - ${filePath.replace(/^\//, '')}`));
  }
  lines.push('');
  lines.push('    Safe moves:');
  lines.push(`      atris push ${slug || ''} --dry-run --only atris/now.md`.trimEnd());
  lines.push('      atris sync --review');
  lines.push('');
  lines.push('    If this broad publish is intentional, rerun with:');
  lines.push('      --allow-broad-workspace');
  if (report.nestedWorkspacePaths.length > 0) lines.push('      --allow-nested-workspace');
  if (report.syncArtifactPaths.length > 0) lines.push('      --allow-sync-artifacts');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function parsePushTimeoutSec(argv = process.argv, defaultSec = 120) {
  let raw = null;
  const eqArg = argv.find(a => a.startsWith('--timeout='));
  if (eqArg) raw = eqArg.slice('--timeout='.length);
  else {
    const idx = argv.indexOf('--timeout');
    if (idx !== -1 && argv[idx + 1]) raw = argv[idx + 1];
  }

  const parsed = raw == null ? defaultSec : Number.parseInt(raw, 10);
  if (!Number.isFinite(parsed)) return defaultSec;
  return Math.max(5, Math.min(300, parsed));
}

async function pushAtris() {
  const elapsedMs = startTimer();
  let slug = process.argv[3];
  let _coldWake = false;

  if (process.argv.includes('--help') || process.argv.includes('-h') || slug === 'help') {
    console.log('Usage: atris push [business] [--from <path>] [--only <prefix>] [--force] [--delete] [--delete-all]');
    console.log('');
    console.log('  Push requires a fresh pull. If cloud has changed since your last pull,');
    console.log('  the push will be blocked until you run `atris pull`. Use --force to override.');
    console.log('');
    console.log('  atris push                   Push from current folder (auto-detect business)');
    console.log('  atris push example-co            Push example-co/ or atris/example-co/');
    console.log('  atris push example-co --only team/nate   Only push files in team/nate/');
    console.log('  atris push --force           Bypass freshness check (force-push, may overwrite cloud changes)');
    console.log('  atris push --delete          Allow small cloud deletes shown by --dry-run');
    console.log('  atris push --delete-all      Extra confirmation for mass-delete recovery');
    console.log('  --allow-broad-workspace      Publish a large unscoped workspace plan after review');
    console.log('  --allow-nested-workspace     Explicitly allow nested <slug>/ paths');
    console.log('  --allow-sync-artifacts       Explicitly allow *.remote/*.local/*.base/*.cloud files');
    process.exit(0);
  }

  // Auto-detect business from .atris/business.json in current dir
  if (!slug || slug.startsWith('-')) {
    const bizFile = path.join(process.cwd(), '.atris', 'business.json');
    if (fs.existsSync(bizFile)) {
      try {
        const biz = JSON.parse(fs.readFileSync(bizFile, 'utf8'));
        slug = biz.slug || biz.name;
      } catch {}
    }
    if (!slug || slug.startsWith('-')) slug = null;
  }

  if (!slug || slug === '--help') {
    console.log('Usage: atris push [business] [--from <path>] [--only <prefix>] [--force] [--delete] [--delete-all]');
    console.log('');
    console.log('  Push requires a fresh pull. If cloud has changed since your last pull,');
    console.log('  the push will be blocked until you run `atris pull`. Use --force to override.');
    console.log('');
    console.log('  atris push                   Push from current folder (auto-detect business)');
    console.log('  atris push example-co            Push example-co/ or atris/example-co/');
    console.log('  atris push example-co --only team/nate   Only push files in team/nate/');
    console.log('  atris push --force           Bypass freshness check (force-push, may overwrite cloud changes)');
    console.log('  atris push --delete          Allow small cloud deletes shown by --dry-run');
    console.log('  atris push --delete-all      Extra confirmation for mass-delete recovery');
    console.log('  --allow-broad-workspace      Publish a large unscoped workspace plan after review');
    console.log('  --allow-nested-workspace     Explicitly allow nested <slug>/ paths');
    console.log('  --allow-sync-artifacts       Explicitly allow *.remote/*.local/*.base/*.cloud files');
    process.exit(0);
  }

  const force = process.argv.includes('--force');
  const dryRun = process.argv.includes('--dry-run');
  const allowDelete = process.argv.includes('--delete');
  const allowMassDelete = process.argv.includes('--delete-all');
  const allowBroadWorkspace = process.argv.includes('--allow-broad-workspace');
  const allowNestedWorkspace = process.argv.includes('--allow-nested-workspace');
  const allowSyncArtifacts = process.argv.includes('--allow-sync-artifacts');
  const allowCrossRootManifest = process.argv.includes('--allow-cross-root-manifest');
  const timeoutSec = parsePushTimeoutSec(process.argv);

  // Parse --only
  let onlyRaw = null;
  const onlyEq = process.argv.find(a => a.startsWith('--only='));
  if (onlyEq) onlyRaw = onlyEq.slice(7);
  else {
    const oi = process.argv.indexOf('--only');
    if (oi !== -1 && process.argv[oi + 1] && !process.argv[oi + 1].startsWith('-')) onlyRaw = process.argv[oi + 1];
  }
  let onlyPrefixes = onlyRaw
    ? onlyRaw.split(',').map(p => {
        const wikiPrefix = normalizeWikiOnlyPrefix(p);
        if (wikiPrefix) return `/${wikiPrefix.replace(/^\//, '')}`;
        let n = '/' + p.replace(/^\//, '');
        if (!n.endsWith('/') && !n.includes('.')) n += '/';
        return n;
      })
    : null;

  const creds = loadCredentials();
  if (!creds || !creds.token) { console.error('Not logged in. Run: atris login'); process.exit(1); }

  // Determine source directory
  const sourceDir = resolvePushSourceDir({ slug });
  if (!sourceDir) {
    console.error(`No local folder found for "${slug}".`);
    console.error('Run from inside a pulled folder, or: atris push example-co --from ./path');
    process.exit(1);
  }

  if (!fs.existsSync(sourceDir)) { console.error(`Source not found: ${sourceDir}`); process.exit(1); }

  // Refuse to walk/upload dangerous paths ($HOME, /, /Users, system dirs).
  assertSafeWorkspaceRoot(sourceDir, { slug, op: 'push from' });

  // Push the whole business workspace by default. Brain-only sync must be
  // explicit with --only atris/ so root workspace files cannot be missed.

  // Resolve business — always refresh from API
  let businessId, workspaceId, businessName, resolvedSlug;
  const businesses = loadBusinesses();
  const listResult = await apiRequestJson('/business/', { method: 'GET', token: creds.token });
  if (listResult.ok) {
    const match = (listResult.data || []).find(b => businessMatchesSlug(b, slug, { includeName: true }));
    if (!match) { console.error(`Business "${slug}" not found.`); process.exit(1); }
    businessId = match.id;
    workspaceId = match.workspace_id;
    businessName = match.name;
    resolvedSlug = match.slug;
    businesses[slug] = { business_id: businessId, workspace_id: workspaceId, name: businessName, slug: match.slug, added_at: new Date().toISOString() };
    saveBusinesses(businesses);
  } else if (businesses[slug]) {
    businessId = businesses[slug].business_id;
    workspaceId = businesses[slug].workspace_id;
    businessName = businesses[slug].name || slug;
    resolvedSlug = businesses[slug].slug || slug;
  } else {
    console.error(`Failed to reach API and no cached business for "${slug}".`);
    process.exit(1);
  }

  if (!workspaceId) { console.error(`Business "${slug}" has no workspace.`); process.exit(1); }

  // Telemetry helper — emits one event with the elapsed wall-clock time.
  // Awaited (not fire-and-forget) because process.exit kills in-flight requests.
  const emit = (outcome, extras = {}) =>
    emitSyncEvent(creds.token, businessId, workspaceId, 'push', outcome, elapsedMs(), extras);

  // Auto-wake the EC2 computer if --auto-wake is set, otherwise check status and warn.
  // Without this, push silently routes to agent_files cache when computer is asleep
  // (the silent fallback footgun from tonight's debugging).
  const autoWake = process.argv.includes('--auto-wake');
  if (autoWake) {
    const statusResult = await apiRequestJson(`/business/${businessId}/ai-computer/status`, { method: 'GET', token: creds.token });
    const computerStatus = statusResult.ok && statusResult.data ? statusResult.data.status : 'unknown';
    if (computerStatus !== 'running' || !(statusResult.data && statusResult.data.endpoint)) {
      process.stdout.write('  Waking EC2 computer... ');
      _coldWake = true;
      await apiRequestJson(`/business/${businessId}/ai-computer/wake`, { method: 'POST', token: creds.token });
      const wakeStart = Date.now();
      while (Date.now() - wakeStart < 90000) {
        await new Promise((r) => setTimeout(r, 3000));
        const s = await apiRequestJson(`/business/${businessId}/ai-computer/status`, { method: 'GET', token: creds.token });
        if (s.ok && s.data && s.data.status === 'running' && s.data.endpoint) {
          const elapsed = Math.floor((Date.now() - wakeStart) / 1000);
          console.log(`awake (${elapsed}s)`);
          break;
        }
      }
    }
  }

  // Load manifest and compute local hashes
  const manifest = loadManifest(resolvedSlug || slug);
  const localFiles = computeLocalHashes(sourceDir);

  if (manifest && manifest.workspace_root && !allowCrossRootManifest) {
    const manifestRoot = canonicalWorkspaceRoot(manifest.workspace_root);
    const currentRoot = canonicalWorkspaceRoot(sourceDir);
    if (manifestRoot !== currentRoot) {
      console.log('');
      console.log('  ✗ This folder has not been pulled since the current sync manifest was created.');
      console.log('');
      console.log(`    Manifest folder: ${manifest.workspace_root}`);
      console.log(`    Current folder:  ${sourceDir}`);
      console.log('');
      console.log('    To sync safely, run these from the folder you want to push:');
      console.log(`      atris pull ${resolvedSlug || slug} --keep-local --timeout 120`);
      console.log(`      atris push ${resolvedSlug || slug} --dry-run`);
      console.log(`      atris push ${resolvedSlug || slug}`);
      process.exit(1);
    }
  }

  if (Object.keys(localFiles).length === 0) {
    console.log(`\nNo files to push from ${sourceDir}`);
    return;
  }

  console.log('');
  console.log(`Pushing to ${businessName}...`);

  // ───────────────────────────────────────────────────────────────────
  // FRESHNESS CHECK — pull-before-push enforcement.
  // ───────────────────────────────────────────────────────────────────
  // Compare cloud's current state to our local manifest. If cloud has any
  // file the manifest doesn't know about, OR a file with a different hash
  // than what we last pulled, the user is out of date and MUST pull first.
  // This prevents stale local state from clobbering fresh cloud changes —
  // the "lagging version push" footgun. Use --force to bypass (e.g., for
  // genuine local-canonical pushes like align --hard).
  if (!force) {
    process.stdout.write('  Checking cloud freshness... ');
    const snapshotResult = await apiRequestJson(
      `/business/${businessId}/workspaces/${workspaceId}/snapshot?include_content=false`,
      { method: 'GET', token: creds.token, timeoutMs: 60000 }
    );
    if (snapshotResult.ok && snapshotResult.data && Array.isArray(snapshotResult.data.files)) {
      const cloudHashes = filterSyncFiles(buildCloudHashMap(snapshotResult.data.files));
      const manifestFiles = filterSyncFiles((manifest && manifest.files) || {});
      const driftFiles = [];
      // Direction 1: cloud has files the manifest doesn't know about, OR
      // cloud's hash differs from what we last pulled (someone changed it).
      for (const [p, hash] of Object.entries(cloudHashes)) {
        // Apply --only filter to drift detection too: if user is scoping the
        // push to a subtree, only block on drift inside that subtree.
        if (onlyPrefixes && !onlyPrefixes.some((pref) => p.startsWith(pref))) continue;
        const manifestEntry = manifestFiles[p];
        if (!manifestEntry || manifestEntry.hash !== hash) {
          driftFiles.push(p);
        }
      }
      // Direction 2: manifest has files the cloud no longer has (someone
      // deleted them). Without this check, we'd silently re-push deleted
      // files on the next push, undoing the deletion.
      //
      // CAVEAT: the warm runner's snapshot endpoint deliberately hides certain
      // basenames (CLAUDE.md, .* dotfiles, node_modules, __pycache__, .git) —
      // see ecs_warm_runner.py _snapshot_dir. They CAN exist on cloud but
      // never appear in cloudHashes. Skip them in the missing-side check or
      // every CLAUDE.md push will be flagged as drift forever.
      const SERVER_HIDDEN_BASENAMES = new Set(['CLAUDE.md']);
      const cloudPathSet = new Set(Object.keys(cloudHashes));
      for (const p of Object.keys(manifestFiles)) {
        if (onlyPrefixes && !onlyPrefixes.some((pref) => p.startsWith(pref))) continue;
        const idx = p.lastIndexOf('/');
        const base = idx === -1 ? p : p.slice(idx + 1);
        if (SERVER_HIDDEN_BASENAMES.has(base)) continue;
        if (!cloudPathSet.has(p)) {
          driftFiles.push(p);
        }
      }
      if (driftFiles.length > 0) {
        console.log(`drift detected (${driftFiles.length} file${driftFiles.length === 1 ? '' : 's'})`);
        console.log('');
        console.log(`  ✗ Cloud has changed since your last pull. Refusing to push stale state.`);
        console.log('');
        console.log('    Files that differ on cloud:');
        driftFiles.slice(0, 8).forEach((p) => console.log(`      ~ ${p.replace(/^\//, '')}`));
        if (driftFiles.length > 8) console.log(`      ... +${driftFiles.length - 8} more`);
        console.log('');
        console.log('    Run `atris pull` first, then push your changes.');
        console.log('    To override (force-push, may clobber cloud edits): atris push --force');
        await emit('drift', { error_detail: `${driftFiles.length} file(s) drifted` });
        process.exit(1);
      }
      console.log('fresh');
    } else {
      // Snapshot fetch failed — fail closed. The whole point of the freshness
      // check is to prevent accidental stale pushes; if we can't verify cloud
      // state, we don't push. Use --force to bypass when you know what you're
      // doing (e.g., the workspace is genuinely unhealthy and you have a clean
      // local copy you need to recover from).
      console.log(`failed (status ${snapshotResult.status || 'unknown'})`);
      console.log('');
      console.log('  ✗ Could not verify cloud freshness. Refusing to push.');
      console.log('    The workspace may be unreachable or the snapshot endpoint is broken.');
      console.log('    To bypass and force-push anyway: atris push --force');
      await emit('status_unknown', { error_detail: `snapshot status ${snapshotResult.status || 'unknown'}` });
      process.exit(1);
    }
  }

  // Compare local hashes to manifest — NO server call needed
  // Files where local hash differs from manifest = changed locally
  const baseFiles = filterSyncFiles((manifest && manifest.files) ? manifest.files : {});
  const { filesToPush, deletedPaths, unchangedCount } = buildPushChangePlan({
    localFiles,
    baseFiles,
    onlyPrefixes,
    readFileContent: (filePath) => fs.readFileSync(path.join(sourceDir, filePath.replace(/^\//, '')), 'utf8'),
    isLocalFilePresent: (filePath) => fs.existsSync(path.join(sourceDir, filePath.replace(/^\//, ''))),
  });

  if (filesToPush.length === 0 && deletedPaths.length === 0) {
    console.log('\n  Already up to date.\n');
    await emit('success', { files_unchanged: unchangedCount });
    return;
  }

  const safetyReport = analyzePushSafety({
    filesToPush,
    deletedPaths,
    unchangedCount,
    onlyPrefixes,
    slug: resolvedSlug || slug,
    allowBroadWorkspace,
    allowNestedWorkspace,
    allowSyncArtifacts,
  });

  if (!safetyReport.ok && !dryRun) {
    process.stdout.write(renderPushSafetyBlock(safetyReport, resolvedSlug || slug));
    await emit('blocked', { error_detail: safetyReport.reasons.join('; ') });
    process.exit(1);
  }

  // Dry run — show what would be pushed without pushing
  if (dryRun) {
    console.log('');
    for (const f of filesToPush) {
      const isNew = !baseFiles[f.path];
      console.log(`  ${isNew ? '+' : '\u2191'} ${f.path.replace(/^\//, '')}  ${isNew ? 'new file' : 'updated'}  (dry run)`);
    }
    for (const filePath of deletedPaths) {
      console.log(`  x ${filePath.replace(/^\//, '')}  deleted  (dry run)`);
    }
    const parts = [];
    if (filesToPush.length > 0) parts.push(`${filesToPush.length} would be pushed`);
    if (deletedPaths.length > 0) parts.push(`${deletedPaths.length} would be deleted`);
    if (unchangedCount > 0) parts.push(`${unchangedCount} unchanged`);
    console.log(`\n  ${parts.join(', ')}. (--dry-run, nothing sent)\n`);
    if (deletedPaths.length > 0) {
      console.log('  Deletes require an explicit real push with --delete.');
      console.log('  If these deletes are unexpected, run `atris pull --keep-local` first.\n');
    }
    if (!safetyReport.ok) {
      process.stdout.write(renderPushSafetyBlock(safetyReport, resolvedSlug || slug));
      console.log('  Dry run only: nothing was sent.\n');
    }
    return;
  }

  if (deletedPaths.length > 0 && !allowDelete) {
    console.log('');
    console.log(`  ✗ Refusing to delete ${deletedPaths.length} cloud file${deletedPaths.length === 1 ? '' : 's'} without --delete.`);
    console.log('');
    console.log('    Preview first:');
    console.log(`      atris push ${resolvedSlug || slug} --dry-run`);
    console.log('');
    console.log('    If the deletes are intentional:');
    console.log(`      atris push ${resolvedSlug || slug} --delete`);
    console.log('');
    console.log('    If the deletes are surprising, pull cloud truth first:');
    console.log(`      atris pull ${resolvedSlug || slug} --keep-local --timeout 120`);
    process.exit(1);
  }

  if (deletedPaths.length > 0 && allowDelete && !allowMassDelete && isMassDeletePlan({ deletedPaths, filesToPush, unchangedCount })) {
    console.log('');
    console.log(`  ✗ Refusing mass delete of ${deletedPaths.length} cloud files with --delete alone.`);
    console.log('');
    console.log('    This looks like a missing local folder or wrong source root.');
    console.log('    No cloud files were deleted.');
    console.log('');
    console.log('    First inspect the plan:');
    console.log(`      atris push ${resolvedSlug || slug} --dry-run`);
    console.log('');
    console.log('    If this is truly an intentional full cleanup, rerun with both flags:');
    console.log(`      atris push ${resolvedSlug || slug} --delete --delete-all`);
    console.log('');
    console.log('    If this is surprising, pull cloud truth first:');
    console.log(`      atris pull ${resolvedSlug || slug} --keep-local --timeout 120`);
    process.exit(1);
  }

  let pushed = 0;
  let deleted = 0;
  let skipped = [];
  // Files we sent that the server did not confirm as written/unchanged.
  // The /sync endpoint can silently drop files (role-based filters on the
  // business workspace route, path-rejection inside the warm runner, etc.)
  // and still return HTTP 200. If we don't cross-check per-file results,
  // the CLI prints "Pushed" for files that never actually landed — and
  // the manifest records a hash that makes the next push skip them too,
  // losing them permanently. `failedToLand` collects those casualties so
  // we can warn the user AND keep them out of the manifest update.
  let failedToLand = [];
  const landedPaths = new Set();
  let result = { ok: true };
  let batchFailureDetail = null;

  // Server-canonical path format for the /sync endpoint: NO leading slash.
  // The warm runner's _safe_path rejects `/atris/...` with "Absolute path
  // outside workspace" (it only accepts paths under `/workspace/...`). All
  // our internal bookkeeping uses a leading slash (manifest keys, localFiles
  // keys, snapshot response paths), so we strip only at the wire.
  const toWirePath = (p) => (p || '').replace(/^\/+/, '');
  const fromWirePath = (p) => {
    const s = String(p || '');
    return s.startsWith('/') ? s : `/${s}`;
  };
  const wireFiles = (files) => files.map((f) => ({ path: toWirePath(f.path), content: f.content }));
  const syncFiles = (files) => apiRequestJson(
    `/business/${businessId}/workspaces/${workspaceId}/sync?timeout=${timeoutSec}`,
    {
      method: 'POST',
      token: creds.token,
      body: { files: wireFiles(files) },
      headers: { 'X-Atris-Actor-Source': 'cli' },
      timeoutMs: (timeoutSec + 15) * 1000,
    }
  );

  // Inspect per-file results from a /sync response. Treat "written" and
  // "unchanged" as success; everything else (including missing-from-results,
  // which is how silent server-side drops look) is a failure.
  const recordSyncResults = (sentFiles, response) => {
    const resultsArr = response && response.data && Array.isArray(response.data.results)
      ? response.data.results
      : null;
    const seen = new Set();
    if (resultsArr) {
      for (const r of resultsArr) {
        if (!r || !r.path) continue;
        const status = String(r.status || '').toLowerCase();
        const canonical = fromWirePath(r.path);
        if (status === 'written' || status === 'unchanged') {
          landedPaths.add(canonical);
          seen.add(canonical);
        } else {
          failedToLand.push({ path: canonical, status: status || 'error', error: r.error || '' });
          seen.add(canonical);
        }
      }
    } else {
      // No results array in response — old server. Best-effort: assume
      // everything sent landed. This preserves existing behavior when
      // talking to a server that doesn't return per-file status.
      for (const f of sentFiles) {
        landedPaths.add(f.path);
        seen.add(f.path);
      }
    }
    // Any file we sent that the server didn't mention = silently dropped.
    for (const f of sentFiles) {
      if (!seen.has(f.path)) {
        failedToLand.push({ path: f.path, status: 'dropped', error: 'server did not confirm write' });
      }
    }
  };

  if (filesToPush.length > 0) {
    // Push files to server (strip leading slash — server requires workspace-relative paths)
    result = await syncFiles(filesToPush);

    if (!result.ok) {
      if (result.status === 403) {
        const detail = result.errorMessage || result.error || (result.data && result.data.detail) || '';
        if (detail && /plan required|business, max, or enterprise/i.test(detail)) {
          console.error(`\n  Access denied: ${detail}`);
          await emit('access_denied', { error_detail: detail });
          process.exit(1);
        }
        // Permission denied — retry with only team/ and journal/ files
        const allowed = filesToPush.filter(f => f.path.startsWith('/team/') || f.path.startsWith('/journal/'));
        skipped = filesToPush.filter(f => !f.path.startsWith('/team/') && !f.path.startsWith('/journal/'));

        if (allowed.length > 0) {
          const retry = await syncFiles(allowed);
          if (retry.ok) {
            recordSyncResults(allowed, retry);
            pushed = landedPaths.size;
          } else {
            console.error(`\n  Push failed: ${retry.errorMessage || retry.error || retry.status}`);
            await emit('access_denied', { error_detail: `403 retry failed: ${retry.status}` });
            process.exit(1);
          }
        } else {
          console.error('\n  Access denied: you can only push to your team/ folder.');
          await emit('access_denied');
          process.exit(1);
        }
      } else if (result.status === 409) {
        console.error('\n  Computer is sleeping. Wake it first.');
        await emit('cold_wake', { error_detail: 'computer sleeping (409)' });
        process.exit(1);
      } else if (shouldRetrySyncIndividually(result, filesToPush)) {
        batchFailureDetail = `${result.status || 'unknown'}: ${result.errorMessage || result.error || 'batch sync failed'}`;
        console.log('');
        console.log(`  Batch push failed (${result.errorMessage || result.error || result.status}). Retrying one file at a time...`);
        for (const f of filesToPush) {
          const single = await syncFiles([f]);
          if (single.ok) {
            recordSyncResults([f], single);
          } else {
            failedToLand.push({
              path: f.path,
              status: single.status || 'error',
              error: single.errorMessage || single.error || '',
            });
          }
        }
        pushed = landedPaths.size;
      } else {
        console.error(`\n  Push failed: ${result.errorMessage || result.error || result.status}`);
        await emit('status_unknown', { error_detail: `sync status ${result.status}` });
        process.exit(1);
      }
    } else {
      recordSyncResults(filesToPush, result);
      pushed = landedPaths.size;
    }
  }

  // Delete loop — throttled, 429-aware, tracks per-file success/failure.
  // Earlier bug: bulk deletes hit rate limit (60/min default) at request 60,
  // then process.exit'd, leaving partial state and a manifest that thought
  // everything was deleted. New behavior:
  //   - 600ms throttle between deletes (≈100/min, safe under default rate limit)
  //   - 429 → wait 20s, retry once
  //   - 404 → counted as success (file already gone)
  //   - other failures → collected, reported at end, do NOT exit
  //   - manifest update only counts confirmed-deleted paths
  const deletedConfirmed = [];
  const deleteFailed = [];
  let _rateLimitedDeletes = 0;
  for (let i = 0; i < deletedPaths.length; i++) {
    const filePath = deletedPaths[i];
    if (i > 0) {
      // sleep 600ms between deletes
      await new Promise((r) => setTimeout(r, 600));
    }
    let deleteResult = await apiRequestJson(
      `/business/${businessId}/workspaces/${workspaceId}/file?path=${encodeURIComponent(filePath)}`,
      { method: 'DELETE', token: creds.token }
    );
    if (deleteResult.status === 429) {
      // Rate limit — wait 20s, retry once
      _rateLimitedDeletes++;
      await new Promise((r) => setTimeout(r, 20000));
      deleteResult = await apiRequestJson(
        `/business/${businessId}/workspaces/${workspaceId}/file?path=${encodeURIComponent(filePath)}`,
        { method: 'DELETE', token: creds.token }
      );
    }
    if (deleteResult.ok || deleteResult.status === 404) {
      deletedConfirmed.push(filePath);
      deleted++;
    } else {
      deleteFailed.push({ path: filePath, status: deleteResult.status, error: deleteResult.error });
    }
    // Show progress for large batches
    if (deletedPaths.length > 20 && (i + 1) % 20 === 0) {
      console.log(`  [delete ${i + 1}/${deletedPaths.length}] ${deletedConfirmed.length} ok, ${deleteFailed.length} failed`);
    }
  }
  if (deleteFailed.length > 0) {
    console.log('');
    console.log(`  ⚠ ${deleteFailed.length} ${deleteFailed.length === 1 ? 'delete' : 'deletes'} failed (NOT marked as deleted in manifest):`);
    deleteFailed.slice(0, 10).forEach((f) => console.log(`    ${f.status} ${f.path.replace(/^\//, '')}`));
    if (deleteFailed.length > 10) console.log(`    ... +${deleteFailed.length - 10} more`);
  }

  // Display results — only for files the server confirmed as landed.
  // A non-technical user seeing "+ atris/ideas/foo.md new file" naturally
  // assumes foo.md is on cloud. So we only print that line when the server
  // actually confirmed it via per-file status. Anything else goes into the
  // loud failure block below.
  console.log('');
  for (const f of filesToPush) {
    if (skipped.includes(f)) continue;
    if (!landedPaths.has(f.path)) continue;
    const isNew = !baseFiles[f.path];
    console.log(`  ${isNew ? '+' : '\u2191'} ${f.path.replace(/^\//, '')}  ${isNew ? 'new file' : 'updated'}`);
  }
  for (const f of skipped) {
    console.log(`  - ${f.path.replace(/^\//, '')}  skipped (no permission)`);
  }
  // Only print confirmed deletes (not failed ones — they were reported above)
  for (const filePath of deletedConfirmed) {
    console.log(`  x ${filePath.replace(/^\//, '')}  deleted`);
  }

  // Loud failure block — files the server silently dropped or rejected.
  // These did NOT land on cloud even though the HTTP call returned 200.
  if (failedToLand.length > 0) {
    console.log('');
    console.log(`  ⚠ ${failedToLand.length} ${failedToLand.length === 1 ? 'file' : 'files'} did NOT land on cloud (server returned 200 but`);
    console.log(`     dropped or rejected these files):`);
    const shown = failedToLand.slice(0, 15);
    for (const f of shown) {
      const detail = f.error ? ` — ${f.error}` : ` (${f.status})`;
      console.log(`    ✗ ${f.path.replace(/^\//, '')}${detail}`);
    }
    if (failedToLand.length > shown.length) {
      console.log(`    ... +${failedToLand.length - shown.length} more`);
    }
    console.log('');
    console.log('  Common causes: path is outside the workspace (e.g. absolute /Users/... path),');
    console.log('  your role lacks write permission for that folder, or warm runner returned an error.');
    console.log('  These files will appear as drift on your next push so you can retry.');
  }

  // Summary
  console.log('');
  const parts = [];
  if (pushed > 0) parts.push(`${pushed} pushed`);
  if (deleted > 0) parts.push(`${deleted} deleted`);
  if (deleteFailed.length > 0) parts.push(`${deleteFailed.length} delete failed`);
  if (unchangedCount > 0) parts.push(`${unchangedCount} unchanged`);
  if (skipped.length > 0) parts.push(`${skipped.length} skipped`);
  console.log(`  ${parts.join(', ')}.`);

  // Update manifest — mark pushed files with their new hash, drop ONLY confirmed deletes.
  // Failed deletes stay in the manifest so the next push will retry them.
  //
  // CRITICAL: only record manifest entries for files the server confirmed as
  // landed (landedPaths). If we recorded the local hash for a file that the
  // server silently dropped, the next push would compare local==manifest and
  // skip it — the file would never land. Keeping it OUT of the manifest means
  // the next push sees it as new/changed and retries automatically.
  const updatedFiles = { ...baseFiles };
  for (const f of filesToPush) {
    if (skipped.includes(f)) continue;
    if (!landedPaths.has(f.path)) continue;
    updatedFiles[f.path] = localFiles[f.path];
  }
  for (const filePath of deletedConfirmed) {
    delete updatedFiles[filePath];
  }
  saveManifest(resolvedSlug || slug, buildManifest(updatedFiles, null, { workspaceRoot: sourceDir }));

  // Telemetry — outcome reflects actual run quality, not just exit-code-zero.
  // Partial delete failures or rate-limit retries mean the run was NOT a clean win;
  // labeling them success would poison the RL signal.
  const bytesChanged = filesToPush.reduce((acc, f) => acc + (f.content ? Buffer.byteLength(f.content, 'utf8') : 0), 0);
  let finalOutcome;
  let finalDetail;
  if (failedToLand.length > 0) {
    finalOutcome = 'status_unknown';
    finalDetail = `${failedToLand.length} file(s) silently dropped by server (statuses: ${[...new Set(failedToLand.map(f => f.status))].join(',')})`;
  } else if (deleteFailed.length > 0) {
    finalOutcome = 'status_unknown';
    finalDetail = `${deleteFailed.length} delete(s) failed (statuses: ${[...new Set(deleteFailed.map(f => f.status))].join(',')})`;
  } else if (batchFailureDetail) {
    finalOutcome = 'status_unknown';
    finalDetail = `batch sync failed but individual retry landed all files (${batchFailureDetail})`;
  } else if (_rateLimitedDeletes > 0) {
    finalOutcome = 'rate_limited';
    finalDetail = `${_rateLimitedDeletes} delete(s) hit 429 (recovered)`;
  } else if (_coldWake) {
    finalOutcome = 'cold_wake';
  } else {
    finalOutcome = 'success';
  }
  await emit(finalOutcome, {
    files_pushed: pushed,
    files_deleted: deleted,
    files_unchanged: unchangedCount,
    bytes_changed: bytesChanged,
    bytes_transferred: bytesChanged,
    error_detail: finalDetail,
  });
}

module.exports = {
  pushAtris,
  buildPushChangePlan,
  shouldRetrySyncIndividually,
  resolvePushSourceDir,
  canonicalWorkspaceRoot,
  basenameOfManifestPath,
  buildCloudHashMap,
  isBusinessWorkspaceRoot,
  isMassDeletePlan,
  parsePushTimeoutSec,
  analyzePushSafety,
  isNestedWorkspacePollutionPath,
  isSyncReviewArtifactPath,
  renderPushSafetyBlock,
};
