const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { loadManifest, saveManifest } = require('../lib/manifest');
const { removeBaseContents, writeBaseContents } = require('../lib/company-brain-sync');
const { collectCloudOrphans } = require('../commands/cloud');

const WATCH_IGNORED_DIRS = new Set([
  '.git', '.atris', '.claude', '.cursor', '.next', '.cache',
  'node_modules', '__pycache__', 'venv', '.venv', 'dist', 'build',
  'coverage', 'tmp', 'temp',
]);
const WATCH_IGNORED_FILES = new Set(['.DS_Store']);

function commandLine(args) {
  return ['atris', ...args].join(' ');
}

function parseFlagValue(args, name, fallback) {
  const eq = args.find((arg) => arg.startsWith(`${name}=`));
  if (eq) return eq.slice(name.length + 1);
  const idx = args.indexOf(name);
  if (idx !== -1 && args[idx + 1] && !args[idx + 1].startsWith('-')) return args[idx + 1];
  return fallback;
}

function parseBusinessSyncArgs(args = []) {
  const positional = args.filter((arg) => arg && !arg.startsWith('-'));
  const status = args.includes('--status') || positional[0] === 'status' || positional[0] === 'doctor';
  const review = args.includes('--review') || positional[0] === 'review';
  const resolveIdx = positional.indexOf('resolve');
  const resolveFlag = parseFlagValue(args, '--resolve', null);
  const resolve = resolveFlag || (resolveIdx !== -1 ? positional[resolveIdx + 1] : null);
  const resolvePath = parseFlagValue(args, '--path', parseFlagValue(args, '--file', null));
  const takeRaw = parseFlagValue(args, '--take', null);
  const take = takeRaw ? String(takeRaw).trim().toLowerCase() : null;
  const commandWords = new Set(['status', 'doctor', 'review', 'resolve', 'local', 'cloud', 'both', 'merge']);
  const slug = positional.find((arg) => !commandWords.has(arg)) || null;
  const dryRun = args.includes('--dry-run');
  const timeout = parseFlagValue(args, '--timeout', '120');
  const allowDelete = args.includes('--delete');
  const watch = args.includes('--watch');
  const intervalSec = Number.parseInt(parseFlagValue(args, '--interval', '60'), 10);
  const debounceSec = Number.parseInt(parseFlagValue(args, '--debounce', '5'), 10);
  const showOrphans = args.includes('--show-orphans');
  const help = args.includes('--help') || args.includes('-h') || positional[0] === 'help';

  return { slug, dryRun, timeout, allowDelete, watch, intervalSec, debounceSec, status, review, resolve, resolvePath, take, showOrphans, help };
}

function readBusinessSlug(cwd = process.cwd()) {
  const bizFile = path.join(cwd, '.atris', 'business.json');
  if (!fs.existsSync(bizFile)) return null;
  try {
    const biz = JSON.parse(fs.readFileSync(bizFile, 'utf8'));
    return biz.slug || biz.name || null;
  } catch {
    return null;
  }
}

function resolveBusinessSyncOptions(args = [], cwd = process.cwd()) {
  const options = parseBusinessSyncArgs(args);
  if (!options.slug) options.slug = readBusinessSlug(cwd);
  return options;
}

function buildBusinessSyncPlan(options) {
  if (!options.slug) return null;

  const pullArgs = ['pull', options.slug, '--keep-local', '--fail-on-conflict', '--timeout', String(options.timeout)];
  const pushArgs = ['push', options.slug];
  if (options.dryRun) {
    pullArgs.push('--dry-run');
    pushArgs.push('--dry-run');
  }
  if (options.allowDelete) pushArgs.push('--delete');

  return { pullArgs, pushArgs };
}

function shouldIgnoreWatchPath(relativePath) {
  if (!relativePath) return true;
  const parts = relativePath.split(path.sep);
  if (parts.some((part) => WATCH_IGNORED_DIRS.has(part))) return true;
  return WATCH_IGNORED_FILES.has(path.basename(relativePath));
}

function collectWorkspaceSnapshot(root) {
  const snapshot = new Map();

  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      const rel = path.relative(root, full);
      if (shouldIgnoreWatchPath(rel)) continue;
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile()) {
        try {
          const stat = fs.statSync(full);
          snapshot.set(rel, `${stat.size}:${Math.floor(stat.mtimeMs)}`);
        } catch {
          // Files can move while the editor is saving.
        }
      }
    }
  }

  walk(root);
  return snapshot;
}

const collectBrainSnapshot = collectWorkspaceSnapshot;

function snapshotsDiffer(before, after) {
  if (before.size !== after.size) return true;
  for (const [key, value] of before.entries()) {
    if (after.get(key) !== value) return true;
  }
  return false;
}

function sameRealPath(a, b) {
  try {
    return fs.realpathSync(a) === fs.realpathSync(b);
  } catch {
    return path.resolve(a || '') === path.resolve(b || '');
  }
}

function canPreviewPush(cwd, slug) {
  const manifest = loadManifest(slug);
  if (!manifest || !manifest.workspace_root) return true;
  return sameRealPath(manifest.workspace_root, cwd);
}

function syncStatusPath(cwd) {
  return path.join(cwd, '.atris', 'sync', 'status.json');
}

function readJsonFile(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function writeSyncStatus(cwd, payload = {}) {
  const statusPath = syncStatusPath(cwd);
  fs.mkdirSync(path.dirname(statusPath), { recursive: true });
  fs.writeFileSync(statusPath, JSON.stringify({
    schema: 'atris.company_brain_sync.status.v1',
    updated_at: new Date().toISOString(),
    ...payload,
  }, null, 2) + '\n', 'utf8');
}

function countWorkspaceFiles(cwd) {
  let count = 0;

  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      const rel = path.relative(cwd, full);
      if (shouldIgnoreWatchPath(rel)) continue;
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile()) count += 1;
    }
  }

  walk(cwd);
  return count;
}

function countFilesUnder(dir) {
  let count = 0;

  function walk(current) {
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile()) count += 1;
    }
  }

  walk(dir);
  return count;
}

function collectWorkspaceWarnings(cwd, slug) {
  const warnings = [];
  if (slug) {
    const nested = path.join(cwd, slug);
    if (fs.existsSync(nested)) {
      try {
        if (fs.statSync(nested).isDirectory()) {
          warnings.push(`nested workspace folder: ${slug}/ (${countFilesUnder(nested)} files)`);
        }
      } catch {
        // Ignore races while editors or sync tools move folders.
      }
    }
  }

  const syncArtifacts = [];
  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      const rel = path.relative(cwd, full);
      if (shouldIgnoreWatchPath(rel)) continue;
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile() && ['.remote', '.local', '.base', '.cloud'].some((suffix) => entry.name.endsWith(suffix))) {
        syncArtifacts.push(rel.replace(/\\/g, '/'));
      }
    }
  }
  walk(cwd);
  if (syncArtifacts.length > 0) {
    warnings.push(`sync review artifacts outside .atris/: ${syncArtifacts.length}`);
  }
  return warnings;
}

function listConflictSummaries(cwd) {
  const conflictsDir = path.join(cwd, '.atris', 'sync', 'conflicts');
  const summaries = [];

  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.isFile() && entry.name === 'summary.md') {
        summaries.push(path.relative(cwd, full).replace(/\\/g, '/'));
      }
    }
  }

  walk(conflictsDir);
  return summaries.sort();
}

function collectLocalSyncStatus(cwd = process.cwd(), options = {}) {
  const slug = options.slug || readBusinessSlug(cwd);
  const manifest = slug ? loadManifest(slug) : null;
  const heartbeat = readJsonFile(syncStatusPath(cwd));
  const conflictSummaries = listConflictSummaries(cwd);
  const brainDir = path.join(cwd, 'atris');
  const workspaceFileCount = countWorkspaceFiles(cwd);
  const manifestRootMatches = !manifest || !manifest.workspace_root || sameRealPath(manifest.workspace_root, cwd);
  const warnings = collectWorkspaceWarnings(cwd, slug);

  return {
    slug,
    cwd,
    brainDir,
    brainExists: fs.existsSync(brainDir),
    brainFileCount: workspaceFileCount,
    workspaceFileCount,
    conflictCount: conflictSummaries.length,
    latestConflict: conflictSummaries[conflictSummaries.length - 1] || null,
    lastSync: manifest && manifest.last_sync ? manifest.last_sync : null,
    manifestRoot: manifest && manifest.workspace_root ? manifest.workspace_root : null,
    manifestRootMatches,
    heartbeat,
    warnings,
  };
}

function renderLocalSyncStatus(status) {
  const lines = [];
  const fileLabel = status.workspaceFileCount === 1 ? 'file' : 'files';
  lines.push('Business workspace sync status');
  lines.push(`  business: ${status.slug || 'not detected'}`);
  lines.push(`  folder: ${status.cwd}`);
  lines.push(`  workspace: ${status.workspaceFileCount} ${fileLabel} (${status.brainExists ? 'atris/ present' : 'missing atris/'})`);
  lines.push('  loop: Pull -> Review -> Publish');
  lines.push('  quest gate: exact files beat broad pushes');
  lines.push(`  last cloud sync: ${status.lastSync || 'never on this machine'}`);
  if (status.manifestRoot && !status.manifestRootMatches) {
    lines.push(`  manifest: from another folder (${status.manifestRoot})`);
  } else {
    lines.push(`  manifest: ${status.manifestRoot ? 'matches this folder' : 'not created yet'}`);
  }
  if (status.conflictCount > 0) {
    lines.push(`  conflicts: ${status.conflictCount} review packet${status.conflictCount === 1 ? '' : 's'}`);
    lines.push(`  latest: ${status.latestConflict}`);
  } else {
    lines.push('  conflicts: none');
  }
  if (status.warnings && status.warnings.length > 0) {
    lines.push(`  warnings: ${status.warnings.length}`);
    status.warnings.slice(0, 3).forEach((warning) => lines.push(`    - ${warning}`));
  } else {
    lines.push('  warnings: none');
  }
  if (status.orphanError !== undefined) {
    lines.push(`  orphans: ${status.orphanError}`);
  } else if (status.orphanPaths !== undefined) {
    if (status.orphanPaths.length === 0) {
      lines.push('  orphans: none');
    } else {
      const orphanLabel = status.orphanPaths.length === 1 ? 'file' : 'files';
      lines.push(`  orphans: ${status.orphanPaths.length} cloud ${orphanLabel} not present locally`);
      status.orphanPaths.slice(0, 20).forEach((p) => lines.push(`    - ${p.replace(/^\//, '')}`));
      if (status.orphanPaths.length > 20) {
        lines.push(`    ... +${status.orphanPaths.length - 20} more`);
      }
    }
  }
  if (status.heartbeat && status.heartbeat.updated_at) {
    lines.push(`  watcher: last heartbeat ${status.heartbeat.updated_at} (${status.heartbeat.state || 'unknown'})`);
  } else {
    lines.push('  watcher: no heartbeat yet');
  }
  lines.push('');
  lines.push('Next: run `atris sync --dry-run` to preview the quest, or `atris sync --review` if conflicts exist.');
  return `${lines.join('\n')}\n`;
}

function renderBusinessSyncHelp() {
  return [
    'Usage: atris sync [business] [--dry-run] [--watch] [--status] [--show-orphans] [--review] [--take local|cloud] [--resolve local|cloud|both|merge] [--path <file>] [--timeout 120]',
    '',
    'Safe loop:',
    '  Pull -> Review -> Publish',
    '',
    'Commands:',
    '  atris sync --status       Show local sync health',
    '  atris sync --status --show-orphans   Show local sync health plus cloud files not present locally',
    '  atris sync --dry-run      Preview pull and publish plans without writing cloud',
    '  atris sync --review       List conflicts; pick local / cloud / merge per file',
    '  atris sync --review --take local|cloud',
    '                            Non-interactive: take local or cloud for every conflict',
    '  atris sync --resolve cloud|local|merge [--path <file>]',
    '  atris sync --watch        Keep the workspace live with the same safety gates',
    '',
    'Publish safety:',
    '  Large unscoped pushes, nested workspace folders, and *.remote artifacts are blocked.',
    '  Use exact --only paths for repairs, or explicit push override flags after review.',
    '',
  ].join('\n');
}

function readTextIfExists(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function buildConflictMarkers(localContent = '', remoteContent = '') {
  const local = String(localContent);
  const remote = String(remoteContent);
  const localBody = local.endsWith('\n') || local === '' ? local : `${local}\n`;
  const remoteBody = remote.endsWith('\n') || remote === '' ? remote : `${remote}\n`;
  return `<<<<<<< local\n${localBody}=======\n${remoteBody}>>>>>>> cloud\n`;
}

function listConflictFiles(entries = []) {
  const lines = [];
  const count = entries.length;
  if (count === 0) {
    lines.push('no sync conflicts need review.');
    return `${lines.join('\n')}\n`;
  }
  lines.push(`${count} file${count === 1 ? '' : 's'} conflict`);
  entries.forEach((entry, index) => {
    lines.push(`  ${index + 1}. ${entry.targetRel}`);
  });
  lines.push('');
  lines.push('pick local / cloud / merge per file (interactive), or run:');
  lines.push('  atris sync --review --take local');
  lines.push('  atris sync --review --take cloud');
  lines.push('merge writes standard conflict markers into the file (no .remote dump).');
  return `${lines.join('\n')}\n`;
}

function applyReviewChoice(cwd, entry, choice) {
  const strategy = String(choice || '').trim().toLowerCase();
  if (!['local', 'cloud', 'merge'].includes(strategy)) {
    throw new Error(`unknown choice "${choice}". use local, cloud, or merge.`);
  }

  const targetPath = assertWorkspaceTarget(cwd, entry.targetRel);
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });

  if (strategy === 'merge') {
    const localContent = readTextIfExists(entry.localPath);
    const remoteContent = readTextIfExists(entry.remotePath);
    fs.writeFileSync(targetPath, buildConflictMarkers(localContent, remoteContent), 'utf8');
  } else {
    const sourcePath = strategy === 'local' ? entry.localPath : entry.remotePath;
    if (!fs.existsSync(sourcePath)) {
      throw new Error(`missing ${strategy} artifact for ${entry.targetRel}`);
    }
    fs.copyFileSync(sourcePath, targetPath);
  }

  // Review path never leaves sibling .remote dumps next to workspace files.
  cleanupResolvedConflictSidecars(cwd, entry.targetRel, { keepCloud: false });
  cleanupConflictPacketArtifacts(entry);
  return { path: entry.targetRel, choice: strategy };
}

async function promptReviewChoice(entry, ask) {
  const answer = await ask(`${entry.targetRel}: local / cloud / merge? `);
  const choice = String(answer || '').trim().toLowerCase();
  if (!['local', 'cloud', 'merge'].includes(choice)) {
    throw new Error(`invalid choice "${answer}". use local, cloud, or merge.`);
  }
  return choice;
}

/**
 * S2 conflict handler for `atris sync --review`.
 * Lists each conflicting file, then resolves via interactive prompt or `--take local|cloud`.
 * Merge writes standard conflict markers into the target file (no workspace .remote dump).
 */
async function runSyncReview(cwd = process.cwd(), options = {}) {
  const take = options.take ? String(options.take).trim().toLowerCase() : null;
  if (take && !['local', 'cloud'].includes(take)) {
    return {
      resolved: [],
      choices: [],
      message: 'use --take local or --take cloud (merge is interactive only).\n',
      exitCode: 1,
    };
  }

  const wantedTarget = normalizeResolvePath(options.path || options.resolvePath || null);
  const entries = collectConflictResolutionEntries(cwd)
    .filter((entry) => !wantedTarget || normalizeResolvePath(entry.targetRel) === wantedTarget);

  if (entries.length === 0) {
    // Fall back to packet summary when no resolvable .local artifacts exist.
    return {
      resolved: [],
      choices: [],
      message: renderLatestConflictReview(cwd),
      exitCode: 0,
    };
  }

  const lines = [];
  lines.push(`${entries.length} file${entries.length === 1 ? '' : 's'} conflict`);
  entries.forEach((entry, index) => {
    lines.push(`  ${index + 1}. ${entry.targetRel}`);
  });

  const interactive = typeof options.ask === 'function';
  if (!take && !interactive) {
    lines.push('');
    lines.push('pick local / cloud / merge per file (interactive), or run:');
    lines.push('  atris sync --review --take local');
    lines.push('  atris sync --review --take cloud');
    lines.push('merge writes standard conflict markers into the file (no .remote dump).');
    lines.push('');
    lines.push(renderLatestConflictReview(cwd).trimEnd());
    lines.push('');
    return { resolved: [], choices: [], message: `${lines.join('\n')}\n`, exitCode: 0 };
  }

  const choices = [];
  const resolved = [];
  for (const entry of entries) {
    const choice = take || await promptReviewChoice(entry, options.ask);
    const result = applyReviewChoice(cwd, entry, choice);
    choices.push(result);
    resolved.push(result.path);
    lines.push(`  -> ${result.path}: ${result.choice}`);
  }

  const finalizedManifests = cleanupEmptyConflictPackets(cwd, entries);
  lines.push('');
  lines.push(`resolved ${resolved.length} conflict${resolved.length === 1 ? '' : 's'}.`);
  if (finalizedManifests.length) {
    lines.push(`updated sync manifest for ${finalizedManifests.join(', ')}.`);
  }
  lines.push('next: run `atris sync --dry-run` before publishing.');
  lines.push('');
  return { resolved, choices, message: `${lines.join('\n')}\n`, exitCode: 0 };
}

function renderLatestConflictReview(cwd = process.cwd()) {
  const summaries = listConflictSummaries(cwd);
  if (summaries.length === 0) {
    return 'No sync conflicts need review.\n';
  }

  const latest = summaries[summaries.length - 1];
  const fullPath = path.join(cwd, latest);
  const content = fs.readFileSync(fullPath, 'utf8');
  return [
    `Latest sync conflict review: ${latest}`,
    '',
    content.trimEnd(),
    '',
    'Resolve the local file, then run `atris sync --dry-run` before publishing.',
    '',
  ].join('\n');
}

function latestConflictDir(cwd = process.cwd()) {
  const summaries = listConflictSummaries(cwd);
  if (summaries.length === 0) return null;
  return path.dirname(path.join(cwd, summaries[summaries.length - 1]));
}

function collectConflictResolutionEntries(cwd = process.cwd()) {
  const dir = latestConflictDir(cwd);
  if (!dir) return [];
  const entries = [];

  function walk(current) {
    let items;
    try {
      items = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const item of items) {
      const full = path.join(current, item.name);
      if (item.isDirectory()) {
        walk(full);
      } else if (item.isFile() && item.name.endsWith('.local')) {
        const localPath = full;
        const remotePath = full.replace(/\.local$/, '.remote');
        const targetRel = path.relative(dir, full).replace(/\\/g, '/').replace(/\.local$/, '');
        entries.push({
          targetRel,
          packetDir: dir,
          basePath: full.replace(/\.local$/, '.base'),
          localPath,
          remotePath,
        });
      }
    }
  }

  walk(dir);
  return entries.sort((a, b) => a.targetRel.localeCompare(b.targetRel));
}

function assertWorkspaceTarget(cwd, targetRel) {
  const targetPath = path.resolve(cwd, targetRel);
  const root = path.resolve(cwd);
  if (!targetPath.startsWith(`${root}${path.sep}`)) {
    throw new Error(`Refusing to resolve outside workspace: ${targetRel}`);
  }
  return targetPath;
}

function cleanupResolvedConflictSidecars(cwd, targetRel, { keepCloud = false } = {}) {
  const suffixes = ['.base', '.local', '.remote', ...(keepCloud ? [] : ['.cloud'])];
  for (const suffix of suffixes) {
    fs.rmSync(assertWorkspaceTarget(cwd, `${targetRel}${suffix}`), { force: true });
  }
}

function cleanupConflictPacketArtifacts(entry) {
  for (const artifactPath of [entry.basePath, entry.localPath, entry.remotePath]) {
    fs.rmSync(artifactPath, { force: true });
  }
}

function conflictPacketHasEntries(packetDir) {
  let hasEntries = false;

  function walk(current) {
    if (hasEntries) return;
    let items;
    try {
      items = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const item of items) {
      const full = path.join(current, item.name);
      if (item.isDirectory()) walk(full);
      else if (item.isFile() && item.name.endsWith('.local')) {
        hasEntries = true;
        return;
      }
      if (hasEntries) return;
    }
  }

  walk(packetDir);
  return hasEntries;
}

function finalizeResolvedConflictPacket(cwd, packetDir) {
  const pendingPath = path.join(packetDir, 'manifest.json');
  const pending = readJsonFile(pendingPath);
  if (!pending || !pending.manifest || !pending.manifest.files) return null;

  const slug = pending.slug || readBusinessSlug(cwd);
  if (!slug) return null;

  const manifest = {
    ...pending.manifest,
    workspace_root: pending.manifest.workspace_root || cwd,
  };
  saveManifest(slug, manifest);
  if (pending.baseContents && typeof pending.baseContents === 'object') {
    writeBaseContents(cwd, pending.baseContents);
  }
  if (Array.isArray(pending.deletedRemote)) {
    removeBaseContents(cwd, pending.deletedRemote);
  }
  return slug;
}

function cleanupEmptyConflictPackets(cwd, entries) {
  const finalized = [];
  const packetDirs = Array.from(new Set(entries.map((entry) => entry.packetDir).filter(Boolean)));
  for (const packetDir of packetDirs) {
    if (!conflictPacketHasEntries(packetDir)) {
      const slug = finalizeResolvedConflictPacket(cwd, packetDir);
      if (slug) finalized.push(slug);
      fs.rmSync(packetDir, { recursive: true, force: true });
    }
  }
  return finalized;
}

function changedRange(baseLines, changedLines) {
  let start = 0;
  while (start < baseLines.length && start < changedLines.length && baseLines[start] === changedLines[start]) {
    start += 1;
  }

  let baseEnd = baseLines.length;
  let changedEnd = changedLines.length;
  while (
    baseEnd > start
    && changedEnd > start
    && baseLines[baseEnd - 1] === changedLines[changedEnd - 1]
  ) {
    baseEnd -= 1;
    changedEnd -= 1;
  }

  return {
    start,
    end: baseEnd,
    replacement: changedLines.slice(start, changedEnd),
  };
}

function safeLineMerge(baseContent, localContent, remoteContent) {
  if (localContent === remoteContent) return { ok: true, content: localContent };
  if (localContent === baseContent) return { ok: true, content: remoteContent };
  if (remoteContent === baseContent) return { ok: true, content: localContent };

  const baseLines = baseContent.split('\n');
  const localRange = changedRange(baseLines, localContent.split('\n'));
  const remoteRange = changedRange(baseLines, remoteContent.split('\n'));
  const sameRange = localRange.start === remoteRange.start && localRange.end === remoteRange.end;
  const sameReplacement = localRange.replacement.join('\n') === remoteRange.replacement.join('\n');
  if (sameRange && sameReplacement) return { ok: true, content: localContent };

  const overlaps = localRange.start < remoteRange.end && remoteRange.start < localRange.end;
  const sameInsertionPoint = localRange.start === localRange.end
    && remoteRange.start === remoteRange.end
    && localRange.start === remoteRange.start;
  if (overlaps || sameInsertionPoint) {
    return { ok: false, reason: 'local and cloud edits overlap' };
  }

  const merged = baseLines.slice();
  for (const range of [localRange, remoteRange].sort((a, b) => b.start - a.start)) {
    merged.splice(range.start, range.end - range.start, ...range.replacement);
  }
  return { ok: true, content: merged.join('\n') };
}

function markdownSectionRanges(content) {
  const lines = content.split('\n');
  const ranges = [];
  const headingPattern = /^(#{1,6})\s+(.+?)\s*$/;
  for (let i = 0; i < lines.length; i += 1) {
    const match = lines[i].match(headingPattern);
    if (!match) continue;
    const level = match[1].length;
    let end = lines.length;
    for (let j = i + 1; j < lines.length; j += 1) {
      const next = lines[j].match(headingPattern);
      if (next && next[1].length <= level) {
        end = j;
        break;
      }
    }
    ranges.push({
      key: lines[i].trim().toLowerCase(),
      level,
      start: i,
      end,
    });
  }
  return ranges;
}

function changedMarkdownSections(baseContent, changedContent) {
  const baseLines = baseContent.split('\n');
  const changedLines = changedContent.split('\n');
  const range = changedRange(baseLines, changedLines);
  if (range.start === range.end && range.replacement.length === 0) return new Set();
  const touchedStart = range.start;
  const touchedEnd = Math.max(range.end, range.start + 1);
  const touched = markdownSectionRanges(baseContent)
    .filter((section) => section.start < touchedEnd && touchedStart < section.end);
  const deepestLevel = touched.reduce((max, section) => Math.max(max, section.level), 0);
  const sections = touched
    .filter((section) => section.level === deepestLevel)
    .map((section) => section.key);
  return new Set(sections.length ? sections : ['__preamble__']);
}

function replaceMarkdownSection(content, sectionKey, replacementContent) {
  const lines = content.split('\n');
  const ranges = markdownSectionRanges(content);
  const range = ranges.find((section) => section.key === sectionKey);
  if (!range) return null;
  const replacementRange = markdownSectionRanges(replacementContent)
    .find((section) => section.key === sectionKey);
  if (!replacementRange) return null;
  const replacementLines = replacementContent.split('\n').slice(replacementRange.start, replacementRange.end);
  const merged = lines.slice();
  merged.splice(range.start, range.end - range.start, ...replacementLines);
  return merged.join('\n');
}

function safeMarkdownMerge(baseContent, localContent, remoteContent) {
  const lineMerge = safeLineMerge(baseContent, localContent, remoteContent);
  if (lineMerge.ok) return { ...lineMerge, mode: 'line' };

  const localSections = changedMarkdownSections(baseContent, localContent);
  const remoteSections = changedMarkdownSections(baseContent, remoteContent);
  if (localSections.has('__preamble__') || remoteSections.has('__preamble__')) {
    return { ok: false, reason: 'local and cloud edits overlap outside markdown sections' };
  }
  for (const section of localSections) {
    if (remoteSections.has(section)) {
      return { ok: false, reason: `local and cloud both edited ${section}` };
    }
  }

  let merged = baseContent;
  for (const section of localSections) {
    const next = replaceMarkdownSection(merged, section, localContent);
    if (next === null) return { ok: false, reason: `could not apply local section ${section}` };
    merged = next;
  }
  for (const section of remoteSections) {
    const next = replaceMarkdownSection(merged, section, remoteContent);
    if (next === null) return { ok: false, reason: `could not apply cloud section ${section}` };
    merged = next;
  }
  return { ok: true, content: merged, mode: 'markdown' };
}

function normalizeResolvePath(value) {
  return String(value || '').replace(/\\/g, '/').replace(/^\.\//, '').replace(/^\/+/, '');
}

function resolveLatestConflict(cwd = process.cwd(), strategy = 'local', target = null) {
  if (!['local', 'cloud', 'both', 'merge'].includes(strategy)) {
    throw new Error('Use `atris sync --resolve local`, `atris sync --resolve cloud`, `atris sync --resolve both`, or `atris sync --resolve merge`.');
  }

  const wantedTarget = normalizeResolvePath(target);
  const entries = collectConflictResolutionEntries(cwd)
    .filter((entry) => !wantedTarget || normalizeResolvePath(entry.targetRel) === wantedTarget);
  if (entries.length === 0) {
    return {
      resolved: [],
      message: wantedTarget
        ? `No sync conflicts need resolution for ${wantedTarget}.\n`
        : 'No sync conflicts need resolution.\n',
    };
  }

  const resolved = [];
  const unresolved = [];
  for (const entry of entries) {
    const targetPath = assertWorkspaceTarget(cwd, entry.targetRel);
    if (strategy === 'both') {
      if (fs.existsSync(entry.localPath)) {
        fs.mkdirSync(path.dirname(targetPath), { recursive: true });
        fs.copyFileSync(entry.localPath, targetPath);
      }
      if (fs.existsSync(entry.remotePath)) {
        const remoteCopyRel = `${entry.targetRel}.cloud`;
        const remoteCopyPath = assertWorkspaceTarget(cwd, remoteCopyRel);
        fs.mkdirSync(path.dirname(remoteCopyPath), { recursive: true });
        fs.copyFileSync(entry.remotePath, remoteCopyPath);
      }
      cleanupResolvedConflictSidecars(cwd, entry.targetRel, { keepCloud: true });
      cleanupConflictPacketArtifacts(entry);
      resolved.push(entry.targetRel);
      continue;
    }

    if (strategy === 'merge') {
      if (!fs.existsSync(entry.basePath) || !fs.existsSync(entry.localPath) || !fs.existsSync(entry.remotePath)) {
        unresolved.push(`${entry.targetRel} (missing base/local/cloud artifact)`);
        continue;
      }
      const merged = safeMarkdownMerge(
        fs.readFileSync(entry.basePath, 'utf8'),
        fs.readFileSync(entry.localPath, 'utf8'),
        fs.readFileSync(entry.remotePath, 'utf8')
      );
      if (!merged.ok) {
        unresolved.push(`${entry.targetRel} (${merged.reason})`);
        continue;
      }
      fs.mkdirSync(path.dirname(targetPath), { recursive: true });
      fs.writeFileSync(targetPath, merged.content, 'utf8');
      cleanupResolvedConflictSidecars(cwd, entry.targetRel);
      cleanupConflictPacketArtifacts(entry);
      resolved.push(entry.targetRel);
      continue;
    }

    const sourcePath = strategy === 'local' ? entry.localPath : entry.remotePath;
    if (!fs.existsSync(sourcePath)) continue;
    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
    fs.copyFileSync(sourcePath, targetPath);
    cleanupResolvedConflictSidecars(cwd, entry.targetRel);
    cleanupConflictPacketArtifacts(entry);
    resolved.push(entry.targetRel);
  }

  const finalizedManifests = cleanupEmptyConflictPackets(cwd, entries);

  return {
    resolved,
    unresolved,
    message: [
      `Resolved ${resolved.length} conflict${resolved.length === 1 ? '' : 's'} using ${strategy === 'both' ? 'both versions' : `${strategy === 'merge' ? 'safe merge' : `${strategy === 'local' ? 'local' : 'cloud'} version`}`}.`,
      ...resolved.map((rel) => `  - ${rel}`),
      ...(finalizedManifests.length ? ['', `Updated sync manifest for ${finalizedManifests.join(', ')}.`] : []),
      ...(unresolved.length ? ['', 'Still needs review:', ...unresolved.map((rel) => `  - ${rel}`)] : []),
      '',
      'Next: run `atris sync --dry-run` before publishing.',
      '',
    ].join('\n'),
  };
}

function describeWatchFailure(err) {
  const isConflict = err && err.status === 2;
  return {
    state: isConflict ? 'conflict' : 'retrying',
    headline: `Sync ${isConflict ? 'paused for review' : 'will retry'}: ${err && err.message ? err.message : err}`,
    detail: isConflict
      ? 'Resolve the review packet, then the watcher will pick up the next clean cycle.'
      : 'The watcher is still running and will check again.',
  };
}

function runCli(args, cwd = process.cwd()) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(__dirname, '..', 'bin', 'atris.js'), ...args], {
      cwd,
      stdio: 'inherit',
      env: { ...process.env, ATRIS_SKIP_UPDATE_CHECK: '1' },
    });
    child.on('error', reject);
    child.on('exit', (status) => {
      if (status === 0) resolve({ status });
      else {
        const err = new Error(`${commandLine(args)} exited ${status}`);
        err.status = status;
        err.args = args;
        reject(err);
      }
    });
  });
}

async function runSyncCycle(plan, cwd, options = {}) {
  await runCli(plan.pullArgs, cwd);
  if (options.dryRun) {
    if (!canPreviewPush(cwd, options.slug)) {
      console.log('');
      console.log('Publish preview skipped until the pull preview is applied.');
      console.log('  This folder is not the source of the current sync manifest yet.');
      return;
    }
    try {
      await runCli(plan.pushArgs, cwd);
    } catch (err) {
      console.log('');
      console.log('Publish preview skipped until the pull preview is applied.');
      console.log(`  ${err.message || err}`);
    }
    return;
  }
  await runCli(plan.pushArgs, cwd);
  if (options.writeStatus) {
    writeSyncStatus(cwd, {
      slug: options.slug,
      state: 'current',
      mode: options.watch ? 'watch' : 'sync',
      last_error: null,
    });
  }
}

async function businessSync(args = process.argv.slice(3), cwd = process.cwd(), deps = {}) {
  const options = resolveBusinessSyncOptions(args, cwd);

  if (options.help) {
    process.stdout.write(renderBusinessSyncHelp());
    return;
  }

  if (options.status) {
    const status = collectLocalSyncStatus(cwd, options);
    if (options.showOrphans) {
      try {
        const { orphanPaths } = await collectCloudOrphans(cwd, options.slug, deps);
        status.orphanPaths = orphanPaths;
      } catch (err) {
        status.orphanError = err.message || String(err);
      }
    }
    process.stdout.write(renderLocalSyncStatus(status));
    return;
  }

  if (options.review) {
    let ask = null;
    if (!options.take && process.stdin.isTTY) {
      const { promptUser } = require('../utils/auth');
      ask = (question) => promptUser(question);
    }
    const result = await runSyncReview(cwd, {
      take: options.take,
      path: options.resolvePath,
      ask,
    });
    process.stdout.write(result.message);
    if (result.exitCode && result.exitCode !== 0) process.exit(result.exitCode);
    return;
  }

  if (options.resolve) {
    process.stdout.write(resolveLatestConflict(cwd, options.resolve, options.resolvePath).message);
    return;
  }

  const plan = buildBusinessSyncPlan(options);

  if (!plan) {
    console.error(renderBusinessSyncHelp().trimEnd());
    console.error('Run inside a business workspace or pass a business slug.');
    process.exit(1);
  }

  console.log('');
  console.log(`Syncing ${options.slug} business workspace...`);
  console.log('  scope: full workspace');
  console.log('  loop: Pull -> Review -> Publish');
  console.log('  quest gate: exact files beat broad pushes');
  if (options.watch) {
    console.log(`  watch: on (${options.intervalSec}s interval, ${options.debounceSec}s debounce)`);
  }
  console.log('');

  await runSyncCycle(plan, cwd, {
    dryRun: options.dryRun,
    slug: options.slug,
    writeStatus: !options.dryRun,
    watch: options.watch,
  });
  if (!options.watch) return;

  let lastSnapshot = collectWorkspaceSnapshot(cwd);
  let running = false;
  let quietTicks = 0;
  let pendingLocal = false;

  console.log('');
  console.log('Business workspace sync is watching this folder. Press Ctrl+C to stop.');

  const tickMs = 1000;
  setInterval(async () => {
    if (running) return;
    const current = collectWorkspaceSnapshot(cwd);
    if (snapshotsDiffer(lastSnapshot, current)) {
      pendingLocal = true;
      quietTicks = 0;
      lastSnapshot = current;
      return;
    }

    if (pendingLocal) {
      quietTicks += 1;
      if (quietTicks < options.debounceSec) return;
    }

    const shouldPeriodicSync = !pendingLocal && quietTicks >= options.intervalSec;
    const shouldLocalSync = pendingLocal && quietTicks >= options.debounceSec;
    quietTicks += 1;
    if (!shouldLocalSync && !shouldPeriodicSync) return;

    running = true;
    try {
      console.log('');
      console.log(shouldLocalSync ? 'Local workspace changed. Syncing...' : 'Checking cloud workspace...');
      await runSyncCycle(plan, cwd, {
        dryRun: options.dryRun,
        slug: options.slug,
        writeStatus: !options.dryRun,
        watch: true,
      });
      lastSnapshot = collectWorkspaceSnapshot(cwd);
      pendingLocal = false;
      quietTicks = 0;
    } catch (err) {
      const failure = describeWatchFailure(err);
      console.error(`\n${failure.headline}`);
      console.error(failure.detail);
      if (!options.dryRun) {
        writeSyncStatus(cwd, {
          slug: options.slug,
          state: failure.state,
          mode: 'watch',
          last_error: err.message || String(err),
        });
      }
      pendingLocal = false;
      quietTicks = 0;
    } finally {
      running = false;
    }
  }, tickMs);
}

module.exports = {
  applyReviewChoice,
  businessSync,
  buildBusinessSyncPlan,
  buildConflictMarkers,
  canPreviewPush,
  collectBrainSnapshot,
  collectWorkspaceWarnings,
  collectLocalSyncStatus,
  collectConflictResolutionEntries,
  describeWatchFailure,
  listConflictFiles,
  parseBusinessSyncArgs,
  readBusinessSlug,
  renderLatestConflictReview,
  renderLocalSyncStatus,
  renderBusinessSyncHelp,
  resolveLatestConflict,
  resolveBusinessSyncOptions,
  runSyncReview,
  safeLineMerge,
  safeMarkdownMerge,
  shouldIgnoreWatchPath,
  snapshotsDiffer,
  writeSyncStatus,
};
