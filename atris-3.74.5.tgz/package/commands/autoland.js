'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');

const autoland = require('../lib/autoland');
const { gateForHuman, plainLandingReason } = require('../lib/voice-gate');
const { evaluateAutoAccept } = require('../lib/auto-accept-certified');
const { sweepEngineAskReceipts } = require('../lib/engine-receipt-sweep');
const { readSshAgents, findLeakedSshAgents, findAgentStartLines, agentStartLineText, stopLeakedSshAgents, closeLostRuns, readResourceHistory, errorReason, leakGrowthNote } = require('../lib/engine-resource');
const { validateRecentAskReceipts } = require('../lib/engine-validate');
const { operatorReady, hasAgentJargon, explainResult } = autoland;
const MISSION_AUTO_VERIFY_STATUSES = new Set(['planning', 'paused', 'ready']);
const CLOSED_TASK_STATUSES = new Set(['done', 'archived']);
const MAX_MISSION_AUTO_VERIFY_PER_TICK = 3;

function repoRoot(cwd = process.cwd()) {
  const result = spawnSync('git', ['rev-parse', '--show-toplevel'], { cwd, encoding: 'utf8' });
  if (result.status !== 0) return cwd;
  return result.stdout.trim() || cwd;
}

function projectName(root) {
  return path.basename(root);
}

function missionReasonBreakdown(rows, fallback = 'stale') {
  const tally = {};
  for (const row of rows || []) {
    const reason = String(row?.reason || row?.pause_reason || fallback).trim() || fallback;
    tally[reason] = (tally[reason] || 0) + 1;
  }
  return tally;
}

function mergeReasonBreakdown(left = {}, right = {}) {
  const merged = { ...(left && typeof left === 'object' ? left : {}) };
  for (const [reason, count] of Object.entries(right || {})) {
    merged[reason] = (Number(merged[reason]) || 0) + (Number(count) || 0);
  }
  return merged;
}

function mergeHeldMissions(left = {}, held = []) {
  const merged = { ...(left && typeof left === 'object' ? left : {}) };
  for (const row of held || []) {
    if (!row || !row.id) continue;
    merged[row.id] = {
      id: row.id,
      owner: row.owner || null,
      objective: row.objective || '',
      reason: row.reason || 'operator-required',
      resume_command: row.resume_command || `atris mission run ${row.id}`,
    };
  }
  return merged;
}

function recordJanitorState(state, { stopped = [], held = [], worktrees = 0 } = {}) {
  const stoppedCount = Array.isArray(stopped) ? stopped.length : Number(stopped) || 0;
  const heldRows = Array.isArray(held) ? held : [];
  const worktreeCount = Number(worktrees) || 0;
  if (!stoppedCount && !heldRows.length && !worktreeCount) return;
  const prior = state.janitor && typeof state.janitor === 'object' ? state.janitor : {};
  const missionHolds = mergeHeldMissions(prior.mission_holds, heldRows);
  const missionStopReasons = mergeReasonBreakdown(prior.mission_stop_reasons, missionReasonBreakdown(stopped, 'stale'));
  state.janitor = {
    ...prior,
    missions_stopped: (Number(prior.missions_stopped) || 0) + stoppedCount,
    worktrees_reaped: (Number(prior.worktrees_reaped) || 0) + worktreeCount,
    ...(Object.keys(missionStopReasons).length ? { mission_stop_reasons: missionStopReasons } : {}),
    ...(Object.keys(missionHolds).length ? { mission_holds: missionHolds, missions_held: Object.keys(missionHolds).length } : {}),
  };
}

// The digest's "next, if you agree" section: top candidate moves from Atris
// state, each with the member best suited to own it. Moves that can't explain
// themselves are counted, not shown. Never blocks the digest.
function missionHasBudgetRemaining(mission, nowMs = Date.now()) {
  if (mission?.budget_contract?.policy !== 'spend_full_budget') return false;
  const seconds = Number(mission?.budget_contract?.requested_seconds || mission?.max_wall_seconds || 0);
  const startedMs = Date.parse(mission?.started_at || mission?.created_at || mission?.updated_at || '');
  return Number.isFinite(seconds) && seconds > 0
    && Number.isFinite(startedMs) && startedMs + seconds * 1000 > nowMs;
}

function normalizedMissionObjective(mission) {
  return String(mission?.objective || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function digestNextMoves(root) {
  try {
    const { nextMoves } = require('../lib/next-moves');
    const { resolveFunctionalOwner } = require('../lib/functional-owner');
    const { listMissions } = require('./mission');
    const missionRows = listMissions(root) || [];
    const missions = new Map(missionRows.map((mission) => [mission.id, mission]));
    const activeBudgetObjectives = new Set(missionRows
      .filter((mission) => missionHasBudgetRemaining(mission))
      .map(normalizedMissionObjective)
      .filter(Boolean));
    const all = (nextMoves(root, 5) || [])
      .filter((move) => move && move.title)
      .filter((move) => {
        if (move.kind !== 'mission_ready') return true;
        const mission = missions.get(move.ref);
        return !missionHasBudgetRemaining(mission)
          && !activeBudgetObjectives.has(normalizedMissionObjective(mission));
      });
    const explainable = all.filter((move) => move.kind === 'mission_ready' || operatorReady(move.title));
    const ready = explainable.slice(0, 3).map((move) => {
      let owner = null;
      const mission = move.kind === 'mission_ready' ? missions.get(move.ref) : null;
      if (mission?.owner) owner = mission.owner;
      else {
        try { owner = resolveFunctionalOwner({ title: move.title, root })?.owner || null; } catch {}
      }
      return { title: move.title, owner, kind: move.kind || null, label: move.label || null };
    });
    return { moves: ready, unexplained: all.length - explainable.length };
  } catch {
    return { moves: [], unexplained: 0 };
  }
}

function flag(args, name, fallback = '') {
  const idx = args.indexOf(name);
  if (idx === -1) return fallback;
  return args[idx + 1] || fallback;
}

function runOwnCli(root, cliArgs, timeoutMs = 300000) {
  // Always spawn the bin this module shipped with. Resolving through the
  // target root or a global `atris` breaks whenever the tick runs a project
  // that isn't the CLI repo on a machine without a global install (CI, cron).
  const bin = path.resolve(__dirname, '..', 'bin', 'atris.js');
  return spawnCapture([bin, ...cliArgs], { cwd: root, timeoutMs });
}

// spawnSync keeps 1 MB of stdout by default and kills the child past it
// (ENOBUFS). A certify-and-land sweep over 150+ review rows prints more than
// that, so the accept step read as unreadable on most ticks. Allow 64 MB.
const OWN_CLI_MAX_BUFFER = 64 * 1024 * 1024;

function spawnCapture(nodeArgs, { cwd, timeoutMs = 300000 } = {}) {
  const result = spawnSync(process.execPath, nodeArgs, { cwd, encoding: 'utf8', timeout: timeoutMs, maxBuffer: OWN_CLI_MAX_BUFFER });
  return {
    status: result.status,
    stdout: String(result.stdout || ''),
    stderr: String(result.stderr || ''),
    error_code: result.error && result.error.code ? result.error.code : null,
    signal: result.signal || null,
    timeout_ms: timeoutMs,
  };
}

// The accept sweep walks every pending-review row under --all, so a fixed
// 300s child timeout kills a real backlog mid-accept. Size the window from
// the queue: roughly 8s a row on top of a 60s floor, never under the old
// 300s default, capped at 25min.
function acceptSweepTimeoutMs(pendingRows) {
  return Math.min(1500000, Math.max(300000, 60000 + pendingRows * 8000));
}

// A killed child truncates stdout and often leaves stderr empty, so the
// spawn failure itself is the first thing to name. Without this a timed-out
// sweep reports "output unreadable" forever.
function describeAcceptKillCause(accept) {
  if (accept.error_code === 'ETIMEDOUT') return `auto-accept timed out at ${accept.timeout_ms}ms`;
  if (accept.error_code) return `auto-accept spawn failed: ${accept.error_code}`;
  if (accept.signal) return `auto-accept killed by ${accept.signal}`;
  return null;
}

function readProjection(root) {
  try {
    const raw = fs.readFileSync(path.join(root, '.atris', 'state', 'tasks.projection.json'), 'utf8');
    const projection = JSON.parse(raw);
    return Array.isArray(projection.tasks) ? projection.tasks : [];
  } catch (err) {
    return [];
  }
}

function readAcceptedTaskHistory(root, fallbackTasks = [], dbPath = undefined) {
  try {
    const taskDb = require('../lib/task-db');
    const db = taskDb.open(dbPath);
    const rows = taskDb.listTasks(db, { workspaceRoot: root });
    return taskDb.withTaskDisplayRefs(rows);
  } catch {
    return fallbackTasks;
  }
}

function digestStoryRows(accepted, acceptedTasks) {
  const byRef = new Map((acceptedTasks || []).map((task) => [task.display_id || task.legacy_ref || task.id, task]));
  return (accepted?.auto || []).map((item) => {
    const summary = autoland.digestLine(item);
    if (!summary || !operatorReady(summary)) return null;
    const task = byRef.get(item.ref);
    const candidates = [
      task?.review?.landing?.happened || task?.metadata?.landing_happened || '',
      item.result,
      item.happened,
      autoland.clarify(item.title, 160),
      summary,
    ].map((candidate) => autoland.historicalLandingText(candidate, 160));
    return { item, story: candidates.find((candidate) => operatorReady(candidate)) || summary };
  }).filter(Boolean);
}

function compactId(value) {
  return String(value || '').trim();
}

function taskIdentityRefs(task) {
  return [
    task?.id,
    task?.display_id,
    task?.legacy_ref,
    task?.ref,
    task?.task_id,
    task?.metadata?.task_id,
    task?.metadata?.display_id,
    task?.metadata?.ref,
  ].map(compactId).filter(Boolean);
}

function taskGoalRefs(task) {
  return [
    task?.goal_id,
    task?.goalId,
    task?.mission_id,
    task?.missionId,
    task?.metadata?.goal_id,
    task?.metadata?.goalId,
    task?.metadata?.mission_id,
    task?.metadata?.missionId,
    task?.metadata?.goal?.id,
  ].map(compactId).filter(Boolean);
}

function missionTaskRefs(mission) {
  return [
    ...(Array.isArray(mission?.task_ids) ? mission.task_ids : []),
    mission?.task_id,
    mission?.current_task_id,
    mission?.task_ref,
    mission?.xp_task?.task_id,
    mission?.xp_task?.ref,
  ].map(compactId).filter(Boolean);
}

function attachedTasksForMission(mission, tasks) {
  const missionId = compactId(mission?.id);
  const taskRefs = new Set(missionTaskRefs(mission));
  return (tasks || []).filter((task) => {
    if (missionId && taskGoalRefs(task).includes(missionId)) return true;
    if (taskRefs.size === 0) return false;
    return taskIdentityRefs(task).some((ref) => taskRefs.has(ref));
  });
}

function taskIsClosed(task) {
  return CLOSED_TASK_STATUSES.has(String(task?.status || '').trim().toLowerCase());
}

function missionHasVerifier(mission) {
  return Boolean(String(mission?.verifier || mission?.effective_verifier || '').trim());
}

function missionReadyForClosedTaskVerify(mission, tasks) {
  const status = String(mission?.status || '').trim().toLowerCase();
  if (!MISSION_AUTO_VERIFY_STATUSES.has(status)) return false;
  if (!missionHasVerifier(mission)) return false;
  if (mission?.verifier_result?.passed === true) return false;
  const attached = attachedTasksForMission(mission, tasks);
  return attached.length > 0 && attached.every(taskIsClosed);
}

function parseMissionVerifyResult(id, result) {
  let payload = null;
  try {
    payload = JSON.parse(result.stdout || '{}');
  } catch {}
  const verifier = payload?.verifier_result || null;
  const passed = verifier ? verifier.passed === true : null;
  return {
    id,
    result: passed === true ? 'passed' : passed === false ? 'failed' : (payload?.action || (result.status === 0 ? 'tick_recorded' : 'tick_failed')),
    status: payload?.mission?.status || null,
    receipt_path: payload?.receipt_path || null,
    exit_status: result.status,
  };
}

function verifyClosedTaskMissions(root, tasks, { limit = MAX_MISSION_AUTO_VERIFY_PER_TICK } = {}) {
  const verified = [];
  const errors = [];
  let candidates = [];
  try {
    const { listMissions } = require('./mission');
    candidates = listMissions(root).filter((mission) => missionReadyForClosedTaskVerify(mission, tasks)).slice(0, limit);
  } catch (err) {
    return {
      verified,
      errors: [{ error: String((err && err.message) || err).slice(0, 200) }],
    };
  }

  for (const mission of candidates) {
    const result = runOwnCli(root, [
      'mission',
      'tick',
      mission.id,
      '--verify',
      '--yes',
      '--full',
      '--summary',
      'The linked repair tasks are closed, so the mission check ran again.',
      '--json',
    ]);
    const outcome = parseMissionVerifyResult(mission.id, result);
    verified.push(outcome);
    if (result.status !== 0 || outcome.result === 'failed' || outcome.result === 'tick_failed') {
      errors.push({
        id: mission.id,
        result: outcome.result,
        status: result.status,
        stderr: String(result.stderr || '').slice(0, 200),
        stdout: String(result.stdout || '').slice(-500),
      });
    }
  }
  return { verified, errors };
}

function landSummarySafe(root) {
  try {
    return require('./land').landSummary(root);
  } catch (err) {
    return null;
  }
}

function refreshLandingRefs(root) {
  const remotes = spawnSync('git', ['remote'], { cwd: root, encoding: 'utf8', timeout: 10000 });
  if (remotes.status !== 0 || !remotes.stdout.split(/\r?\n/).includes('origin')) return;
  // One round-trip for both; a missing branch doesn't fail the other with a
  // multi-ref fetch on any git that supports it, and fetch errors are ignored
  // here anyway.
  const both = spawnSync('git', ['fetch', 'origin', 'master', 'main'], { cwd: root, encoding: 'utf8', timeout: 30000 });
  if (both.status === 0) return;
  for (const branch of ['master', 'main']) {
    spawnSync('git', ['fetch', 'origin', branch], { cwd: root, encoding: 'utf8', timeout: 30000 });
  }
}

function sweepLanding(root, { ttlDays, staleHours, now = Date.now(), refresh = true } = {}) {
  if (refresh) refreshLandingRefs(root);
  const { collectBoard, reap } = require('./land');
  // light: this board only feeds .branches staleness + .summary; reap builds
  // its own full board for dirty-count salvage decisions.
  const beforeBoard = collectBoard(root, { ttlDays, staleHours, now, light: true });
  const stale = beforeBoard.branches
    .filter((b) => b.state === 'active' && b.stale)
    .sort((a, b) => b.activityHours - a.activityHours)
    .map((b) => ({
      name: b.name,
      ahead: b.ahead,
      ageHours: b.ageHours,
      activityHours: b.activityHours,
    }));
  const reaped = reap(root, {
    ttlDays,
    staleHours,
    remote: false,
    includeDetached: false,
    now,
    by: 'atris autoland',
  });
  const afterBoard = collectBoard(root, { ttlDays, staleHours, now, light: true });
  const human = [];
  for (const kept of reaped.keptWorktrees || []) {
    if (String(kept).includes('(fresh_worktree_grace)')) continue;
    if (String(kept).includes('(current_checkout)')) continue;
    human.push(String(kept));
  }
  for (const moved of reaped.keptMovedBranches || []) human.push(`${moved} moved during cleanup`);
  if (reaped.bundleError) human.push(`backup failed: ${reaped.bundleError}`);
  return {
    at: new Date(now).toISOString(),
    before: beforeBoard.summary,
    after: afterBoard.summary,
    stale,
    human,
    reaped: {
      branches: reaped.deletedBranches.length,
      worktrees: reaped.removedWorktrees.length,
      bundle: reaped.bundle,
      patches: reaped.patches.length,
      untracked: (reaped.untracked || []).length,
      bundleError: reaped.bundleError || null,
      keptWorktrees: reaped.keptWorktrees || [],
      keptMovedBranches: reaped.keptMovedBranches || [],
    },
  };
}

function recordLandingSweepState(state, sweep, { error = null } = {}) {
  const at = sweep?.at || new Date().toISOString();
  const today = at.slice(0, 10);
  state.last_reap_date = today;
  state.last_reap_at = at;
  if (error) {
    state.last_reap_error = { date: today, error };
    delete state.landing_sweep;
    return;
  }
  delete state.last_reap_error;
  state.landing_sweep = {
    at,
    before: sweep.before,
    after: sweep.after,
    reaped: sweep.reaped,
    stale_count: sweep.stale.length,
    stale: sweep.stale.slice(0, 10),
    human_count: sweep.human.length,
    human: sweep.human.slice(0, 10),
  };
}

function wishSweepSummaryLine(summary, error = null) {
  if (error) return `wishes: sweep failed (${error})`;
  const dispatched = Number(summary?.dispatched) || 0;
  const fulfilled = Number(summary?.fulfilled) || 0;
  const waiting = Number(summary?.waiting_on_operator) || 0;
  const noExecutor = Number(summary?.skipped_no_executor) || 0;
  const capped = Number(summary?.capped) || 0;
  let line = `wishes: ${dispatched} dispatched, ${waiting} waiting on operator, ${fulfilled} fulfilled`;
  const notes = [];
  if (noExecutor > 0) notes.push(`${noExecutor} need a working builder`);
  if (capped > 0) notes.push(`${capped} held for the next tick`);
  if (notes.length) line += ` (${notes.join(', ')})`;
  return line;
}

function evaluateQueue(root, { strictVerify, acceptAll }) {
  return readProjection(root)
    .filter((task) => task && task.status === 'review')
    .filter((task) => String(task.review?.approval_status || task.metadata?.approval_status || 'pending') === 'pending')
    .sort((a, b) => Number(b.updated_at || 0) - Number(a.updated_at || 0))
    .slice(0, 50)
    .map((task) => {
      const evaluation = evaluateAutoAccept(
        { ...task, workspace_root: root },
        { strictVerify, acceptAll, executeVerify: false },
      );
      return {
        ...evaluation,
        action: evaluation.eligible ? 'would_accept' : 'skipped',
      };
    });
}

function protectedReviewWaiting(root, policy = {}, waiting = []) {
  const alreadyWaiting = new Set((waiting || []).map((row) => row.ref));
  return evaluateQueue(root, {
    strictVerify: policy.strict_verify !== false,
    acceptAll: Boolean(policy.accept_all),
  })
    .filter((row) => /^denied_tag_/.test(String(row.reason || '')))
    .filter((row) => !alreadyWaiting.has(row.ref));
}

// One reason table for every human-facing landing refusal lives in
// lib/voice-gate.js (plainLandingReason); this alias keeps call sites short.
const plainReason = plainLandingReason;

function showStatus(root, args, deps = {}) {
  const json = args.includes('--json');
  const policy = autoland.readPolicy(root);
  const enabled = Boolean(policy && policy.enabled);
  const strictVerify = policy ? policy.strict_verify !== false : true;
  const acceptAll = Boolean(policy && policy.accept_all);
  const results = evaluateQueue(root, { strictVerify, acceptAll })
    .filter((r) => r.reason !== 'not_in_review');
  const readyForRecheck = results.filter((r) => r.action === 'would_accept');
  const wouldLand = readyForRecheck.filter((r) => r.verification_pending !== true);
  const blocked = results.filter((r) => r.action !== 'would_accept');
  const tasks = readProjection(root);
  const waiting = autoland.waitingOnHuman(tasks);
  // Ask the crontab, not the policy file. The cached flag is written once at
  // `autoland on` time, so it reports "unknown" for a cron that has been
  // running hourly for weeks, and would keep reporting "running" for one
  // someone deleted. A loop that cannot confirm its own liveness from
  // evidence cannot be trusted to say it is healthy.
  const heartbeatInstalled = autoland.heartbeatLiveness(root, policy);
  const heartbeatLive = autoland.heartbeatIsLive(root);

  if (json) {
    console.log(JSON.stringify({
      enabled,
      policy,
      heartbeat_installed: heartbeatInstalled,
      would_land: wouldLand,
      ready_for_recheck: readyForRecheck,
      blocked,
      waiting_on_human: waiting,
    }, null, 2));
    return 0;
  }

  console.log('');
  console.log(`autoland: ${autoland.certifiedWorkLandsPhrase(root)}; you keep the irreversible calls`);
  console.log('');
  const policyOwner = String(policy?.enabled_by || 'unknown').trim() || 'unknown';
  const policyText = enabled
    ? (policy.default
      ? `on by default for this workspace (no policy set; would accept as ${policyOwner}). set it: atris autoland on`
      : `on (flipped by ${policyOwner}${policy.enabled_at ? ` on ${String(policy.enabled_at).slice(0, 10)}` : ''})`)
    : 'off - everything waits for you';
  console.log(`  policy: ${policyText}`);
  if (enabled && acceptAll) console.log('  bar: everything lands except the protected lanes (money, deploys, security, customer, outward)');
  console.log(`  heartbeat: ${autoland.heartbeatStatusText(root, policy)}`);
  if (policy && policy.imessage_to) console.log(`  daily message: ${policy.imessage_to} at ${policy.digest_hour ?? autoland.DEFAULT_DIGEST_HOUR}:00`);
  const reapTrouble = autoland.readState(root).last_reap_error;
  if (reapTrouble) console.log(`  cleanup trouble: landing sweep failed on ${reapTrouble.date} (${reapTrouble.error}) - run: atris land --reap`);
  const lost = readResourceHistory(root);
  if (lost.read_error) console.log(`  engine run log: could not read it (${lost.read_error}), so lost, killed, and failed runs in the last day are unknown`);
  if (lost.lost_closed_day) {
    const newest = lost.last_lost_closed;
    const when = `${String(newest.at || '').slice(0, 16).replace('T', ' ')} UTC`;
    console.log(`  engine runs closed after their parent died in the last day: ${lost.lost_closed_day}, newest ${newest.engine || 'unknown engine'} on ${newest.task || 'no task'} at ${when}`);
  }
  if (lost.kills_day) {
    // Timeouts are counted apart, and the newest kill named is the newest one
    // that was not a timeout, so a night of timeouts cannot hide a crash.
    const timeLimit = lost.time_limit_kills_day;
    const counts = timeLimit === lost.kills_day
      ? 'all at their time limit'
      : `${timeLimit ? `${timeLimit} at their time limit, ` : ''}${lost.low_memory_kills_day} with machine memory low`;
    const kill = lost.last_day_other_kill || lost.last_kill;
    const label = timeLimit && lost.last_day_other_kill ? 'newest not at a time limit:' : 'newest';
    const when = `${String(kill.at || '').slice(0, 16).replace('T', ' ')} UTC`;
    const free = Number.isFinite(kill.free_pct) ? `, ${kill.free_pct}% memory free` : '';
    console.log(`  engine runs force-killed in the last day: ${lost.kills_day}, ${counts}; ${label} ${kill.engine || 'unknown engine'} on ${kill.task || 'no task'} at ${when}, ${kill.cause || 'cause unknown'}${free}`);
  }
  if (lost.errors_day) {
    // Runs that failed with a message and were not killed, such as an engine
    // that could not start; kills are counted on the line above.
    const failed = lost.last_day_error;
    const when = `${String(failed.at || '').slice(0, 16).replace('T', ' ')} UTC`;
    console.log(`  engine runs that ended in an error in the last day: ${lost.errors_day}, newest ${failed.engine || 'unknown engine'} on ${failed.task || 'no task'} at ${when}: ${errorReason(failed)}`);
  }
  const { leaked: leakedAgents, unread: unreadAgents } = countLeakedSshAgents(deps);
  const unchecked = unreadAgents.length ? `could not read the ${unreadAgents.join(' or the ')}, so some ssh-agents went unchecked` : '';
  if (leakedAgents) {
    const stop = heartbeatLive ? 'the next hourly pass stops them' : 'stop them now: atris engine sweep --apply';
    console.log(`  leaked ssh-agents on this machine: ${unchecked ? 'at least ' : ''}${leakedAgents}${leakGrowthNote(lost.first_day_leak_reading, leakedAgents)}; ${stop}${unchecked ? `; ${unchecked}` : ''}`);
    // A test run reads only the home it was handed, never the real one.
    if (deps.home || !process.env.NODE_TEST_CONTEXT) {
      for (const found of findAgentStartLines(deps.home ? { home: deps.home } : {})) console.log(`    ${agentStartLineText(found)}`);
    }
  } else if (unchecked) {
    console.log(`  leaked ssh-agents on this machine: unknown, ${unchecked}`);
  }
  console.log('');
  const humanOnly = blocked.filter((r) => String(r.reason || '').startsWith('denied_tag_'));
  const needsWork = blocked.filter((r) => !String(r.reason || '').startsWith('denied_tag_'));
  if (humanOnly.length > 0) {
    console.log(`  yours to decide first: ${humanOnly.length} protected ${humanOnly.length === 1 ? 'review' : 'reviews'}.`);
    for (const r of humanOnly.slice(0, 10)) console.log(`    ${r.ref} waits for you; ${plainReason(r.reason)}.`);
  }
  if (readyForRecheck.length > 0) {
    if (heartbeatLive) {
      console.log(`  landing on their own after the hourly recheck: ${readyForRecheck.length}.`);
      for (const r of readyForRecheck.slice(0, 10)) console.log(`    ${r.ref} passes the recheck, then lands itself.`);
    } else {
      console.log(`  ready to land ${autoland.STALE_HEARTBEAT_LANDING}: ${readyForRecheck.length}.`);
      for (const r of readyForRecheck.slice(0, 10)) {
        console.log(`    ${r.ref} passes the recheck, then lands ${autoland.STALE_HEARTBEAT_LANDING}.`);
      }
    }
  } else {
    console.log('  nothing is ready to land on its own right now.');
  }
  if (needsWork.length > 0) {
    console.log(`  still needs work before it can land: ${needsWork.length}.`);
    for (const r of needsWork.slice(0, 10)) console.log(`    ${r.ref} stays put; ${plainReason(String(r.reason || ''))}.`);
  }
  if (waiting.length > 0) {
    console.log('');
    console.log(`  waiting on a human right now: ${waiting.length}, oldest ${waiting[0].hours}h`);
  }
  // What the next tick's idle sweep will do, read-only (no check runs here).
  if (enabled && policy.janitor !== false && policy.idle_sweep !== false) {
    try {
      const idle = require('../lib/idle-review-sweep').sweepIdleReviews(root, { tasks, policy, dryRun: true });
      const days = Number(policy.idle_close_days) > 0 ? Number(policy.idle_close_days) : 7;
      if (idle.closed.length) {
        console.log(`  closing on the next tick: ${idle.closed.length} idle over ${days} days that can never land on their own, each with a plain reason.`);
      }
      if (idle.human_waiting.length) {
        console.log(`  staying with you: ${idle.human_waiting.length} in money, deploys, security, or customer work; idle time never closes these.`);
      }
    } catch {
      // Preview only.
    }
  }
  console.log('');
  if (!enabled) console.log("  flip it on: atris autoland on   (one decision; everything after is receipts)");
  console.log('');
  return 0;
}

function turnOn(root, args) {
  const owner = flag(args, '--as', os.userInfo().username);
  const to = flag(args, '--to', '');
  const digestHour = Number(flag(args, '--digest-hour', autoland.DEFAULT_DIGEST_HOUR));
  const alarmHours = Number(flag(args, '--alarm-hours', autoland.DEFAULT_ALARM_HOURS));
  const acceptAll = args.includes('--all');
  const previous = autoland.readPolicy(root);
  const policy = autoland.writePolicy(root, {
    enabled: true,
    enabled_by: owner,
    enabled_at: new Date().toISOString(),
    imessage_to: to || null,
    digest_hour: Number.isFinite(digestHour) ? digestHour : autoland.DEFAULT_DIGEST_HOUR,
    alarm_hours: Number.isFinite(alarmHours) && alarmHours > 0 ? alarmHours : autoland.DEFAULT_ALARM_HOURS,
    strict_verify: !args.includes('--no-strict-verify'),
    accept_all: acceptAll,
    daily_experiment: previous.daily_experiment !== false,
  });
  const cronOk = autoland.installCron(root);
  autoland.writePolicy(root, {
    ...policy,
    heartbeat_installed: cronOk,
    heartbeat_checked_at: new Date().toISOString(),
  });
  console.log('');
  console.log('autoland is on.');
  if (acceptAll) console.log(`  everything in review now lands itself, accepted as ${owner}; only the protected lanes wait.`);
  else console.log(`  certified, verified, reversible work now lands itself, accepted as ${owner}.`);
  console.log('  protected lanes (money, deploys, security, customer, outward) still wait for you.');
  console.log(`  heartbeat: ${cronOk ? 'installed, runs hourly' : 'could not install cron; run atris autoland tick yourself'}`);
  if (policy.imessage_to) {
    console.log(`  daily message to ${policy.imessage_to} at ${policy.digest_hour}:00; anything waiting on you past ${policy.alarm_hours}h pings you.`);
  } else {
    console.log('  no phone number set; digest goes to the log only. add one: atris autoland on --to <your number>');
  }
  console.log('  turn it off any time: atris autoland off');
  console.log('');
  return 0;
}

function turnOff(root) {
  const policy = autoland.readPolicy(root) || {};
  const disabledPolicy = autoland.writePolicy(root, {
    ...policy,
    enabled: false,
    disabled_at: new Date().toISOString(),
  });
  const cronOk = autoland.uninstallCron(root);
  autoland.writePolicy(root, {
    ...disabledPolicy,
    heartbeat_installed: cronOk ? false : null,
    heartbeat_checked_at: new Date().toISOString(),
  });
  console.log('');
  console.log('autoland is off. everything waits for your accept again.');
  console.log(`  heartbeat ${cronOk ? 'removed' : 'removal failed; check crontab -l'}.`);
  console.log('');
  return 0;
}

function runDigest(root, args, { forceSend = false } = {}) {
  const policy = autoland.readPolicy(root) || {};
  const tasks = readProjection(root);
  const acceptedTasks = readAcceptedTaskHistory(root, tasks);
  const accepted = autoland.acceptedInLastDay(acceptedTasks);
  const state = autoland.readState(root);
  let waitingWishes = [];
  try {
    waitingWishes = require('./wish').waitingOperatorWishes(root);
  } catch {}
  const waiting = autoland.waitingOnHuman(tasks);
  const text = autoland.composeDigest({
    accepted,
    waiting,
    protectedWaiting: protectedReviewWaiting(root, policy, waiting),
    waitingWishes,
    landed: landSummarySafe(root),
    project: projectName(root),
    nextMoves: digestNextMoves(root),
    acceptAll: Boolean(policy.accept_all),
    reapError: state.last_reap_error?.error || null,
    landingSweep: state.landing_sweep || null,
    fullStory: true,
    root,
  });
  console.log(text);
  // the full story: what each piece actually was, in its own words
  const storied = digestStoryRows(accepted, acceptedTasks).slice(3);
  if (storied.length > 0) {
    let printedStoryHeader = false;
    for (const { item, story } of storied) {
      if (!printedStoryHeader) {
        console.log('');
        printedStoryHeader = true;
      }
      console.log(`  - ${story}`);
    }
  }
  const shouldSend = (forceSend || args.includes('--send')) && policy.imessage_to;
  if (shouldSend) {
    const sent = autoland.sendImessage(root, policy.imessage_to, text);
    console.log(sent.ok ? `(sent to ${policy.imessage_to})` : `(send failed: ${sent.output})`);
    return sent.ok ? 0 : 1;
  }
  return 0;
}

function pidAlive(pid) {
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch {
    return false;
  }
}

async function runTick(root, args) {
  const json = args.includes('--json');
  const policy = autoland.readPolicy(root);
  const receipt = { at: new Date().toISOString(), landed: [], alarms: 0, digest_due: false, digest_sent: false, enabled: Boolean(policy && policy.enabled) };
  if (!policy || policy.enabled !== true) {
    if (json) console.log(JSON.stringify(receipt));
    else console.log('autoland is off; tick did nothing.');
    return 0;
  }
  if (args.includes('--dry-run')) return runTickPreview(root, { json, receipt });

  // One live tick at a time: verify re-runs can take minutes each, and a
  // second hourly cron firing into the same snapshot double-accepts,
  // double-alarms, and double-digests. A stale lock (dead pid or >55min)
  // never wedges the loop.
  const lockPath = path.join(root, '.atris', 'state', 'autoland.tick.lock');
  try {
    const prev = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
    const fresh = Date.now() - Number(prev.at || 0) < 55 * 60 * 1000;
    if (fresh && pidAlive(prev.pid)) {
      receipt.skipped_reason = 'tick_already_running';
      if (json) console.log(JSON.stringify(receipt));
      else console.log('autoland tick: another tick is still running; skipped.');
      return 0;
    }
  } catch {}
  try {
    fs.mkdirSync(path.dirname(lockPath), { recursive: true });
    fs.writeFileSync(lockPath, JSON.stringify({ pid: process.pid, at: Date.now() }));
  } catch {}
  try {
    return await runTickBody(root, { json, policy, receipt });
  } finally {
    try { fs.unlinkSync(lockPath); } catch {}
  }
}

// `atris autoland tick --dry-run`: what the hourly pass would close, send
// back, and check, read only. No lock, no receipt, no GitHub writes, no job
// changes, no fetch.
function runTickPreview(root, { json, receipt }) {
  receipt.dry_run = true;
  runMergedWorkClose(root, receipt, { dryRun: true });
  // The second check's next turn, in the order it would take the jobs.
  try {
    const taskDb = require('../lib/task-db');
    const workspaceRoot = taskDb.workspaceRoot(mainCheckoutRoot(root) || root);
    const certify = require('./task').cmdCertifyVerified([], { preview: true, silent: true, workspaceRoot });
    receipt.second_check = {
      would_check: certify.results.filter((r) => r.action === 'would_certify').map((r) => ({ ref: r.ref, verify: r.verify })),
      skipped: certify.results.filter((r) => r.action === 'skipped').map((r) => ({ ref: r.ref, reason: r.reason })),
    };
  } catch (err) {
    receipt.second_check_error = String((err && err.message) || err).slice(0, 200);
  }
  if (json) {
    console.log(JSON.stringify(receipt));
    return 0;
  }
  const close = receipt.merged_close || {};
  console.log(`autoland tick (dry run): would close ${(close.would_close || []).length} merged job${(close.would_close || []).length === 1 ? '' : 's'}, would send ${(close.would_send_back || []).length} clashing job${(close.would_send_back || []).length === 1 ? '' : 's'} back`);
  const prLine = (row) => (row.action === 'merged_earlier'
    ? `merged earlier, closed without counting it as a new landing: its own pull request #${row.number} merged over a day ago`
    : `its own pull request #${row.number} merged`);
  for (const row of close.would_close || []) console.log(`  close ${row.ref || row.id}: ${row.proof || prLine(row)}`);
  for (const row of close.would_send_back || []) console.log(`  send back ${row.id}: pull request #${row.number} clashes`);
  for (const line of close.merge_line || []) console.log(`  ${line}`);
  if (receipt.merged_close_error) console.log(`  could not check merged work: ${receipt.merged_close_error}`);
  const check = receipt.second_check || { would_check: [], skipped: [] };
  console.log(`second check: would check ${check.would_check.length} job${check.would_check.length === 1 ? '' : 's'} next, ${check.skipped.length} skipped`);
  for (const row of check.would_check) console.log(`  check ${row.ref}: ${row.verify}`);
  if (receipt.second_check_error) console.log(`  could not preview the second check: ${receipt.second_check_error}`);
  return 0;
}

function persistTickReceipt(root, receipt) {
  const runsDir = path.join(root, 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const safeTime = String(receipt.at || new Date().toISOString()).replace(/[:.]/g, '-');
  const receiptPath = path.join(runsDir, `autoland-tick-${safeTime}.json`);
  receipt.receipt_path = path.relative(root, receiptPath);
  fs.writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`, 'utf8');
  return receipt.receipt_path;
}

// A tick that scans a backlog, lands none of it, and prints only zeros is
// indistinguishable from a tick with no work. Say the standing numbers out
// loud, and call out the two states that mean the loop is wedged rather than
// idle: work blocked behind a check the harness could not execute, and work
// that passed every gate and still did not land.
// Heartbeat liveness helpers live in lib/autoland.js so task ready copy and
// status share one gate (recent tick receipt within two hours).

function acceptedNotLandedNote(receipt) {
  const rows = Array.isArray(receipt.accepted_not_landed) ? receipt.accepted_not_landed : [];
  if (!rows.length) return '';
  return `, ${rows.length} accepted but not proven landed (${rows.map((r) => `${r.ref} ${r.status}`).join(', ')})`;
}

function stuckBacklogNote(receipt) {
  const parts = [];
  const scanned = Number(receipt.scanned || 0);
  const certified = Number(receipt.certified || 0);
  // Stuck means nothing cleared review. Accepted-but-unproven work is named
  // separately (accepted_not_landed), not misread as a wedged queue.
  const accepted = Array.isArray(receipt.accepted) ? receipt.accepted.length : receipt.landed.length;
  if (scanned > 0 && accepted === 0) {
    parts.push(`${certified}/${scanned} certified in review, none landed`);
  }
  const unrunnable = Array.isArray(receipt.unrunnable_verifiers) ? receipt.unrunnable_verifiers.length : 0;
  if (unrunnable > 0) {
    parts.push(`${unrunnable} blocked by a check this machine could not run`);
  }
  return parts.length ? `, ${parts.join(', ')}` : '';
}

function digestTickStatus(receipt) {
  if (receipt.digest_sent) return 'sent';
  if (receipt.digest_due) return 'saved';
  return 'not due';
}

function engineReceiptSweepNote(receipt) {
  const finalized = Number(receipt.engine_receipt_sweep?.finalized) || 0;
  if (!finalized) return '';
  return `, finalized ${finalized} stale engine receipt${finalized === 1 ? '' : 's'} as presumed dead`;
}

// Read only: how many ssh-agents look leaked right now, and which readers
// failed, since then the count is only a floor. A test run never reads the
// real machine, and a thrown read counts as none.
function countLeakedSshAgents(deps = {}) {
  const none = { leaked: 0, unread: [] };
  try {
    const read = deps.readSshAgents;
    if (!read && process.env.NODE_TEST_CONTEXT) return none;
    const uid = deps.uid !== undefined ? deps.uid : (typeof process.getuid === 'function' ? process.getuid() : null);
    if (uid === null) return none;
    const { agents, referenced, unread = [] } = (read || readSshAgents)();
    return { leaked: findLeakedSshAgents(agents, { referenced, uid }).length, unread };
  } catch {
    return none;
  }
}

// Shell startup files that start an ssh-agent per shell leave one behind
// for every engine shell. Each pass stops the ones a fresh recheck still
// calls leaked, and never lets a failed read break the pass.
function runSshAgentSweep(root, receipt, deps = {}) {
  try {
    const read = deps.read || readSshAgents;
    const uid = deps.uid !== undefined ? deps.uid : (typeof process.getuid === 'function' ? process.getuid() : null);
    const empty = { stopped: [], failed: [], skipped: [] };
    // A test run must never stop real agents on the machine running it.
    if (uid === null || (!deps.read && process.env.NODE_TEST_CONTEXT)) {
      receipt.ssh_agent_sweep = empty;
      return receipt.ssh_agent_sweep;
    }
    const { agents, referenced, unread = [] } = read();
    const leaked = findLeakedSshAgents(agents, { referenced, uid });
    const result = leaked.length
      ? stopLeakedSshAgents(root, leaked, { read, uid, ...(deps.kill ? { kill: deps.kill } : {}) })
      : empty;
    // A reading that failed on either scan is kept, so the summary can say
    // some agents went unchecked instead of reading as a clean machine.
    const missed = [...new Set([...unread, ...(result.unread || [])])];
    receipt.ssh_agent_sweep = missed.length ? { ...result, unread: missed } : result;
  } catch (err) {
    receipt.ssh_agent_sweep_error = String((err && err.message) || err).slice(0, 200);
  }
  return receipt.ssh_agent_sweep || null;
}

function sshAgentSweepNote(receipt) {
  const stopped = (receipt.ssh_agent_sweep?.stopped || []).length;
  const failed = (receipt.ssh_agent_sweep?.failed || []).length;
  const replaced = (receipt.ssh_agent_sweep?.replaced || []).length;
  const unread = receipt.ssh_agent_sweep?.unread || [];
  const stoppedNote = stopped ? `, stopped ${stopped} leaked ssh-agent${stopped === 1 ? '' : 's'}` : '';
  const failedNote = failed ? `, could not stop ${failed} leaked ssh-agent${failed === 1 ? '' : 's'}` : '';
  const replacedNote = replaced ? `, left ${replaced} younger replacement ssh-agent${replaced === 1 ? '' : 's'} alone` : '';
  const unreadNote = unread.length ? `, could not read the ${unread.join(' or the ')}, so some ssh-agents went unchecked` : '';
  const scanErrorNote = receipt.ssh_agent_sweep_error ? ', could not scan ssh-agents, so leaked agents may remain' : '';
  return stoppedNote + failedNote + replacedNote + unreadNote + scanErrorNote;
}

// An engine run whose dispatching process died never writes its own end.
// Each pass writes a "parent gone" end for those, so the log stops carrying
// them as open, and never lets a failed read break the pass.
function runLostRunSweep(root, receipt, deps = {}) {
  try {
    const close = deps.close || closeLostRuns;
    const closed = close(root, deps.now ? { now: deps.now } : {});
    receipt.lost_run_sweep = { closed: closed.map((end) => end.run_id) };
  } catch (err) {
    receipt.lost_run_sweep_error = String((err && err.message) || err).slice(0, 200);
  }
  return receipt.lost_run_sweep || null;
}

function lostRunSweepNote(receipt) {
  const closed = (receipt.lost_run_sweep?.closed || []).length;
  const closedNote = closed ? `, closed ${closed} lost engine run${closed === 1 ? '' : 's'}` : '';
  const errorNote = receipt.lost_run_sweep_error ? ', could not close lost engine runs, so unfinished records may remain' : '';
  return closedNote + errorNote;
}

async function runEngineAnswerValidation(root, receipt, deps = {}) {
  try {
    receipt.engine_answer_validation = await validateRecentAskReceipts(root, deps);
  } catch (err) {
    receipt.engine_answer_validation_error = String((err && err.message) || err).slice(0, 200);
  }
  return receipt.engine_answer_validation || null;
}

function engineAnswerValidationLine(receipt) {
  const graded = Number(receipt.engine_answer_validation?.graded_answers) || 0;
  if (!graded) return '';
  return `graded ${graded} engine answer${graded === 1 ? '' : 's'}, scoreboard updated`;
}

// Merged work closes its jobs; clashing work goes back on the list. Until
// 2026-10-22 this ran only inside the team wake loop, which last swept on
// 2026-10-15, so four merged jobs waited a week. Two sources: the autoland
// list (pull requests GitHub merged at the member's own commit, through the
// team loop's shared five-minute pass) and git itself (lib/merged-review-close.js)
// for jobs that left the list. dryRun reads and reports, and writes nothing.
function runMergedWorkClose(root, receipt, { dryRun = false, now = Date.now() } = {}) {
  const out = dryRun
    ? { would_close: [], would_send_back: [], merge_line: [] }
    : { closed: [], sent_back: [], merge_line: [] };
  const closedList = dryRun ? out.would_close : out.closed;
  const sentList = dryRun ? out.would_send_back : out.sent_back;
  try {
    const memberAutoland = require('../lib/member-autoland');
    const queue = dryRun
      ? memberAutoland.requeueDroppedAutolands({ cwd: root, now, dryRun: true })
      : memberAutoland.sweepAfterMissionRun({ cwd: root, now });
    for (const r of (queue && queue.results) || []) {
      if (r.line) out.merge_line.push(r.line);
      for (const id of r.closed || []) closedList.push({ id, how: 'pull_request', number: r.number, action: r.stale ? 'merged_earlier' : 'merged' });
      for (const id of r.sent_back || []) sentList.push({ id, number: r.number });
    }
    const taskDb = require('../lib/task-db');
    const db = taskDb.open();
    const workspace = taskDb.workspaceRoot(mainCheckoutRoot(root) || root);
    const tasks = taskDb.listTasks(db, { workspaceRoot: workspace, status: 'review' })
      .filter((t) => !closedList.some((c) => c.id === t.id));
    const scan = require('../lib/merged-review-close').closeMergedReviewJobs({ root, tasks, now, dryRun });
    for (const row of dryRun ? scan.matched : scan.closed) closedList.push(row);
    out.checked = scan.checked;
  } catch (err) {
    receipt.merged_close_error = String((err && err.message) || err).slice(0, 200);
  }
  receipt.merged_close = out;
  return out;
}

function mainCheckoutRoot(root) {
  const result = spawnSync('git', ['rev-parse', '--path-format=absolute', '--git-common-dir'], { cwd: root, encoding: 'utf8' });
  if (result.status !== 0 || !result.stdout.trim()) return null;
  return path.dirname(result.stdout.trim());
}

function mergedCloseNote(receipt) {
  const closed = (receipt.merged_close?.closed || []).length;
  const sent = (receipt.merged_close?.sent_back || []).length;
  return (closed ? `, closed ${closed} merged job${closed === 1 ? '' : 's'}` : '')
    + (sent ? `, sent ${sent} clashing job${sent === 1 ? '' : 's'} back on the list` : '')
    + (receipt.merged_close_error ? ', could not check which jobs already merged' : '');
}

async function runTickBody(root, { json, policy, receipt, engineValidationDeps = {} }) {

  try {
    receipt.engine_receipt_sweep = sweepEngineAskReceipts(root);
  } catch (err) {
    receipt.engine_receipt_sweep_error = String((err && err.message) || err).slice(0, 200);
  }

  runSshAgentSweep(root, receipt);
  runLostRunSweep(root, receipt);

  await runEngineAnswerValidation(root, receipt, engineValidationDeps);

  // 1. certify and land in one task process. Keeping both phases together lets
  // the landing gate reuse the live certification verifier result without
  // persisting trust across heartbeats. Denied lanes and check-less proofs wait.
  // No hardcoded --limit here: a fixed low cap (this used to be 12) silently
  // undercounts a real backlog every single tick: 12/hour forever even with
  // 78 certified rows waiting. Let `atris task auto-accept-certified` apply
  // its own default (12 without --all, a high safety cap under --all) so a
  // policy with accept_all:true actually drains the full certified set.
  // Refresh origin once, before anything is accepted: the landing proof reads
  // origin's target, and a stale ref would call landed work unlanded.
  refreshLandingRefs(root);
  const cliArgs =['task', 'auto-accept-certified', '--json', '--certify-first'];
  if (policy.accept_all) cliArgs.push('--all');
  else if (policy.strict_verify === false) cliArgs.push('--no-strict-verify');
  const pendingReviewRows = readProjection(root)
    .filter((task) => task && task.status === 'review')
    .filter((task) => String(task.review?.approval_status || task.metadata?.approval_status || 'pending') === 'pending')
    .length;
  const accept = runOwnCli(root, cliArgs, acceptSweepTimeoutMs(pendingReviewRows));
  let acceptResults = [];
  try {
    const parsed = JSON.parse(accept.stdout);
    const results = Array.isArray(parsed.results) ? parsed.results : [];
    acceptResults = results;
    // A refused sweep (ok:false, a guard tripped, policy race) carries no
    // summary fields. Name the reason instead of leaving nulls that read as
    // "no work": a blind heartbeat must say WHY it is blind.
    if (parsed.ok === false) {
      receipt.accept_error = String(parsed.reason || 'auto-accept refused');
    }
    receipt.reviews_certified = parsed.certification?.certified ?? 0;
    if (parsed.certification && parsed.certification.ok !== true) {
      receipt.certify_error = 'certify-verified failed';
    }
    // Accepted is a review verdict; landed is a git fact. Only work whose
    // landing proof passed (lib/landing-proof.js) may be called landed. The
    // rest is named with the reason, so an accept over an empty or unpushed
    // commit reads as what it is instead of padding the landed count.
    const acceptedRows = results.filter((r) => r.action === 'accepted');
    receipt.accepted = acceptedRows.map((r) => r.ref);
    receipt.landed = acceptedRows.filter((r) => r.landing && r.landing.status === 'landed').map((r) => r.ref);
    const notLanded = acceptedRows
      .filter((r) => !r.landing || r.landing.status !== 'landed')
      .map((r) => ({
        ref: r.ref,
        status: (r.landing && r.landing.status) || 'unverified',
        reason: (r.landing && r.landing.reason) || 'no_landing_proof',
      }));
    if (notLanded.length) receipt.accepted_not_landed = notLanded;
    const citationBlocks = results
      .filter((r) => r.action === 'skipped' && r.proof_state === 'suite_green_citation_required')
      .map((r) => ({ ref: r.ref, reason: r.reason }));
    if (citationBlocks.length) receipt.citation_blocks = citationBlocks;
    // A verifier the machine cannot execute is a broken harness, not a verdict
    // on the diff. It must never sit quietly in the skipped pile: surface it
    // as an alarm so a wedged loop is visible on the first tick, not the 480th.
    // Not filtered by action: an unrunnable check surfaces as `skipped` from
    // the eligibility gate and as `revised`/`revise_failed` from the landing
    // gate. The reason is the signal, not the lane it came through.
    const unrunnable = results
      .filter((r) => r && r.action !== 'accepted' && r.reason === 'verify_unrunnable')
      .map((r) => ({
        ref: r.ref,
        cause: r.unrunnable_cause || 'unknown',
        command: r.command || r.verify || null,
      }));
    if (unrunnable.length) {
      receipt.unrunnable_verifiers = unrunnable;
      receipt.alarms = Number(receipt.alarms || 0) + unrunnable.length;
    }
    receipt.certified = parsed.certified ?? null;
    receipt.scanned = parsed.scanned ?? null;
    receipt.revised = parsed.revised ?? null;
    receipt.skipped = parsed.skipped ?? null;
    receipt.undercounted = Boolean(parsed.undercounted);
  } catch (err) {
    receipt.accept_error = describeAcceptKillCause(accept) || accept.stderr.slice(0, 200) || 'auto-accept output unreadable';
  }

  // 2a. merged work closes its jobs and clashing work goes back on the list,
  // every hour, whether or not a team loop is running. After the accept step,
  // so work that can be checked and landed the normal way is landed first.
  const mergedClose = runMergedWorkClose(root, receipt);
  if ((mergedClose.closed || []).length + (mergedClose.sent_back || []).length > 0) {
    try { require('./task').refreshKeptTaskList(root); } catch {}
  }

  // 2b. tell the operator the moment something lands: one text, one landing
  // sentence per piece (the day-one PM sentence written at finish time),
  // capped at three with the rest counted. Off with live_updates: false.
  const tasksForLive = readProjection(root);
  if (receipt.landed.length > 0 && policy.imessage_to && policy.live_updates !== false) {
    const text = autoland.composeLiveUpdate({
      landedRefs: receipt.landed,
      tasks: tasksForLive,
      project: projectName(root),
      root,
    });
    if (text) {
      // Keep the exact operator surface beside the delivery result. The next
      // linguist pass must audit what was sent, not reconstruct today's code.
      receipt.live_update_text = text;
      const sent = autoland.sendImessage(root, policy.imessage_to, text);
      receipt.live_update_sent = sent.ok;
    }
  }

  // 3. alarm on anything waiting on a human past the line
  const state = autoland.readState(root);
  const tasks = readProjection(root);
  const waiting = autoland.waitingOnHuman(tasks);
  const protectedWaiting = protectedReviewWaiting(root, policy, waiting);
  const alarmHours = Number(policy.alarm_hours) || autoland.DEFAULT_ALARM_HOURS;
  const due = autoland.dueForAlarm(waiting, state, { alarmHours });
  if (due.length > 0 && policy.imessage_to) {
    const text = autoland.composeAlarm({ waiting: due, project: projectName(root), alarmHours });
    const sent = autoland.sendImessage(root, policy.imessage_to, text);
    if (sent.ok) {
      autoland.markAlerted(state, due);
      receipt.alarms = due.length;
    }
  }

  // 3b. janitor, every tick: a mission left paused past 48h and a worktree
  // already merged into base are the same rot pattern as an unlanded branch,
  // left alone they accumulate until a human runs `mission stop` and
  // `worktree cleanup --apply` by hand, which is exactly the chore autoland
  // exists to remove. Off switch: policy.janitor === false (default on, the
  // same absent-means-on convention as live_updates/strict_verify). Counts
  // accumulate in state so the daily digest reports the day's total, not
  // just the last tick's.
  receipt.missions_stopped = 0;
  receipt.missions_held = 0;
  receipt.worktrees_reaped = 0;
  if (policy.janitor !== false) {
    let stoppedMissions = [];
    let heldMissions = [];
    try {
      const { reapPausedMissions } = require('./mission');
      stoppedMissions = reapPausedMissions(root);
      heldMissions = Array.isArray(stoppedMissions.held) ? stoppedMissions.held : [];
      receipt.missions_stopped = stoppedMissions.length;
      if (stoppedMissions.length > 0) receipt.missions_stopped_refs = stoppedMissions.map((m) => m.id);
      if (stoppedMissions.length > 0) receipt.missions_stopped_reasons = missionReasonBreakdown(stoppedMissions, 'stale');
      receipt.missions_held = heldMissions.length;
      if (heldMissions.length > 0) {
        receipt.missions_held_refs = heldMissions.map((m) => m.id);
        receipt.missions_held_reasons = missionReasonBreakdown(heldMissions, 'operator-required');
      }
    } catch (err) {
      receipt.janitor_mission_error = String((err && err.message) || err).slice(0, 200);
    }
    try {
      const { cleanupWorktrees } = require('./worktree');
      const cleaned = cleanupWorktrees({ root, apply: true, by: 'atris autoland' });
      receipt.worktrees_reaped = cleaned.removed.length;
      if (cleaned.removed.length > 0) receipt.worktrees_reaped_paths = cleaned.removed.map((w) => w.path);
    } catch (err) {
      receipt.janitor_worktree_error = String((err && err.message) || err).slice(0, 200);
    }
    recordJanitorState(state, { stopped: stoppedMissions, held: heldMissions, worktrees: receipt.worktrees_reaped });
  }

  // 3b2. green landing, every tick: one stale branch that merges clean and
  // passes the full verify in a scratch checkout lands on base and is pushed.
  // A red branch opens a close flag the same hour instead of waiting for the
  // TTL reap to salvage it. Off by policy: green_landing:false.
  if (policy.green_landing !== false) {
    try {
      const { landStaleGreenBranches, summaryLine } = require('../lib/land-green');
      const green = landStaleGreenBranches(root, {
        verifyCommand: policy.verify_command || undefined,
        limit: Number(policy.green_landing_limit) > 0 ? Number(policy.green_landing_limit) : 1,
      });
      receipt.green_landing = {
        candidates: green.candidates.length,
        landed: green.landed,
        red: green.red,
        verdicts: green.verdicts.map((v) => ({ branch: v.branch, action: v.action, reason: v.reason || null, detail: v.detail || null, failing: v.verify ? v.verify.failing : undefined })),
        summary: summaryLine(green),
      };
      state.green_landing = { at: green.at, ...receipt.green_landing };
    } catch (err) {
      receipt.green_landing_error = String((err && err.message) || err).slice(0, 200);
    }
  }

  // 3c. landing sweep, every tick: merged branch residue is cleared,
  // TTL-expired work is salvaged before deletion, and 48h-stale active work
  // is carried into the digest instead of silently aging forever.
  try {
    const landingSweep = sweepLanding(root, { refresh: false });
    receipt.reaped = landingSweep.reaped;
    receipt.landing_sweep = {
      before: landingSweep.before,
      after: landingSweep.after,
      stale: landingSweep.stale.length,
      human: landingSweep.human.length,
    };
    if (landingSweep.reaped.bundleError) {
      receipt.reap_error = `backup failed, unlanded work kept in place: ${landingSweep.reaped.bundleError}`;
    }
    recordLandingSweepState(state, landingSweep);
  } catch (err) {
    receipt.reap_error = String((err && err.message) || err).slice(0, 200);
    recordLandingSweepState(state, null, { error: receipt.reap_error });
  }

  // 3c2. idle work resolves itself, every tick. Finished work that sat still
  // past the grace period (policy.idle_close_days, default 7) and can never
  // land on its own is closed with a plain reason; done and long-idle rows
  // leave the list. This used to run only when someone opened a session, so
  // nights and trips piled up work nobody would ever land. Protected lanes
  // (money, deploys, security, customer, outward) are never closed by idle
  // time. Off switch: policy.idle_sweep === false or policy.janitor === false.
  if (policy.janitor !== false && policy.idle_sweep !== false) {
    try {
      const liveReasons = new Map(acceptResults
        .filter((r) => r && r.ref && r.reason && r.action !== 'accepted')
        .map((r) => [r.ref, r.reason]));
      const kept = require('../lib/task-list-keeper').keepWorkspaceTaskList(root, { actor: 'autoland', includeDone: false });
      const idle = require('../lib/idle-review-sweep').sweepIdleReviews(root, {
        tasks: readProjection(root),
        policy,
        liveReasons,
      });
      const putAway = (kept.put_away || []).length + (kept.reaped || []).length;
      if (putAway + idle.closed.length > 0) require('./task').refreshKeptTaskList(root);
      receipt.idle_sweep = {
        closed: idle.closed.map((c) => ({ ref: c.ref, reason: c.reason })),
        put_away: putAway,
        human_waiting: idle.human_waiting.length,
      };
    } catch (err) {
      receipt.idle_sweep_error = String((err && err.message) || err).slice(0, 200);
    }
  }
  try {
    const { appendOvernightNote, tickSummaryLine } = require('../lib/cleanup-summary');
    const line = tickSummaryLine({
      landed: (receipt.landed || []).length,
      closed: receipt.idle_sweep ? receipt.idle_sweep.closed.length : 0,
      putAway: receipt.idle_sweep ? receipt.idle_sweep.put_away : 0,
      needYou: receipt.idle_sweep ? receipt.idle_sweep.human_waiting : protectedWaiting.length,
    });
    if (line) {
      appendOvernightNote(root, line);
      receipt.summary_line = line;
    }
  } catch {
    // The journal line is a courtesy; it never fails the tick.
  }

  // 3d. wish sweep: queued wishes are allowed to wake a mission without a
  // foreground `atris wish` session, but they must never endanger landing.
  try {
    const wishDispatch = require('./wish').sweepWishes(root);
    receipt.wish_dispatch = wishDispatch;
  } catch (err) {
    receipt.wish_dispatch_error = String((err && err.message) || err).slice(0, 200);
  }

  // 3e. map fold, once an hour: map notes member changes saved as their own
  // files under atris/refs/map-notes.d/ are folded into the shared map notes
  // on main and removed, in one pushed commit. Off by policy: map_fold:false.
  if (policy.map_fold !== false) {
    try {
      const { foldDue, foldMapNotesOnMain } = require('../lib/member-map-fold');
      if (foldDue(state.last_map_fold_at)) {
        const fold = foldMapNotesOnMain(root);
        receipt.map_fold = { folded: fold.folded, added: fold.added || 0, reason: fold.reason || null };
        if (fold.reason !== 'main_unreadable') state.last_map_fold_at = new Date().toISOString();
      }
    } catch (err) {
      receipt.map_fold_error = String((err && err.message) || err).slice(0, 200);
    }
  }

  // 4. daily digest at the configured hour
  const today = new Date().toISOString().slice(0, 10);
  const digestHour = Number(policy.digest_hour ?? autoland.DEFAULT_DIGEST_HOUR);
  if (new Date().getHours() === digestHour && state.last_digest_date !== today) {
    receipt.digest_due = true;
    let waitingWishes = [];
    try {
      waitingWishes = require('./wish').waitingOperatorWishes(root);
    } catch {}
    const text = autoland.composeDigest({
      accepted: autoland.acceptedInLastDay(readAcceptedTaskHistory(root, tasks)),
      waiting,
      protectedWaiting,
      waitingWishes,
      landed: landSummarySafe(root),
      project: projectName(root),
      nextMoves: digestNextMoves(root),
      acceptAll: Boolean(policy.accept_all),
      reapError: state.last_reap_error?.error || null,
      janitor: state.janitor || null,
      landingSweep: state.landing_sweep || null,
      root,
    });
    if (policy.imessage_to) {
      const sent = autoland.sendImessage(root, policy.imessage_to, text);
      receipt.digest_sent = sent.ok;
    }
    receipt.digest_text = text;
    state.last_digest_date = today;
    delete state.janitor;

    // 5. once a day, keep the receipt shelf lean: compress old run receipts
    // into the manifest and drop unreferenced clutter, newest 200 kept.
    const prune = runOwnCli(root, ['mission', 'prune-runs', '--apply', '--days', '14', '--keep-newest', '200', '--json']);
    try {
      const pruned = JSON.parse(prune.stdout);
      receipt.receipts_pruned = pruned.pruned_count ?? pruned.pruned ?? pruned.removed ?? 0;
    } catch {
      receipt.receipts_pruned = null;
    }
  }

  // 5b. daily keep/revert experiment, self-gated inside experiments daily;
  // hourly ticks are harmless no-ops after the first run each day.
  if (policy.daily_experiment !== false) {
    const daily = runOwnCli(root, ['experiments', 'daily', '--json']);
    receipt.daily_experiment = {
      status: daily.status,
      stdout: daily.stdout.trim(),
      stderr: daily.stderr.slice(0, 200) || null,
    };
    try {
      receipt.daily_experiment.result = JSON.parse(daily.stdout.trim());
    } catch {
      receipt.daily_experiment.result = null;
    }
  } else {
    receipt.daily_experiment_skipped = true;
  }

  // 6. once a day, do slower mission cleanup. Landing cleanup runs hourly
  // above, outside this date gate, so limbo cannot silently accumulate.
  if (state.last_mission_cleanup_date !== today) {
    // Missions rot the same way branches do: paused/planning/ready and
    // untouched for a week means abandoned. Age them out under the same
    // daily gate so `mission list` shows work, not archaeology.
    try {
      const { expireStaleMissions } = require('./mission');
      const expiredMissions = expireStaleMissions(root);
      const heldMissions = Array.isArray(expiredMissions.held) ? expiredMissions.held : [];
      if (expiredMissions.length > 0) receipt.expired_missions = expiredMissions.length;
      if (expiredMissions.length > 0) receipt.expired_mission_reasons = missionReasonBreakdown(expiredMissions, 'stale');
      if (expiredMissions.length > 0) recordJanitorState(state, { stopped: expiredMissions });
      if (heldMissions.length > 0) {
        receipt.expired_missions_held = heldMissions.length;
        receipt.expired_missions_held_refs = heldMissions.map((m) => m.id);
        receipt.expired_missions_held_reasons = missionReasonBreakdown(heldMissions, 'operator-required');
        recordJanitorState(state, { held: heldMissions });
      }
    } catch (err) {
      receipt.mission_expiry_error = String((err && err.message) || err).slice(0, 200);
    }
    try {
      const missionVerify = verifyClosedTaskMissions(root, readProjection(root));
      if (missionVerify.verified.length > 0) receipt.verified_missions = missionVerify.verified;
      if (missionVerify.errors.length > 0) receipt.mission_verify_errors = missionVerify.errors;
    } catch (err) {
      receipt.mission_verify_errors = [{ error: String((err && err.message) || err).slice(0, 200) }];
    }
    state.last_mission_cleanup_date = today;
  }
  autoland.writeState(root, state);

  try {
    persistTickReceipt(root, receipt);
  } catch (err) {
    receipt.receipt_error = String((err && err.message) || err).slice(0, 200);
  }

  if (json) console.log(JSON.stringify(receipt));
  else {
    const reapedTotal = Number(receipt.reaped?.branches || 0) + Number(receipt.reaped?.worktrees || 0);
    const reapNote = reapedTotal > 0 ? `, reaped ${receipt.reaped.branches} landed/overdue branches` : '';
    const janitorNote = `, janitor stopped ${receipt.missions_stopped} mission${receipt.missions_stopped === 1 ? '' : 's'} + reaped ${receipt.worktrees_reaped} worktree${receipt.worktrees_reaped === 1 ? '' : 's'}`;
    const heldNote = receipt.missions_held ? `, held ${receipt.missions_held} human-blocked mission${receipt.missions_held === 1 ? '' : 's'}` : '';
    const wishNote = `, ${wishSweepSummaryLine(receipt.wish_dispatch, receipt.wish_dispatch_error)}`;
    const engineSweepNote = engineReceiptSweepNote(receipt);
    const receiptNote = receipt.receipt_path ? `, receipt ${receipt.receipt_path}` : '';
    // Deltas alone ("0 certified, 0 landed") are true and useless: they read
    // as "nothing to do" whether the queue is empty or 19-deep and wedged.
    // Always print the standing backlog, and name work that cleared every
    // gate and still did not land. That is the shape of a stuck loop.
    const stuckNote = stuckBacklogNote(receipt);
    const summary = `autoland tick: ${receipt.reviews_certified ?? 0} reviews certified, ${receipt.landed.length} landed${receipt.landed.length ? ` (${receipt.landed.join(', ')})` : ''}${acceptedNotLandedNote(receipt)}${mergedCloseNote(receipt)}, ${receipt.alarms} alarms${stuckNote}, digest ${digestTickStatus(receipt)}${reapNote}${janitorNote}${heldNote}${wishNote}${engineSweepNote}${sshAgentSweepNote(receipt)}${lostRunSweepNote(receipt)}${receiptNote}`;
    const validationLine = engineAnswerValidationLine(receipt);
    if (validationLine) console.log(validationLine);
    console.log(gateForHuman(summary).text);
    for (const fulfilled of receipt.wish_dispatch?.fulfilled_results || []) {
      if (fulfilled.review_ask) console.log(fulfilled.review_ask);
    }
  }
  return 0;
}

function showHelp() {
  console.log('');
  console.log(`atris autoland: you approve the policy once; ${autoland.certifiedWorkLandsPhrase(process.cwd())}`);
  console.log('');
  console.log('finished work that passed its checks and two independent reviews lands');
  console.log('automatically with a receipt. money, deploys, security, customer, and');
  console.log('outward-facing work always waits for you.');
  console.log('');
  console.log('recommended agent flight checks:');
  console.log('  fast suite: npm run test:fast');
  console.log('  focused: node --test <focused files>');
  console.log('record one runnable verifier; autoland reruns the recorded check.');
  console.log('');
  console.log('  atris autoland                     what would land, what waits for you');
  console.log('  atris autoland on [--to <phone>]   flip it on: hourly heartbeat, daily');
  console.log('                                     message, ping when something waits');
  console.log('                                     on you past 24h');
  console.log('  atris autoland on --all            lower the bar: everything lands except');
  console.log('                                     the protected lanes; a failing recorded');
  console.log('                                     check still blocks');
  console.log('  atris autoland off                 back to approving every item');
  console.log('  atris autoland digest [--send]     the daily message, now');
  console.log('  atris autoland tick [--json]       one heartbeat (what the hourly cron runs)');
  console.log('  atris autoland tick --dry-run      what the heartbeat would close, send back,');
  console.log('                                     and check, without changing anything');
  console.log('');
  console.log('help is always read-only: atris autoland tick --help never lands work.');
  console.log('');
  return 0;
}

function wantsHelp(args = []) {
  return args.some((arg) => arg === 'help' || arg === '--help' || arg === '-h');
}

function autolandCommand(args = []) {
  const [sub, ...rest] = args;
  if (wantsHelp(args)) return showHelp();
  if (!sub || sub.startsWith('--')) return showStatus(repoRoot(), args);
  const root = repoRoot();
  if (sub === 'on') return turnOn(root, rest);
  if (sub === 'off') return turnOff(root);
  if (sub === 'tick') return runTick(root, rest);
  if (sub === 'digest') return runDigest(root, rest);
  if (sub === 'status') return showStatus(root, rest);
  console.error(`atris autoland: unknown subcommand '${sub}' (try: atris autoland help)`);
  return 1;
}

module.exports = {
  autolandCommand,
  digestNextMoves,
  acceptSweepTimeoutMs,
  describeAcceptKillCause,
  spawnCapture,
  digestStoryRows,
  digestTickStatus,
  engineAnswerValidationLine,
  explainResult,
  operatorReady,
  readAcceptedTaskHistory,
  hasAgentJargon,
  runEngineAnswerValidation,
  runTickBody,
  runSshAgentSweep,
  sshAgentSweepNote,
  showStatus,
  runLostRunSweep,
  lostRunSweepNote,
  sweepLanding,
  verifyClosedTaskMissions,
};
