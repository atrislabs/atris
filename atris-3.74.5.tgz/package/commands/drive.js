// atris drive: self-driving tick over the mission plane.
// One tick: run mission doctor, auto-execute the fixes it prescribes that are
// safe to run (stale ready receipts -> verify tick), and log everything that
// still needs a human as an explicit disengagement. The metric that matters:
// disengagements per tick, driven to zero.
//
// State: .atris/state/drive.jsonl (one line per tick, append-only).

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const rsi = require('../lib/rsi-record');

const BIN = path.join(__dirname, '..', 'bin', 'atris.js');

function runAtris(args, cwd) {
  const res = spawnSync(process.execPath, [BIN, ...args], {
    cwd,
    encoding: 'utf8',
    timeout: 120000,
    maxBuffer: 16 * 1024 * 1024,
  });
  return { code: res.status, stdout: res.stdout || '', stderr: res.stderr || '' };
}

function parseJsonLoose(text) {
  if (!text) return null;
  const start = text.indexOf('{');
  if (start === -1) return null;
  try { return JSON.parse(text.slice(start)); } catch (err) { return null; }
}

function statePath(cwd) {
  return path.join(cwd, '.atris', 'state', 'drive.jsonl');
}

function loadHistory(cwd, limit = 20) {
  try {
    const lines = fs.readFileSync(statePath(cwd), 'utf8').trim().split('\n');
    return lines.slice(-limit).map((l) => { try { return JSON.parse(l); } catch (e) { return null; } }).filter(Boolean);
  } catch (err) { return []; }
}

function appendState(cwd, record) {
  const file = statePath(cwd);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.appendFileSync(file, JSON.stringify(record) + '\n');
}

async function driveCommand(argv) {
  const cwd = process.cwd();
  const json = argv.includes('--json');
  const dryRun = argv.includes('--dry-run');

  if (argv.includes('--help') || argv.includes('-h')) {
    console.log('atris drive - one self-driving tick over the mission plane');
    console.log('');
    console.log('  atris drive [--dry-run] [--json]   doctor -> auto-fix safe findings -> count disengagements');
    console.log('  atris drive status [--json]        disengagement trend from past ticks');
    console.log('');
    console.log('  Auto-handled: stale_ready_receipt (runs the verify tick, completes on pass).');
    console.log('  Everything else = a disengagement: the system needed a human. Logged, counted, escalated.');
    return 0;
  }

  if (argv[0] === 'status') {
    const history = loadHistory(cwd);
    if (!history.length) { console.log('No drive ticks yet. Run: atris drive'); return 0; }
    if (json) { console.log(JSON.stringify({ ok: true, ticks: history }, null, 2)); return 0; }
    console.log('drive: disengagements per tick (goal: 0)\n');
    for (const t of history) {
      console.log(`  ${t.at}  fixed ${t.fixed}/${t.findings}  disengagements ${t.disengagements}`);
    }
    return 0;
  }

  // Dream-RSI: one drive run is one bounded improvement attempt. Recorded
  // only when the workspace has the recorder; a recording failure never
  // changes the run or its exit code.
  const rsiLog = (m) => process.stderr.write(`rsi: ${m}\n`);
  const rsiAttempt = dryRun ? null : rsi.beginAttempt(cwd, { lane: rsi.IMPROVE_LANE, engine: 'claude', log: rsiLog });
  const rsiBefore = rsiAttempt ? rsi.gitSnapshot(cwd) : null;
  const rsiT0 = Date.now();
  const rsiFinish = (outcome) => {
    if (!rsiAttempt) return;
    const delta = rsi.gitDelta(cwd, rsiBefore);
    rsi.finishAttempt(cwd, rsiAttempt, {
      commits: delta.commits,
      files: delta.files,
      elapsed_s: Math.round((Date.now() - rsiT0) / 100) / 10,
      engine_calls: 1,
      verify: 'skipped',
      ...outcome,
    }, { log: rsiLog });
  };

  try {
  const doctor = runAtris(['mission', 'doctor', '--json'], cwd);
  const report = parseJsonLoose(doctor.stdout);
  if (!report || !Array.isArray(report.findings)) {
    rsiFinish({ status: 'failed', reason: 'mission doctor returned no parseable findings' });
    console.error('drive: mission doctor returned no parseable findings.');
    if (doctor.stderr) console.error(doctor.stderr.slice(0, 500));
    return 1;
  }

  const fixed = [];
  const disengagements = [];

  // Missions the doctor says have no verifier. A verify-tick physically cannot
  // pass without one, so promising to verify-tick such a mission is a phantom
  // fix that never sticks, count it as a wheel-grab instead.
  const noVerifier = new Set(
    report.findings.filter((f) => f.code === 'missing_verifier' && f.mission_id).map((f) => f.mission_id),
  );

  for (const f of report.findings) {
    if (f.code === 'stale_ready_receipt' && f.mission_id && noVerifier.has(f.mission_id)) {
      disengagements.push({ ...pick(f), reason: 'ready_without_verifier' });
      continue;
    }
    if (f.code === 'stale_ready_receipt' && f.mission_id && !dryRun) {
      const tick = runAtris(['mission', 'tick', f.mission_id, '--verify', '--complete-on-pass', '--json'], cwd);
      const result = parseJsonLoose(tick.stdout);
      const passed = tick.code === 0 && result && result.ok !== false;
      if (passed) {
        fixed.push({ mission_id: f.mission_id, action: 'verify_tick', objective: f.objective });
        continue;
      }
      disengagements.push({ ...pick(f), reason: 'verify_tick_failed' });
      continue;
    }
    if (f.code === 'stale_ready_receipt' && dryRun) {
      fixed.push({ mission_id: f.mission_id, action: 'would_verify_tick', objective: f.objective });
      continue;
    }
    // No verifier and stale (planning >24h old, or already paused): park it.
    // A paused mission is reversible; a zombie in planning is a permanent disengagement.
    if (f.code === 'missing_verifier' && f.mission_id && isParkable(f)) {
      if (dryRun) {
        fixed.push({ mission_id: f.mission_id, action: 'would_park', objective: f.objective });
        continue;
      }
      const stop = runAtris(['mission', 'stop', f.mission_id, '--pause', '--reason', 'drive: no verifier + stale, auto-parked (restart with a --verify to resume)'], cwd);
      if (stop.code === 0) {
        fixed.push({ mission_id: f.mission_id, action: 'parked', objective: f.objective });
        continue;
      }
      disengagements.push({ ...pick(f), reason: 'park_failed' });
      continue;
    }
    disengagements.push({ ...pick(f), reason: f.code });
  }

  // One stuck mission is one wheel-grab, even if it trips several findings.
  // Count disengagements per mission so the metric tracks "how many missions
  // still need a human", not "how many symptoms did we print".
  const dedupedDisengagements = [];
  const seenDisengaged = new Set();
  for (const d of disengagements) {
    const key = d.mission_id || `${d.reason}:${d.objective || ''}`;
    if (seenDisengaged.has(key)) continue;
    seenDisengaged.add(key);
    dedupedDisengagements.push(d);
  }
  disengagements.length = 0;
  disengagements.push(...dedupedDisengagements);

  function isParkable(f) {
    if (f.status === 'paused') return true;
    if (f.status !== 'planning') return false;
    const m = /^mission-(\d{4}-\d{2}-\d{2})-/.exec(f.mission_id || '');
    if (!m) return false;
    return (Date.now() - new Date(m[1] + 'T00:00:00Z').getTime()) > 24 * 3600 * 1000;
  }

  function pick(f) {
    return { mission_id: f.mission_id, code: f.code, owner: f.owner, objective: (f.objective || '').slice(0, 120), next: f.next };
  }

  const record = {
    at: new Date().toISOString(),
    findings: report.findings.length,
    checked: report.checked_count,
    fixed: fixed.length,
    disengagements: disengagements.length,
    dry_run: dryRun,
    fixed_detail: fixed,
    disengagement_detail: disengagements,
  };
  if (!dryRun) appendState(cwd, record);

  rsiFinish({
    status: fixed.length ? 'shipped' : 'nothing',
    reason: `${fixed.length} auto-fixed, ${disengagements.length} still need a human`.slice(0, 200),
  });

  if (json) { console.log(JSON.stringify({ ok: true, ...record }, null, 2)); return 0; }

  console.log(`drive tick: ${report.checked_count} missions checked, ${report.findings.length} findings`);
  console.log(`  auto-fixed:      ${fixed.length}`);
  for (const x of fixed) console.log(`    ✓ ${x.action} ${x.mission_id}`);
  console.log(`  disengagements:  ${disengagements.length}  (a human has to grab the wheel)`);
  const byCode = {};
  for (const d of disengagements) byCode[d.reason] = (byCode[d.reason] || 0) + 1;
  for (const [code, n] of Object.entries(byCode)) console.log(`    ✋ ${code} ×${n}`);
  const history = loadHistory(cwd, 5);
  if (history.length > 1) {
    console.log(`  trend: ${history.map((t) => t.disengagements).join(' → ')}`);
  }
  console.log(`  next: atris drive status · fix the ✋ list · re-run atris drive`);
  return disengagements.length > 0 ? 0 : 0;
  } catch (err) {
    rsiFinish({ status: 'failed', reason: String(err && err.message ? err.message : err).slice(0, 200) });
    throw err;
  }
}

module.exports = { driveCommand };
