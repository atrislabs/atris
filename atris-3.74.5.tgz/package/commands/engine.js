'use strict';

// atris engine: bring any intelligence.
// Every installed headless coding CLI is a swappable worker behind one
// contract (bounded prompt in, verified proof out, engines never
// self-certify). This command shows the roster, flips the default, and the
// same names ride --engine on mission run / autopilot / run.
//
//   atris engine            roster + current default
//   atris engine roster     show every job's workers, built-in jobs first
//   atris engine roster confirm  renew every dated worker for 30 days
//   atris engine roster session [clear]  this shell's own changes
//   atris engine roster --available  tools and models on this machine
//   atris engine roster set <job> <tool> <model>  swap a job's lead; the old lead backs it up
//   atris engine roster set --member <name> <tool> <model>  give one member its own model
//   atris engine assign <job> <tool> [--like <kind>] [--model <m>] [--effort <level>] [--max "20 min"] [--prep <job>] [--backup "<tool> [model]"] [--days <n>] [--add] [--session | --everywhere]
//   atris engine assign <job> --promote "<tool> [model]" | --remove <tool> | --clear [--session | --everywhere]
//   jobs are open-ended: search, build, review, or your own ("small build")
//   atris engine cursor     make cursor the default engine here
//   atris engine reset      back to the house default (atris-fast)
//
// The default persists to .atris/engine.json. Per-run flags and
// ATRIS_RUNNER_PROFILE always beat the file.

const fs = require('fs');
const os = require('os');
const path = require('path');
const readline = require('readline');
const { spawnSync } = require('child_process');
const { Writable } = require('stream');
const {
  RUNNER_PROFILE_DEFS,
  RUNNER_PROFILE_NAMES,
  HIDDEN_PROFILE_NAMES,
  buildRunnerCommand,
} = require('../lib/runner-command');
const { parseScopeFlag } = require('../lib/cli-scope');
const { isFreshWorkspace, speakFirstMinute } = require('../lib/first-minute');
const { teamRosterView } = require('../lib/member-engine');
const { engineModelText, engineRunsView, modelLabel } = require('../lib/roster-models');
const { renderTable } = require('../lib/text-table');
const { TEAM_FOOTER } = require('../lib/team-lineup');
const { readRosterRuns, workerRuns, summarizeRuns, recentRuns, renderRunLine, runView, DEFAULT_DAYS: RUN_DAYS } = require('../lib/roster-runs');
const { attachSuggestions } = require('../lib/roster-suggest');
const { swapList, swapJob, swapMember } = require('../lib/roster-swap');
const { PIN_MAX_AGE_DAYS: PIN_STALE_DAYS, attachStaleModels, modelCatalog } = require('../lib/roster-stale');
const {
  ENGINE_ROLES,
  ENGINE_JOBS,
  ROSTER_SOURCES,
  ROSTER_LAYERS,
  rosterDecided,
  rosterWorkerWalk,
  rosterToolName,
  rosterSessionKey,
  clearSessionRoster,
  NO_SESSION_MESSAGE,
  rosterJobKey,
  rosterJobLabel,
  rosterJobNameError,
  rosterJobRole,
  readRosterState,
  retiredModelsNamed,
  RETIRED_CLAUDE_MODELS,
  customRosterJobKeys,
  setRosterPick,
  confirmRoster,
  rosterMaxText,
  rosterPinFor,
  parseRosterUntil,
  ENGINE_DUTIES,
  ENGINE_HEALTH_STATUSES,
  binInstalled,
  canonicalEngineName,
  engineRegistryFile,
  engineRegistryView,
  readEngineRegistry,
  resolveEngineForRole,
  resolveEngineForRoleRanked,
  resolveNotesJob,
  jobTakesAnyEngine,
  requireEngineBin,
  engineDoctorReport,
  engineFailureHealthStatus,
  engineReadyAt,
  coolingView,
  setEngineOverrides,
  setEngineHealth,
} = require('../lib/engine-registry');
const { DISPATCH_CAPABLE, runDispatchFlight } = require('../lib/fleet');
const {
  buildReadOnlyEngineInvocation,
  runEngineAskCommand,
} = require('../lib/engine-ask');
const { runEngineValidateCommand } = require('../lib/engine-validate');
const { runEngineWatchCommand } = require('./engine-watch');
const { ensureValidCredentials } = require('../utils/auth');
const { apiRequestJson } = require('../utils/api');

const HOUSE_ENGINE = 'atris-fast';
const MAX_ENGINE_LOGIN_FILE_BYTES = 64 * 1024;
const ENGINE_DEVICE_LOGIN_POLL_MS = 3000;
const ENGINE_DEVICE_LOGIN_TIMEOUT_MS = 16 * 60 * 1000;
const ENGINE_LOGIN_MANIFESTS = Object.freeze({
  codex: Object.freeze({
    type: 'files',
    files: Object.freeze(['~/.codex/auth.json']),
    missingHint: 'run codex login first',
  }),
  claude: Object.freeze({
    type: 'files',
    files: Object.freeze(['~/.claude/.credentials.json']),
    missingHint: 'run claude login first',
  }),
  cursor: Object.freeze({
    type: 'files',
    files: Object.freeze(['~/.cursor/cli-config.json']),
    missingHint: 'run cursor login first',
  }),
  devin: Object.freeze({
    type: 'api_key',
    missingHint: 'paste a Devin API key',
  }),
  grok: Object.freeze({
    type: 'files',
    files: Object.freeze(['~/.grok/auth.json']),
    missingHint: 'run grok and log in with grok.com',
  }),
});

function knownLoginProviders() {
  return Object.keys(ENGINE_LOGIN_MANIFESTS);
}

function engineFile(root = process.cwd()) {
  return path.join(root, '.atris', 'engine.json');
}

function readSavedEngine(root = process.cwd()) {
  try {
    const saved = JSON.parse(fs.readFileSync(engineFile(root), 'utf8'));
    return canonicalEngineName(saved.default);
  } catch {
    return '';
  }
}

// The default engine for this workspace, in precedence order:
// env (per-run flags land here) -> .atris/engine.json -> house default.
// When nothing is configured the pick comes from the registry's saved health
// (seeded once on first sight, refreshed by `atris engine doctor`), never a
// machine probe: policy over probes. A stale "ready" is the execution stage's
// problem, where requireEngineBin fails in one plain sentence.
function resolveDefaultEngine(root = process.cwd()) {
  const env = canonicalEngineName(process.env.ATRIS_RUNNER_PROFILE);
  if (env) return { name: env, source: 'env' };
  const saved = readSavedEngine(root);
  if (saved) return { name: saved, source: 'saved' };
  const ready = new Set(
    engineRegistryView(root)
      .filter((engine) => engineReadyAt(engine))
      .map((engine) => engine.id)
  );
  if (ready.has(HOUSE_ENGINE)) return { name: HOUSE_ENGINE, source: 'house' };
  const fallback = RUNNER_PROFILE_NAMES.find((name) => ready.has(name));
  return fallback ? { name: fallback, source: 'detected' } : { name: HOUSE_ENGINE, source: 'none' };
}

function roster(root = process.cwd()) {
  const current = resolveDefaultEngine(root);
  return engineRegistryView(root)
    .filter((engine) => !HIDDEN_PROFILE_NAMES.includes(engine.id))
    .map((engine) => ({
      ...engine,
      default: engine.id === current.name,
    }));
}

function setEngine(name, root = process.cwd()) {
  const canonical = canonicalEngineName(name);
  if (!canonical) {
    throw new Error(`Unknown engine "${name}". Known engines: ${RUNNER_PROFILE_NAMES.join(', ')}`);
  }
  const file = engineFile(root);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify({ default: canonical, set_at: new Date().toISOString() }, null, 2)}\n`);
  return canonical;
}

function resetEngine(root = process.cwd()) {
  try { fs.unlinkSync(engineFile(root)); return true; } catch { return false; }
}

function expandHomePath(filePath, homeDir = os.homedir()) {
  const value = String(filePath || '');
  if (value === '~') return homeDir;
  if (value.startsWith('~/')) return path.join(homeDir, value.slice(2));
  return value;
}

function normalizeLoginProvider(name) {
  const raw = String(name || '').trim().toLowerCase();
  if (!raw) return '';
  const canonical = canonicalEngineName(raw) || raw;
  return ENGINE_LOGIN_MANIFESTS[canonical] ? canonical : '';
}

function normalizeEngineLoginSeat(name) {
  return String(name || '')
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, '_');
}

function validEngineLoginSeat(name) {
  return /^[A-Z0-9][A-Z0-9_]{0,47}$/.test(String(name || ''));
}

function engineLoginSeatError() {
  return 'seat names are letters, numbers, underscores - like personal or work';
}

function byteLength(value) {
  return Buffer.byteLength(String(value || ''), 'utf8');
}

function detectedEmailFromJsonValue(value, depth = 0) {
  if (depth > 6 || value == null) return '';
  if (typeof value === 'string') {
    const match = value.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
    return match ? match[0] : '';
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = detectedEmailFromJsonValue(item, depth + 1);
      if (found) return found;
    }
    return '';
  }
  if (typeof value === 'object') {
    const preferred = ['email', 'account_email', 'user_email'];
    for (const key of preferred) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        const found = detectedEmailFromJsonValue(value[key], depth + 1);
        if (found) return found;
      }
    }
    for (const item of Object.values(value)) {
      const found = detectedEmailFromJsonValue(item, depth + 1);
      if (found) return found;
    }
  }
  return '';
}

function detectedEmailFromContent(content) {
  try {
    return detectedEmailFromJsonValue(JSON.parse(content));
  } catch {
    return '';
  }
}

function readEngineLoginFiles(provider, { homeDir = os.homedir(), fsModule = fs } = {}) {
  const manifest = ENGINE_LOGIN_MANIFESTS[provider];
  if (!manifest || manifest.type !== 'files') {
    throw new Error(`No file manifest for ${provider}`);
  }

  const files = {};
  const summary = [];
  for (const displayPath of manifest.files) {
    const absolutePath = expandHomePath(displayPath, homeDir);
    let stat;
    try {
      stat = fsModule.statSync(absolutePath);
    } catch {
      const err = new Error(`Missing ${displayPath}. ${manifest.missingHint}.`);
      err.code = 'missing_file';
      throw err;
    }
    if (!stat.isFile()) {
      const err = new Error(`Missing ${displayPath}. ${manifest.missingHint}.`);
      err.code = 'missing_file';
      throw err;
    }
    if (stat.size > MAX_ENGINE_LOGIN_FILE_BYTES) {
      const err = new Error(`${displayPath} is ${stat.size} bytes; maximum is ${MAX_ENGINE_LOGIN_FILE_BYTES} bytes.`);
      err.code = 'file_too_large';
      throw err;
    }
    const content = fsModule.readFileSync(absolutePath, 'utf8');
    files[displayPath] = content;
    summary.push({
      path: displayPath,
      bytes: byteLength(content),
      email: detectedEmailFromContent(content),
    });
  }
  return { payload: { files }, summary };
}

function parseEngineLoginArgs(args = []) {
  const options = {
    provider: '',
    list: false,
    remove: '',
    yes: false,
    json: false,
    computer: false,
    business: '',
    businessFlag: false,
    seat: '',
    seatFlag: false,
    help: false,
  };
  for (let i = 0; i < args.length; i += 1) {
    const arg = String(args[i] || '');
    if (arg === '--help' || arg === '-h' || arg === 'help') {
      options.help = true;
      continue;
    }
    if (arg === '--list' || arg === 'list') {
      options.list = true;
      continue;
    }
    if (arg === '--remove' && args[i + 1]) {
      options.remove = String(args[i + 1] || '').trim();
      i += 1;
      continue;
    }
    if (arg.startsWith('--remove=')) {
      options.remove = arg.slice('--remove='.length).trim();
      continue;
    }
    if (arg === '--yes' || arg === '-y') {
      options.yes = true;
      continue;
    }
    if (arg === '--json') {
      options.json = true;
      continue;
    }
    if (arg === '--computer') {
      options.computer = true;
      continue;
    }
    if (arg === '--business' || arg === '-b') {
      options.computer = true;
      options.businessFlag = true;
      const next = args[i + 1] === undefined ? '' : String(args[i + 1] || '');
      if (next && !next.startsWith('--')) {
        options.business = next.trim();
        i += 1;
      }
      continue;
    }
    if (arg.startsWith('--business=')) {
      options.computer = true;
      options.businessFlag = true;
      options.business = arg.slice('--business='.length).trim();
      continue;
    }
    if (arg === '--seat') {
      options.seatFlag = true;
      const next = args[i + 1] === undefined ? '' : String(args[i + 1] || '');
      if (next && !next.startsWith('--')) {
        options.seat = normalizeEngineLoginSeat(next);
        i += 1;
      }
      continue;
    }
    if (arg.startsWith('--seat=')) {
      options.seatFlag = true;
      options.seat = normalizeEngineLoginSeat(arg.slice('--seat='.length));
      continue;
    }
    if (arg.startsWith('--')) continue;
    if (!options.provider) options.provider = arg;
  }
  return options;
}

function parseEngineSeedArgs(args = []) {
  const options = {
    provider: '',
    business: '',
    user: false,
    json: false,
    help: false,
  };
  for (let i = 0; i < args.length; i += 1) {
    const arg = String(args[i] || '');
    if (arg === '--help' || arg === '-h' || arg === 'help') {
      options.help = true;
      continue;
    }
    if ((arg === '--business' || arg === '-b') && args[i + 1]) {
      options.business = String(args[i + 1] || '').trim();
      i += 1;
      continue;
    }
    if (arg.startsWith('--business=')) {
      options.business = arg.slice('--business='.length).trim();
      continue;
    }
    if (arg === '--user') {
      options.user = true;
      continue;
    }
    if (arg === '--json') {
      options.json = true;
      continue;
    }
    if (arg.startsWith('--')) continue;
    if (!options.provider) options.provider = arg;
  }
  return options;
}

function printEngineLoginHelp() {
  console.log('\n  atris engine login <provider> --yes\n                           upload a local whitelisted engine login to the Atris vault\n  atris engine login <provider> --computer [--seat <name>]\n                           sign in on one of your Atris computers by device flow\n  atris engine login <provider> --business <id> [--seat <name>]\n                           sign in on a business Atris computer by device flow\n  atris engine login --list\n                           list vaulted engine logins\n  atris engine login --remove <provider>\n                           remove a vaulted engine login\n  providers: codex, claude, cursor, devin, grok\n');
}

function printEngineSeedHelp() {
  console.log('\n  atris engine seed <provider> --business <id>\n  atris engine seed <provider> --user\n                           ask the backend to seed a vaulted login onto a computer\n');
}

function redactBackendResponse(value, parentKey = '') {
  if (value == null) return value;
  if (Array.isArray(value)) return value.map((item) => redactBackendResponse(item, parentKey));
  if (typeof value !== 'object') {
    if (/api[_-]?key|token|secret|credential|auth|files?/i.test(parentKey)) return '[redacted]';
    return value;
  }
  const output = {};
  for (const [key, item] of Object.entries(value)) {
    if (/api[_-]?key|token|secret|credential|auth/i.test(key)) {
      output[key] = '[redacted]';
    } else if (key === 'files' && item && typeof item === 'object') {
      output[key] = Object.fromEntries(Object.keys(item).map((filePath) => [filePath, '[redacted]']));
    } else {
      output[key] = redactBackendResponse(item, key);
    }
  }
  return output;
}

function printBackendResult(result, { json = false } = {}) {
  const data = result && result.data !== undefined && result.data !== null
    ? result.data
    : { ok: Boolean(result && result.ok), status: result && result.status };
  const safe = redactBackendResponse(data);
  if (json || typeof safe === 'object') {
    console.log(JSON.stringify(safe, null, 2));
  } else {
    console.log(String(safe));
  }
}

function printLoginSummary(provider, summary) {
  console.log('');
  console.log(`  engine login: ${provider}`);
  for (const item of summary) {
    const email = item.email ? ` email: ${item.email}` : '';
    console.log(`  ${item.path.padEnd(32)} ${String(item.bytes).padStart(6)} bytes${email}`);
  }
  console.log('');
}

function readLineNoEcho(question) {
  return new Promise((resolve) => {
    if (!process.stdin.isTTY) {
      let data = '';
      process.stdout.write(question);
      process.stdin.setEncoding('utf8');
      process.stdin.on('data', (chunk) => { data += chunk; });
      process.stdin.on('end', () => resolve(data.trim()));
      process.stdin.on('error', () => resolve(''));
      process.stdin.resume();
      return;
    }

    const muted = new Writable({
      write(chunk, encoding, callback) {
        if (!muted.muted) process.stdout.write(chunk, encoding);
        callback();
      },
    });
    const rl = readline.createInterface({ input: process.stdin, output: muted, terminal: true });
    rl.question(question, (answer) => {
      rl.close();
      process.stdout.write('\n');
      resolve(String(answer || '').trim());
    });
    muted.muted = true;
  });
}

function readLineVisible(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(question, (answer) => {
      rl.close();
      resolve(String(answer || '').trim());
    });
  });
}

async function promptApiKey(provider, deps = {}) {
  if (typeof deps.promptSecret === 'function') {
    return String(await deps.promptSecret(provider) || '').trim();
  }
  return readLineNoEcho(`Paste ${provider} API key: `);
}

async function confirmEngineLoginUpload(provider, deps = {}) {
  if (typeof deps.confirmUpload === 'function') {
    return Boolean(await deps.confirmUpload(provider));
  }
  const answer = await readLineVisible('Upload this credential to the Atris backend vault? [y/N] ');
  return /^y(es)?$/i.test(answer);
}

async function authenticatedEngineApi(pathname, options, deps = {}) {
  const apiFn = deps.apiRequestJson || apiRequestJson;
  const ensureFn = deps.ensureValidCredentials || ensureValidCredentials;
  const ensured = await ensureFn(apiFn);
  if (ensured.error) {
    return {
      ok: false,
      status: 0,
      data: null,
      error: ensured.detail || ensured.error || 'not_logged_in',
      authError: true,
    };
  }
  const token = ensured.credentials && ensured.credentials.token;
  return apiFn(pathname, {
    ...options,
    token,
  });
}

async function listEngineLogins(deps = {}) {
  return authenticatedEngineApi('/engines/logins', {
    method: 'GET',
    timeoutMs: 15000,
    retries: 0,
  }, deps);
}

async function listEngineSeats(deps = {}) {
  return authenticatedEngineApi('/engines/logins/seats', {
    method: 'GET',
    timeoutMs: 15000,
    retries: 0,
  }, deps);
}

async function readyCheckEngineLogin(provider, target, deps = {}) {
  return authenticatedEngineApi(`/engines/logins/${encodeURIComponent(provider)}/ready-check`, {
    method: 'POST',
    body: { target },
    timeoutMs: 30000,
    retries: 0,
  }, deps);
}

function formatEngineSeats(data, now = Date.now()) {
  const seats = Array.isArray(data?.seats) ? data.seats : [];
  if (!seats.length) return 'No accounts linked yet. Run: atris computer setup';

  const nowValue = now instanceof Date ? now.getTime() : Number(now);
  const nowSeconds = Number.isFinite(nowValue) ? nowValue / 1000 : Date.now() / 1000;
  return seats.map((seat) => {
    const engine = String(seat?.engine || 'engine').trim().toLowerCase();
    const name = String(seat?.name || 'account').trim().toLowerCase();
    const coolingUntil = Number(seat?.cooling_until);
    if (!Number.isFinite(coolingUntil) || coolingUntil <= nowSeconds) {
      return `${engine} ${name} - ready`;
    }
    const minutes = Math.ceil((coolingUntil - nowSeconds) / 60);
    const hours = Math.floor(minutes / 60);
    return `${engine} ${name} - cooling down, back ${hours}h ${minutes % 60}m`;
  }).join('\n');
}

async function runEngineSeatsCommand(deps = {}) {
  const result = await listEngineSeats(deps);
  if (!result.ok) {
    console.error(result.authError ? 'Run atris login first.' : `engine seats failed: ${result.error || result.status}`);
    return 1;
  }
  const now = typeof deps.now === 'function' ? deps.now() : Date.now();
  console.log(formatEngineSeats(result.data, now));
  return 0;
}

async function buildEngineLoginPayload(provider, deps = {}) {
  const manifest = ENGINE_LOGIN_MANIFESTS[provider];
  if (!manifest) {
    throw new Error(`Unknown engine login provider "${provider}". Known providers: ${knownLoginProviders().join(', ')}`);
  }

  if (manifest.type === 'api_key') {
    const apiKey = await promptApiKey(provider, deps);
    if (!apiKey) {
      const err = new Error('No API key provided.');
      err.code = 'missing_api_key';
      throw err;
    }
    if (byteLength(apiKey) > MAX_ENGINE_LOGIN_FILE_BYTES) {
      const err = new Error(`API key is ${byteLength(apiKey)} bytes; maximum is ${MAX_ENGINE_LOGIN_FILE_BYTES} bytes.`);
      err.code = 'api_key_too_large';
      throw err;
    }
    return {
      payload: { api_key: apiKey },
      summary: [{ path: 'api key', bytes: byteLength(apiKey), email: '' }],
    };
  }

  return readEngineLoginFiles(provider, deps);
}

function engineDeviceLoginTarget(options) {
  if (options.target) return options.target;
  if (!options.computer) return null;
  if (options.businessFlag && !options.business) {
    const err = new Error('usage: atris engine login <provider> --business <id>');
    err.code = 'usage';
    throw err;
  }
  if (options.business) return { type: 'business', id: options.business };
  return { type: 'user' };
}

function normalizeDeviceLoginStatus(data, provider, sessionId, seat = '') {
  const payload = data && typeof data === 'object' ? data : {};
  return {
    ...payload,
    session_id: payload.session_id || sessionId || '',
    provider: payload.provider || provider,
    ...(payload.seat || seat ? { seat: payload.seat || seat } : {}),
  };
}

function printDeviceLoginCode(status, { json = false } = {}) {
  const lines = [
    '',
    `Sign in: ${status.verify_url}`,
    `Code:    ${status.code}   (expires in 15 minutes; never share this code)`,
    '',
  ];
  for (const line of lines) {
    if (json) console.error(line);
    else console.log(line);
  }
}

function printDeviceLoginCompleted(status, { json = false } = {}) {
  if (json) {
    console.log(JSON.stringify(status, null, 2));
    return;
  }
  const registered = status.registered === true ? 'true' : status.registered === false ? 'false' : String(status.registered ?? '');
  console.log('');
  console.log(`engine login ready: ${status.provider}`);
  if (status.seat) console.log(`seat: ${status.seat}`);
  console.log(`account_email: ${status.account_email || '(none)'}`);
  console.log(`registered: ${registered}`);
  console.log(`ready-check: provider=${status.provider} session_id=${status.session_id || ''} status=${status.status} registered=${registered}`);
  console.log('');
}

function printDeviceLoginFinalJson(status, options) {
  if (options.json) console.log(JSON.stringify(status, null, 2));
}

async function waitForDeviceLoginPoll(ms, deps = {}) {
  if (typeof deps.sleep === 'function') return deps.sleep(ms);
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function readDeviceLoginPasteBackCode(deps = {}) {
  const readlineDep = deps.readline || readline;
  const input = deps.stdin || process.stdin;
  const output = deps.stdout || process.stdout;
  const rl = readlineDep.createInterface({ input, output });
  try {
    return String(await new Promise((resolve) => rl.question('', resolve)) || '').trim();
  } finally {
    rl.close();
  }
}

async function runEngineDeviceLoginCommand(provider, options, deps = {}) {
  let target;
  let seat;
  try {
    target = engineDeviceLoginTarget(options);
    seat = normalizeEngineLoginSeat(options.seat);
    if ((options.seatFlag || options.seat) && !validEngineLoginSeat(seat)) {
      const err = new Error(engineLoginSeatError());
      err.code = 'usage';
      throw err;
    }
  } catch (err) {
    console.error(err.message);
    return 2;
  }

  const body = seat ? { target, seat } : { target };
  const started = await authenticatedEngineApi(`/engines/logins/${encodeURIComponent(provider)}/device-login`, {
    method: 'POST',
    body,
    timeoutMs: 30000,
    retries: 0,
  }, deps);
  if (!started.ok) {
    console.error(options.setup
      ? `could not connect the ${provider} account; please try again.`
      : (started.authError ? 'Run atris login first.' : `engine login device flow failed: ${started.error || started.status}`));
    return 1;
  }

  const startStatus = normalizeDeviceLoginStatus(started.data, provider, '', seat);
  const sessionId = startStatus.session_id;
  if (!sessionId) {
    console.error(options.setup
      ? `could not connect the ${provider} account; please try again.`
      : 'engine login device flow failed: missing session_id');
    return 1;
  }

  let finalStatus = startStatus;
  let codePrinted = false;
  let pasteBackSubmitted = false;
  const pollMs = Math.max(1, Number(deps.deviceLoginPollMs ?? ENGINE_DEVICE_LOGIN_POLL_MS));
  const timeoutMs = Math.max(0, Number(deps.deviceLoginTimeoutMs ?? ENGINE_DEVICE_LOGIN_TIMEOUT_MS));
  const maxPolls = Math.ceil(timeoutMs / pollMs);

  for (let attempt = 0; attempt <= maxPolls; attempt += 1) {
    const polled = await authenticatedEngineApi(`/engines/logins/device-login/${encodeURIComponent(sessionId)}`, {
      method: 'GET',
      timeoutMs: 30000,
      retries: 0,
    }, deps);
    if (!polled.ok) {
      console.error(options.setup
        ? `could not connect the ${provider} account; please try again.`
        : (polled.authError ? 'Run atris login first.' : `engine login device poll failed: ${polled.error || polled.status}`));
      return 1;
    }

    finalStatus = normalizeDeviceLoginStatus(polled.data, provider, sessionId, seat);
    const status = String(finalStatus.status || '').toLowerCase();
    if (!codePrinted && finalStatus.verify_url && finalStatus.code) {
      if (options.setup) {
        console.log(`On your phone, open: ${finalStatus.verify_url}  and type the code: ${finalStatus.code}`);
      } else {
        printDeviceLoginCode(finalStatus, { json: options.json });
      }
      codePrinted = true;
    }

    const pasteBackRequired = !pasteBackSubmitted
      && status === 'pending_user'
      && finalStatus.verify_url
      && !finalStatus.code
      && String(finalStatus.provider || provider).toLowerCase() === 'claude';
    if (pasteBackRequired) {
      const printPrompt = options.json ? console.error : console.log;
      printPrompt(`On your phone, open: ${finalStatus.verify_url}`);
      let submitted = false;
      for (let submitAttempt = 0; submitAttempt < 2; submitAttempt += 1) {
        printPrompt('When the browser shows you a code, paste it here:');
        const pastedCode = await readDeviceLoginPasteBackCode(deps);
        const codeResult = await authenticatedEngineApi(
          `/engines/logins/device-login/${encodeURIComponent(sessionId)}/code`,
          {
            method: 'POST',
            body: { code: pastedCode },
            timeoutMs: 30000,
            retries: 0,
          },
          deps
        );
        if (codeResult.ok) {
          submitted = true;
          pasteBackSubmitted = true;
          break;
        }
        if (submitAttempt === 0) {
          console.error('that code did not work; paste it again.');
        } else {
          console.error('that code did not work; please start the login again.');
        }
      }
      if (!submitted) return 1;
    }

    if (status === 'completed') {
      if (options.setup) console.log(`${seat} linked.`);
      else printDeviceLoginCompleted(finalStatus, { json: options.json });
      return 0;
    }
    if (status === 'failed' || status === 'expired') {
      if (options.setup) {
        console.error(`could not connect the ${provider} account; please try again.`);
      } else {
        printDeviceLoginFinalJson(finalStatus, options);
        console.error(`engine login device flow ended: ${status}`);
      }
      return 1;
    }

    if (attempt < maxPolls) await waitForDeviceLoginPoll(pollMs, deps);
  }

  finalStatus = {
    ...finalStatus,
    status: 'timeout',
    error: `device login did not complete within ${Math.round(timeoutMs / 60000)} minutes`,
  };
  if (options.setup) {
    console.error(`could not connect the ${provider} account; please try again.`);
  } else {
    printDeviceLoginFinalJson(finalStatus, options);
    console.error('engine login device flow timed out');
  }
  return 1;
}

async function runEngineLoginCommand(args, root, deps = {}) {
  const options = parseEngineLoginArgs(args);
  if (options.help) {
    printEngineLoginHelp();
    return 0;
  }

  if (options.list) {
    const result = await listEngineLogins(deps);
    if (!result.ok) {
      console.error(result.authError ? 'Run atris login first.' : `engine login list failed: ${result.error || result.status}`);
      return 1;
    }
    printBackendResult(result, { json: options.json });
    return 0;
  }

  if (options.remove) {
    const provider = normalizeLoginProvider(options.remove);
    if (!provider) {
      console.error(`Unknown engine login provider "${options.remove}". Known providers: ${knownLoginProviders().join(', ')}`);
      return 2;
    }
    const result = await authenticatedEngineApi(`/engines/logins/${encodeURIComponent(provider)}`, {
      method: 'DELETE',
      timeoutMs: 15000,
      retries: 0,
    }, deps);
    if (!result.ok) {
      console.error(result.authError ? 'Run atris login first.' : `engine login remove failed: ${result.error || result.status}`);
      return 1;
    }
    printBackendResult(result, { json: options.json });
    return 0;
  }

  const provider = normalizeLoginProvider(options.provider);
  if (!provider) {
    console.error(`usage: atris engine login <provider> --yes; providers: ${knownLoginProviders().join(', ')}`);
    return 2;
  }

  if (options.seatFlag && !options.computer) {
    console.error('use --seat with --computer or --business');
    return 2;
  }

  if (options.computer) {
    return runEngineDeviceLoginCommand(provider, options, deps);
  }

  let built;
  try {
    built = await buildEngineLoginPayload(provider, deps);
  } catch (err) {
    console.error(err.message);
    return err.code === 'missing_file' || err.code === 'missing_api_key' ? 1 : 2;
  }

  printLoginSummary(provider, built.summary);
  if (!options.yes) {
    const confirmed = await confirmEngineLoginUpload(provider, deps);
    if (!confirmed) {
      console.error('engine login upload cancelled');
      return 1;
    }
  }

  const result = await authenticatedEngineApi(`/engines/logins/${encodeURIComponent(provider)}`, {
    method: 'POST',
    body: built.payload,
    timeoutMs: 30000,
    retries: 0,
  }, deps);
  if (!result.ok) {
    console.error(result.authError ? 'Run atris login first.' : `engine login upload failed: ${result.error || result.status}`);
    return 1;
  }
  printBackendResult(result, { json: options.json });
  return 0;
}

async function runEngineSeedCommand(args, root, deps = {}) {
  const options = parseEngineSeedArgs(args);
  if (options.help) {
    printEngineSeedHelp();
    return 0;
  }

  const provider = normalizeLoginProvider(options.provider);
  if (!provider) {
    console.error(`usage: atris engine seed <provider> --business <id>|--user; providers: ${knownLoginProviders().join(', ')}`);
    return 2;
  }
  if ((options.business && options.user) || (!options.business && !options.user)) {
    console.error('usage: atris engine seed <provider> --business <id>|--user');
    return 2;
  }

  const body = options.user
    ? { target: { type: 'user' } }
    : { target: { type: 'business', id: options.business } };
  const result = await authenticatedEngineApi(`/engines/logins/${encodeURIComponent(provider)}/seed`, {
    method: 'POST',
    body,
    timeoutMs: 60000,
    retries: 0,
  }, deps);
  if (!result.ok) {
    console.error(result.authError ? 'Run atris login first.' : `engine seed failed: ${result.error || result.status}`);
    return 1;
  }
  printBackendResult(result, { json: options.json });
  return 0;
}

function printRoster(root, { scope = 'workspace' } = {}) {
  reconcileStaleEngineProbeErrors(root);
  printJobRoster(root);
  const list = roster(root);
  const scoped = scope === 'global'
    ? list
    : list.filter((engine) => engine.installed || engine.default || ['ready', 'cooling'].includes(engine.health.status));
  const found = scoped.filter((e) => e.installed).length;
  const current = resolveDefaultEngine(root);
  console.log('');
  console.log(`  engines: ${found} intelligence${found === 1 ? '' : 's'} found (${scope})`);
  console.log('');
  for (const engine of scoped) {
    const mark = engine.default ? '→' : ' ';
    const state = engine.health.status === 'not_installed' ? 'not installed' : engine.health.status.replace(/_/g, ' ');
    const roles = engine.roles.join(',');
    console.log(`  ${mark} ${engine.id.padEnd(12)} ${state.padEnd(13)} ${engine.tier.padEnd(4)} ${roles}`);
    const details = [`models: ${engine.models.join(', ')}`];
    if (engine.duty) details.push(`duty: ${engine.duty}`);
    if (engine.health.status === 'cooling') details.push(coolingView(engine).text);
    console.log(`      ${details.join('   ')}`);
  }
  if (scope !== 'global' && list.length > scoped.length) {
    console.log(`  … ${list.length - scoped.length} not installed hidden (pass --global to list)`);
  }
  console.log('');
  console.log(`  default: ${current.name}${current.source === 'saved' ? ' (set here)' : current.source === 'env' ? ' (this session)' : ''}`);
  console.log(`  switch:  atris engine <name>   ·   one run: --engine <name> on mission run / autopilot / run`);
  console.log('');
}

function registryPayload(root, { scope = 'workspace', includeHidden = false } = {}) {
  const current = resolveDefaultEngine(root);
  const registry = readEngineRegistry(root);
  const engines = registry.engines
    .map((engine) => ({
      ...engine,
      hidden: HIDDEN_PROFILE_NAMES.includes(engine.id),
      default: engine.id === current.name,
    }))
    .filter((engine) => includeHidden || !engine.hidden);
  const scoped = scope === 'global'
    ? engines
    : engines.filter((engine) => engine.installed || engine.default || (engine.health && engine.health.status === 'ready'));
  return {
    scope,
    default: current.name,
    source: current.source,
    roster: jobRosterView(root),
    engines: scoped,
  };
}

// A hand-edited file can hold a string or a list where a pick belongs. Only
// an object naming an engine counts; anything else shows as no pick.
function rosterPickEntry(value) {
  return value && typeof value === 'object' && !Array.isArray(value) && value.engine ? value : null;
}

const WORKER_SKIP_WORDS = Object.freeze({ 'not ready': 'down', expired: 'expired', 'bad model': 'names a model it cannot run' });

// A worker whose end date is this many days away or fewer gets a heads-up.
const ENDS_SOON_DAYS = 7;
const RENEW_COMMAND = 'atris engine roster confirm';

// Whole local days from today to a worker's end date: 0 on its last day,
// negative once it has ended, null when it has no valid end date.
function endsInDays(until, now = new Date()) {
  const end = parseRosterUntil(until);
  if (!end) return null;
  const date = new Date(now);
  if (Number.isNaN(date.getTime())) return null;
  const today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  return Math.round((end.getTime() - today.getTime()) / 86400000);
}

function endsSoon(days) {
  return days !== null && days >= 0 && days <= ENDS_SOON_DAYS;
}

function endsInText(days) {
  if (days === 0) return 'ends today';
  if (days === 1) return 'ends tomorrow';
  return `ends in ${days} days`;
}

function shortDay(until) {
  const date = parseRosterUntil(until);
  return date ? date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }).toLowerCase() : '';
}

// One worker of a job's team as the view shows it: what it runs, and whether
// it leads now, backs up, or is skipped and why.
function workerRow(step, index, leadIndex, now = new Date()) {
  const { worker } = step;
  const endsIn = endsInDays(worker.until, now);
  const runs = worker.error ? null : engineRunsView(worker.engine, { model: worker.model || '', effort: worker.effort || '' });
  const status = index === leadIndex ? 'leads' : step.skip ? 'skipped' : 'backup';
  const why = step.skip === 'bad line' ? `bad line: ${worker.error}`
    : step.skip === 'cooling' && step.cooling ? step.cooling.text
      : step.skip ? WORKER_SKIP_WORDS[step.skip] : '';
  return {
    engine: worker.engine || null,
    model: worker.model || null,
    effort: worker.effort || null,
    max_seconds: Number(worker.max_seconds) > 0 ? Number(worker.max_seconds) : null,
    prep: worker.prep ? rosterJobLabel(worker.prep) : null,
    until: worker.until || null,
    ends_in_days: endsIn,
    expiring_soon: endsSoon(endsIn),
    verified: worker.verified || null,
    line: worker.line || null,
    ...(worker.error ? { text: worker.text || '' } : {}),
    status,
    why,
    ...(step.cooling ? { cooling_until: step.cooling.until, cooling_reason: step.cooling.reason } : {}),
    runs,
  };
}

function jobRosterRow(job, role, root, state, registry, now, key = role) {
  const custom = key !== role || !ENGINE_ROLES.includes(key);
  const layerPicks = Object.fromEntries(ROSTER_LAYERS.map((scope) => [scope, (state[scope] && state[scope].picks) || {}]));
  const picks = Object.fromEntries(ROSTER_LAYERS.map((scope) => [scope, rosterPickEntry(layerPicks[scope][key])]));
  const resolved = resolveEngineForRoleRanked(role, root, {
    now,
    sessionRosterPicks: layerPicks.session,
    projectRosterPicks: layerPicks.project,
    machineRosterPicks: layerPicks.machine,
    ...(custom ? { job: key } : {}),
  });
  // Show the layer that decided; when none did, show the first one set. A
  // custom job that fell back to its kind's pick did not decide on its own.
  const decided = rosterDecided(resolved.source) && (!custom || resolved.job === job);
  const source = decided ? resolved.source : ROSTER_LAYERS.find((scope) => picks[scope]) || null;
  const pick = source ? picks[source] : null;
  const walk = pick ? rosterWorkerWalk(pick, role, registry, now, { anyEngine: jobTakesAnyEngine(key) }) : [];
  const leadIndex = decided && resolved.source === source ? walk.findIndex((step) => !step.skip) : -1;
  const good = walk.map((step, index) => ({ step, index })).filter(({ step }) => !step.worker.error);
  const first = good[0] || null;
  const status = !pick ? 'router'
    : first && first.step.skip === 'expired' ? 'expired'
      : first && leadIndex === first.index ? 'picked'
        : first && first.step.skip === 'cooling' ? 'cooling'
          : 'not ready';
  const lead = leadIndex === -1 ? 'none'
    : first && leadIndex === first.index ? 'first'
      : good[1] && leadIndex === good[1].index ? 'backup'
        : 'later';
  const kind = Object.keys(ENGINE_JOBS).find((name) => ENGINE_JOBS[name] === role);
  const pickEndsIn = pick ? endsInDays(pick.until, now) : null;
  // What the job really runs: its first two good workers, each with its own
  // model and effort, or the router's engine when no line decides.
  const runsOf = (entry) => (entry ? engineRunsView(entry.step.worker.engine, { model: entry.step.worker.model || '', effort: entry.step.worker.effort || '' }) : null);
  const runs = runsOf(first);
  const nowRuns = resolved.engine
    ? engineRunsView(resolved.engine.id, { model: resolved.engine.roster_model || '', effort: resolved.engine.roster_effort || '' })
    : null;
  return {
    job,
    role,
    ...(custom ? { key, like: kind } : {}),
    pick,
    from: source ? ROSTER_SOURCES[source] : null,
    file: source ? state[source].file : null,
    session_pick: picks.session,
    project_pick: picks.project,
    machine_pick: picks.machine,
    engine: resolved.engine ? resolved.engine.id : null,
    model: resolved.engine && resolved.engine.roster_model ? resolved.engine.roster_model : null,
    effort: resolved.engine && resolved.engine.roster_effort ? resolved.engine.roster_effort : null,
    max_seconds: pick && Number(pick.max_seconds) > 0 ? Number(pick.max_seconds) : null,
    ends_in_days: pickEndsIn,
    expiring_soon: endsSoon(pickEndsIn),
    prep: first && first.step.worker.prep ? rosterJobLabel(first.step.worker.prep) : null,
    backup_prep: good[1] && good[1].step.worker.prep ? rosterJobLabel(good[1].step.worker.prep) : null,
    runs: runs || nowRuns,
    backup_runs: runsOf(good[1]),
    now_runs: nowRuns,
    workers: walk.map((step, index) => workerRow(step, index, leadIndex, now)),
    lead,
    status,
    ...(status === 'cooling' ? { cooling: first.step.cooling.text } : {}),
    reason: resolved.reason,
  };
}

// The three built-in jobs first, then the owner's own jobs from this
// session, this project, and the all-projects roster.
function jobRosterView(root = process.cwd(), now = new Date(), state = null) {
  const registry = readEngineRegistry(root);
  const layers = state || readRosterState(root, { now });
  const rows = Object.entries(ENGINE_JOBS).map(([job, role]) => jobRosterRow(job, role, root, layers, registry, now));
  const customKeys = [...new Set(ROSTER_LAYERS.flatMap((scope) => customRosterJobKeys(layers[scope] && layers[scope].picks)))];
  for (const key of customKeys) {
    const role = rosterJobRole(key, root, {
      now,
      sessionRosterPicks: layers.session.picks,
      projectRosterPicks: layers.project.picks,
      machineRosterPicks: layers.machine.picks,
    });
    if (!role) continue;
    rows.push(jobRosterRow(rosterJobLabel(key), role, root, layers, registry, now, key));
  }
  return rows;
}

// Jobs, the team, and one warning per roster line that could not be used.
function rosterReport(root = process.cwd(), now = new Date()) {
  const state = readRosterState(root, { now });
  const jobs = jobRosterView(root, now, state);
  const team = teamRosterView(root, { now, rosterState: state });
  const expiring = expiringWorkers(jobs);
  return {
    jobs,
    expiring,
    renew_command: expiring.length ? RENEW_COMMAND : null,
    upgraded: upgradedModels(state),
    team: team.rows,
    warnings: [...state.session.warnings, ...state.project.warnings, ...state.machine.warnings, ...team.warnings],
    files: {
      session: state.session.format === 'none' ? null : state.session.file,
      project: state.project.format === 'none' ? null : state.project.file,
      machine: state.machine.format === 'none' ? null : state.machine.file,
    },
    session: state.session.key || null,
  };
}

// Retired models a roster file still names. Every read runs them as their
// replacement, so this is only a heads-up; nobody has to edit the file.
function upgradedModels(state) {
  const found = [];
  for (const layer of [state.session, state.project, state.machine]) {
    if (!layer || layer.format === 'none' || !layer.path) continue;
    let text = '';
    try { text = fs.readFileSync(layer.path, 'utf8'); } catch { continue; }
    for (const from of retiredModelsNamed(text)) {
      if (!found.some((item) => item.from === from)) found.push({ from, to: RETIRED_CLAUDE_MODELS[from] });
    }
  }
  return found;
}

function renderUpgradedLine(upgraded) {
  return (upgraded || []).map((item) => `note: ${modelLabel(item.from)} is retired, so your roster runs ${modelLabel(item.to)} in its place. no edit needed.`).join('\n');
}

// Every worker, in any job, whose end date is today or within the next
// seven days. Workers already past their date show on their own lines. A
// job set for this shell only is skipped: roster confirm does not renew it.
function expiringWorkers(jobs) {
  const list = [];
  for (const row of jobs || []) {
    if (row.session_pick) continue;
    for (const worker of row.workers || []) {
      if (!worker.expiring_soon) continue;
      list.push({
        job: row.job,
        engine: worker.engine,
        model: worker.model,
        tool: worker.runs ? worker.runs.text : worker.engine,
        until: worker.until,
        ends_in_days: worker.ends_in_days,
        from: row.from,
      });
    }
  }
  return list;
}

function untilText(worker, days = null) {
  const until = parseRosterUntil(worker.until);
  if (until) return `until ${shortDay(worker.until)}${endsSoon(days) ? `, ${endsInText(days)}` : ''}`;
  return worker.never_expires ? 'no end date' : 'until no valid date';
}

// One line under the jobs when any worker ends within seven days, naming
// each one and the command that keeps it going.
function renderExpiringLine(expiring) {
  if (!expiring || !expiring.length) return '';
  const names = expiring.map((item) => `${item.tool} on ${item.job} ${endsInText(item.ends_in_days)}`);
  const them = expiring.length === 1 ? 'it' : 'them';
  return `heads up: ${names.join(', ')}. to keep ${them} 30 more days, run: ${RENEW_COMMAND}`;
}

// The same heads-up, short enough for one boot line.
function bootExpiringLine(expiring) {
  if (!expiring || !expiring.length) return '';
  const [first] = expiring;
  const more = expiring.length > 1 ? ` and ${expiring.length - 1} more` : '';
  return `${first.tool} on ${first.job} ${endsInText(first.ends_in_days)}${more}. renew: ${RENEW_COMMAND}`;
}

// --- the roster as tables -------------------------------------------------
//
// One row per job, one row per member. Plain columns, a header row, two
// spaces between; a cell that needs more than one line (effort, several
// backups) carries on underneath in its own column.

function workerCellText(view) {
  return view ? engineModelText(view.engine, view.model) : '';
}

function maxCellText(seconds) {
  const text = rosterMaxText(seconds);
  return text ? text.replace(/^max /, '') : '-';
}

// Workers that name a tool the roster can run, in written order.
function goodWorkers(row) {
  return (row.workers || []).filter((worker) => worker.engine && worker.runs);
}

// Why a backup is passed over, in two or three words.
function backupSkipText(worker) {
  if (worker.status !== 'skipped') return '';
  if (worker.why === 'expired' && worker.ends_in_days !== null && worker.ends_in_days !== undefined) return `ended ${shortDay(worker.until)}`;
  return worker.why || 'skipped';
}

// "newer <model> out" or "pin 45 days old": the outdated-model flags,
// short enough for the note column. The full line with its fix prints
// under the table.
function staleNote(worker) {
  if (worker.stale_model && worker.newer_model) return `newer ${modelLabel(worker.newer_model)} out`;
  if (worker.pin_age_days !== null && worker.pin_age_days !== undefined && worker.pin_age_days > PIN_STALE_DAYS) return `pin ${worker.pin_age_days} days old`;
  return '';
}

function jobNoteText(row, lead, backups, mainFrom) {
  // A tool on its own default model is named alone here, to keep notes short.
  const nowText = !row.now_runs ? 'no ready engine' : row.now_runs.model ? workerCellText(row.now_runs) : row.now_runs.engine;
  if (!row.pick) return row.like ? `no pick, same as ${row.like}` : 'no pick, router decides';
  const fallback = row.lead === 'backup' ? 'using backup'
    : row.lead === 'later' ? `using ${nowText}`
      : row.like ? `falls back to ${row.like}` : `router decides: ${nowText}`;
  const ended = row.ends_in_days !== null && row.ends_in_days !== undefined ? `ended ${shortDay(row.pick.until)}` : 'expired';
  const parts = [];
  if (row.status === 'expired') parts.push(`${ended}, ${fallback}`);
  else if (row.status === 'cooling') parts.push(`${row.cooling}, ${fallback}`);
  else if (row.status === 'not ready') parts.push(`not ready, ${fallback}`);
  else if (row.expiring_soon) parts.push(endsInText(row.ends_in_days));
  if (lead && lead.prep) parts.push(`prep: ${lead.prep}`);
  if (lead && staleNote(lead)) parts.push(staleNote(lead));
  for (const worker of backups) if (staleNote(worker)) parts.push(`backup ${staleNote(worker)}`);
  if (row.from && row.from !== mainFrom) parts.push(`from ${row.from}`);
  return parts.join(', ');
}

// The roster file most jobs come from; the table heading names it.
function mainRosterSource(rows) {
  const counts = new Map();
  for (const row of rows) if (row.pick && row.from) counts.set(row.from, (counts.get(row.from) || 0) + 1);
  const [from] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0] || [];
  const row = rows.find((item) => item.from === from);
  return { from: from || null, file: row ? row.file : null };
}

function jobTableRow(row, mainFrom) {
  const [lead, ...backups] = row.pick ? goodWorkers(row) : [];
  const leadView = row.pick ? (lead && lead.runs) : row.now_runs;
  const leads = leadView
    ? [workerCellText(leadView), leadView.effort ? `(${leadView.effort} effort)` : null]
    : [row.pick ? 'no ready tool' : 'no ready engine'];
  const backupCell = backups.length
    ? backups.map((worker) => {
      // Effort, max time, and prep for a backup stay in --json; the cell keeps
      // what changes who runs: a skip reason or an end date.
      const skip = backupSkipText(worker);
      const until = !skip && parseRosterUntil(worker.until) ? `until ${shortDay(worker.until)}${worker.expiring_soon ? `, ${endsInText(worker.ends_in_days)}` : ''}` : '';
      const extras = [skip, until].filter(Boolean);
      return `${workerCellText(worker.runs)}${extras.length ? ` (${extras.join(', ')})` : ''}`;
    })
    : ['none'];
  const until = lead && parseRosterUntil(lead.until) ? lead.until : '-';
  return [
    row.job,
    leads,
    backupCell,
    lead ? maxCellText(lead.max_seconds) : '-',
    until,
    jobNoteText(row, lead, backups, mainFrom) || '-',
  ];
}

function renderJobRoster(rows, { width, heading = true } = {}) {
  if (!rows.length) return '';
  const { from, file } = mainRosterSource(rows);
  const columns = [
    { header: 'JOB' }, { header: 'LEADS' }, { header: 'BACKUP' }, { header: 'MAX' }, { header: 'UNTIL' },
    { header: 'NOTE', wrap: true, min: 16 },
  ];
  const table = renderTable(columns, rows.map((row) => jobTableRow(row, from)), { width });
  const title = !heading ? '' : file ? `jobs, from ${file}` : 'jobs';
  const suggestions = rows.filter((row) => row.suggestion).map((row) => `suggestion for ${row.job}: ${row.suggestion.text}`);
  return [title, table, ...renderWorkerRecords(rows, { width }), ...suggestions].filter(Boolean).join('\n');
}

// Each worker's recent record (last 7 days), only for workers with runs, as
// one small table under the jobs.
function renderWorkerRecords(rows, { width } = {}) {
  const records = [];
  for (const row of rows) {
    for (const worker of row.workers || []) {
      if (worker.record) records.push([row.job, worker.runs ? workerCellText(worker.runs) : worker.engine, worker.record.text.replace(/^last \d+ days: /, '')]);
    }
  }
  if (!records.length) return [];
  return ['\nlast 7 days', renderTable([{ header: 'JOB' }, { header: 'WORKER' }, { header: 'RECORD', clip: true, min: 20 }], records, { width })];
}

// "sep 30, 3 runs" or "quiet 8 to 14 days", from the same evidence atris
// team reads. '-' for idle members and when activity was not read.
function teamActivityTag(activity) {
  if (!activity || activity.status === 'idle') return '-';
  if (activity.status === 'quiet') return 'quiet 8 to 14 days';
  const runs = Number(activity.runs_7d) || 0;
  const day = activity.days_since === 0 ? 'today' : activity.days_since === 1 ? 'yesterday' : shortDay(activity.last_active);
  return `${day}, ${runs} run${runs === 1 ? '' : 's'}`;
}

function renderTeamRoster(rows, { width } = {}) {
  if (!rows.length) return '';
  const showActivity = rows.some((row) => row.activity !== undefined);
  const columns = [{ header: 'MEMBER' }, { header: 'JOB' }, { header: 'ENGINE · MODEL' }, { header: 'SOURCE' }];
  if (showActivity) columns.push({ header: 'LAST 7 DAYS', clip: true, min: 11 });
  const cells = rows.map((row) => {
    const engine = row.engine ? workerCellText(engineRunsView(row.engine, { model: row.model || '', effort: row.effort || '' })) : 'no ready engine';
    const stale = row.stale_model && row.newer_model ? ` (newer ${modelLabel(row.newer_model)} out)` : '';
    const cell = [row.member, row.job || '-', `${engine}${stale}`, row.source === 'file' ? (row.file || 'roster file') : 'automatic'];
    if (showActivity) cell.push(teamActivityTag(row.activity));
    return cell;
  });
  return ['team', renderTable(columns, cells, { width })].join('\n');
}

function renderRosterWarnings(warnings) {
  return warnings.map((warning) => `warning: ${warning.file} line ${warning.line} "${warning.text}" ${warning.message}.`).join('\n');
}

function renderRosterReport(report, { width } = {}) {
  const stale = (report.stale || []).map((item) => item.text);
  const jobs = [renderJobRoster(report.jobs, { width }), renderExpiringLine(report.expiring), ...stale, renderUpgradedLine(report.upgraded)].filter(Boolean).join('\n');
  return [jobs, renderTeamRoster(report.team, { width }), renderRosterWarnings(report.warnings)]
    .filter(Boolean)
    .join('\n\n');
}

function printJobRoster(root, now = new Date()) {
  console.log(renderRosterReport(rosterReport(root, now)));
}

// With the owner's picks: the swap list on top (atris engines, then the
// picks), then every model under "more models". Without: every tool's list.
function renderAvailable(rows, list = null) {
  if (!rows.length) return 'no tools found on this machine. run atris engine doctor to check again';
  const top = list && list.picked ? list.options.filter((option) => !option.more) : [];
  const width = Math.max(...rows.map((row) => row.tool.length), ...top.map((option) => option.tool.length));
  const full = rows.map((row) => `${row.tool.padEnd(width)}  ${row.models.join(', ') || 'its own default'}  (${row.source})`);
  if (!top.length) return ['on this machine', ...full].join('\n');
  const labels = Math.max(...top.map((option) => option.label.length));
  const picks = top.map((option) => `${option.tool.padEnd(width)}  ${option.label.padEnd(labels)}  ${option.atris ? 'atris' : 'pick'}`);
  return ['on this machine', ...picks, '', 'more models', ...full].join('\n');
}

// Only this session's changes, from its own file.
function renderSessionRoster(report, key) {
  const jobs = report.jobs.filter((row) => row.from === ROSTER_SOURCES.session);
  const team = report.team.filter((row) => row.source === 'file' && row.file === report.files.session);
  if (!jobs.length && !team.length) return `this session (${key}) has no roster changes. add one with: atris engine assign <job> <tool> --session`;
  const head = `this session (${key}) changes${report.files.session ? `, from ${report.files.session}` : ''}`;
  return [head, renderJobRoster(jobs, { heading: false }), renderTeamRoster(team)].filter(Boolean).join('\n\n');
}

function runRosterSessionCommand(rest, json, root, now) {
  const key = rosterSessionKey();
  if (rest[1] === 'clear') {
    try {
      const cleared = clearSessionRoster();
      console.log(cleared ? 'cleared this session\'s roster changes' : 'this session has no roster changes to clear');
      return 0;
    } catch (err) {
      console.error(err.message);
      return 2;
    }
  }
  if (!key) {
    console.error(NO_SESSION_MESSAGE);
    return 2;
  }
  const report = rosterReport(root, now);
  if (json) {
    const jobs = report.jobs.filter((row) => row.from === ROSTER_SOURCES.session);
    const team = report.team.filter((row) => row.source === 'file' && row.file === report.files.session);
    console.log(JSON.stringify({ session: key, file: report.files.session, jobs, team }, null, 2));
  } else {
    console.log(renderSessionRoster(report, key));
  }
  return 0;
}

// Attach each worker's recent record (last 7 days) to the roster report, and
// at most one suggestion per job when that record says the order is wrong.
// Only the roster command reads the whole tail of the run file; the boot
// line reads a smaller tail just to count suggestions. Nothing here writes
// the roster: a suggestion is a line to read and a command a person may run.
function attachRunRecords(report, root, now = new Date()) {
  const runs = readRosterRuns(root, { now, days: RUN_DAYS });
  if (!runs.length) return report;
  for (const row of report.jobs || []) {
    for (const worker of row.workers || []) {
      if (!worker.engine) continue;
      const record = summarizeRuns(workerRuns(runs, { job: row.key || row.job, engine: worker.engine, model: worker.model || '' }), { days: RUN_DAYS });
      if (record) worker.record = record;
    }
  }
  attachSuggestions(report.jobs, runs);
  return report;
}

// Pins are proven by landed runs; a pin older than 30 days is flagged, so
// the look-back reaches well past that.
const STALE_PROOF_DAYS = 90;

// Each team row gets the member's activity (last 7 days, quiet, or idle)
// from the same evidence atris team reads: dated logs, commits that name
// the member, roster runs, and stream events, read once for the team.
function attachTeamActivity(report, root, now = new Date()) {
  const rows = report.team || [];
  if (!rows.length) return report;
  try {
    const { collectMemberActivity } = require('./team');
    const activity = collectMemberActivity(root, rows.map((row) => ({ name: row.member })), { nowMs: new Date(now).getTime() });
    const byName = new Map(activity.map(({ days, ...rest }) => [rest.name, rest]));
    for (const row of rows) row.activity = byName.get(String(row.member).toLowerCase()) || null;
  } catch {
    // Activity is a view; a read that fails leaves the roster as it was.
  }
  return report;
}

// Mark workers that run an outdated model or an unproven old pin. Local
// files only: the registry, codex's models cache, and the run record.
function attachStaleCheck(report, root, now = new Date()) {
  const engines = readEngineRegistry(root, { persist: false }).engines;
  return attachStaleModels(report, {
    catalog: modelCatalog(engines),
    runs: readRosterRuns(root, { now, days: STALE_PROOF_DAYS }),
    now,
  });
}

const RUNS_LIST_DAYS = 30;
const RUNS_LIST_LIMIT = 20;

// The recent attempts, newest first, one plain line each.
function runRosterRunsCommand(job, json, root, now) {
  const runs = recentRuns(readRosterRuns(root, { now, days: RUNS_LIST_DAYS }), { job, limit: RUNS_LIST_LIMIT });
  if (json) {
    console.log(JSON.stringify({ job: job || null, days: RUNS_LIST_DAYS, runs: runs.map(runView) }, null, 2));
    return 0;
  }
  if (!runs.length) {
    console.log(job ? `no ${job} runs recorded in the last ${RUNS_LIST_DAYS} days` : `no runs recorded in the last ${RUNS_LIST_DAYS} days`);
    return 0;
  }
  console.log([`recent ${job ? `${job} ` : ''}runs, newest first`, ...runs.map(renderRunLine)].join('\n'));
  return 0;
}

const ROSTER_SET_USAGE = 'usage: atris engine roster set <job> <tool> <model>, or atris engine roster set --member <name> <tool> <model>. the tools and models come from atris engine roster --available';

// The words after set: the job (one quoted argument, or every word before
// the first one that names a tool), the tool (one word, or two like "claude
// code"), then the model, which may be several words.
function splitSetWords(words, needJob) {
  // "claude code" and "atris fast" are two words; every other tool is one.
  const toolAt = (i) => {
    const two = i + 1 < words.length ? `${words[i]} ${words[i + 1]}` : '';
    if (two && rosterToolNameOf(two)) return { at: i, size: 2 };
    return rosterToolNameOf(words[i]) ? { at: i, size: 1 } : null;
  };
  let start = 0;
  let job = '';
  if (needJob) {
    if (!words.length) return null;
    if (/\s/.test(String(words[0]).trim())) {
      job = String(words[0]).trim();
      start = 1;
    } else {
      let found = null;
      for (let i = 1; i < words.length && !found; i += 1) found = toolAt(i);
      if (!found) return null;
      job = words.slice(0, found.at).join(' ');
      start = found.at;
    }
  }
  const tool = toolAt(start);
  if (!tool) return words.length > start ? { job, tool: words[start], model: words.slice(start + 1).join(' ') } : null;
  return { job, tool: words.slice(start, start + tool.size).join(' '), model: words.slice(start + tool.size).join(' ') };
}

function rosterToolNameOf(words) {
  return rosterToolName(String(words || '').trim());
}

function runRosterSetCommand(args, root) {
  const json = args.includes('--json');
  const words = args.filter((arg) => arg !== '--json');
  let member = '';
  const at = words.indexOf('--member');
  if (at !== -1) {
    member = words[at + 1] || '';
    words.splice(at, 2);
    if (!member || member.startsWith('--')) {
      console.error(ROSTER_SET_USAGE);
      return 2;
    }
  }
  if (words.some((word) => String(word).startsWith('--'))) {
    console.error(ROSTER_SET_USAGE);
    return 2;
  }
  const parts = splitSetWords(words, !member);
  if (!parts || (!member && !parts.job)) {
    console.error(ROSTER_SET_USAGE);
    return 2;
  }
  try {
    const out = member
      ? swapMember(root, member, parts.tool, parts.model)
      : swapJob(root, parts.job, parts.tool, parts.model);
    console.log(json ? JSON.stringify(out, null, 2) : out.line);
    return 0;
  } catch (err) {
    console.error(err.message);
    return 2;
  }
}

function runRosterCommand(args, root, now = new Date()) {
  if (args[0] === 'set') return runRosterSetCommand(args.slice(1), root);
  const json = args.includes('--json');
  const available = args.includes('--available');
  const runsAt = args.indexOf('--runs');
  if (runsAt !== -1) {
    const other = args.slice(0, runsAt).filter((arg) => arg !== '--json');
    const job = args.slice(runsAt + 1).filter((arg) => !String(arg).startsWith('--')).join(' ').trim();
    if (other.length || available) {
      console.error('usage: atris engine roster --runs [job] [--json]');
      return 2;
    }
    return runRosterRunsCommand(job, json, root, now);
  }
  const rest = args.filter((arg) => arg !== '--json' && arg !== '--available');
  const known = !rest.length
    || (rest.length === 1 && ['confirm', 'session'].includes(rest[0]))
    || (rest.length === 2 && rest[0] === 'session' && rest[1] === 'clear');
  if (!known || (available && rest.length)) {
    console.error('usage: atris engine roster [confirm | session [clear] | set <job> <tool> <model> | set --member <name> <tool> <model> | --available | --runs [job]] [--json]');
    return 2;
  }
  if (available) {
    // the same ordered list the phone's engine card reads
    const list = swapList(root);
    const rows = list.tools;
    console.log(json ? JSON.stringify({ tools: rows, list: list.options }, null, 2) : renderAvailable(rows, list));
    return 0;
  }
  if (rest[0] === 'session') return runRosterSessionCommand(rest, json, root, now);
  if (rest[0] === 'confirm') confirmRoster(root, now);
  const report = attachTeamActivity(attachStaleCheck(attachRunRecords(rosterReport(root, now), root, now), root, now), root, now);
  if (json) console.log(JSON.stringify(report, null, 2));
  else console.log(`${renderRosterReport(report)}\n\n${TEAM_FOOTER.join('\n')}`);
  return 0;
}

const ASSIGN_USAGE = 'usage: atris engine assign <job> <tool> [--model <m>] [--effort low|medium|high|xhigh|max] [--max "20 min"] [--prep <job>] [--days <n>] [--add] [--backup "<tool> [model]"] [--like search|build|review] [--session | --everywhere], atris engine assign <job> --promote "<tool> [model]" to move an existing worker to the top unchanged, or atris engine assign <job> --remove <tool> | --clear. jobs live in atris/ROSTER.md (~/.atris/ROSTER.md with --everywhere, this shell only with --session) and you can edit that file any time';

function runAssignCommand(args, root, now = new Date()) {
  const job = args[0] && !String(args[0]).startsWith('--') ? args[0] : '';
  if (!job) {
    console.error('name the job first: atris engine assign <job> <tool>. jobs: search, build, review, or your own, like "small build"');
    return 2;
  }
  if (!rosterJobKey(job)) {
    console.error(rosterJobNameError(job));
    return 2;
  }
  const switches = ['--everywhere', '--session', '--clear', '--add'];
  const everywhere = args.includes('--everywhere');
  const session = args.includes('--session');
  const clear = args.includes('--clear');
  const add = args.includes('--add');
  const rest = args.slice(1).filter((arg) => !switches.includes(arg));
  // The tool may be several words: claude code, atris fast.
  const toolWords = [];
  while (rest.length && !rest[0].startsWith('--')) toolWords.push(rest.shift());
  const engine = toolWords.join(' ');
  const flags = {};
  for (let i = 0; i < rest.length; i += 1) {
    const arg = rest[i];
    if (!['--model', '--backup', '--days', '--like', '--effort', '--max', '--prep', '--remove', '--promote'].includes(arg) || !rest[i + 1] || rest[i + 1].startsWith('--')) {
      console.error(`invalid assign option "${arg}"`);
      return 2;
    }
    flags[arg.slice(2)] = rest[++i];
  }
  const removing = flags.remove !== undefined;
  const promoting = flags.promote !== undefined;
  if (clear && (engine || Object.keys(flags).length || add)) {
    console.error('use --clear without an engine or other options');
    return 2;
  }
  if (removing && (engine || Object.keys(flags).length > 1 || add)) {
    console.error('use --remove <tool> without other options');
    return 2;
  }
  if (promoting && (engine || Object.keys(flags).length > 1 || add)) {
    console.error('use --promote "<tool> [model]" without an engine or other options');
    return 2;
  }
  if (!clear && !removing && !promoting && !engine) {
    console.error(ASSIGN_USAGE);
    return 2;
  }
  try {
    setRosterPick(job, engine, { ...flags, clear, add, session, everywhere, now, note: (text) => console.log(text) }, root);
    printJobRoster(root, now);
    return 0;
  } catch (err) {
    console.error(err.message);
    return 2;
  }
}

function chartEngineLabel(engine) {
  const id = String(engine && (engine.id || engine.name) || '').trim();
  const models = Array.isArray(engine && engine.models)
    ? engine.models.map((model) => String(model || '').trim()).filter(Boolean)
    : [];
  return models.length ? `${id}: ${models.join(', ')}` : id;
}

function chartBox(title, engines, note = '', emptyLabel = 'unassigned') {
  const labels = engines.length ? engines.map(chartEngineLabel) : (emptyLabel ? [emptyLabel] : []);
  const body = [title, ...labels, ...(note ? [note] : [])];
  const innerWidth = Math.max(...body.map((line) => line.length)) + 2;
  return {
    width: innerWidth + 2,
    lines: [
      `┌${'─'.repeat(innerWidth)}┐`,
      ...body.map((line) => `│ ${line.padEnd(innerWidth - 2)} │`),
      `└${'─'.repeat(innerWidth)}┘`,
    ],
  };
}

function centerChartLine(line, width, center = Math.floor((width - 1) / 2)) {
  const left = Math.max(0, center - Math.floor(line.length / 2));
  return `${' '.repeat(left)}${line}`.padEnd(width);
}

function renderEngineChart(registry) {
  const engines = (Array.isArray(registry) ? registry : ((registry && registry.engines) || []))
    .filter((entry) => !HIDDEN_PROFILE_NAMES.includes(entry.id));
  const specialDuties = new Set(ENGINE_DUTIES);
  const leaders = engines.filter((entry) => entry.duty === 'leader');
  const rolePool = engines.filter((entry) => !specialDuties.has(entry.duty));
  const builders = rolePool.filter((entry) => Array.isArray(entry.roles) && entry.roles.includes('executor'));
  const checkers = rolePool.filter((entry) => Array.isArray(entry.roles) && entry.roles.includes('validator'));
  const errands = engines.filter((entry) => entry.duty === 'errands');
  const apprentices = engines.filter((entry) => entry.duty === 'learning');

  const ownerBox = chartBox('owner', [], '', '');
  const leaderBox = chartBox('leader', leaders);
  const columns = [
    chartBox('builders', builders),
    chartBox('checkers', checkers),
    chartBox('errands', errands),
  ];
  const gap = 3;
  const totalWidth = columns.reduce((sum, column) => sum + column.width, 0) + (gap * (columns.length - 1));
  const columnHeight = Math.max(...columns.map((column) => column.lines.length));
  const columnLines = [];
  for (let row = 0; row < columnHeight; row += 1) {
    columnLines.push(columns.map((column) => (column.lines[row] || '').padEnd(column.width)).join(' '.repeat(gap)));
  }

  const centers = [];
  let offset = 0;
  for (const column of columns) {
    centers.push(offset + Math.floor(column.width / 2));
    offset += column.width + gap;
  }
  const fleetCenter = centers[1];
  const branch = Array(totalWidth).fill(' ');
  for (let i = centers[0]; i <= centers[centers.length - 1]; i += 1) branch[i] = '─';
  branch[centers[0]] = '┌';
  branch[centers[centers.length - 1]] = '┐';
  for (const center of centers.slice(1, -1)) branch[center] = '┬';
  branch[fleetCenter] = centers.includes(fleetCenter) ? '┼' : '┴';
  const stems = Array(totalWidth).fill(' ');
  for (const center of centers) stems[center] = '│';

  const lines = [
    ...ownerBox.lines.map((line) => centerChartLine(line, totalWidth, fleetCenter)),
    centerChartLine('│', totalWidth, fleetCenter),
    ...leaderBox.lines.map((line) => centerChartLine(line, totalWidth, fleetCenter)),
    centerChartLine('│', totalWidth, fleetCenter),
    branch.join(''),
    stems.join(''),
    ...columnLines,
  ];
  if (apprentices.length) {
    const apprenticeBox = chartBox('apprentice', apprentices, 'learning the system');
    lines.push(centerChartLine('│', totalWidth, fleetCenter));
    lines.push(...apprenticeBox.lines.map((line) => centerChartLine(line, totalWidth, fleetCenter)));
  }
  return lines.map((line) => line.replace(/\s+$/, '')).join('\n');
}

function printEngineChart(root) {
  console.log(renderEngineChart(readEngineRegistry(root)));
}

function flagValue(args, flag) {
  const equals = `${flag}=`;
  for (let i = 0; i < args.length; i += 1) {
    const value = String(args[i] || '');
    if (value === flag) return { present: true, value: args[i + 1] || '' };
    if (value.startsWith(equals)) return { present: true, value: value.slice(equals.length) };
  }
  return { present: false, value: '' };
}

function runSetEngineCommand(args, root) {
  const name = String(args[0] || '').trim();
  const dutyFlag = flagValue(args.slice(1), '--duty');
  const modelsFlag = flagValue(args.slice(1), '--models');
  const duty = String(dutyFlag.value || '').trim();
  const models = String(modelsFlag.value || '').split(',').map((model) => model.trim()).filter(Boolean);
  if (!name || (!dutyFlag.present && !modelsFlag.present)) {
    console.error('usage: atris engine set <name> [--duty leader|errands|learning] [--models "a, b"]');
    return 2;
  }
  if (dutyFlag.present && !ENGINE_DUTIES.includes(duty)) {
    console.error(`unknown duty "${duty}". known duties: ${ENGINE_DUTIES.join(', ')}`);
    return 2;
  }
  if (modelsFlag.present && !models.length) {
    console.error('models must include at least one name');
    return 2;
  }
  try {
    const updated = setEngineOverrides(name, {
      ...(dutyFlag.present ? { duty } : {}),
      ...(modelsFlag.present ? { models } : {}),
    }, root);
    const details = [];
    if (updated.duty) details.push(`duty ${updated.duty}`);
    if (updated.models) details.push(`models ${updated.models.join(', ')}`);
    console.log(`${updated.id} updated: ${details.join('; ')}`);
    return 0;
  } catch (err) {
    console.error(String(err.message || err).replace(/^Unknown/, 'unknown'));
    return 2;
  }
}

function parseSetFlag(args) {
  const prefix = '--set=';
  for (let i = 0; i < args.length; i += 1) {
    const arg = String(args[i]);
    if (arg === '--set') return args[i + 1] || '';
    if (arg.startsWith(prefix)) return arg.slice(prefix.length);
  }
  return '';
}

// One worker as a person reads it: the tool, then its model and effort.
function notesWorkerText(worker) {
  const details = [worker.model, worker.effort ? `effort ${worker.effort}` : '', worker.installed ? '' : 'not installed'].filter(Boolean);
  return details.length ? `${worker.engine} (${details.join(', ')})` : worker.engine;
}

// The notes job: the roster's pick when one is set, else the built-in
// default. Always answers, so scripts can call it with a short timeout.
function runNotesResolve(json, root, now) {
  const answer = resolveNotesJob(root, { now });
  if (json) {
    console.log(JSON.stringify(answer));
    return 0;
  }
  const backup = answer.backup.length ? `backup ${answer.backup.map(notesWorkerText).join(', then ')}` : 'no backup';
  const where = answer.source === 'roster' ? `from ${answer.from}` : `built-in default${answer.skipped ? ` (${answer.skipped})` : ''}`;
  console.log(`notes: ${notesWorkerText(answer)}, ${backup}, ${where}`);
  return 0;
}

function runResolveCommand(args, root, now) {
  const json = args.includes('--json');
  const role = args.filter((a) => !String(a).startsWith('--'))[0] || '';
  if (role && rosterJobKey(role) === 'notes') return runNotesResolve(json, root, now);
  if (!role) {
    const message = `usage: atris engine resolve <role> or <job>; roles: ${ENGINE_ROLES.join(', ')}; jobs: search, build, review, or your own`;
    if (json) console.log(JSON.stringify({ ok: false, error: message }, null, 2));
    else console.error(message);
    return 2;
  }
  let picked;
  try {
    // A role (navigator, executor, validator) resolves as before; any job
    // name, built-in or the owner's own, resolves through its roster pick.
    const jobRole = ENGINE_ROLES.includes(String(role).trim().toLowerCase()) ? '' : rosterJobRole(role, root);
    if (!ENGINE_ROLES.includes(String(role).trim().toLowerCase()) && !jobRole) {
      throw new Error(`Unknown role "${role}". Known roles: ${ENGINE_ROLES.join(', ')}; jobs: search, build, review, or one set with atris engine assign`);
    }
    picked = jobRole
      ? resolveEngineForRoleRanked(jobRole, root, { job: role })
      : resolveEngineForRoleRanked(role, root);
  } catch (err) {
    if (json) console.log(JSON.stringify({ ok: false, error: err.message }, null, 2));
    else console.error(err.message);
    return 2;
  }
  const engine = picked.engine;
  if (!engine) {
    const message = `No ready installed engine can fill role "${role}".`;
    if (json) console.log(JSON.stringify({ ok: false, role, error: message, won_reason: picked.reason }, null, 2));
    else console.error(message);
    return 1;
  }
  if (json) console.log(JSON.stringify({ ...engine, won_reason: picked.reason }, null, 2));
  else {
    console.error(picked.reason);
    console.log(engine.id);
  }
  return 0;
}

// Doctor and roster both read saved health; when a probe once failed but the
// binary is present again, clear stale error so routing is not stuck forever.
function reconcileStaleEngineProbeErrors(root = process.cwd()) {
  for (const engine of engineRegistryView(root)) {
    const status = engine.health && engine.health.status;
    if (status !== 'error') continue;
    if (!binInstalled(engine.bin)) continue;
    try { setEngineHealth(engine.id, 'ready', root); } catch { /* best effort */ }
  }
}

// Doctor is the one opt-in place that probes the machine: it checks every
// engine binary, reports installed state, and folds ready/not_installed flips
// back into the policy file. Routing itself never probes.
function runDoctorCommand(args, root) {
  const json = args.includes('--json');
  reconcileStaleEngineProbeErrors(root);
  const engines = engineDoctorReport(root).map((engine) => {
    if (!engine.installed) return engine;
    const status = engine.health && engine.health.status;
    if (status !== 'error') return engine;
    try {
      const updated = setEngineHealth(engine.id, 'ready', root);
      return { ...engine, health: updated.health };
    } catch {
      return engine;
    }
  });
  if (json) {
    console.log(JSON.stringify({ ok: true, engines }, null, 2));
    return 0;
  }
  console.log('');
  for (const engine of engines.filter((engine) => !HIDDEN_PROFILE_NAMES.includes(engine.id))) {
    const state = engine.installed ? 'installed' : 'missing';
    const health = engine.health.status.replace(/_/g, ' ');
    console.log(`  ${engine.id.padEnd(12)} ${String(engine.bin).padEnd(14)} ${state.padEnd(10)} health: ${health}`);
  }
  console.log('');
  console.log('  probed just now and saved to the registry; routing reads that saved policy, never the machine.');
  console.log('');
  return 0;
}

function runHealthCommand(args, root) {
  const json = args.includes('--json');
  const positional = args.filter((a) => !String(a).startsWith('--'));
  const name = positional[0] || '';
  const status = parseSetFlag(args);
  if (!name || !status) {
    const message = `usage: atris engine health <name> --set <status>; statuses: ${ENGINE_HEALTH_STATUSES.join(', ')}`;
    if (json) console.log(JSON.stringify({ ok: false, error: message }, null, 2));
    else console.error(message);
    return 2;
  }
  try {
    const engine = setEngineHealth(name, status, root);
    if (json) console.log(JSON.stringify(engine, null, 2));
    else console.log(`engine ${engine.id} health: ${engine.health.status}`);
    return 0;
  } catch (err) {
    if (json) console.log(JSON.stringify({ ok: false, error: err.message }, null, 2));
    else console.error(err.message);
    return 2;
  }
}

// Preflight: run one engine CLI headless with a reply-OK prompt and report
// pass/fail. A dead login, missing binary, or hung spawn is a one-command
// diagnosis instead of a failed overnight flight. `name` is canonical.
const PROBE_PROMPT = 'Reply with exactly the two characters: OK';
// Real engines think before replying: cursor measured at ~68s for a one-word
// answer on 2026-07-02. 30s produced a false FAIL on a healthy engine.
const PROBE_DEFAULT_TIMEOUT_MS = 120000;

function probeEngine(name, { timeout = PROBE_DEFAULT_TIMEOUT_MS, root = process.cwd() } = {}) {
  const def = RUNNER_PROFILE_DEFS[name];
  if (!binInstalled(def.bin)) {
    return {
      engine: name,
      bin: def.bin,
      pass: false,
      reason: 'not-installed',
      message: `${def.bin} CLI not installed`,
      stdout: '',
      stderr: '',
      durationMs: 0,
    };
  }
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'atris-engine-probe-'));
  const promptFile = path.join(tmpDir, 'prompt.txt');
  fs.writeFileSync(promptFile, `${PROBE_PROMPT}\n`);
  let cmd;
  const prevProfile = process.env.ATRIS_RUNNER_PROFILE;
  process.env.ATRIS_RUNNER_PROFILE = name;
  try {
    cmd = buildRunnerCommand({ promptFile });
  } finally {
    if (prevProfile === undefined) delete process.env.ATRIS_RUNNER_PROFILE;
    else process.env.ATRIS_RUNNER_PROFILE = prevProfile;
  }
  // Machine memory and load at both ends of the probe, so one killed with
  // SIGKILL says whether the machine was short on memory.
  const endResource = require('../lib/engine-resource').startEngineRun(root, { engine: name, task: 'engine probe' });
  const start = Date.now();
  let res;
  try {
    res = spawnSync('sh', ['-c', cmd], { encoding: 'utf8', timeout });
  } catch (err) {
    endResource(err);
    fs.rmSync(tmpDir, { recursive: true, force: true });
    return {
      engine: name,
      bin: def.bin,
      pass: false,
      reason: 'spawn-error',
      message: String(err && err.message ? err.message : err),
      stdout: '',
      stderr: '',
      durationMs: Date.now() - start,
    };
  }
  const durationMs = Date.now() - start;
  // spawnSync does not throw, so a failure is passed in the thrown shape.
  const launchFailed = res.error || res.signal || res.status !== 0;
  const end = endResource(launchFailed ? {
    code: res.error && res.error.code,
    signal: res.signal,
    stderr: res.stderr,
    message: res.error ? res.error.message : `exit ${res.status}`,
  } : null);
  const cause = end && end.cause ? `; ${end.cause}` : '';
  fs.rmSync(tmpDir, { recursive: true, force: true });
  const stdout = res.stdout || '';
  const stderr = res.stderr || '';
  const timedOut = res.status === null && Boolean(res.signal) && String(res.signal).toLowerCase().includes('term');
  const combined = `${stdout}\n${stderr}`.trim();
  const ok = res.status === 0 && /OK/i.test(combined);
  let reason;
  if (ok) reason = 'ok';
  else if (timedOut) reason = 'timeout';
  else if (res.status !== 0 && res.status !== null) reason = 'bad-exit';
  else if (!/OK/i.test(combined)) reason = 'no-ok';
  else reason = 'unknown';
  return {
    engine: name,
    bin: def.bin,
    pass: ok,
    reason,
    message: ok
      ? 'responded OK'
      : (timedOut ? `no reply within ${timeout}ms` : `did not reply OK (exit ${res.status}, signal ${res.signal})${cause}`),
    stdout,
    stderr,
    durationMs,
  };
}

// A probe is a real engine round trip on the same command shape dispatches
// use, so its pass/fail and latency are routing evidence. Record one receipt
// per role the engine serves so the router brain (lib/router-brain.js) can
// learn from every preflight. Liveness evidence only: real build outcomes
// land in the same pool via task receipts and outweigh probes over time.
function writeProbeReceipt(result, root = process.cwd()) {
  const runsDir = path.join(root, 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  let roles = [];
  try {
    const engine = engineRegistryView(root).find((row) => row.id === result.engine);
    roles = engine && Array.isArray(engine.roles) ? engine.roles : [];
  } catch { /* registry unavailable: still record the probe */ }
  if (!roles.length) roles = ['executor'];
  const at = new Date().toISOString();
  const stampMs = Date.now();
  for (const role of roles) {
    const receipt = {
      schema: 'atris.engine_probe_receipt.v1',
      engine: result.engine,
      task_type: role,
      verified_passed: Boolean(result.pass),
      duration_ms: result.durationMs,
      reason: result.reason,
      at,
    };
    const file = path.join(runsDir, `engine-probe-task-${result.engine}-${role}-${stampMs}.json`);
    fs.writeFileSync(file, `${JSON.stringify(receipt, null, 2)}\n`);
  }
}

function runBenchCommand(args, root, deps = {}) {
  const probe = deps.probe || probeEngine;

  const names = [];
  let runs = 3;
  let timeout;
  let json = false;

  for (let i = 0; i < args.length; i += 1) {
    const a = args[i];
    if (a === '--runs') { runs = parseInt(args[i + 1] || '3', 10); i += 1; continue; }
    if (a.startsWith('--runs=')) { runs = parseInt(a.slice('--runs='.length), 10); continue; }
    if (a === '--timeout') { timeout = parseInt(args[i + 1] || '0', 10) * 1000; i += 1; continue; }
    if (a.startsWith('--timeout=')) { timeout = parseInt(a.slice('--timeout='.length), 10) * 1000; continue; }
    if (a === '--json') { json = true; continue; }
    if (a.startsWith('--')) continue;
    names.push(a);
  }

  let enginesToBench;
  if (names.length) {
    enginesToBench = names.map((n) => {
      const c = canonicalEngineName(n);
      if (!c) {
        throw new Error(`Unknown engine "${n}". Known engines: ${RUNNER_PROFILE_NAMES.join(', ')}`);
      }
      return c;
    });
  } else {
    enginesToBench = deps.installedEngines || RUNNER_PROFILE_NAMES.filter((n) => binInstalled(RUNNER_PROFILE_DEFS[n].bin));
    if (!enginesToBench.length) {
      if (json) {
        console.log(JSON.stringify({ ok: false, error: 'no installed engines to bench' }, null, 2));
      } else {
        console.error('\n  no installed engines to bench\n');
      }
      return 1;
    }
  }

  const probeOpts = { root };
  if (timeout) probeOpts.timeout = timeout;

  const results = [];
  let allHavePasses = true;

  for (const engine of enginesToBench) {
    const passedRuns = [];
    let passes = 0;
    for (let i = 0; i < runs; i += 1) {
      const res = probe(engine, probeOpts);
      if (res.pass) {
        passedRuns.push(res.durationMs);
        passes += 1;
      }
    }

    let medianMs = 0;
    let minMs = 0;
    let maxMs = 0;

    if (passes > 0) {
      passedRuns.sort((a, b) => a - b);
      minMs = passedRuns[0];
      maxMs = passedRuns[passedRuns.length - 1];
      const mid = Math.floor(passes / 2);
      medianMs = passes % 2 !== 0 ? passedRuns[mid] : (passedRuns[mid - 1] + passedRuns[mid]) / 2;
    } else {
      allHavePasses = false;
    }

    results.push({
      engine,
      passes,
      runs,
      medianMs,
      minMs,
      maxMs,
    });
  }

  results.sort((a, b) => {
    if (a.passes === 0 && b.passes !== 0) return 1;
    if (b.passes === 0 && a.passes !== 0) return -1;
    if (a.passes === 0 && b.passes === 0) return a.engine.localeCompare(b.engine);
    return a.medianMs - b.medianMs;
  });

  const stateFile = path.join(root, '.atris', 'state', 'engine-bench.latest.json');
  let previous = null;
  try {
    if (fs.existsSync(stateFile)) {
      previous = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    }
  } catch {
    // best-effort read
  }

  const stateObj = {
    at: new Date().toISOString(),
    runs,
    results,
  };

  try {
    fs.mkdirSync(path.dirname(stateFile), { recursive: true });
    fs.writeFileSync(stateFile, `${JSON.stringify(stateObj, null, 2)}\n`);
  } catch {
    // best-effort write
  }

  if (json) {
    console.log(JSON.stringify({ ...stateObj, previous }, null, 2));
    return allHavePasses ? 0 : 1;
  }

  console.log('');
  for (const r of results) {
    let deltaStr = '';
    if (previous && previous.results) {
      const prevRes = previous.results.find((pr) => pr.engine === r.engine);
      if (prevRes && prevRes.passes > 0 && r.passes > 0) {
        const diff = Math.round(r.medianMs - prevRes.medianMs);
        if (diff > 0) deltaStr = ` (slower by ${diff}ms)`;
        else if (diff < 0) deltaStr = ` (faster by ${Math.abs(diff)}ms)`;
        else deltaStr = ' (no change)';
      }
    }

    if (r.passes > 0) {
      const ms = Math.round(r.medianMs);
      console.log(`  ${r.engine.padEnd(12)} ${r.passes}/${r.runs} passes, median ${ms}ms${deltaStr}`);
    } else {
      console.error(`  ${r.engine.padEnd(12)} FAIL, 0/${r.runs} passes`);
    }
  }
  console.log('');

  return allHavePasses ? 0 : 1;
}

function runEngineTest(targets, { json, root } = {}) {
  let enginesToTest;
  if (targets && targets.length) {
    enginesToTest = targets.map((n) => {
      const c = canonicalEngineName(n);
      if (!c) {
        throw new Error(`Unknown engine "${n}". Known engines: ${RUNNER_PROFILE_NAMES.join(', ')}`);
      }
      return c;
    });
  } else {
    enginesToTest = RUNNER_PROFILE_NAMES.filter((n) => binInstalled(RUNNER_PROFILE_DEFS[n].bin));
    if (!enginesToTest.length) {
      if (json) {
        console.log(JSON.stringify({ ok: false, results: [], summary: { pass: 0, fail: 0 } }, null, 2));
      } else {
        console.error('\n  no installed engines to test\n');
      }
      return 1;
    }
  }
  const results = enginesToTest.map((name) => probeEngine(name, { root }));
  const failures = results.filter((r) => !r.pass);
  const passed = results.length - failures.length;
  // A live probe is the freshest health evidence there is: write it back so
  // a transient failure does not leave an engine stuck on error forever.
  for (const r of results) {
    try { setEngineHealth(r.engine, r.pass ? 'ready' : 'error', root); } catch { /* best-effort */ }
    if (r.reason !== 'not-installed') {
      try { writeProbeReceipt(r, root); } catch { /* best-effort */ }
    }
  }
  if (json) {
    console.log(JSON.stringify({
      ok: failures.length === 0,
      results,
      summary: { pass: passed, fail: failures.length },
    }, null, 2));
  } else {
    console.log('');
    for (const r of results) {
      const mark = r.pass ? '✓' : '✗';
      const line = r.pass
        ? `  ${mark} ${r.engine.padEnd(12)} pass, ${r.message} (${r.durationMs}ms)`
        : `  ${mark} ${r.engine.padEnd(12)} FAIL, ${r.message}`;
      if (r.pass) console.log(line);
      else console.error(line);
    }
    console.log('');
    if (failures.length) {
      console.error(`  ${failures.length} engine${failures.length === 1 ? '' : 's'} failed: ${failures.map((f) => f.engine).join(', ')}`);
      console.error(`  fix the login/binary, then re-run: atris engine test${targets && targets.length ? ' ' + targets.join(' ') : ''}`);
    } else {
      console.log(`  all engines responded, clear for flight`);
    }
    console.log('');
  }
  return failures.length ? 1 : 0;
}

// One-command dispatch: claim -> worktree start -> bounded prompt -> engine
// -> re-run Check: -> ship -> task ready, in one call instead of the 6
// hand-rolled Bash calls per task the manual version took. Task ids are
// positional; --engine/--prompt-file are the only flags, so parse by hand
// instead of the generic "anything starting with --" split used above (that
// split would swallow an --engine value like "cursor" as a task id).
function parseDispatchArgs(args) {
  const taskIds = [];
  let engine = '';
  let promptFile = '';
  let base = '';
  let json = false;
  let yolo = false;
  for (let i = 0; i < args.length; i += 1) {
    const a = args[i];
    if (a === '--engine') { engine = args[i + 1] || ''; i += 1; continue; }
    if (a.startsWith('--engine=')) { engine = a.slice('--engine='.length); continue; }
    if (a === '--prompt-file') { promptFile = args[i + 1] || ''; i += 1; continue; }
    if (a.startsWith('--prompt-file=')) { promptFile = a.slice('--prompt-file='.length); continue; }
    if (a === '--base') { base = args[i + 1] || ''; i += 1; continue; }
    if (a.startsWith('--base=')) { base = a.slice('--base='.length); continue; }
    if (a === '--json') { json = true; continue; }
    if (a === '--yolo') { yolo = true; continue; }
    if (a.startsWith('--')) continue;
    taskIds.push(a);
  }
  return { taskIds, engine, promptFile, base, json, yolo };
}

function runDispatchCommand(args, root) {
  const { taskIds, engine, promptFile, base, json, yolo } = parseDispatchArgs(args);
  if (!taskIds.length || !engine) {
    console.error('usage: atris engine dispatch <task-id> [<task-id> ...] --engine <engine> [--prompt-file <f>] [--yolo]');
    return 2;
  }
  const canonical = canonicalEngineName(engine);
  if (!canonical || !DISPATCH_CAPABLE.includes(canonical)) {
    console.error(`engine dispatch: --engine must be one of ${DISPATCH_CAPABLE.join(', ')}`);
    return 2;
  }
  // Argument-shape errors surface before environment errors: --prompt-file
  // with multiple ids is wrong on any machine, installed CLI or not.
  let promptOverride = '';
  if (promptFile) {
    if (taskIds.length > 1) {
      console.error('engine dispatch: --prompt-file only supports a single task id');
      return 2;
    }
    try {
      promptOverride = fs.readFileSync(promptFile, 'utf8');
    } catch (err) {
      console.error(`engine dispatch: could not read --prompt-file ${promptFile}: ${err.message}`);
      return 2;
    }
  }
  // Execution stage: this is where the binary must exist. Routing above never
  // probed the machine; a missing CLI fails loudly here instead.
  try {
    requireEngineBin(canonical);
  } catch (err) {
    const status = engineFailureHealthStatus({ status: 'errored', reason: err.message });
    if (status) {
      try { setEngineHealth(canonical, status, root); } catch { /* best effort */ }
    }
    console.error(canonical === 'fable'
      ? `fable handoff failed: ${err.message}`
      : `engine dispatch: ${err.message}`);
    return 2;
  }
  // The build line's model, effort, time cap, and prep job ride along when
  // the roster picks this same engine for build.
  const pin = rosterPinFor('executor', canonical, root);
  return runDispatchFlight({
    root,
    taskIds,
    engine: canonical,
    prompt: promptOverride,
    yolo,
    ...(base ? { checkoutBase: base } : {}),
    ...(pin.roster_model ? { model: pin.roster_model } : {}),
    ...(pin.roster_effort ? { effort: pin.roster_effort } : {}),
    ...(pin.roster_max_seconds ? { maxSeconds: pin.roster_max_seconds } : {}),
    ...(pin.roster_prep ? { prep: pin.roster_prep } : {}),
  }).then((flight) => {
    if (json) console.log(JSON.stringify(flight, null, 2));
    return flight.paused.length ? 1 : 0;
  });
}

const TASK_ID_TOKEN = /^[a-z][a-z0-9]*-\d+$/i;
const SHORTHAND_VALUE_FLAGS = new Set(['--model', '--concurrency', '--timeout', '--jobs', '--engine', '--engines']);

function shorthandPromptParts(args) {
  const parts = [];
  for (let index = 0; index < args.length; index += 1) {
    const value = String(args[index] || '');
    if (SHORTHAND_VALUE_FLAGS.has(value)) {
      index += 1;
      continue;
    }
    if (value.startsWith('--')) continue;
    parts.push(value);
  }
  return parts;
}

function shorthandModelError(engine, args, root) {
  const requested = flagValue(args, '--model');
  const model = String(requested.value || '').trim();
  if (!requested.present || !model) return '';
  try {
    buildReadOnlyEngineInvocation(engine, 'check model support', model);
    return '';
  } catch (error) {
    if (!error || error.reason !== 'model_not_supported') return '';
    const examples = engineRegistryView(root).find((entry) => entry.id === engine)?.models || [];
    const known = examples.length ? examples.join(', ') : 'use the engine default';
    return `${error.message}. known-good ${engine} examples: ${known}`;
  }
}

function formatAgentAge(seconds) {
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days) return `${days}d ${hours % 24}h`;
  if (hours) return `${hours}h ${minutes % 60}m`;
  return `${minutes}m`;
}

// atris engine sweep: list ssh-agents that engine shells started and left
// behind. With --apply it rechecks each one and stops it with SIGTERM, and
// writes a parent gone end line for each run whose parent process is gone.
function runEngineSweepCommand(args, root, deps = {}) {
  const { readSshAgents, findLeakedSshAgents, findAgentStartLines, agentStartLineText, stopLeakedSshAgents, closeLostRuns, readResourceHistory, leakGrowthNote, LEAK_MIN_AGE_SEC } = require('../lib/engine-resource');
  const read = deps.read || readSshAgents;
  const { agents, referenced, unread = [] } = read();
  const uid = deps.uid !== undefined ? deps.uid : process.getuid();
  const leaked = findLeakedSshAgents(agents, { referenced, uid });
  const apply = args.includes('--apply');
  const result = apply
    ? stopLeakedSshAgents(root, leaked, { read, uid, ...(deps.kill ? { kill: deps.kill } : {}), ...(deps.now ? { now: deps.now } : {}) })
    : { stopped: [], failed: [], skipped: [] };
  result.unread = [...new Set([...unread, ...(result.unread || [])])];
  const scanWarning = result.unread.length
    ? `could not read the ${result.unread.join(' or the ')} for every process, so some ssh-agents could not be checked; the leak count may be incomplete`
    : null;
  result.closed_runs = [];
  if (apply) {
    // Agents may already be stopped here, so a failed close is reported
    // beside them rather than thrown away with the whole report.
    try {
      result.closed_runs = closeLostRuns(root, deps.now ? { now: deps.now } : {});
    } catch (err) {
      result.close_error = String((err && err.message) || err).slice(0, 200);
    }
  }
  // A test run reads only the home it was handed, never the real one.
  const startLines = leaked.length && (deps.home || !process.env.NODE_TEST_CONTEXT)
    ? findAgentStartLines(deps.home ? { home: deps.home } : {})
    : [];
  const code = result.failed.length || result.close_error ? 1 : 0;
  if (args.includes('--json')) {
    console.log(JSON.stringify({ running: agents.length, leaked, unread, ...result, agent_start_lines: startLines, history: readResourceHistory(root) }, null, 2));
    return code;
  }
  const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
  if (apply) {
    const lines = [`stopped ${plural(result.stopped.length, 'leaked ssh-agent')}`];
    const replaced = (result.replaced || []).length;
    const otherSkipped = result.skipped.length - replaced;
    if (replaced) lines.push(`${replaced} skipped because ${replaced === 1 ? 'a younger ssh-agent now has' : 'younger ssh-agents now have'} the same process number`);
    if (otherSkipped) lines.push(`${otherSkipped} skipped because they were in use or gone on the recheck`);
    for (const { pid, code: reason } of result.failed) lines.push(`could not stop pid ${pid}: ${reason}`);
    if (result.close_error) lines.push(`could not close lost runs, so unfinished records may remain: ${result.close_error}`);
    else lines.push(`closed ${plural(result.closed_runs.length, 'run')} whose parent is gone`);
    if (scanWarning) lines.push(scanWarning);
    console.log(lines.join('\n'));
    return code;
  }
  const shown = 20;
  const history = readResourceHistory(root);
  const lines = [
    `${plural(agents.length, 'ssh-agent')} running, ${leaked.length} ${leaked.length === 1 ? 'looks' : 'look'} leaked${leakGrowthNote(history.first_day_leak_reading, leaked.length)}`
      + ` (no parent, older than ${LEAK_MIN_AGE_SEC / 60} min, not in use by any live shell)`,
    ...leaked.slice(0, shown).map((agent) => `  pid ${String(agent.pid).padEnd(6)} ${formatAgentAge(agent.age_sec)}`),
  ];
  if (leaked.length > shown) lines.push(`  and ${leaked.length - shown} more`);
  lines.push(...startLines.map(agentStartLineText));
  if (scanWarning) lines.push(scanWarning);
  lines.push(leaked.length ? 'nothing was stopped. run atris engine sweep --apply to stop them.' : 'nothing was stopped.');
  lines.push('', ...resourceHistoryLines(history));
  console.log(lines.join('\n'));
  return 0;
}

function utcMinute(at) {
  return `${String(at || '').slice(0, 16).replace('T', ' ')} UTC`;
}

// What the resource log says about past runs: the newest sweep, runs with no
// end, the newest run that failed without being killed and why, the newest
// SIGKILL and its likely cause, and how many SIGKILLs came with low memory.
function resourceHistoryLines(history) {
  const { errorReason } = require('../lib/engine-resource');
  const lines = [];
  if (history.read_error) {
    lines.push(`could not read the engine run log: ${history.read_error}, so past sweeps, kills, and errors are unknown`);
    return lines;
  }
  const sweep = history.last_sweep;
  lines.push(sweep
    ? `last sweep: ${utcMinute(sweep.at)}, stopped ${(sweep.stopped || []).length}`
    : 'no sweep recorded yet');
  const started = history.last_open;
  if (started) {
    const unrecorded = history.open_runs - history.parent_gone - history.still_running;
    const parts = [
      history.parent_gone && `${history.parent_gone} whose parent is gone`,
      history.still_running && `${history.still_running} still running`,
      unrecorded && `${unrecorded} from before parents were recorded`,
    ].filter(Boolean);
    lines.push(`${history.open_runs} run${history.open_runs === 1 ? '' : 's'} started with no end recorded: ${parts.join(', ')};`
      + ` newest: ${started.engine || 'engine'} on ${started.task || 'an unnamed task'} at ${utcMinute(started.at)}`);
  }
  const failed = history.last_error;
  if (failed) {
    lines.push(`last engine error: ${failed.engine || 'engine'} on ${failed.task || 'an unnamed task'} at ${utcMinute(failed.at)}: ${errorReason(failed)}`);
  }
  const kill = history.last_kill;
  if (!kill) {
    lines.push('no engine run has ended in SIGKILL');
    return lines;
  }
  const killLine = (entry) => {
    const free = Number.isFinite(entry.free_pct) ? `, ${entry.free_pct}% memory free` : '';
    return `${entry.engine || 'engine'} on ${entry.task || 'an unnamed task'} at ${utcMinute(entry.at)}, ${entry.cause}${free}`;
  };
  lines.push(`last SIGKILL: ${killLine(kill)}`);
  // Timeouts can pile up after a crash; still name the newest kill that was not one.
  const other = history.last_other_kill;
  if (other && other !== kill) lines.push(`last SIGKILL not at a time limit: ${killLine(other)}`);
  const timeLimit = history.time_limit_kills ? `, ${history.time_limit_kills} at their time limit` : '';
  lines.push(`${history.low_memory_kills} of ${history.kills} SIGKILL${history.kills === 1 ? '' : 's'} ended with machine memory low${timeLimit}`);
  return lines;
}

function engineCommand(args = [], deps = {}) {
  const root = deps.root || process.cwd();
  const dispatch = deps.engineDispatch || runDispatchCommand;
  if ((args[0] || '').trim() === 'ask') {
    return runEngineAskCommand(args.slice(1), root, deps.engineAsk || {});
  }
  if ((args[0] || '').trim() === 'watch') {
    return runEngineWatchCommand(args.slice(1), root, deps.engineWatch || {});
  }
  if ((args[0] || '').trim() === 'sweep') {
    return runEngineSweepCommand(args.slice(1), root, deps.engineSweep || {});
  }
  if ((args[0] || '').trim() === 'validate') {
    return runEngineValidateCommand(args.slice(1), root, deps.engineValidate || {});
  }
  if ((args[0] || '').trim() === 'dispatch') {
    return dispatch(args.slice(1), root);
  }

  const requestedEngine = (args[0] || '').trim();
  if (canonicalEngineName(requestedEngine) && args.length > 1) {
    const canonical = canonicalEngineName(requestedEngine);
    const shorthandArgs = args.slice(1);
    const promptParts = shorthandPromptParts(shorthandArgs);
    if (TASK_ID_TOKEN.test(promptParts[0] || '')) {
      if (shorthandArgs.length !== 1) {
        console.error('engine shorthand: a task id cannot include prompt text or flags; pick one: ask a question or build the task');
        return 2;
      }
      return dispatch([promptParts[0], '--engine', canonical], root);
    }
    const modelError = shorthandModelError(canonical, shorthandArgs, root);
    if (modelError) {
      console.error(`engine ask: ${modelError}`);
      return 2;
    }
    return runEngineAskCommand([...shorthandArgs, '--engine', canonical], root, deps.engineAsk || {});
  }

  const scope = parseScopeFlag(args);
  const json = scope.args.includes('--json') || args.includes('--json');
  const positional = scope.args.filter((a) => !a.startsWith('--'));
  const sub = (positional[0] || '').trim();

  if (sub === 'roster') return runRosterCommand(scope.args.slice(scope.args.indexOf('roster') + 1), root, deps.now);
  if (sub === 'assign') return runAssignCommand(scope.args.slice(scope.args.indexOf('assign') + 1), root, deps.now);

  if (sub === 'login') {
    return runEngineLoginCommand(scope.args.slice(scope.args.indexOf('login') + 1), root);
  }

  if (sub === 'seed') {
    return runEngineSeedCommand(scope.args.slice(scope.args.indexOf('seed') + 1), root);
  }

  if (sub === 'seats') {
    return runEngineSeatsCommand(deps);
  }

  if (sub === 'test') {
    return runEngineTest(positional.slice(1), { json, root });
  }

  if (sub === 'bench') {
    return runBenchCommand(scope.args.slice(scope.args.indexOf('bench') + 1), root, deps);
  }

  if (sub === 'resolve') {
    return runResolveCommand(scope.args.slice(scope.args.indexOf('resolve') + 1), root, deps.now);
  }

  if (sub === 'health') {
    return runHealthCommand(scope.args.slice(scope.args.indexOf('health') + 1), root);
  }

  if (sub === 'doctor') {
    return runDoctorCommand(scope.args.slice(scope.args.indexOf('doctor') + 1), root);
  }

  if (sub === 'set') {
    return runSetEngineCommand(scope.args.slice(scope.args.indexOf('set') + 1), root);
  }

  if (sub === 'chart' || scope.args.includes('--chart') || args.includes('--chart')) {
    if (isFreshWorkspace(root)) {
      return speakFirstMinute({ root, fresh: true, asJson: json });
    }
    printEngineChart(root);
    return 0;
  }

  if (!sub || sub === 'list' || sub === 'status' || sub === 'help') {
    if (sub === 'help' || args.includes('--help') || args.includes('-h')) {
      console.log('\n  atris engine watch [<id>|latest] [--no-follow]\n                           follow one live transcript or list running engine work');
      console.log('\n  long read-only asks: atris engine ask "..." --engine agy --timeout <seconds>\n                           quick asks default to 120 seconds; explicit jobs allow up to 3600\n                           follow live work with atris engine watch latest');
      console.log('\n  atris engine            roster + current default\n  atris engine roster [--json] show every job and its workers in order: search, build, review, and your own\n                           flags a model with a newer version on this machine, or a pin not proven in 30 days\n                           (a landed run, or "verified 2026-09-30" on its line, proves it)\n  atris engine roster confirm renew every dated worker for 30 days\n  atris engine roster session [clear]\n                           show or drop the roster changes for this shell only\n  atris engine roster --available\n                           tools on this machine and the models each one offers\n  atris engine roster set <job> <tool> <model>\n                           swap the lead of a job to a tool and model this machine offers; the old lead becomes the first backup\n  atris engine roster set --member <name> <tool> <model>\n                           give one member its own model; every other job stays put\n  atris engine roster --runs [job]\n                           the last 20 runs, newest first, with tool, model, time, and outcome\n  atris engine assign <job> <tool> [--like <kind>] [--model <m>] [--effort <level>] [--max "20 min"] [--prep <job>] [--backup "<tool> [model]"] [--days <n>] [--add] [--session | --everywhere]\n  atris engine assign <job> --promote "<tool> [model]" | --remove <tool> | --clear [--session | --everywhere]\n                           sets the lead worker of the job; --promote moves one of its workers to the top as written;\n                           --add puts one more at the end; jobs: search, build, review,\n                           or your own like "small build" (--like search|build|review when the name does not say);\n                           --prep search has that job read the task first and hand this worker a short brief;\n                           --everywhere is for all projects; --session is this shell only (set ATRIS_ROSTER_SESSION=<name>)\n  atris engines --chart   show the fleet as an org chart\n  atris engine list --json [--all] full registry: default + engines with tier, roles, fallback, health (--all includes hidden engines)\n  atris engine set <name> --duty leader|errands|learning [--models "a, b"]\n                           arrange the fleet and save its model policy\n  atris engine resolve <role> or <job> [--json]\n                           choose the best ready engine for navigator|executor|validator or a roster job;\n                           notes always answers: its roster pick, else agy then haiku\n  atris engine health <name> --set ready|not_installed|credit_out\n                           flip runtime health, for example when credits run out\n  atris engine doctor [--json]\n                           probe which engine CLIs are installed here and sync that into health policy\n  atris engine <name>     make that engine the default here\n  atris engine test [name] preflight: run the engine CLI headless, report pass/fail\n  atris engine bench [names...] [--runs N]\n                           ranked latency scoreboard of engine passes\n  atris engine ask "<question>" --engine <name> [--engine <name> ...]\n                           ask several engines in parallel without allowing edits\n  atris engine ask --jobs <jobs.json>\n                           ask different read-only questions in parallel\n  atris engine validate <receipt-path|latest> [--engine <name>]\n                           check ask answers with a different read-only referee\n  atris engine validate scoreboard\n                           show pass rates by worker engine\n  atris engine sweep [--apply] [--json]\n                           list ssh-agents that engine shells left running; --apply rechecks and stops them\n  atris engine dispatch <task-id> [<task-id> ...] --engine cursor|codex [--prompt-file <f>] [--yolo]\n                           one-command claim, worktree, build, verify, ship, ready\n  atris engine login <provider> --yes\n                           upload a local provider CLI login to the backend vault\n  atris engine login <provider> --computer [--seat <name>]\n  atris engine login <provider> --business <id> [--seat <name>]\n                           sign in on an Atris computer by device flow\n  atris engine login --list | --remove <provider>\n                           list or remove vaulted provider logins\n  atris engine seats       show which named accounts are ready to work\n  atris engine seed <provider> --business <id>|--user\n                           push a vaulted login onto an Atris computer\n  atris engine reset      back to the house default\n  --engine <name>         one run on that engine (mission run / autopilot / run)\n');
      return 0;
    }
    if (isFreshWorkspace(root)) {
      return speakFirstMinute({ root, fresh: true, asJson: json });
    }
    if (json) {
      console.log(JSON.stringify(registryPayload(root, { scope: scope.kind, includeHidden: args.includes('--all') }), null, 2));
      return 0;
    }
    printRoster(root, { scope: scope.kind });
    return 0;
  }

  if (sub === 'reset' || sub === 'off') {
    const removed = resetEngine(root);
    console.log(removed
      ? `\n  default engine reset, back to ${resolveDefaultEngine(root).name}\n`
      : `\n  nothing to reset, no engine was set here\n`);
    return 0;
  }

  // atris engine <name>: flip the default. An unknown name is a plain user
  // typo, not a crash: report it cleanly (and as JSON on demand) instead of
  // letting setEngine throw a raw stack trace at a new person.
  if (!canonicalEngineName(sub)) {
    const known = RUNNER_PROFILE_NAMES.join(', ');
    if (json) {
      console.log(JSON.stringify({ ok: false, error: `Unknown engine "${sub}"`, known: RUNNER_PROFILE_NAMES }, null, 2));
    } else {
      console.error(`\n  Unknown engine "${sub}". known engines: ${known}`);
      console.error('  run "atris engine" to see the roster, or "atris engine help".\n');
    }
    return 2;
  }
  const canonical = setEngine(sub, root);
  console.log(`default engine changed to ${canonical}`);
  console.log(`ask a question: atris engine ask "..." --engine ${canonical}`);
  console.log(`dispatch a build: atris engine dispatch <task> --engine ${canonical}`);
  return 0;
}

module.exports = {
  engineCommand,
  resolveDefaultEngine,
  canonicalEngineName,
  readSavedEngine,
  roster,
  rosterReport,
  renderRosterReport,
  jobRosterView,
  expiringWorkers,
  bootExpiringLine,
  engineRegistryFile,
  readEngineRegistry,
  resolveEngineForRole,
  setEngineHealth,
  setEngineOverrides,
  renderEngineChart,
  parseDispatchArgs,
  runDispatchCommand,
  runBenchCommand,
  ENGINE_LOGIN_MANIFESTS,
  expandHomePath,
  normalizeLoginProvider,
  normalizeEngineLoginSeat,
  validEngineLoginSeat,
  engineLoginSeatError,
  parseEngineLoginArgs,
  listEngineSeats,
  readyCheckEngineLogin,
  formatEngineSeats,
  runEngineDeviceLoginCommand,
  runEngineLoginCommand,
  runEngineSeedCommand,
  HOUSE_ENGINE,
};
