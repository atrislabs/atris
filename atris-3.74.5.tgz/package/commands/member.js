const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { execFileSync, spawnSync } = require('child_process');
const { loadCredentials } = require('../utils/auth');
const { resolveBackendRoot } = require('../utils/backend-root');
const { apiRequestJson } = require('../utils/api');
const { runAliveTick } = require('../lib/member-alive');
const { memberRefusalReason } = require('../lib/member-type');
const { callerRuntime, defaultObjectiveRunner } = require('../lib/default-runner');
const { readJson, writeJson } = require('../lib/json-file');
const { sleepSync } = require('../lib/sleep-sync');
const { hasFlag, readFlag, readNumberFlag } = require('../lib/arg-parser');
const { ensureMemberBundle, memberBundlePresent, updateMemberSkills } = require('../lib/member-scaffold');
const { memberProcessPrompt, MEMBER_PROCESS_PATH } = require('../lib/member-context');

function findWorkspaceBusinessId(startDir = process.cwd()) {
  let dir = path.resolve(startDir);
  while (true) {
    const file = path.join(dir, '.atris', 'business.json');
    if (fs.existsSync(file)) {
      try {
        return JSON.parse(fs.readFileSync(file, 'utf8')).business_id || null;
      } catch (error) {
        console.warn(`Warning: could not parse ${file}: ${error.message}`);
        return null;
      }
    }
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

function todayLogName() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}.md`;
}

function ensureMemberLog(memberDir, { name, role, description, source = 'cli' } = {}) {
  const logsDir = path.join(memberDir, 'logs');
  fs.mkdirSync(logsDir, { recursive: true });
  const logPath = path.join(logsDir, todayLogName());
  if (fs.existsSync(logPath)) return logPath;
  const stamp = new Date().toTimeString().slice(0, 5);
  const content = [
    `## ${stamp} · Member initialized`,
    `- team: ${name || path.basename(memberDir)}`,
    role ? `- role: ${role}` : '',
    description ? `- mission: ${description}` : '',
    `- source: ${source}`,
    '- status: ready_for_room',
  ].filter(Boolean).join('\n') + '\n';
  fs.writeFileSync(logPath, content, 'utf8');
  return logPath;
}

function appendMemberLifecycleLog(memberDir, name, action, detail = '') {
  const logsDir = path.join(memberDir, 'logs');
  fs.mkdirSync(logsDir, { recursive: true });
  const logPath = path.join(logsDir, todayLogName());
  const stamp = new Date().toTimeString().slice(0, 5);
  const content = [
    `## ${stamp} · Member ${action}`,
    `- team: ${name || path.basename(memberDir)}`,
    detail ? `- detail: ${detail}` : '',
    `- status: ${action}`,
    '',
  ].filter(Boolean).join('\n');
  fs.appendFileSync(logPath, content, 'utf8');
  return logPath;
}

function archiveName(name) {
  return `${name}-${todayLogName().replace(/\.md$/, '')}`;
}

function uniqueArchiveDir(archiveRoot, name) {
  const base = archiveName(name);
  let candidate = path.join(archiveRoot, base);
  let i = 2;
  while (fs.existsSync(candidate)) {
    candidate = path.join(archiveRoot, `${base}-${i}`);
    i += 1;
  }
  return candidate;
}

function parseDaysFlag(flags, fallback = 60) {
  const joined = flags.join(' ');
  const match = joined.match(/--days[=\s]+(\d+)/);
  const days = match ? Number(match[1]) : fallback;
  return Number.isFinite(days) && days >= 0 ? days : fallback;
}

function parseConfirmFlag(flags) {
  const joined = flags.join(' ');
  return joined.match(/--confirm[=\s]+["']?([^"']+)["']?/)?.[1] || '';
}

function readRepeatedFlag(args, name) {
  const values = [];
  const prefix = `${name}=`;
  for (let i = 0; i < args.length; i += 1) {
    const arg = String(args[i]);
    if (arg === name && args[i + 1] && !String(args[i + 1]).startsWith('--')) {
      values.push(String(args[i + 1]).replace(/^["']|["']$/g, ''));
      i += 1;
      continue;
    }
    if (arg.startsWith(prefix)) values.push(arg.slice(prefix.length).replace(/^["']|["']$/g, ''));
  }
  return values.filter(Boolean);
}

function stripKnownFlags(args, valueNames, booleanNames = []) {
  const out = [];
  const valueSet = new Set(valueNames);
  const booleanSet = new Set(['--full', '--verbose', ...booleanNames]);
  for (let i = 0; i < args.length; i += 1) {
    const arg = String(args[i]);
    const key = arg.includes('=') ? arg.slice(0, arg.indexOf('=')) : arg;
    if (booleanSet.has(key)) continue;
    if (valueSet.has(key)) {
      if (!arg.includes('=') && args[i + 1] && !String(args[i + 1]).startsWith('--')) i += 1;
      continue;
    }
    out.push(args[i]);
  }
  return out;
}

function stampIso() {
  return new Date().toISOString();
}

function fileSafeStamp() {
  return stampIso().replace(/[:.]/g, '-');
}

function slugHash(value) {
  return crypto.createHash('sha1').update(String(value || '')).digest('hex').slice(0, 8);
}

function makeGoalId(title) {
  return `goal-${todayLogName().replace(/\.md$/, '')}-${slugHash(title)}`;
}

function uniqueGoalId(state, baseId) {
  const existingIds = new Set((state.goals || []).map((goal) => goal.id).filter(Boolean));
  if (!existingIds.has(baseId)) return baseId;
  let index = 2;
  let id = `${baseId}-${index}`;
  while (existingIds.has(id)) {
    index += 1;
    id = `${baseId}-${index}`;
  }
  return id;
}

function makeExperimentId(goalId, title) {
  return `exp-${slugHash(`${goalId}:${title}:${Date.now()}`)}`;
}

const MEMBER_RUNTIME_ALIASES = Object.freeze({
  'problem-finder': 'signal-scout',
  'info-organizer': 'wiki-miner',
  coordinator: 'supervisor',
  'task-planner': 'objective-generator',
  improver: 'architect',
  'problem-solver': 'generalist',
});

function memberRuntimeKind(name) {
  const key = lowerCompact(name);
  return MEMBER_RUNTIME_ALIASES[key] || key;
}

function resolveMemberRuntime(name) {
  const requestedName = String(name || '').trim();
  const requestedPaths = memberPaths(requestedName);
  const runtimeKind = memberRuntimeKind(requestedName);
  const aliasOf = runtimeKind !== lowerCompact(requestedName) ? runtimeKind : null;
  if (requestedName && fs.existsSync(requestedPaths.memberFile)) {
    return {
      requestedName,
      storageName: requestedName,
      runtimeKind,
      aliasOf,
      paths: requestedPaths,
    };
  }
  if (aliasOf) {
    const legacyPaths = memberPaths(runtimeKind);
    if (fs.existsSync(legacyPaths.memberFile)) {
      return {
        requestedName,
        storageName: runtimeKind,
        runtimeKind,
        aliasOf,
        paths: legacyPaths,
      };
    }
  }
  return {
    requestedName,
    storageName: requestedName,
    runtimeKind,
    aliasOf,
    paths: requestedPaths,
  };
}

function memberPaths(name) {
  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const memberDir = path.join(teamDir, name || '');
  // Steering signals live in the workspace's single .atris/state store. Resolve
  // the shared workspace root (spine -> git -> cwd) so a member run from a
  // subdirectory reads steering from the real store instead of a nonexistent
  // nested .atris, the same resolver the mission/task/usage/autopilot state
  // uses. (teamDir markdown discovery is a separate cwd concern, filed.)
  const workspaceRoot = require('../lib/mission-root').resolveWorkspaceRoot(process.cwd());
  return {
    teamDir,
    memberDir,
    memberFile: path.join(memberDir, 'MEMBER.md'),
    missionFile: path.join(memberDir, 'MISSION.md'),
    goalsJson: path.join(memberDir, 'goals.json'),
    goalsMd: path.join(memberDir, 'goals.md'),
    steeringJsonl: path.join(workspaceRoot, '.atris', 'state', 'steering.jsonl'),
  };
}

function missionFileMarkdown({ name, role, description } = {}) {
  const title = role || name || 'Member';
  const purpose = description || `Define why ${name || 'this member'} exists and how it chooses goals.`;
  return [
    '# Mission',
    '',
    '<!-- Human-authored purpose file. Keep this durable; runtime state belongs in .atris/state/*.jsonl and now.md. -->',
    '',
    '## North Star',
    '',
    purpose,
    '',
    '## How To Choose Goals',
    '',
    `- Use MEMBER.md to stay inside ${title}'s identity, authority, and tools.`,
    '- Choose one useful bounded goal toward this mission.',
    '- Verify the work, write the receipt, and update the log.',
    '- Ask the human when vision, taste, risk, or uncertainty matters.',
    '',
  ].join('\n');
}

function ensureMissionFile(memberDir, { name, role, description } = {}) {
  const missionPath = path.join(memberDir, 'MISSION.md');
  if (!fs.existsSync(missionPath)) {
    fs.writeFileSync(missionPath, missionFileMarkdown({ name, role, description }), 'utf8');
  }
  return missionPath;
}

function listExistingMemberSlugs() {
  const teamDir = path.join(process.cwd(), 'atris', 'team');
  try {
    return fs.readdirSync(teamDir, { withFileTypes: true })
      .filter(entry => entry.isDirectory() && !entry.name.startsWith('_'))
      .map(entry => entry.name)
      .filter(slug => fs.existsSync(path.join(teamDir, slug, 'MEMBER.md')))
      .sort();
  } catch {
    return [];
  }
}

function editDistance(a, b) {
  const rows = a.length + 1;
  const cols = b.length + 1;
  const dist = Array.from({ length: rows }, (_, i) => [i, ...Array(cols - 1).fill(0)]);
  for (let j = 0; j < cols; j++) dist[0][j] = j;
  for (let i = 1; i < rows; i++) {
    for (let j = 1; j < cols; j++) {
      dist[i][j] = Math.min(
        dist[i - 1][j] + 1,
        dist[i][j - 1] + 1,
        dist[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
  }
  return dist[rows - 1][cols - 1];
}

function nearestMemberSlug(name, slugs) {
  const needle = String(name || '').toLowerCase();
  let best = null;
  let bestScore = Infinity;
  for (const slug of slugs) {
    const score = editDistance(needle, slug.toLowerCase());
    if (score < bestScore) {
      best = slug;
      bestScore = score;
    }
  }
  return bestScore <= Math.max(2, Math.floor(needle.length / 3)) ? best : null;
}

// A person is never run as an agent. Reads the member's own type and returns
// the plain refusal sentence, or '' when the member can run.
function memberRefusalFor(name, memberFile) {
  try {
    return memberRefusalReason(name, parseFrontmatter(fs.readFileSync(memberFile, 'utf8')) || {});
  } catch {
    return '';
  }
}

// Same as requireMemberDir, then stops with a non-zero exit for a human or
// odd-typed member. Every path that runs a member as an agent starts here.
function requireRunnableMember(name) {
  const paths = requireMemberDir(name);
  const reason = memberRefusalFor(name, paths.memberFile);
  if (reason) {
    console.error(reason);
    process.exit(1);
  }
  return paths;
}

function requireMemberDir(name) {
  if (!name) {
    console.error('Usage: atris member <goal|tick|review> <name> ...');
    process.exit(1);
  }
  if (!/^[a-zA-Z0-9._-]+$/.test(name)) {
    console.error('Member name must be a local slug: letters, numbers, dots, underscores, or dashes.');
    process.exit(1);
  }
  const resolved = resolveMemberRuntime(name);
  const paths = resolved.paths;
  if (!fs.existsSync(paths.memberFile)) {
    const aliasHint = resolved.aliasOf ? ` or atris/team/${resolved.aliasOf}/MEMBER.md` : '';
    console.error(`Member "${name}" not found at atris/team/${name}/MEMBER.md${aliasHint}`);
    const team = listExistingMemberSlugs();
    const nearest = nearestMemberSlug(name, team);
    if (nearest) {
      console.error(`Did you mean "${nearest}"?`);
    } else if (team.length) {
      console.error(`Team here: ${team.join(', ')}`);
    } else {
      console.error(`No team members exist here yet. Create one: atris member create ${name} --role="..."`);
    }
    process.exit(1);
  }
  return {
    ...paths,
    requestedName: resolved.requestedName,
    storageName: resolved.storageName,
    runtimeKind: resolved.runtimeKind,
    aliasOf: resolved.aliasOf,
  };
}

function emptyMemberGoals(name) {
  return {
    schema: 'atris.member_goals.v1',
    member: name,
    updated_at: stampIso(),
    goals: [],
  };
}

function loadMemberGoals(name, paths = memberPaths(name)) {
  const parsed = readJson(paths.goalsJson, {}) || {};
  return {
    ...emptyMemberGoals(name),
    ...parsed,
    goals: Array.isArray(parsed.goals) ? parsed.goals : [],
  };
}

function activeGoal(goalsState, goalId = '') {
  if (goalId) return goalsState.goals.find((goal) => goal.id === goalId) || null;
  for (let i = (goalsState.goals || []).length - 1; i >= 0; i -= 1) {
    if (goalsState.goals[i]?.status === 'active') return goalsState.goals[i];
  }
  return goalsState.goals[0] || null;
}

function allExperiments(state) {
  const out = [];
  for (const goal of state.goals || []) {
    for (const experiment of goal.experiments || []) out.push({ goal, experiment });
  }
  return out;
}

function findExperiment(state, experimentId) {
  for (const item of allExperiments(state)) {
    if (item.experiment.id === experimentId) return item;
  }
  return { goal: null, experiment: null };
}

function latestByTime(items, field = 'created_at') {
  return items
    .filter(Boolean)
    .slice()
    .sort((a, b) => String(b[field] || '').localeCompare(String(a[field] || '')))[0] || null;
}

function recentLogLines(memberDir, maxLines = 8) {
  const logsDir = path.join(memberDir, 'logs');
  if (!fs.existsSync(logsDir)) return [];
  const logs = fs.readdirSync(logsDir)
    .filter((name) => /^\d{4}-\d{2}-\d{2}\.md$/.test(name))
    .sort();
  const latest = logs[logs.length - 1];
  if (!latest) return [];
  return fs.readFileSync(path.join(logsDir, latest), 'utf8')
    .split(/\r?\n/)
    .filter((line) => line.trim())
    .slice(-maxLines);
}

function readOptionalText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function extractMarkdownSection(text, heading) {
  const lines = String(text || '').split(/\r?\n/);
  const target = String(heading || '').trim().toLowerCase();
  const start = lines.findIndex((line) => {
    const match = line.match(/^##\s+(.+?)\s*$/);
    return match && match[1].trim().toLowerCase() === target;
  });
  if (start === -1) return '';
  const out = [];
  for (let i = start + 1; i < lines.length; i += 1) {
    if (/^##\s+/.test(lines[i])) break;
    out.push(lines[i]);
  }
  return out.join('\n').trim();
}

function firstUsefulLine(text) {
  return String(text || '')
    .split(/\r?\n/)
    .map((line) => line.replace(/^[-*]\s+/, '').trim())
    .find((line) => line && !line.startsWith('<!--')) || '';
}

function compactSentence(text, max = 120) {
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (clean.length <= max) return clean;
  // Cut at a word boundary so titles never end mid-word ("rollb...").
  const cut = clean.slice(0, Math.max(0, max - 1));
  const lastSpace = cut.lastIndexOf(' ');
  return `${(lastSpace > max * 0.6 ? cut.slice(0, lastSpace) : cut).trim()}...`;
}

function activeRuntimeMissionFromNow(nowText) {
  const heading = String(nowText || '').match(/^##\s+(.+?)\s*$/m)?.[1]?.trim() || '';
  const id = String(nowText || '').match(/^- id:\s*(.+?)\s*$/m)?.[1]?.trim() || '';
  const status = String(nowText || '').match(/^- status:\s*(.+?)\s*$/m)?.[1]?.trim() || '';
  const next = String(nowText || '').match(/^- next:\s*(.+?)\s*$/m)?.[1]?.trim() || '';
  return { heading, id, status, next };
}

function missionPurpose(paths) {
  const missionText = readOptionalText(paths.missionFile);
  const nowText = readOptionalText(path.join(paths.memberDir, 'now.md'));
  const northStar = firstUsefulLine(extractMarkdownSection(missionText, 'North Star'));
  const goalGuidance = extractMarkdownSection(missionText, 'How To Choose Goals');
  const runtimeMission = activeRuntimeMissionFromNow(nowText);
  const meaningful = Boolean(northStar) && !/define why .* exists/i.test(northStar);
  return {
    missionText,
    nowText,
    northStar,
    goalGuidance,
    runtimeMission,
    meaningful,
  };
}

const MEMBER_RUN_RUNNABLE_STATUSES = new Set(['planning', 'running', 'ready']);
const MISSION_TERMINAL_STATUSES = new Set(['complete', 'stopped', 'failed']);

function memberRunMissionMap(root = process.cwd()) {
  try {
    const missionMod = require('./mission');
    const map = new Map(missionMod.loadMissionMap(root));
    for (const rolled of missionMod.listWorktreeRollupMissions(root)) {
      if (!rolled?.id) continue;
      const existing = map.get(rolled.id);
      if (!existing || missionTimeMs(rolled) >= missionTimeMs(existing)) {
        map.set(rolled.id, rolled);
      }
    }
    return map;
  } catch {
    return new Map();
  }
}

function memberRunRunnableMissionId(candidateId, missionMap) {
  const id = String(candidateId || '').trim();
  if (!id) return '';
  const mission = missionMap.get(id);
  // Unknown here can mean a worktree-held mission; let mission run decide.
  if (!mission) return id;
  return MEMBER_RUN_RUNNABLE_STATUSES.has(mission.status) ? id : '';
}

function memberRunOwnedActiveMissionId(name, missionMap) {
  // Discovery fallback when the member's own pointers are stale: resume the
  // member's newest moving mission. ready is excluded, it waits for review.
  const owner = String(name || '').trim().toLowerCase();
  const candidates = Array.from(missionMap.values())
    .filter((mission) => String(mission?.owner || '').trim().toLowerCase() === owner)
    .filter((mission) => mission.status === 'running' || mission.status === 'planning')
    .filter((mission) => !/^decide and start the next useful mission after:/i.test(String(mission?.objective || '')))
    .sort((a, b) => {
      if (a.status !== b.status) return a.status === 'running' ? -1 : 1;
      return String(b.updated_at || b.created_at || '').localeCompare(String(a.updated_at || a.created_at || ''));
    });
  return candidates[0]?.id || '';
}

const MEMBER_LIVE_MISSION_STATUSES = new Set(['running', 'planning']);
const MEMBER_ACTIVE_ACTIVITY_MS = 24 * 60 * 60 * 1000;
const MEMBER_RECENT_ACTIVITY_MS = 72 * 60 * 60 * 1000;

function memberSlugFromRecord(member) {
  if (member?.format === 'directory' && member.dir) return path.basename(member.dir);
  if (member?.format === 'flat' && member.path) return path.basename(member.path, '.md');
  return lowerCompact(member?.name || '');
}

function isFleetMember(member) {
  if (!member || member.format !== 'directory') return false;
  const slug = memberSlugFromRecord(member);
  return Boolean(slug) && !new Set(['_archive', '_archived', '_template']).has(slug);
}

function missionTimeMs(mission) {
  return Date.parse(mission?.last_tick_at || mission?.updated_at || mission?.created_at || '') || 0;
}

function memberOwnedMissions(name, missionMap = memberRunMissionMap()) {
  const owner = lowerCompact(name);
  return Array.from(missionMap.values())
    .filter((mission) => lowerCompact(mission?.owner) === owner)
    .sort((a, b) => missionTimeMs(b) - missionTimeMs(a));
}

function memberLatestMission(name, missionMap = memberRunMissionMap()) {
  return memberOwnedMissions(name, missionMap)[0] || null;
}

function memberLiveMission(name, missionMap = memberRunMissionMap()) {
  return memberOwnedMissions(name, missionMap)
    .find((mission) => {
      if (!MEMBER_LIVE_MISSION_STATUSES.has(String(mission?.status || '').toLowerCase())) return false;
      // A closed window can leave a running row behind. Only a known dead
      // process proves it is free; missing process records still hold it.
      try {
        const root = mission.worktree_root || mission.worktree?.path || process.cwd();
        const health = require('./mission').missionDriverHealth(mission, root);
        return !health.pid || health.alive;
      } catch { return true; }
    }) || null;
}

function missionShortName(mission, max = 36) {
  return compactSentence(mission?.slug || mission?.title || mission?.objective || mission?.id || '', max) || '-';
}

function ageLabelFromMs(ms, nowMs = Date.now()) {
  if (!ms) return '-';
  const seconds = Math.max(0, Math.floor((nowMs - ms) / 1000));
  if (seconds < 60) return 'now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours}h`;
  return `${Math.floor(hours / 24)}d`;
}

function timestampMs(value) {
  const ms = Date.parse(value || '');
  return Number.isFinite(ms) ? ms : 0;
}

function newestMtimeRecursive(root) {
  if (!fs.existsSync(root)) return 0;
  let newest = 0;
  const stack = [root];
  while (stack.length) {
    const current = stack.pop();
    let stat = null;
    try {
      stat = fs.statSync(current);
    } catch {
      continue;
    }
    newest = Math.max(newest, stat.mtimeMs || 0);
    if (!stat.isDirectory()) continue;
    let entries = [];
    try {
      entries = fs.readdirSync(current);
    } catch {
      continue;
    }
    for (const entry of entries) stack.push(path.join(current, entry));
  }
  return newest;
}

function newestRunActivityMtime(name, root = process.cwd()) {
  const runsDir = path.join(root, 'atris', 'runs');
  if (!fs.existsSync(runsDir)) return 0;
  const needle = lowerCompact(name);
  let newest = 0;
  for (const entry of fs.readdirSync(runsDir)) {
    if (!lowerCompact(entry).includes(needle)) continue;
    try {
      newest = Math.max(newest, fs.statSync(path.join(runsDir, entry)).mtimeMs || 0);
    } catch { /* ignore unreadable activity entries */ }
  }
  return newest;
}

function memberLastActivity(name, paths = memberPaths(name), root = process.cwd()) {
  const logsMs = newestMtimeRecursive(path.join(paths.memberDir, 'logs'));
  const runsMs = newestRunActivityMtime(name, root);
  const ms = Math.max(logsMs, runsMs);
  return {
    at_ms: ms,
    age: ageLabelFromMs(ms),
  };
}

function memberMissionSummary(name, missionMap = memberRunMissionMap(), root = process.cwd()) {
  const latest = memberLatestMission(name, missionMap);
  const live = memberLiveMission(name, missionMap);
  const lastTickMs = timestampMs(latest?.last_tick_at);
  let driver = null;
  if (latest) {
    try {
      const { missionDriverHealth } = require('./mission');
      const missionRoot = latest.worktree_root || latest.worktree?.path || root;
      driver = missionDriverHealth(latest, missionRoot);
    } catch {
      driver = null;
    }
  }
  const worktreeRoot = latest?.worktree_root || latest?.worktree?.path || null;
  const worktreeBranch = latest?.worktree_branch || latest?.worktree?.branch || null;
  return {
    latest,
    live,
    name: missionShortName(latest),
    objective: latest?.objective || null,
    state: latest?.status || '-',
    runner: latest?.runner || null,
    model: latest?.model || null,
    worktree_root: worktreeRoot,
    worktree_branch: worktreeBranch,
    task_ref: latest?.task_ref || latest?.xp_task?.ref || null,
    current_task_id: latest?.current_task_id || latest?.task_ids?.[0] || null,
    last_tick_at: latest?.last_tick_at || null,
    last_tick_age: ageLabelFromMs(lastTickMs),
    live_mission: Boolean(live) || Boolean(driver?.alive),
    driver,
  };
}

function memberVerdict({ mission, activity }, nowMs = Date.now()) {
  const activityAge = activity?.at_ms ? nowMs - activity.at_ms : Number.POSITIVE_INFINITY;
  if (mission?.live_mission || activityAge < MEMBER_ACTIVE_ACTIVITY_MS) return 'ACTIVE';
  if (activityAge < MEMBER_RECENT_ACTIVITY_MS) return 'RECENT';
  return 'IDLE';
}

function memberGoalPlaneStatus(name, paths = requireMemberDir(name)) {
  const state = loadMemberGoals(name, paths);
  const goal = activeGoal(state);
  const current = memberOpenExperiment(state);
  const lastReviewed = memberLastReviewedExperiment(state);
  const value = memberValueSummary(state);
  const logs = recentLogLines(paths.memberDir);
  const needsUser = current?.status === 'blocked';
  const stateLabel = !goal
    ? 'no_goal'
    : needsUser
      ? 'needs_user'
      : current
        ? current.status
        : 'ready';
  const ask = needsUser ? (current.block?.ask || 'Needs operator input.') : null;
  const nextCommand = !goal
    ? `atris member goal ${name} "..."`
    : needsUser
      ? `atris member review ${name} ${current.id} --discard --proof "..."`
      : current
        ? `atris member review ${name} ${current.id} --accept --proof "..." --value 4`
        : `atris member tick ${name}`;
  return {
    state,
    goal,
    current,
    lastReviewed,
    value,
    logs,
    needsUser,
    stateLabel,
    ask,
    nextCommand,
  };
}

function resolveMemberRunMissionId(name, args = []) {
  const override = readFlag(args, '--mission', '') || readFlag(args, '--mission-id', '');
  if (override) return override;

  const paths = requireMemberDir(name);
  const missionMap = memberRunMissionMap();
  const purpose = missionPurpose(paths);
  const runtimeId = memberRunRunnableMissionId(purpose.runtimeMission?.id, missionMap);
  if (runtimeId) return runtimeId;

  // strictly active: activeGoal()'s goals[0] fallback would resurrect a
  // paused goal's stale mission pointer and error the leg every hour
  const goals = loadMemberGoals(name, paths);
  const goal = (goals.goals || []).find((candidate) => candidate.status === 'active') || null;
  const goalId = memberRunRunnableMissionId(goal?.mission_id, missionMap);
  if (goalId) return goalId;

  return memberRunOwnedActiveMissionId(paths.storageName || name, missionMap);
}

const MEMBER_RUN_START_VALUE_FLAGS = [
  '--mission',
  '--mission-id',
  '--owner',
  '--runner',
  '--engine',
  '--budget',
  '--repo',
  '--native-goal-status',
  '--native-goal-objective',
  '--visible-goal-status',
  '--visible-goal-objective',
  '--max-idle-ticks',
  '--slots',
  '--referee-engine',
  '--lane',
  '--cadence',
  '--verify',
  '--stop',
  '--model',
  '--max-ticks',
  '--max-wall',
  '--minutes',
  '--hours',
  '--industry',
  '--domain',
  '--value',
  '--outcome',
  '--truth',
  '--proof',
  '--base',
  '--yes-lock',
  '--yes-lock-parent',
];

const MEMBER_RUN_START_BOOLEAN_FLAGS = [
  '--json',
  '--no-verify',
  '--referee',
  '--no-referee',
  '--worktree',
  '--shared-checkout',
  '--no-worktree',
  '--always-on',
  '--xp-task',
  '--agent-xp',
  '--spend-full-budget',
  '--use-whole-budget',
  '--stop-when-done',
  '--choose-work',
  '--auto',
  '--headless',
  '--self-drive',
  '--no-claude',
  '--complete-on-pass',
  '--no-drain',
  '--create-next',
  '--preflight',
  '--no-preflight',
  '--room-preflight',
  '--no-room-preflight',
  '--room-auto-run',
  '--no-room-auto-run',
  '--manual-ack',
  '--allow-native-goal-supersede',
  '--supersede-paused-native-goal',
  '--take-goal-slot',
  '--due',
  '--detach',
  '--fleet',
  '--dry-run',
  '--land',
  '--cloud',
  '--ignite',
  '--wait',
  '--sync',
  '--no-driver',
];

function memberRunMissionWordIndices(args = []) {
  const values = new Set(MEMBER_RUN_START_VALUE_FLAGS);
  const booleans = new Set(['--full', '--verbose', ...MEMBER_RUN_START_BOOLEAN_FLAGS]);
  const indices = [];
  for (let i = 0; i < args.length; i += 1) {
    const arg = String(args[i]);
    const key = arg.includes('=') ? arg.slice(0, arg.indexOf('=')) : arg;
    if (booleans.has(key)) continue;
    if (values.has(key)) {
      if (!arg.includes('=') && args[i + 1] && !String(args[i + 1]).startsWith('--')) i += 1;
      continue;
    }
    indices.push(i);
  }
  return indices;
}

function memberRunMissionText(args = []) {
  return memberRunMissionWordIndices(args).map((index) => args[index]).join(' ').trim();
}

function cleanMemberRunPhrase(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function memberRunDomain(args = []) {
  return cleanMemberRunPhrase(readFlag(args, '--industry', '') || readFlag(args, '--domain', '')) || 'this workspace and its users';
}

function memberRunOutcome(args = []) {
  return cleanMemberRunPhrase(readFlag(args, '--outcome', '') || readFlag(args, '--value', ''))
    || 'revenue, reliability, speed, security, workflow clarity, or customer trust';
}

function memberRunTruthRule(args = []) {
  return cleanMemberRunPhrase(readFlag(args, '--truth', '') || readFlag(args, '--proof', ''))
    || 'say what changed, what was checked, and what is still unproven';
}

function operatorWaitingWishTexts(root = process.cwd()) {
  // Wishes waiting on operator answers are not actionable candidates: seeding
  // them into member runs spawned three parallel verifier-less wrapper
  // missions chewing the same unanswered sentence (seen live 2026-07-07).
  try {
    const { waitingOperatorWishes } = require('../lib/wish-delegate');
    return new Set(
      waitingOperatorWishes(root)
        .map((wish) => cleanMemberRunPhrase(wish?.text || wish?.task_text || '').toLowerCase())
        .filter(Boolean),
    );
  } catch {
    return new Set();
  }
}

function memberRunUsefulTarget() {
  try {
    const { nextMoves: pickNextMoves, isGenericInboxPlaceholder } = require('../lib/next-moves');
    const moves = pickNextMoves(process.cwd(), 5);
    const waitingWishes = operatorWaitingWishTexts();
    const candidate = moves.find((move) => {
      const title = cleanMemberRunPhrase(move?.title);
      if (!title) return false;
      if (isGenericInboxPlaceholder(title)) return false;
      if (/^mission xp\s*:/i.test(title)) return false;
      if (/^decide and start the next useful mission after:/i.test(title)) return false;
      if (waitingWishes.has(title.toLowerCase())) return false;
      return true;
    });
    return candidate?.title ? cleanMemberRunPhrase(candidate.title) : '';
  } catch {
    return '';
  }
}

function memberRunAutoMissionText(name, args = []) {
  const domain = memberRunDomain(args);
  const outcome = memberRunOutcome(args);
  const truth = memberRunTruthRule(args);
  const target = memberRunUsefulTarget();
  const work = target
    ? `Start with this concrete candidate: ${target}.`
    : 'First inspect current Atris state, then choose one bounded useful task.';
  return [
    `Run ${name} on meaningful work for ${domain}.`,
    work,
    `Useful means it improves ${outcome}.`,
    `Truth rule: ${truth}.`,
    'Explain the choice in plain language, prove the result before Review, and stop instead of doing fake busywork when no useful task exists.',
  ].join(' ');
}

function memberRunBudgetSeconds(args = []) {
  const hours = readNumberFlag(args, '--hours', null);
  if (Number.isFinite(hours) && hours > 0) return Math.round(hours * 3600);
  const minutes = readNumberFlag(args, '--minutes', null);
  if (Number.isFinite(minutes) && minutes > 0) return Math.round(minutes * 60);
  return null;
}

// A job with no time given gets 15 minutes, or the roster's limit for this
// member's engine plus ten minutes for the review, whichever is longer.
function memberRunDefaultWallSeconds(name, cwd = process.cwd()) {
  let cap = 0;
  try {
    const picked = require('../lib/member-engine').memberRosterEngine(name, cwd);
    cap = Number(picked && picked.engine && picked.engine.roster_max_seconds) || 0;
  } catch {}
  // No roster cap means the tick runs on the default tick cap, so the run
  // needs that much plus review time, or the wall kills it first.
  const tickSeconds = cap || require('./mission').missionTickTimeoutMs({}, Infinity) / 1000;
  return Math.max(900, tickSeconds + 600);
}

function pushFlagValue(out, args, name) {
  const value = readFlag(args, name, '');
  if (value) out.push(name, String(value));
}

function pushFlagWhenPresent(out, args, name) {
  if (hasFlag(args, name)) out.push(name);
}

// The runner a new member mission starts with. An explicit --runner or
// --engine wins. With neither, a member the roster names runs on "auto", so
// every tick picks the member's engine from ROSTER.md (edits apply on the next
// tick). Otherwise the old default holds.
function memberRunRunner(owner, args = [], cwd = process.cwd()) {
  const explicit = readFlag(args, '--runner', '');
  if (explicit) return explicit;
  // codex_goal stalls unattended (no live codex session drives its native goal
  // slot). Default to claude unless a live codex session is signalled; explicit
  // --runner still wins. Proven footgun 2026-07-16. See lib/default-runner.js.
  const fallback = defaultObjectiveRunner(args);
  if (fallback !== 'claude' || readFlag(args, '--engine', '')) return fallback;
  const { memberRosterEngine } = require('../lib/member-engine');
  return memberRosterEngine(owner, cwd) ? 'auto' : fallback;
}

function inferMemberRunVerifier(missionText, args = [], cwd = process.cwd()) {
  if (hasFlag(args, '--no-verify')) return '';
  const explicit = readFlag(args, '--verify', '');
  if (explicit) return explicit;
  const text = String(missionText || '').trim();
  if (!text) return '';
  const cmdMatch = text.match(/\b(npm\s+run\s+type-check|node\s+--test\s+tests?\/[A-Za-z0-9_./-]+)\b/);
  if (cmdMatch) return cmdMatch[1].replace(/\s+/g, ' ');
  const testFileMatch = text.match(/\b(tests?\/[A-Za-z0-9_./-]+\.test\.m?js)\b/);
  if (testFileMatch && fs.existsSync(path.join(cwd, testFileMatch[1]))) {
    return `node --test ${testFileMatch[1]}`;
  }
  return '';
}

function buildMemberRunStartArgs(owner, missionText, args = [], cwd = process.cwd()) {
  const resolvedVerifier = inferMemberRunVerifier(missionText, args, cwd);
  const startArgs = [
    'mission',
    'start',
    missionText,
    '--owner',
    owner,
    '--runner',
    memberRunRunner(owner, args, cwd),
    '--lane',
    readFlag(args, '--lane', 'workspace'),
  ];
  pushFlagValue(startArgs, args, '--cadence');
  if (resolvedVerifier) {
    startArgs.push('--verify', String(resolvedVerifier));
  }
  pushFlagValue(startArgs, args, '--stop');
  pushFlagValue(startArgs, args, '--model');
  pushFlagValue(startArgs, args, '--max-wall');
  pushFlagValue(startArgs, args, '--minutes');
  pushFlagValue(startArgs, args, '--hours');
  pushFlagValue(startArgs, args, '--base');
  // a run inside a woken member's run keeps its seal: mission start reads it
  // from the environment, never from these words
  if (!process.env.ATRIS_HANDOFF_YES_LOCK) {
    pushFlagValue(startArgs, args, '--yes-lock');
    pushFlagValue(startArgs, args, '--yes-lock-parent');
  }
  // Member runs choose and drive work immediately, so an absent check must not
  // leave autonomous callers with a mission that never ran. A check inferred
  // from the mission text counts as named.
  if (hasFlag(args, '--no-verify') || !resolvedVerifier) {
    startArgs.push('--no-verify');
  }
  pushFlagWhenPresent(startArgs, args, '--always-on');
  pushFlagWhenPresent(startArgs, args, '--xp-task');
  pushFlagWhenPresent(startArgs, args, '--agent-xp');
  pushFlagWhenPresent(startArgs, args, '--spend-full-budget');
  pushFlagWhenPresent(startArgs, args, '--use-whole-budget');
  pushFlagWhenPresent(startArgs, args, '--stop-when-done');
  // Default to an isolated worktree only when there is a git repo to cut it
  // from. A plain (non-git) workspace would fail every mission start with
  // "fatal: not a git repository", degrade to the shared checkout instead.
  if (!hasFlag(args, '--shared-checkout') && !hasFlag(args, '--no-worktree') && insideGitRepo(cwd)) {
    startArgs.push('--worktree');
  }
  startArgs.push('--json');
  return startArgs;
}

function insideGitRepo(startDir) {
  let dir = path.resolve(startDir || process.cwd());
  while (true) {
    if (fs.existsSync(path.join(dir, '.git'))) return true;
    const parent = path.dirname(dir);
    if (parent === dir) return false;
    dir = parent;
  }
}

function startMemberRunMission(name, missionText, args = []) {
  const paths = requireMemberDir(name);
  const owner = paths.storageName || name;
  const startArgs = buildMemberRunStartArgs(owner, missionText, args);
  return memberRunCli(startArgs, process.cwd());
}

// An ignited run asks a second engine to review the work by default, so every
// run ends with a verdict. --no-referee skips it; an explicit --referee is kept.
function memberRunWantsReferee(runArgs, ignite) {
  return Boolean(ignite) && !hasFlag(runArgs, '--referee') && !hasFlag(runArgs, '--no-referee');
}

function memberRunCli(args, cwd, { live = false, missionId = '' } = {}) {
  const cliPath = path.join(__dirname, '..', 'bin', 'atris.js');
  const runsDir = path.join(cwd, 'atris', 'runs');
  const previousReceipts = live && fs.existsSync(runsDir) ? new Set(fs.readdirSync(runsDir)) : new Set();
  const result = spawnSync(process.execPath, [cliPath, ...args], {
    cwd,
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
    stdio: live ? 'inherit' : ['ignore', 'pipe', 'pipe'],
  });
  if (result.error) throw result.error;
  if (live) {
    const receiptName = fs.existsSync(runsDir)
      ? fs.readdirSync(runsDir).filter((name) => !previousReceipts.has(name) && name.startsWith(`mission-${missionId}-`) && name.endsWith('.json')).sort().at(-1)
      : null;
    const receipt = receiptName ? readJson(path.join(runsDir, receiptName), null) : null;
    return { status: result.status, payload: receipt?.result?.kind === 'mission_run_summary'
      ? { ran_ticks: receipt.result.ran_ticks, ticks: receipt.result.ticks } : null, stderr: '', errorReported: result.status !== 0 };
  }
  let payload = null;
  try {
    payload = JSON.parse(result.stdout);
  } catch (error) {
    if (result.status === 0) throw new Error(`member run: mission command returned invalid json: ${error.message}`);
  }
  return { status: result.status, payload, stderr: String(result.stderr || '').trim() };
}

function memberRunConfiguredVerifier(paths) {
  const frontmatter = parseFrontmatter(fs.readFileSync(paths.memberFile, 'utf8')) || {};
  const check = frontmatter.verify || frontmatter.verifier;
  return typeof check === 'string' ? check.trim() : '';
}

function printMemberRunResult(result, asJson, { quiet = false } = {}) {
  if (quiet) {
    // A caller (member wake) prints this result inside its own report.
  } else if (asJson) {
    console.log(JSON.stringify(result));
  } else if (result.started) {
    console.log(`started ${result.mission_id} (${result.state})`);
  }
  if (!quiet && !asJson && result.ask) console.error(result.ask);
  if (result.ok === false || (!result.started && result.ok !== true)) {
    if (!quiet && !result.errorReported && !result.ask) console.error(result.error);
    process.exitCode = 1;
  }
  return result;
}

// Runners that hand the mission to the agent session that called Atris. From
// a plain terminal nothing is on the other end of them.
const MEMBER_RUN_CALLER_SESSION_RUNNERS = new Set(['codex_goal', 'caller_session', 'current_agent']);

function memberRunUsesCallerSession(runner) {
  return MEMBER_RUN_CALLER_SESSION_RUNNERS.has(String(runner || '').trim().toLowerCase());
}

// A mission whose runner waits on a caller session cannot do anything when
// no such session started this run. Swap in the roster engine for this run
// ("auto" resolves the owner's roster pick per tick) instead of waiting on a
// native goal nothing will start. An explicit --runner or --engine on this
// command still wins, and a real codex caller keeps its native goal.
function memberRunRunnerSwap(mission, args, caller) {
  if (!memberRunUsesCallerSession(mission?.runner)) return null;
  if (caller === 'codex') return null;
  if (readFlag(args, '--runner', '') || readFlag(args, '--engine', '')) return null;
  return {
    from: String(mission.runner),
    to: 'auto',
    reason: `no ${String(mission.runner) === 'codex_goal' ? 'codex' : 'agent'} session started this run, so the member's roster engine does the work`,
  };
}

function memberRunTickDurationMs(tick) {
  const start = Date.parse(tick?.started_at || '');
  const end = Date.parse(tick?.finished_at || '');
  return Number.isFinite(start) && Number.isFinite(end) && end >= start ? end - start : null;
}

// One plain record of the work step this run executed (or why none ran), so
// a reader never has to dig through mission internals to learn what happened.
function memberRunWorkStep(payload, finalMission) {
  const ticks = Array.isArray(payload?.ticks) ? payload.ticks : [];
  const ran = [...ticks].reverse().find((tick) => tick && tick.ran === true) || null;
  const last = ran || ticks[ticks.length - 1] || null;
  const worker = last?.claude || last?.atris2 || null;
  return {
    ran: Boolean(ran),
    ticks_ran: Number(payload?.ran_ticks) || 0,
    engine: last?.engine_id || finalMission?.runner || null,
    model: last?.model || worker?.model || finalMission?.model || null,
    duration_ms: last ? memberRunTickDurationMs(last) : null,
    status: last?.status || null,
    reason: last?.reason || null,
    summary: worker?.summary ? String(worker.summary).slice(0, 400) : null,
    receipt_path: payload?.summary_receipt || finalMission?.receipt_path || null,
  };
}

// The protected-surface guard keeps the staged work and pauses for a person.
// Say so in one line, with the command that shows the work.
function memberRunReviewAsk(name, payload, mission, cwd) {
  const ticks = Array.isArray(payload?.ticks) ? payload.ticks : [];
  const guarded = ticks.find((tick) => tick?.protected_lane_guard && tick.protected_lane_guard.allowed === false);
  const guard = guarded?.protected_lane_guard || null;
  if (!guard) return null;
  const surfaces = Array.isArray(guard.surfaces) && guard.surfaces.length ? guard.surfaces.join(', ') : 'a protected surface';
  if (guard.unreadable) {
    return {
      needs_review: true,
      ask: `${name} paused: Atris could not read the mission diff; fix that, then rerun.`,
      next_command: `atris mission tick ${mission.id} --verify`,
      review_path: cwd,
    };
  }
  const where = JSON.stringify(cwd);
  return {
    needs_review: true,
    ask: `${name} staged a change that touches ${surfaces}; it is kept in ${cwd} for you to review, land, or discard.`,
    next_command: `git -C ${where} status --short && git -C ${where} diff HEAD`,
    resume_command: `atris mission run ${mission.id}`,
    review_path: cwd,
  };
}

// atris member ping <name> "<message>": talk to a busy member mid-run.
// Two delivery lanes: the member's most recently touched live mission
// (including --worktree missions in sibling checkouts), whose next tick
// consumes the note, and the member's claimed task dialogue, which task-loop
// agents re-read every step without ever ticking a mission. The ping lands on
// every lane that exists and errors only when neither does.
function pingClaimedTaskDialogue(name, text, from) {
  let taskDb;
  try {
    taskDb = require('../lib/task-db');
  } catch {
    return null;
  }
  try {
    const db = taskDb.open();
    const local = taskDb.listTasks(db, { workspaceRoot: taskDb.workspaceRoot(), status: 'claimed', claimedBy: name });
    const pool = local.length ? local : taskDb.listTasks(db, { status: 'claimed', claimedBy: name });
    if (!pool.length) return null;
    const task = [...pool].sort((a, b) => Number(b.updated_at || 0) - Number(a.updated_at || 0))[0];
    const result = taskDb.noteTask(db, { id: task.id, actor: from, content: text });
    if (!result.noted) return null;
    return { task_id: task.id, title: task.title };
  } catch {
    return null;
  }
}

function memberPing(name, ...args) {
  if (!name || name === '--help' || name === '-h') {
    console.log('Usage: atris member ping <name> "<message>" [--from <who>] [--json]');
    console.log('Leaves the note on the member\'s active mission and claimed task dialogue; whichever loop the member runs reads it next.');
    return;
  }
  const asJson = args.includes('--json');
  const rest = args.filter((a) => a !== '--json');
  let from = process.env.USER || 'operator';
  const fromIdx = rest.indexOf('--from');
  if (fromIdx !== -1) {
    from = rest[fromIdx + 1] || from;
    rest.splice(fromIdx, 2);
  }
  const text = rest.filter((a) => !a.startsWith('--')).join(' ').trim();
  if (!text) {
    console.error('atris member ping: message required');
    process.exit(2);
  }
  const missionMod = require('./mission');
  const candidates = [
    ...missionMod.listMissions(process.cwd()),
    ...missionMod.listWorktreeRollupMissions(process.cwd()),
  ]
    .filter((m) => m && m.owner === name && !MISSION_TERMINAL_STATUSES.has(m.status))
    .sort((a, b) => String(b.updated_at || b.created_at || '').localeCompare(String(a.updated_at || a.created_at || '')));

  const taskNote = pingClaimedTaskDialogue(name, text, from);

  if (!candidates.length && !taskNote) {
    console.error(`atris member ping: no live mission or claimed task for "${name}". Start one: atris member run ${name} "<objective>"`);
    process.exit(1);
  }

  const mission = candidates.length
    ? missionMod.pingMission([candidates[0].id, text, '--from', from], { silent: true })
    : null;
  const pendingPings = mission ? (mission.pings || []).filter((p) => p && !p.consumed_at).length : null;

  if (asJson) {
    console.log(JSON.stringify({
      ok: true,
      action: 'member_ping',
      member: name,
      mission_id: mission ? mission.id : null,
      pending_pings: pendingPings,
      task_id: taskNote ? taskNote.task_id : null,
    }));
  } else {
    if (mission) console.log(`pinged ${mission.id}, the next tick reads it (${pendingPings} unread).`);
    if (taskNote) console.log(`pinged task ${taskNote.task_id} dialogue, ${name} reads it on the next step.`);
  }
  return { mission, task_note: taskNote };
}

function memberRun(name, ...args) {
  return memberRunWith(name, args);
}

// One plain line for why the reviewing engine refused the work.
function reviewRefusalLine(refusal) {
  if (refusal.timed_out) return 'the reviewer ran out of time';
  const text = String(refusal.output || refusal.reason || '');
  const verdict = text.match(/VERDICT:\s*FAIL\s*[;:]\s*(.+)/i);
  const line = verdict ? verdict[1] : (text.split(/\r?\n/).find((l) => l.trim()) || refusal.reason || 'no reason given');
  return line.trim().slice(0, 200);
}

function memberRunWith(name, args, { quiet = false, closeTaskIds = [] } = {}) {
  if (!name || name === '--help' || name === '-h' || hasFlag(args, '--help') || hasFlag(args, '-h')) {
    console.log('usage: atris member run <name> ["mission text"] [--verify "<cmd>"] [--minutes N|--hours N] [--json]');
    console.log('pick for me: atris member run "fix the flaky login test" (the best member takes it and runs it)');
    console.log('new mission: atris member run growth "improve onboarding proof" --verify "npm test" --minutes 30 --json');
    console.log('choose work: atris member run growth --verify "npm test" --industry logistics --minutes 30 --json');
    console.log('subagent shell: atris member run growth "improve onboarding proof" --engine claude --ignite --json');
    console.log('existing mission: atris member run growth --mission <mission-id> --max-ticks 1 --json');
    console.log('meaning: if mission text is omitted, the member chooses one useful bounded task from atris state.');
    console.log('truth: useful work must improve revenue, reliability, speed, security, clarity, or trust, then show plain proof.');
    console.log('isolation: new missions use --worktree by default; add --shared-checkout to stay here.');
    console.log('check: --verify or a verify field in the member file adds a mission check.');
    console.log('review: an --ignite run has a different engine review the work; add --no-referee to skip it.');
    return;
  }

  // --ignite (or --wait, --sync) runs the member as a subagent shell: it works
  // on the named engine until the check passes, then the mission completes.
  const ignite = hasFlag(args, '--ignite') || hasFlag(args, '--wait') || hasFlag(args, '--sync');
  if (ignite && readFlag(args, '--engine', '') && !readFlag(args, '--runner', '')) {
    args = [...args, '--runner', readFlag(args, '--engine', '')];
  }
  const asJson = hasFlag(args, '--json');
  const paths = requireRunnableMember(name);
  // Parking only hides a member from the team views; a run by name still goes.
  const { isParkedText } = require('../lib/member-park');
  try {
    if (isParkedText(fs.readFileSync(paths.memberFile, 'utf8'))) {
      console.error(`${name} is parked; running anyway`);
    }
  } catch { /* an unreadable card is requireMemberDir's problem, not this notice's */ }
  if (args.filter(require('./mission').isYesLockWord).length > 1) {
    return printMemberRunResult({ started: false, state: null, mission_id: null,
      error: 'member run got more than one --yes-lock, so it is not clear which seal applies; nothing started' }, asJson, { quiet });
  }
  const requestedVerifier = readFlag(args, '--verify', '') || memberRunConfiguredVerifier(paths);
  const missionText = memberRunMissionText(args);
  const hasMissionOverride = Boolean(readFlag(args, '--mission', '') || readFlag(args, '--mission-id', ''));
  let mission = null;
  let startedNewMission = false;
  let nodeModulesLinked = false;
  let nodeModulesSource = null;
  if (missionText && !hasMissionOverride) {
    const start = startMemberRunMission(name, missionText, requestedVerifier ? [...args, '--verify', requestedVerifier] : args);
    if (start.status !== 0 || !start.payload?.mission) {
      return printMemberRunResult({ started: false, state: null, mission_id: start.payload?.mission?.id || null,
        error: start.payload?.detail || start.payload?.error || start.stderr || 'mission creation failed' }, asJson, { quiet });
    }
    mission = start.payload.mission;
    startedNewMission = true;
    nodeModulesLinked = Boolean(start.payload.node_modules_linked);
    nodeModulesSource = start.payload.node_modules_source || null;
  } else {
    const missionId = resolveMemberRunMissionId(name, args);
    if (!missionId) {
      const start = startMemberRunMission(name, memberRunAutoMissionText(name, args), requestedVerifier ? [...args, '--verify', requestedVerifier] : args);
      if (start.status !== 0 || !start.payload?.mission) {
        return printMemberRunResult({ started: false, state: null, mission_id: start.payload?.mission?.id || null,
          error: start.payload?.detail || start.payload?.error || start.stderr || 'mission creation failed' }, asJson, { quiet });
      }
      mission = start.payload.mission;
      startedNewMission = true;
      nodeModulesLinked = Boolean(start.payload.node_modules_linked);
      nodeModulesSource = start.payload.node_modules_source || null;
    } else {
      mission = require('./mission').resolveMission(missionId);
      if (!mission) {
        return printMemberRunResult({ started: false, state: null, mission_id: missionId, error: `mission ${missionId} was not found` }, asJson, { quiet });
      }
    }
  }

  if (startedNewMission && !asJson) {
    if (mission.worktree?.path) console.log(`worktree: ${mission.worktree.path}`);
    if (nodeModulesLinked) console.log(`linked node_modules from ${nodeModulesSource}`);
  }

  // An ignited run works for minutes; say where to watch it before it starts.
  if (ignite && !asJson && !quiet && !hasFlag(args, '--quiet')) {
    const progressDir = process.env.ATRIS_PROGRESS_DIR || '~/.atris/progress';
    console.log(`watch: tail -f ${progressDir}/${String(name).replace(/[^A-Za-z0-9._-]/g, '_')}.log`);
    console.log('board: atris member board --watch');
    console.log('stop: atris member stop <name>');
    console.log(`where work goes: ${require('../lib/member-autoland').landingDestination(mission.worktree?.path || process.cwd())}`);
  }

  const cwd = mission.worktree?.path || process.cwd();
  const verifier = readFlag(args, '--verify', '') || mission.verifier || requestedVerifier;
  if (verifier && verifier !== mission.verifier) {
    const changed = memberRunCli(['mission', 'set-verifier', mission.id, verifier, '--json'], cwd);
    if (changed.status !== 0) {
      return printMemberRunResult({ started: false, state: mission.status, mission_id: mission.id, mission,
        error: changed.payload?.detail || changed.payload?.error || changed.stderr || 'could not set mission check' }, asJson, { quiet });
    }
    mission.verifier = verifier;
  }

  const missionWordIndices = missionText && !hasMissionOverride ? new Set(memberRunMissionWordIndices(args)) : new Set();
  const executionArgs = args.filter((_, index) => !missionWordIndices.has(index));
  const runArgs = stripKnownFlags(executionArgs,
    ['--mission', '--mission-id', '--minutes', '--hours', '--industry', '--domain', '--value', '--outcome', '--truth', '--proof', '--base', '--yes-lock', '--yes-lock-parent'],
    ['--worktree', '--shared-checkout', '--no-worktree', '--choose-work', '--auto', '--ignite', '--wait', '--sync']);
  if (ignite && !hasFlag(runArgs, '--complete-on-pass')) runArgs.push('--complete-on-pass');
  if (memberRunWantsReferee(runArgs, ignite)) runArgs.push('--referee');
  const budgetSeconds = memberRunBudgetSeconds(args);
  if (!readFlag(runArgs, '--max-ticks', '')) {
    runArgs.push('--max-ticks', budgetSeconds ? String(Math.max(4, Math.ceil(budgetSeconds / 300))) : '1');
  }
  if (!readFlag(runArgs, '--max-wall', '')) runArgs.push('--max-wall', String(budgetSeconds || memberRunDefaultWallSeconds(name, cwd)));
  const caller = callerRuntime(args);
  const runnerSwap = memberRunRunnerSwap(mission, args, caller);
  if (runnerSwap) runArgs.push('--engine', runnerSwap.to);
  // A run in the foreground (wake, go, run by name) is noted on the start
  // list under the shared lock, so member up and handoffs count it while it
  // works. A detached run is noted by whoever started it.
  if (!hasFlag(runArgs, '--detach') && !hasFlag(runArgs, '--dry-run')) {
    try {
      const stateDir = path.join(require('./mission').resolveMemberWorkspaceRoot(process.cwd()), '.atris', 'state');
      require('../lib/handoff-wake').withWakeReservation(stateDir,
        ({ record }) => record({ member: name, mission_id: mission.id, pid: process.pid }), { waitMs: 30000 });
    } catch {}
  }
  const run = memberRunCli(['mission', 'run', mission.id, ...runArgs], cwd, { live: !asJson && !quiet, missionId: mission.id });
  const payload = run.payload || {};
  const finalMission = payload.mission || require('./mission').resolveMission(mission.id, cwd) || mission;
  const started = run.status === 0 && payload.ok !== false && Number(payload.ran_ticks) > 0;
  // Inside a real codex session the native goal is the work step: the caller
  // starts it with the action below, so waiting on it is not a failure.
  const waitingOnNativeGoal = caller === 'codex' && payload.requires_native_goal_start === true
    && memberRunUsesCallerSession(finalMission.runner);
  const noWorkStepExpected = hasFlag(runArgs, '--detach') || hasFlag(runArgs, '--dry-run');
  // The work ran but its check failed: the run failed, even though a work
  // step happened. Scripts and the caller read this from the exit code.
  const lastRanTick = [...(Array.isArray(payload.ticks) ? payload.ticks : [])].reverse().find((tick) => tick && tick.ran === true);
  const checkFailed = started && Boolean(String(finalMission.verifier || '').trim())
    && lastRanTick?.verifier_passed === false && finalMission.status !== 'complete';
  const ok = ((run.status === 0 && payload.ok !== false && (started || noWorkStepExpected)) || waitingOnNativeGoal) && !checkFailed;
  const reviewAsk = memberRunReviewAsk(name, payload, finalMission, cwd);
  const result = { ...payload, ok, started, state: finalMission.status, mission_id: mission.id,
    mission: finalMission, node_modules_linked: nodeModulesLinked, node_modules_source: nodeModulesSource,
    started_mission: startedNewMission ? mission : null, worktree: mission.worktree || null,
    caller_runtime: caller,
    runner_swap: runnerSwap,
    work_step: memberRunWorkStep(payload, finalMission),
    errorReported: run.errorReported };
  // The goal-controller view describes whichever mission holds the codex goal
  // slot, often an older one. On a run that is not a native goal it reads as
  // "waiting on create_goal" after this run already worked, so leave it out.
  if (runnerSwap || !memberRunUsesCallerSession(finalMission.runner)) {
    delete result.codex_goal_state;
  }
  if (waitingOnNativeGoal) {
    result.waiting_on = 'native_goal_start';
    result.next_command = payload.next_action || payload.next_command || null;
  }
  if (reviewAsk) Object.assign(result, reviewAsk);
  if (!reviewAsk && payload.reason === 'human_asks_open' && Array.isArray(payload.human_asks) && payload.human_asks.length) {
    result.ask = `${name} is waiting on you: ${payload.human_asks[0]}`;
    result.next_command = payload.next_command || 'atris decide';
  }
  // A finished ignited run whose check passed hands its branch to GitHub
  // auto-merge, only past the local gates; any held gate leaves the branch.
  if (ignite && ok && started && !reviewAsk && finalMission.verifier_result?.passed === true) {
    const ticks = Array.isArray(payload.ticks) ? payload.ticks : [];
    const summary = ticks.map((tick) => tick?.summary || tick?.claude?.summary).filter(Boolean).pop() || '';
    const workerEngine = ticks.map((tick) => tick?.engine_id).filter(Boolean).pop()
      || runnerSwap?.to || readFlag(args, '--runner', '') || '';
    result.autoland = require('../lib/member-autoland').autolandMemberRun({ mission: finalMission, cwd, summary, workerEngine, closeTaskIds });
    if (!asJson && !quiet) console.log(result.autoland.line);
  }
  if (checkFailed) {
    result.check_failed = true;
    const refusal = lastRanTick?.referee_result?.passed === false ? lastRanTick.referee_result : null;
    result.error = refusal
      ? `turned down in review: ${reviewRefusalLine(refusal)}`
      : `the work ran but its check failed: ${finalMission.verifier || 'completion check'}`;
  } else if (!ok) {
    result.error = result.ask || payload.detail || payload.error || payload.reason || payload.next_action
      || run.stderr || 'mission did not run a work step';
  }
  return printMemberRunResult(result, asJson, { quiet });
}

function loadTeamScoreEvidence(scoreJsonPath) {
  const sourcePath = String(scoreJsonPath || '').trim();
  try {
    if (sourcePath) {
      const raw = sourcePath === '-'
        ? fs.readFileSync(0, 'utf8')
        : fs.readFileSync(path.resolve(process.cwd(), sourcePath), 'utf8');
      return {
        ok: true,
        source: sourcePath === '-' ? 'stdin' : path.relative(process.cwd(), path.resolve(process.cwd(), sourcePath)),
        parsed: JSON.parse(raw),
      };
    }
    const scoreScript = path.join(process.cwd(), 'scripts', 'team-overall-score.mjs');
    if (!fs.existsSync(scoreScript)) {
      return {
        ok: false,
        source: null,
        error: 'No --score-json was provided and scripts/team-overall-score.mjs was not found.',
      };
    }
    const raw = execFileSync(process.execPath, [scoreScript, '--json'], {
      cwd: process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    return {
      ok: true,
      source: 'scripts/team-overall-score.mjs --json',
      parsed: JSON.parse(raw),
    };
  } catch (error) {
    return {
      ok: false,
      source: sourcePath || null,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

function normalizeTeamScoreEvidence(parsed, source) {
  const score = parsed?.score || parsed || {};
  const learningPacket = parsed?.learningPacket || {};
  const dimensions = Array.isArray(score.dimensions) ? score.dimensions : [];
  const weakest = score.weakest || dimensions.slice().sort((a, b) => Number(a.score || 0) - Number(b.score || 0))[0] || null;
  const nextMove = compactSentence(
    score.nextMove
      || (weakest ? `Raise ${weakest.label || weakest.id || 'Team Overall'}: ${weakest.recommendation || 'Run one verified improvement loop.'}` : ''),
    220,
  );
  if (!nextMove || !weakest) return null;
  const latestReward = parsed?.taskLedger?.latestReward || parsed?.latestReward || null;
  const targetMember = learningPacket.targetMember || parsed?.targetMember || null;
  return {
    source: source || 'unknown',
    overall: Number.isFinite(Number(score.overall)) ? Number(score.overall) : null,
    formula: score.formula || null,
    next_move: nextMove,
    weakest: {
      id: weakest.id || null,
      label: weakest.label || weakest.id || 'Team Overall',
      score: Number.isFinite(Number(weakest.score)) ? Number(weakest.score) : null,
      recommendation: weakest.recommendation || null,
      evidence: weakest.evidence || null,
    },
    latest_reward: latestReward ? {
      ref: latestReward.ref || latestReward.display_id || latestReward.id || null,
      title: latestReward.title || null,
      reward: latestReward.reward == null ? null : Number.isFinite(Number(latestReward.reward)) ? Number(latestReward.reward) : null,
      proof: latestReward.proof || null,
    } : null,
    target_member: targetMember ? {
      slug: targetMember.slug || null,
      label: targetMember.label || targetMember.slug || null,
      overall: Number.isFinite(Number(targetMember.overall)) ? Number(targetMember.overall) : null,
      next: targetMember.next || null,
      weakest_attribute: targetMember.weakestAttribute || targetMember.weakest_attribute || null,
    } : null,
    drill: learningPacket.drill || null,
    verifier: learningPacket.verifier || null,
    generated_at: parsed?.generated_at || parsed?.generatedAt || parsed?.created_at || null,
  };
}

function latestRewardLine(latestReward) {
  if (!latestReward) return 'no latest reward receipt';
  const ref = latestReward.ref ? `${latestReward.ref} ` : '';
  const reward = latestReward.reward == null ? '' : ` reward ${latestReward.reward}`;
  const proof = latestReward.proof ? ` - ${compactSentence(latestReward.proof, 120)}` : '';
  return `${ref}${latestReward.title || 'latest reviewed task'}${reward}${proof}`.trim();
}

function readSteeringMemory(paths, name) {
  if (!fs.existsSync(paths.steeringJsonl)) return [];
  const records = [];
  try {
    for (const line of fs.readFileSync(paths.steeringJsonl, 'utf8').split(/\r?\n/)) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      const record = JSON.parse(trimmed);
      if (!record || record.schema !== 'atris.steering.v1' || (record.status || 'active') !== 'active') continue;
      const member = record.scope?.member;
      if (member && member !== name) continue;
      records.push({
        id: record.id,
        kind: record.kind || 'preference',
        created_at: record.created_at || null,
        raw: record.raw || null,
        memory: Array.isArray(record.memory) ? record.memory.filter(Boolean).slice(0, 8) : [],
        anti_patterns: Array.isArray(record.anti_patterns) ? record.anti_patterns.filter(Boolean).slice(0, 8) : [],
        applies_to: Array.isArray(record.applies_to) ? record.applies_to.filter(Boolean).slice(0, 8) : [],
      });
    }
  } catch {
    return [];
  }
  return records.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || ''))).slice(0, 12);
}

const WAKE_DIRECTIVE_DECISIONS = new Set(['close_loop', 'report_proof', 'create_missing_task', 'ask', 'wait']);
const CLOSED_TASK_STATUSES = new Set(['done', 'complete', 'completed', 'reviewed', 'failed', 'stopped', 'closed', 'cancelled', 'canceled']);

function parseWakeDirectiveLine(line) {
  const match = String(line || '').match(/\bwake directive:\s*(close_loop|report_proof|create_missing_task|ask|wait)\b(?:\s*[-:]\s*(.*))?/i);
  if (!match) return null;
  return {
    decision: match[1].toLowerCase(),
    note: compactSentence(match[2] || '', 180),
  };
}

function commandForWakeDirective(name, directive, goal) {
  const note = directive.note || goal?.title || 'self-improvement loop';
  if (directive.decision === 'close_loop') return `atris task next --json`;
  if (directive.decision === 'report_proof') return `atris task note ${note}`;
  if (directive.decision === 'create_missing_task') return `atris task delegate "${note}" --to ${name} --tag agent`;
  if (directive.decision === 'ask') return `ask: ${note}`;
  return `atris member loop ${name} --status --json`;
}

function taskRefsFromText(text) {
  return [...new Set(String(text || '').match(/\b[A-Z]{2,10}-\d+\b/gi)?.map((ref) => ref.toUpperCase()) || [])];
}

function steeringWakeDirective(steering, name, goal) {
  for (const record of steering || []) {
    const lines = [...(record.memory || []), record.raw || ''];
    const task_refs = taskRefsFromText(lines.join('\n'));
    for (const line of lines) {
      const parsed = parseWakeDirectiveLine(line);
      if (!parsed || !WAKE_DIRECTIVE_DECISIONS.has(parsed.decision)) continue;
      return {
        ...parsed,
        steering_id: record.id || null,
        task_refs,
        next_command: commandForWakeDirective(name, parsed, goal),
      };
    }
  }
  return null;
}

function taskRef(task) {
  return task?.display_id || task?.displayId || task?.legacy_ref || task?.legacyRef || task?.ref || task?.id || null;
}

function lowerCompact(value) {
  return String(value || '').trim().toLowerCase();
}

function shellQuote(value) {
  return `'${String(value || '').replace(/'/g, "'\\''")}'`;
}

function taskCandidateOwnerValues(task) {
  return [
    task?.claimed_by,
    task?.claimedBy,
    task?.assigned_to,
    task?.assignedTo,
    task?.owner,
    task?.metadata?.assigned_to,
    task?.metadata?.assignedTo,
    task?.metadata?.owner,
    task?.atrisContext?.teamMember,
  ].filter(Boolean).map(lowerCompact);
}

function taskBelongsToMember(task, name) {
  return taskCandidateOwnerValues(task).includes(lowerCompact(name));
}

function taskHasReviewProof(task) {
  if (task?.review?.proof) return true;
  if (task?.proof) return true;
  return (task?.events || []).some((event) => event?.payload?.proof || event?.payload?.review?.proof);
}

function taskIsTaggedNeedsHuman(task) {
  if (!task || typeof task !== 'object') return false;
  if (task?.metadata?.needs_human === true || task?.metadata?.human_only === true) return true;
  const tags = [
    task.tag,
    ...(Array.isArray(task.tags) ? task.tags : []),
    task.metadata?.tag,
    ...(Array.isArray(task.metadata?.tags) ? task.metadata.tags : []),
  ]
    .filter(Boolean)
    .flatMap((t) => String(t).split(/[,;\s]+/))
    .map(lowerCompact);
  return tags.some((t) => t === 'needs-human' || t === 'needs_human' || t === 'human-only' || t === 'human_only');
}

function taskCandidateFromSource(task, source, sourcePath = '') {
  if (taskIsTaggedNeedsHuman(task)) return null;
  const ref = taskRef(task);
  if (!ref) return null;
  const status = lowerCompact(task.status || task.state || 'open');
  const title = compactSentence(task.title || task.summary || ref, 120);
  const base = {
    source,
    source_path: sourcePath || null,
    task_ref: ref,
    title,
    status,
    claimed_by: task.claimed_by || task.claimedBy || null,
    assigned_to: task.assigned_to || task.assignedTo || task.owner || task.metadata?.assigned_to || task.metadata?.owner || null,
    proof: task.review?.proof || task.proof || null,
    updated_at: task.updated_at || task.updatedAt || task.done_at || task.created_at || task.createdAt || null,
  };

  if (['blocked', 'needs_you', 'needs-user', 'needs_user'].includes(status)) {
    return {
      ...base,
      decision: 'ask',
      ask: compactSentence(task.blocker || task.block?.ask || task.review?.next_task || `Need operator input for ${ref}.`, 180),
      next_command: `atris task show ${ref} --json`,
    };
  }

  if (['review', 'ready'].includes(status)) {
    return taskHasReviewProof(task)
      ? null
      : {
          ...base,
          decision: 'report_proof',
          ask: null,
          next_command: `atris task note ${ref} "Report proof for completed loop: ${title}"`,
        };
  }

  if (['open', 'backlog', 'claimed', 'in_progress', 'in-progress', 'working', 'plan', 'do'].includes(status)) {
    const alreadyClaimedByMember = lowerCompact(base.claimed_by) === lowerCompact(base.assigned_to);
    return {
      ...base,
      decision: 'close_loop',
      ask: null,
      next_command: alreadyClaimedByMember
        ? `atris task note ${ref} "Closing nearest open loop: ${title}"`
        : `atris task claim ${ref} --as ${base.assigned_to || 'member'}`,
    };
  }

  if (status === 'done' && !taskHasReviewProof(task)) {
    return {
      ...base,
      decision: 'report_proof',
      ask: null,
      next_command: `atris task note ${ref} "Report proof for completed loop: ${title}"`,
    };
  }

  return null;
}

function goalEvidenceStrings(goal) {
  const seen = new Set();
  const out = [];
  function push(value) {
    if (typeof value !== 'string') return;
    const trimmed = value.trim();
    if (!trimmed || seen.has(trimmed)) return;
    seen.add(trimmed);
    out.push(trimmed);
  }
  function walk(value, depth = 0) {
    if (depth > 4 || value == null) return;
    if (typeof value === 'string') {
      push(value);
      return;
    }
    if (Array.isArray(value)) {
      value.slice(0, 30).forEach((item) => walk(item, depth + 1));
      return;
    }
    if (typeof value === 'object') {
      for (const [key, item] of Object.entries(value).slice(0, 60)) {
        if (/^(history|experiments)$/i.test(key)) continue;
        walk(item, depth + 1);
      }
    }
  }
  walk(goal);
  return out;
}

function normalizeEvidencePath(raw, root = process.cwd()) {
  let value = String(raw || '').trim().replace(/^["'`(<[]+|["'`)>.,;\]]+$/g, '');
  value = value.replace(/:\d+(?::\d+)?$/, '');
  if (!value || value.includes('\0')) return null;
  if (/^[a-z]+:\/\//i.test(value)) return null;
  if (value.startsWith('~/')) value = path.join(os.homedir(), value.slice(2));
  const resolved = path.isAbsolute(value) ? path.resolve(value) : path.resolve(root, value);
  const workspace = path.resolve(root);
  if (resolved !== workspace && !resolved.startsWith(`${workspace}${path.sep}`)) return null;
  const rel = path.relative(workspace, resolved);
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) return null;
  if (rel.split(path.sep).some((part) => ['.git', 'node_modules', 'dist', 'build'].includes(part))) return null;
  return { input: raw, path: resolved, relative_path: rel };
}

function filePathsFromGoal(goal, root = process.cwd()) {
  const explicit = [
    goal?.mission_file,
    goal?.missionFile,
    goal?.source_file,
    goal?.sourceFile,
    goal?.verifier,
  ].filter(Boolean);
  const text = [...explicit, ...goalEvidenceStrings(goal)].join('\n');
  const matches = [];
  const pathPattern = /(?:^|[\s"'(])((?:~\/|\.{1,2}\/|\/)?(?:[A-Za-z0-9._-]+\/)+[A-Za-z0-9._-]+\.[A-Za-z0-9_-]{1,12})(?::\d+(?::\d+)?)?/g;
  const rootFilePattern = /(?:^|[\s"'(])([A-Za-z0-9._-]+\.(?:md|json|js|cjs|mjs|ts|tsx|py|yml|yaml|toml|txt|csv))(?::\d+(?::\d+)?)?/g;
  for (const pattern of [pathPattern, rootFilePattern]) {
    let match = pattern.exec(text);
    while (match) {
      matches.push(match[1]);
      match = pattern.exec(text);
    }
  }
  return [...new Map(
    matches
      .map((item) => normalizeEvidencePath(item, root))
      .filter(Boolean)
      .map((item) => [item.relative_path, item]),
  ).values()].slice(0, 12);
}

function readGoalFileEvidence(goal, root = process.cwd()) {
  const paths = filePathsFromGoal(goal, root);
  const files = [];
  for (const item of paths) {
    const row = {
      input: item.input,
      path: item.relative_path,
      exists: false,
      bytes: 0,
      excerpt: '',
      truncated: false,
    };
    try {
      const stat = fs.statSync(item.path);
      if (!stat.isFile()) {
        row.error = 'not_file';
        files.push(row);
        continue;
      }
      row.exists = true;
      row.bytes = stat.size;
      const maxBytes = 8000;
      const raw = fs.readFileSync(item.path, 'utf8');
      row.excerpt = raw.slice(0, maxBytes);
      row.truncated = raw.length > maxBytes;
    } catch (error) {
      row.error = error && error.code ? error.code : 'read_failed';
    }
    files.push(row);
  }
  return {
    path_count: paths.length,
    files_read: files.filter((file) => file.exists && file.excerpt).length,
    files,
  };
}

function taskIsClosed(task) {
  if (!task) return false;
  const status = lowerCompact(task.status || task.state || '');
  if (CLOSED_TASK_STATUSES.has(status)) return true;
  return Boolean(task.done_at || task.doneAt) && !['open', 'backlog', 'claimed', 'in_progress', 'in-progress', 'working', 'plan', 'do', 'review', 'ready'].includes(status);
}

function taskProjectionRows() {
  const projectionPath = path.join(process.cwd(), '.atris', 'state', 'tasks.projection.json');
  const projection = readJson(projectionPath);
  return Array.isArray(projection?.tasks) ? projection.tasks : [];
}

function findProjectionTaskByRef(ref) {
  const wanted = String(ref || '').toUpperCase();
  return taskProjectionRows().find((task) => String(taskRef(task) || '').toUpperCase() === wanted) || null;
}

function readTaskShowByRef(ref) {
  try {
    const cliPath = path.join(__dirname, '..', 'bin', 'atris.js');
    const output = execFileSync(process.execPath, [cliPath, 'task', 'show', ref, '--json'], {
      cwd: process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 5000,
    });
    const parsed = JSON.parse(output || '{}');
    return parsed?.task || parsed || null;
  } catch {
    return null;
  }
}

function resolveTaskRefStatus(ref) {
  const projectionTask = findProjectionTaskByRef(ref);
  if (projectionTask) {
    return {
      ref,
      found: true,
      source: 'task_projection',
      status: projectionTask.status || projectionTask.state || null,
      closed: taskIsClosed(projectionTask),
    };
  }
  const shownTask = readTaskShowByRef(ref);
  if (shownTask) {
    return {
      ref,
      found: true,
      source: 'task_show',
      status: shownTask.status || shownTask.state || null,
      closed: taskIsClosed(shownTask),
    };
  }
  return {
    ref,
    found: false,
    source: null,
    status: null,
    closed: false,
  };
}

function steeringDirectiveClosure(directive) {
  const refs = Array.isArray(directive?.task_refs) ? directive.task_refs : [];
  const tasks = refs.map(resolveTaskRefStatus);
  const missing_refs = tasks.filter((task) => !task.found).map((task) => task.ref);
  const open_refs = tasks.filter((task) => task.found && !task.closed).map((task) => task.ref);
  const closed_refs = tasks.filter((task) => task.found && task.closed).map((task) => task.ref);
  return {
    steering_id: directive?.steering_id || null,
    task_refs: refs,
    tasks,
    closed_refs,
    open_refs,
    missing_refs,
    all_closed: refs.length > 0 && open_refs.length === 0 && missing_refs.length === 0,
  };
}

function candidatePriority(candidate) {
  const decisionPriority = {
    ask: 4,
    close_loop: 3,
    report_proof: 2,
    create_missing_task: 1,
  }[candidate?.decision] || 0;
  const sourcePriority = {
    task_projection: 3,
    member_room: 2,
    member_room_unlinked_request: 2,
  }[candidate?.source] || 0;
  return decisionPriority * 10 + sourcePriority;
}

function sortEvidenceCandidates(candidates) {
  return candidates
    .filter(Boolean)
    .slice()
    .sort((a, b) => {
      const byPriority = candidatePriority(b) - candidatePriority(a);
      if (byPriority) return byPriority;
      return String(b.updated_at || '').localeCompare(String(a.updated_at || ''));
    });
}

function readTaskProjectionEvidence(name) {
  const projectionPath = path.join(process.cwd(), '.atris', 'state', 'tasks.projection.json');
  const projection = readJson(projectionPath);
  const tasks = taskProjectionRows();
  const candidates = sortEvidenceCandidates(
    tasks
      .filter((task) => taskBelongsToMember(task, name))
      .map((task) => taskCandidateFromSource(task, 'task_projection', projectionPath)),
  );
  return {
    path: projectionPath,
    exists: Boolean(projection),
    task_count: tasks.length,
    candidate_count: candidates.length,
    candidates: candidates.slice(0, 20),
    nearest: candidates[0] || null,
  };
}

function taskGoalId(task) {
  return task?.metadata?.goal_id
    || task?.metadata?.goalId
    || task?.goal_id
    || task?.goalId
    || task?.atrisContext?.goalId
    || '';
}

function missionTaskStatusRank(task) {
  const status = lowerCompact(task?.status || task?.state || '');
  if (['claimed', 'doing', 'in_progress', 'in-progress', 'working'].includes(status)) return 0;
  if (['open', 'todo', 'plan', 'planned'].includes(status)) return 1;
  if (['review', 'ready'].includes(status)) return 2;
  if (status === 'blocked') return 3;
  return 4;
}

function missionTaskUpdatedAt(task) {
  const numeric = Number(task?.updated_at || task?.updatedAt || task?.created_at || task?.createdAt || 0);
  if (Number.isFinite(numeric) && numeric > 0) return numeric;
  const parsed = Date.parse(task?.updated_at || task?.updatedAt || task?.created_at || task?.createdAt || '');
  return Number.isFinite(parsed) ? parsed : 0;
}

function taskOwnerLabel(task) {
  return task?.claimed_by
    || task?.claimedBy
    || task?.assigned_to
    || task?.assignedTo
    || task?.metadata?.assigned_to
    || task?.metadata?.owner
    || task?.owner
    || null;
}

function missionTaskContextForMember(name, missionId) {
  const wanted = String(missionId || '').trim();
  if (!wanted) return null;
  const tasks = taskProjectionRows()
    .filter((task) => String(taskGoalId(task) || '').trim() === wanted)
    .filter((task) => !taskIsClosed(task));
  if (!tasks.length) return null;
  const selected = tasks.slice().sort((a, b) => {
    const byOwner = (taskBelongsToMember(a, name) ? 0 : 1) - (taskBelongsToMember(b, name) ? 0 : 1);
    if (byOwner) return byOwner;
    const byStatus = missionTaskStatusRank(a) - missionTaskStatusRank(b);
    if (byStatus) return byStatus;
    const byUpdated = missionTaskUpdatedAt(a) - missionTaskUpdatedAt(b);
    if (byUpdated) return byUpdated;
    return String(a.title || '').localeCompare(String(b.title || ''));
  })[0];
  const ref = taskRef(selected);
  return {
    ref,
    title: compactSentence(selected.title || selected.summary || ref || 'mission task', 140),
    status: selected.status || selected.state || null,
    owner: taskOwnerLabel(selected),
    goal_id: wanted,
    command: `atris task current-step --goal-id ${wanted} --as ${name} --proof "<proof>" --json`,
  };
}

function nativeGoalFromMissionTask(name, goal, runtime, taskContext) {
  const missionId = runtime?.id || goal?.mission_id || null;
  const objective = taskContext
    ? `${name}: complete ${taskContext.ref} - ${taskContext.title}`
    : `${name}: ${goal.title}`;
  return {
    schema: 'atris.native_goal.v1',
    owner: name,
    runner: 'coding-agent',
    objective,
    slash_goal: objective,
    member_goal_id: goal.id,
    mission_id: missionId,
    task: taskContext || null,
    acceptance: taskContext ? [
      `Move ${taskContext.ref} to Review with a human-readable Result receipt.`,
      'Record the verifier/proof used to check the work.',
      'Stop only when the task is in Review, blocked with a human ask, or accepted by a human.',
    ] : goal.acceptance,
    next_command: taskContext?.command || `atris member tick ${name} --goal ${goal.id}`,
  };
}

function listThreadJsonFiles(root) {
  if (!root || !fs.existsSync(root)) return [];
  const out = [];
  try {
    for (const entry of fs.readdirSync(root)) {
      const projectPath = path.join(root, entry);
      let stat = null;
      try {
        stat = fs.statSync(projectPath);
      } catch {
        continue;
      }
      if (stat.isFile() && entry.endsWith('.json')) {
        out.push({ path: projectPath, mtimeMs: stat.mtimeMs });
        continue;
      }
      if (!stat.isDirectory()) continue;
      for (const file of fs.readdirSync(projectPath)) {
        if (!file.endsWith('.json')) continue;
        const fullPath = path.join(projectPath, file);
        try {
          const fileStat = fs.statSync(fullPath);
          out.push({ path: fullPath, mtimeMs: fileStat.mtimeMs });
        } catch {
          // ignore unreadable thread files
        }
      }
    }
  } catch {
    return [];
  }
  return out.sort((a, b) => b.mtimeMs - a.mtimeMs).slice(0, 80);
}

function latestActionableUserLine(thread) {
  const messages = Array.isArray(thread?.messages) ? thread.messages : [];
  for (const message of messages.slice().reverse()) {
    if (message?.role !== 'user') continue;
    const text = compactSentence(message.text || message.content || '', 140);
    if (!text) continue;
    if (/\b(did you|was it|status|check if|quick check|what happened|what's happening)\b/i.test(text)) continue;
    if (/\b(fix|build|add|wire|prove|ship|close|make|implement|update|create)\b/i.test(text)) return text;
  }
  return '';
}

function readMemberRoomEvidence(name) {
  const roots = [path.join(process.cwd(), '.obelisk', 'threads')];
  const projectsPath = path.join(os.homedir(), '.obelisk', 'projects.json');
  const projects = readJson(projectsPath);
  if (Array.isArray(projects)) {
    const cwd = path.resolve(process.cwd());
    const project = projects.find((item) => item?.path && path.resolve(item.path) === cwd && item.id);
    if (project) roots.push(path.join(os.homedir(), '.obelisk', 'threads', project.id));
  }
  const seen = new Set();
  const candidates = [];
  let files_checked = 0;
  for (const root of roots) {
    for (const item of listThreadJsonFiles(root)) {
      if (seen.has(item.path)) continue;
      seen.add(item.path);
      const thread = readJson(item.path);
      files_checked += 1;
      const context = thread?.atrisContext || {};
      const linkedTasks = Array.isArray(context.linkedTasks) ? context.linkedTasks : [];
      const threadMember = lowerCompact(context.teamMember) === lowerCompact(name);
      for (const linked of linkedTasks) {
        const owned = lowerCompact(linked?.owner || linked?.teamMember || context.teamMember) === lowerCompact(name);
        if (!owned) continue;
        const candidate = taskCandidateFromSource(linked, 'member_room', item.path);
        if (candidate) candidates.push(candidate);
      }
      if (threadMember && linkedTasks.length === 0) {
        const updatedAtMs = Number(thread.updatedAt || thread.updated_at || item.mtimeMs || 0);
        if (updatedAtMs && Date.now() - updatedAtMs > 60 * 60 * 1000) continue;
        const request = latestActionableUserLine(thread);
        if (request) {
          candidates.push({
            source: 'member_room_unlinked_request',
            source_path: item.path,
            task_ref: null,
            title: request,
            status: 'missing_task',
            decision: 'create_missing_task',
            ask: null,
            next_command: `atris task delegate "${request}" --to ${name} --tag agent`,
            updated_at: thread.updatedAt || thread.updated_at || item.mtimeMs,
          });
        }
      }
    }
  }
  const sorted = sortEvidenceCandidates(candidates);
  return {
    files_checked,
    candidate_count: sorted.length,
    candidates: sorted.slice(0, 20),
    nearest: sorted[0] || null,
  };
}

function readRecentWakeReceiptEvidence(name) {
  const latestLoop = readJson(memberLoopPaths(name).latestPath);
  const receiptPath = Array.isArray(latestLoop?.tick_receipts)
    ? latestLoop.tick_receipts.slice().reverse().find(Boolean)
    : null;
  const latestWake = receiptPath ? readJson(receiptPath) : null;
  return {
    latest_loop_path: memberLoopPaths(name).latestPath,
    latest_loop_status: latestLoop?.status || null,
    latest_wake_receipt_path: receiptPath || null,
    latest_wake_decision: latestWake?.decision || null,
    latest_wake_reason: latestWake?.reason || null,
  };
}

function readJsonlRowsIfExists(filePath, maxRows = 80) {
  const tailBytes = 256 * 1024;
  let fd;
  let text = '';
  let truncated = false;
  try {
    fd = fs.openSync(filePath, 'r');
    const stat = fs.fstatSync(fd);
    const bytesToRead = Math.min(stat.size, tailBytes);
    const start = Math.max(0, stat.size - bytesToRead);
    const buffer = Buffer.alloc(bytesToRead);
    let bytesRead = 0;
    while (bytesRead < bytesToRead) {
      const count = fs.readSync(
        fd,
        buffer,
        bytesRead,
        bytesToRead - bytesRead,
        start + bytesRead
      );
      if (count === 0) break;
      bytesRead += count;
    }
    text = buffer.toString('utf8', 0, bytesRead);
    truncated = start > 0;
  } catch {
    return [];
  } finally {
    if (fd !== undefined) {
      try { fs.closeSync(fd); } catch {}
    }
  }
  const rows = [];
  const lines = text
    .split(/\r?\n/)
    .slice(truncated ? 1 : 0)
    .filter((line) => line.trim())
    .slice(-Math.max(1, maxRows));
  for (const line of lines) {
    try {
      rows.push(JSON.parse(line));
    } catch {
      // Bad rows should not block discovery from valid rows in the same stream.
    }
  }
  return rows;
}

function stringFromSignalValue(value) {
  if (typeof value === 'string') return value.trim();
  if (Array.isArray(value)) return value.map(stringFromSignalValue).filter(Boolean).slice(0, 4).join('; ');
  if (value && typeof value === 'object') {
    return [
      value.title,
      value.summary,
      value.reason,
      value.next_action,
      value.recommended_next_action,
      value.next_task_suggestion,
    ].map(stringFromSignalValue).find(Boolean) || '';
  }
  return '';
}

function valueAtPath(row, dottedPath) {
  return String(dottedPath || '').split('.').reduce((value, part) => {
    if (value == null || typeof value !== 'object') return null;
    return value[part];
  }, row);
}

function firstSignalText(row, paths) {
  for (const fieldPath of paths) {
    const text = stringFromSignalValue(valueAtPath(row, fieldPath));
    if (text) return text;
  }
  return '';
}

function signalTimestamp(row) {
  return row?.created_at
    || row?.createdAt
    || row?.generated_at
    || row?.finished_at
    || row?.timestamp
    || row?.ts
    || row?.at
    || row?.episode_created_at
    || null;
}

function actionableProblemText(text) {
  const value = compactSentence(text, 220);
  if (value.length < 12) return '';
  if (/^(none|null|false|n\/a|unknown)$/i.test(value)) return '';
  if (/\b(wait for|waiting for|manual send|owner approval only|human only)\b/i.test(value)) return '';
  const actionish = /\b(add|audit|build|capture|close|compile|connect|create|debug|discover|extract|fix|implement|ingest|model|patch|prove|rank|read|repair|review|scan|seed|ship|summarize|sync|test|triage|update|validate|verify|write)\b/i;
  const strategic = /\b(agi|autonomous|objective|world model|causal|transfer|architecture|emergent|scorecard|receipt|proof|telemetry|loop|customer|revenue|security|release)\b/i;
  return actionish.test(value) || strategic.test(value) ? value : '';
}

function titleFromProblemSignal(text) {
  const clean = compactSentence(text, 110)
    .replace(/^next\s+(task|move|action)\s*[:\-]\s*/i, '')
    .replace(/^recommended\s+next\s+(task|move|action)\s*[:\-]\s*/i, '')
    .replace(/^run\s+`([^`]+)`.*$/i, 'Run $1')
    .trim();
  if (!clean) return 'Investigate discovered problem';
  return `${clean[0].toUpperCase()}${clean.slice(1)}`;
}

function problemSignalSources(root = process.cwd()) {
  const sources = [];
  const seen = new Set();
  function push(source) {
    if (!source) return;
    const key = `${source.source}:${source.path}`;
    if (seen.has(key)) return;
    seen.add(key);
    sources.push(source);
  }
  for (const source of problemSignalFilesForStateDir(path.join(root, '.atris', 'state'))) push(source);
  const siblingBackend = resolveBackendRoot(root);
  if (siblingBackend) {
    for (const source of problemSignalFilesForStateDir(path.join(siblingBackend, '.atris', 'state'), 'backend')) push(source);
  }
  for (const source of configuredProblemSignalSources(root)) push(source);
  return sources;
}

function rowsFromProblemSignalSource(source) {
  if (source.kind === 'jsonl') return readJsonlRowsIfExists(source.path, 80);
  const row = readJson(source.path);
  return row ? [row] : [];
}

function logErrorScanScriptPath(root = process.cwd()) {
  const envPath = process.env.ATRIS_SCAN_ERRORS_SCRIPT;
  const candidates = [
    envPath ? path.resolve(root, envPath) : null,
    path.join(root, 'scripts', 'scan-errors.mjs'),
  ].filter(Boolean);
  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}

function runLogErrorScan(root = process.cwd()) {
  const scriptPath = logErrorScanScriptPath(root);
  if (!scriptPath) {
    return {
      ok: false,
      skipped: 'missing_scan_errors_script',
      script_path: path.join(root, 'scripts', 'scan-errors.mjs'),
    };
  }
  try {
    const stdout = execFileSync(process.execPath, [scriptPath, '--root', root, '--json'], {
      cwd: root,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 10000,
      env: process.env,
    });
    return {
      ok: true,
      script_path: scriptPath,
      scan: JSON.parse(stdout || '{}'),
    };
  } catch (error) {
    return {
      ok: false,
      script_path: scriptPath,
      error: error instanceof Error ? error.message : String(error),
      stderr: error?.stderr ? compactSentence(String(error.stderr), 500) : null,
    };
  }
}

function recurringErrorTaskTitle(pattern) {
  return `Fix recurring error: ${compactSentence(pattern, 90)}`;
}

function existingOpenTaskByTitle(title) {
  const wanted = lowerCompact(title);
  return taskProjectionRows().find((task) => lowerCompact(task.title) === wanted && !taskIsClosed(task)) || null;
}

function signalSourceKind(filePath, override = '') {
  const kind = lowerCompact(override || '');
  if (kind === 'jsonl' || kind === 'json') return kind;
  return String(filePath || '').endsWith('.jsonl') ? 'jsonl' : 'json';
}

function signalSourceLabel(value, fallback = 'external') {
  const clean = lowerCompact(value || fallback).replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return clean || fallback;
}

function problemSignalFilesForStateDir(stateDir, prefix = '') {
  const label = (name) => prefix ? `${prefix}_${name}` : name;
  return [
    { source: label('scorecards'), path: path.join(stateDir, 'scorecards.jsonl'), kind: 'jsonl' },
    { source: label('episodes'), path: path.join(stateDir, 'episodes.jsonl'), kind: 'jsonl' },
    { source: label('task_episodes'), path: path.join(stateDir, 'task_episodes.jsonl'), kind: 'jsonl' },
    { source: label('events'), path: path.join(stateDir, 'events.jsonl'), kind: 'jsonl' },
    { source: label('master_loop_events'), path: path.join(stateDir, 'master_loop_events.jsonl'), kind: 'jsonl' },
    { source: label('pulse_agi_loop_receipts'), path: path.join(stateDir, 'pulse_agi_loop_receipts.jsonl'), kind: 'jsonl' },
    { source: label('company_yc_wow_latest'), path: path.join(stateDir, 'company_yc_wow_latest.json'), kind: 'json' },
  ];
}

function normalizeSignalRoot(raw, baseDir = process.cwd()) {
  const text = typeof raw === 'string'
    ? raw
    : raw?.path || raw?.root || raw?.workspace || '';
  if (!text || String(text).includes('\0')) return null;
  const expanded = String(text).trim().startsWith('~/')
    ? path.join(os.homedir(), String(text).trim().slice(2))
    : String(text).trim();
  if (!expanded) return null;
  const resolved = path.isAbsolute(expanded) ? path.resolve(expanded) : path.resolve(baseDir, expanded);
  try {
    if (!fs.statSync(resolved).isDirectory()) return null;
  } catch {
    return null;
  }
  const label = signalSourceLabel(raw?.label || raw?.source || path.basename(resolved), 'external');
  return { root: resolved, label };
}

function configuredSignalFile(raw, baseDir = process.cwd()) {
  if (!raw) return null;
  const filePath = typeof raw === 'string' ? raw : raw.path || raw.file || '';
  if (!filePath || String(filePath).includes('\0')) return null;
  const expanded = String(filePath).trim().startsWith('~/')
    ? path.join(os.homedir(), String(filePath).trim().slice(2))
    : String(filePath).trim();
  if (!expanded) return null;
  const resolved = path.isAbsolute(expanded) ? path.resolve(expanded) : path.resolve(baseDir, expanded);
  if (!/\.(jsonl|json)$/i.test(resolved)) return null;
  const label = signalSourceLabel(raw?.source || raw?.label || path.basename(resolved).replace(/\.(jsonl|json)$/i, ''), 'external_file');
  return {
    source: label,
    path: resolved,
    kind: signalSourceKind(resolved, raw?.kind || ''),
  };
}

function readMemberSignalSourceConfig(root = process.cwd()) {
  const candidates = [
    path.join(root, '.atris', 'state', 'member-signal-sources.json'),
    path.join(root, '.atris', 'member-signal-sources.json'),
  ];
  for (const configPath of candidates) {
    const config = readJson(configPath);
    if (config && typeof config === 'object') return { config, configPath };
  }
  return { config: null, configPath: null };
}

function configuredProblemSignalSources(root = process.cwd()) {
  const sources = [];
  const seen = new Set();
  function push(source) {
    if (!source) return;
    const key = `${source.source}:${source.path}`;
    if (seen.has(key)) return;
    seen.add(key);
    sources.push(source);
  }

  const envRoots = String(process.env.ATRIS_MEMBER_SIGNAL_ROOTS || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
  for (const item of envRoots) {
    const normalized = normalizeSignalRoot(item, root);
    if (!normalized) continue;
    for (const source of problemSignalFilesForStateDir(path.join(normalized.root, '.atris', 'state'), normalized.label)) {
      push(source);
    }
  }

  const { config } = readMemberSignalSourceConfig(root);
  if (config) {
    const rootEntries = [
      ...(Array.isArray(config.roots) ? config.roots : []),
      ...(Array.isArray(config.external_roots) ? config.external_roots : []),
    ];
    for (const entry of rootEntries) {
      const normalized = normalizeSignalRoot(entry, root);
      if (!normalized) continue;
      for (const source of problemSignalFilesForStateDir(path.join(normalized.root, '.atris', 'state'), normalized.label)) {
        push(source);
      }
    }
    const fileEntries = [
      ...(Array.isArray(config.sources) ? config.sources : []),
      ...(Array.isArray(config.files) ? config.files : []),
    ];
    for (const entry of fileEntries) push(configuredSignalFile(entry, root));
  }

  return sources;
}

const PROBLEM_ACTION_FIELDS = [
  'next_task_suggestion',
  'recommended_next_action',
  'recommended_next_move',
  'next_owner_action',
  'next_operator_action',
  'next_action',
  'next_move',
  'next_task',
  'useful_work',
  'task',
  'summary.recommended_next_action',
  'summary.next_action',
  'summary.next_owner_action',
  'owner_gate.recommended_next_action',
  'owner_gate.next_owner_action',
  'action_packet.recommended_next_action',
  'task_seed.next_task',
  'decision.recommended_next_action',
];

const PROBLEM_CONTEXT_FIELDS = [
  'current_blocker',
  'first_external_blocker',
  'next_priority_gap',
  'lesson',
  'failure',
  'blocker',
  'why',
  'goal',
  'problem',
  'summary.current_blocker',
  'summary.next_priority_gap',
  'summary.pending_requirements',
  'owner_gate.pending_requirements',
  'pending_requirements',
  'blockers',
];

function problemCandidateFromSignal(row, source, rowIndex, name, purpose) {
  const actionText = actionableProblemText(firstSignalText(row, PROBLEM_ACTION_FIELDS));
  const contextText = actionableProblemText(firstSignalText(row, PROBLEM_CONTEXT_FIELDS));
  const seedText = actionText || contextText;
  if (!seedText) return null;
  const problem = contextText || seedText;
  const title = titleFromProblemSignal(seedText);
  const candidate = {
    source: source.source,
    source_path: source.path,
    signal_index: rowIndex,
    title,
    objective_title: title,
    problem: compactSentence(problem, 180),
    suggested_action: compactSentence(actionText || seedText, 180),
    next_command: `atris member wake ${name} --execute --confirm-autonomy-policy`,
    updated_at: signalTimestamp(row),
  };
  return scoreProblemCandidate(candidate, purpose);
}

function problemCandidateFromLogErrorScan(scanResult, name, purpose) {
  const scan = scanResult?.scan || {};
  const selected = scan.selected || (scan.pattern ? { pattern: scan.pattern, count: scan.count, evidence: [] } : null);
  const pattern = compactSentence(selected?.pattern || '', 180);
  const count = Number(selected?.count || scan.count || 0);
  const threshold = Number(scan.threshold || 3);
  if (!pattern || !Number.isFinite(count) || count < threshold) return null;
  const title = recurringErrorTaskTitle(pattern);
  const existingTask = existingOpenTaskByTitle(title);
  const duplicateRef = existingTask ? taskRef(existingTask) : null;
  const evidencePaths = Array.isArray(selected.evidence)
    ? [...new Set(selected.evidence.map((item) => item?.path).filter(Boolean))]
    : [];
  const candidate = {
    source: 'log_error_scan',
    source_path: scanResult.script_path,
    signal_index: null,
    title,
    objective_title: title,
    task_title: title,
    problem: `${count} occurrences in ${scan.since_hours || 24}h: ${pattern}`,
    suggested_action: title,
    autonomous_action: duplicateRef ? 'note_existing_task' : 'create_task',
    duplicate_task_ref: duplicateRef,
    error_pattern: pattern,
    error_count: count,
    evidence_paths: evidencePaths,
    next_command: duplicateRef
      ? `atris task show ${duplicateRef} --json`
      : `atris task new ${shellQuote(title)} --tag auto-discovery`,
    updated_at: new Date().toISOString(),
  };
  return scoreProblemCandidate(candidate, purpose);
}

function scoreProblemCandidate(candidate, purpose) {
  const text = `${candidate.title || ''} ${candidate.problem || ''} ${candidate.suggested_action || ''} ${purpose?.northStar || ''}`;
  const components = {
    urgency: Math.max(1, Math.min(5, 1 + scoreKeywords(text, ['blocked', 'missing', 'failed', 'failing', 'stalled', 'required', 'gap']))),
    strategic_value: strategicScore(text, { title: purpose?.northStar || '', why: purpose?.goalGuidance || '', acceptance: [] }, null),
    novelty: Math.max(1, Math.min(5, 2 + scoreKeywords(text, ['new', 'novel', 'discover', 'scan', 'unknown', 'emergent', 'explore']))),
    signal_quality: candidate.suggested_action && candidate.problem ? 5 : 3,
    recency: recencyScore(candidate.updated_at),
  };
  const sourceBoost = {
    pulse_agi_loop_receipts: 18,
    backend_pulse_agi_loop_receipts: 18,
    scorecards: 15,
    episodes: 10,
    task_episodes: 10,
    master_loop_events: 8,
    backend_master_loop_events: 8,
    log_error_scan: 22,
  }[candidate.source] || 4;
  const score = sourceBoost
    + (components.urgency * 22)
    + (components.strategic_value * 25)
    + (components.novelty * 16)
    + (components.signal_quality * 8)
    + (components.recency * 5);
  return { ...candidate, score, components };
}

function collectProblemDiscoveryEvidence(name, purpose, runtimeKind = memberRuntimeKind(name)) {
  const candidates = [];
  const sources = problemSignalSources();
  const sourcesWithRows = [];
  const logErrorScan = runtimeKind === 'signal-scout' ? runLogErrorScan() : null;
  const logErrorCandidate = logErrorScan ? problemCandidateFromLogErrorScan(logErrorScan, name, purpose) : null;
  if (logErrorCandidate) candidates.push(logErrorCandidate);
  for (const source of sources) {
    const rows = rowsFromProblemSignalSource(source);
    if (!rows.length) continue;
    sourcesWithRows.push({
      source: source.source,
      path: source.path,
      row_count: rows.length,
    });
    rows.forEach((row, index) => {
      const candidate = problemCandidateFromSignal(row, source, index, name, purpose);
      if (candidate) candidates.push(candidate);
    });
  }
  const deduped = [];
  const seen = new Set();
  for (const candidate of candidates.sort((a, b) => b.score - a.score)) {
    const key = lowerCompact(candidate.objective_title || candidate.title);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    deduped.push(candidate);
  }
  return {
    sources_checked: sources.length,
    sources_with_rows: sourcesWithRows,
    candidate_count: deduped.length,
    selected: deduped[0] ? {
      source: deduped[0].source,
      source_path: deduped[0].source_path,
      signal_index: deduped[0].signal_index,
      title: deduped[0].title,
      objective_title: deduped[0].objective_title,
      problem: deduped[0].problem,
      suggested_action: deduped[0].suggested_action,
      score: deduped[0].score,
      components: deduped[0].components,
      next_command: deduped[0].next_command,
      autonomous_action: deduped[0].autonomous_action || null,
      task_title: deduped[0].task_title || null,
      duplicate_task_ref: deduped[0].duplicate_task_ref || null,
      error_pattern: deduped[0].error_pattern || null,
      error_count: deduped[0].error_count || null,
      evidence_paths: deduped[0].evidence_paths || [],
    } : null,
    candidates: deduped.map((candidate) => ({
      source: candidate.source,
      title: candidate.title,
      objective_title: candidate.objective_title,
      problem: candidate.problem,
      suggested_action: candidate.suggested_action,
      score: candidate.score,
      components: candidate.components,
      next_command: candidate.next_command,
      autonomous_action: candidate.autonomous_action || null,
      task_title: candidate.task_title || null,
      duplicate_task_ref: candidate.duplicate_task_ref || null,
      error_pattern: candidate.error_pattern || null,
      error_count: candidate.error_count || null,
      evidence_paths: candidate.evidence_paths || [],
    })).slice(0, 12),
    log_error_scan: logErrorScan ? {
      ok: logErrorScan.ok === true,
      skipped: logErrorScan.skipped || null,
      script_path: displaySignalPath(logErrorScan.script_path),
      error: logErrorScan.error || null,
      threshold: logErrorScan.scan?.threshold || null,
      selected: logErrorScan.scan?.selected || null,
      scanned: logErrorScan.scan?.scanned || null,
    } : null,
  };
}

function collectWakeEvidence(name, goal = null, purpose = null, runtimeKind = memberRuntimeKind(name)) {
  const taskProjection = readTaskProjectionEvidence(name);
  const memberRoom = readMemberRoomEvidence(name);
  const receipt = readRecentWakeReceiptEvidence(name);
  const openLoopCandidates = sortEvidenceCandidates([
    ...(taskProjection.candidates || []),
    ...(memberRoom.candidates || []),
  ]);
  const nearest = openLoopCandidates[0] || null;
  return {
    task_projection: taskProjection,
    member_room: memberRoom,
    receipt,
    goal_files: goal ? readGoalFileEvidence(goal) : { path_count: 0, files_read: 0, files: [] },
    problem_discovery: goal && runtimeKind !== 'signal-scout'
      ? { sources_checked: 0, sources_with_rows: [], candidate_count: 0, selected: null, candidates: [], log_error_scan: null }
      : collectProblemDiscoveryEvidence(name, purpose || {}, runtimeKind),
    open_loop_candidates: openLoopCandidates.slice(0, 30),
    nearest_open_loop: nearest,
  };
}

function scoreKeywords(text, keywords) {
  const haystack = lowerCompact(text);
  return keywords.reduce((score, keyword) => score + (haystack.includes(keyword) ? 1 : 0), 0);
}

function strategicScore(text, goal = null, evidence = null) {
  const strategicKeywords = [
    'agi', 'autonomous', 'objective', 'world model', 'knowledge graph', 'meta',
    'causal', 'transfer', 'architecture', 'emergent', 'customer', 'revenue',
    'security', 'release', 'production', 'feedback', 'proof', 'strategy',
  ];
  const score = scoreKeywords(text, strategicKeywords);
  const goalText = compactSentence(`${goal?.title || ''} ${goal?.why || ''} ${(goal?.acceptance || []).join(' ')}`, 500).toLowerCase();
  const candidateWords = new Set(lowerCompact(text).split(/[^a-z0-9]+/).filter((word) => word.length >= 5));
  let overlap = 0;
  for (const word of candidateWords) {
    if (goalText.includes(word)) overlap += 1;
  }
  const fileBoost = evidence?.goal_files?.files_read ? 1 : 0;
  return Math.max(1, Math.min(5, score + Math.min(2, overlap) + fileBoost));
}

function noveltyScore(candidate, evidence = null) {
  const text = `${candidate?.title || ''} ${candidate?.reason || ''}`;
  let score = 2 + Math.min(3, scoreKeywords(text, ['new', 'novel', 'unknown', 'explore', 'experiment', 'discover', 'scan']));
  const recentDecision = evidence?.receipt?.latest_wake_decision || '';
  const recentReason = evidence?.receipt?.latest_wake_reason || '';
  if (candidate?.task_ref && recentReason.includes(candidate.task_ref)) score -= 1;
  if (candidate?.decision && candidate.decision === recentDecision) score -= 1;
  return Math.max(1, Math.min(5, score));
}

function recencyScore(value) {
  if (!value) return 1;
  const ms = typeof value === 'number' ? value : Date.parse(value);
  if (!Number.isFinite(ms)) return 1;
  const ageHours = Math.max(0, (Date.now() - ms) / (60 * 60 * 1000));
  if (ageHours <= 6) return 5;
  if (ageHours <= 24) return 4;
  if (ageHours <= 72) return 3;
  if (ageHours <= 168) return 2;
  return 1;
}

function scoreWakeCandidate(candidate, goal, evidence) {
  const urgencyByDecision = {
    ask: 5,
    report_proof: 4,
    close_loop: 3,
    create_missing_task: 3,
    tick: 1,
  };
  const proximityBySource = {
    steering: 5,
    task_projection: 5,
    member_room: 4,
    member_room_unlinked_request: 3,
    goal: 1,
  };
  const text = `${candidate.title || ''} ${candidate.ask || ''} ${candidate.reason || ''}`;
  const components = {
    urgency: urgencyByDecision[candidate.decision] || 1,
    strategic_value: strategicScore(text, goal, evidence),
    novelty: noveltyScore(candidate, evidence),
    loop_proximity: proximityBySource[candidate.source] || 1,
    recency: recencyScore(candidate.updated_at),
  };
  const score = (components.urgency * 30)
    + (components.strategic_value * 25)
    + (components.novelty * 15)
    + (components.loop_proximity * 10)
    + (components.recency * 5);
  return { ...candidate, score, components };
}

function scoredWakeCandidates(name, goal, evidence, directive = null) {
  const candidates = [];
  if (directive) {
    candidates.push({
      source: 'steering',
      decision: directive.decision,
      title: directive.note || `Steering directive for ${name}`,
      reason: `steering_directive:${directive.steering_id || 'unknown'}`,
      task_ref: Array.isArray(directive.task_refs) && directive.task_refs.length ? directive.task_refs[0] : null,
      ask: directive.decision === 'ask' ? directive.note || 'Needs operator direction.' : null,
      next_command: directive.next_command,
      updated_at: directive.created_at || null,
    });
  }
  for (const openLoop of evidence.open_loop_candidates || []) {
    const evidenceRef = openLoop.task_ref || 'missing_task';
    candidates.push({
      ...openLoop,
      reason: `nearest_open_loop:${openLoop.source}:${evidenceRef}`,
    });
  }
  if (goal) {
    candidates.push({
      source: 'goal',
      decision: 'tick',
      title: goal.title || `Next bounded step for ${name}`,
      reason: 'safe_next_bounded_step',
      task_ref: null,
      ask: null,
      next_command: `atris member tick ${name} --goal ${goal.id}`,
      updated_at: goal.updated_at || goal.created_at || null,
    });
  }
  const scored = candidates
    .map((candidate) => scoreWakeCandidate(candidate, goal, evidence))
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return candidatePriority(b) - candidatePriority(a);
    });
  return {
    selected: scored[0] || null,
    candidates: scored.map((candidate) => ({
      source: candidate.source,
      decision: candidate.decision,
      reason: candidate.reason,
      task_ref: candidate.task_ref || null,
      title: candidate.title,
      score: candidate.score,
      components: candidate.components,
      next_command: candidate.next_command,
    })).slice(0, 12),
  };
}

function memberValueSummary(state) {
  const reviewed = allExperiments(state)
    .map(({ experiment }) => experiment)
    .filter((experiment) => experiment.status === 'accepted' || experiment.status === 'discarded');
  const scored = reviewed.filter((experiment) => Number.isFinite(Number(experiment.value)));
  const accepted = reviewed.filter((experiment) => experiment.status === 'accepted').length;
  if (!reviewed.length) return { reviewed: 0, accepted: 0, average: null, line: 'No reviewed experiments yet.' };
  const average = scored.length
    ? Math.round((scored.reduce((sum, experiment) => sum + Number(experiment.value), 0) / scored.length) * 10) / 10
    : null;
  const scoreLine = average == null ? 'value not scored yet' : `avg value ${average}/5`;
  return { reviewed: reviewed.length, accepted, average, line: `${accepted}/${reviewed.length} accepted; ${scoreLine}.` };
}

function memberOpenExperiment(state) {
  return latestByTime(allExperiments(state)
    .map(({ goal, experiment }) => ({ ...experiment, goal_id: goal.id, goal_title: goal.title }))
    .filter((experiment) => ['blocked', 'proposed', 'running'].includes(experiment.status)));
}

function experimentIsClosed(experiment) {
  return ['accepted', 'discarded', 'superseded'].includes(String(experiment?.status || '').toLowerCase());
}

// A proposal that cannot be reviewed must not gate the member.
//
// wake returns decision 'wait' for any open experiment, on the theory that the
// ball is with a human reviewer. That is right for a real proposal. It is a
// permanent deadlock for a FALLBACK proposal: those carry verifier=null and
// generation.mode='fallback' (template text emitted when LLM authoring did not
// happen), and the review executor correctly refuses to accept anything
// unverifiable. So the member waits on a gate nothing can pass -- observed
// 2026-07-26 in project-obelisk with validator blocked 52 days, signal-scout 48,
// and land-keeper 22, three of six rostered members doing no work at all.
//
// Deliberately narrow: a proposal WITH a verifier still blocks (a human genuinely
// owes it a review), and 'running'/'blocked' still block regardless of shape.
function experimentIsUnreviewable(experiment) {
  if (String(experiment?.status || '').toLowerCase() !== 'proposed') return false;
  const verifier = experiment?.verifier;
  const hasVerifier = Array.isArray(verifier) ? verifier.length > 0 : Boolean(String(verifier || '').trim());
  if (hasVerifier) return false;
  return String(experiment?.generation?.mode || '').toLowerCase() === 'fallback';
}

function supersedeOtherOpenExperiments(state, activeGoal, proof) {
  const superseded = [];
  for (const goal of state.goals || []) {
    if (goal === activeGoal || goal.id === activeGoal?.id) continue;
    for (const experiment of goal.experiments || []) {
      if (!['proposed', 'running'].includes(experiment.status)) continue;
      experiment.status = 'superseded';
      experiment.superseded_at = stampIso();
      experiment.proof = proof;
      experiment.lesson = 'Direction changed by score-derived goal evidence.';
      experiment.source = experiment.source || 'previous_goal';
      superseded.push({
        goal_id: goal.id,
        goal_title: goal.title,
        experiment_id: experiment.id,
        experiment_title: experiment.title,
      });
    }
  }
  return superseded;
}

function memberLastReviewedExperiment(state) {
  return latestByTime(allExperiments(state)
    .map(({ goal, experiment }) => ({ ...experiment, goal_id: goal.id, goal_title: goal.title }))
    .filter((experiment) => experiment.status === 'accepted' || experiment.status === 'discarded'), 'reviewed_at');
}

function renderMemberGoalsMarkdown(state) {
  const lines = [
    '# Goals',
    '',
    '<!-- Generated from goals.json. Edit with `atris member goal/tick/review` when possible. -->',
    '',
  ];
  for (const goal of state.goals) {
    lines.push(`## ${goal.title}`);
    lines.push('');
    lines.push(`- id: ${goal.id}`);
    lines.push(`- status: ${goal.status}`);
    lines.push(`- cadence: ${goal.cadence || 'manual'}`);
    if (goal.why) lines.push(`- why: ${goal.why}`);
    const criteria = Array.isArray(goal.acceptance) ? goal.acceptance : [];
    if (criteria.length) {
      lines.push('- acceptance:');
      for (const item of criteria) lines.push(`  - ${item}`);
    }
    const experiments = Array.isArray(goal.experiments) ? goal.experiments : [];
    if (experiments.length) {
      lines.push('');
      lines.push('### Experiments');
      for (const experiment of experiments) {
        lines.push(`- ${experiment.id}: ${experiment.status} - ${experiment.title}`);
        if (experiment.proof) lines.push(`  - proof: ${experiment.proof}`);
        if (experiment.lesson) lines.push(`  - lesson: ${experiment.lesson}`);
        if (Number.isFinite(Number(experiment.value))) lines.push(`  - value: ${experiment.value}/5`);
        if (experiment.block?.ask) lines.push(`  - ask: ${experiment.block.ask}`);
      }
    }
    lines.push('');
  }
  if (state.goals.length === 0) lines.push('No goals yet.');
  return `${lines.join('\n').trimEnd()}\n`;
}

function writeMemberGoals(paths, state) {
  state.updated_at = stampIso();
  fs.writeFileSync(paths.goalsJson, JSON.stringify(state, null, 2) + '\n', 'utf8');
  fs.writeFileSync(paths.goalsMd, renderMemberGoalsMarkdown(state), 'utf8');
}

function displaySignalPath(filePath) {
  if (!filePath) return '';
  const rel = path.relative(process.cwd(), filePath);
  if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return rel;
  return filePath;
}

function seedAutonomousProblemGoal(name, paths, state, candidate, purpose) {
  const title = candidate.objective_title || candidate.title || 'Investigate discovered problem';
  const id = makeGoalId(title);
  const existing = state.goals.find((goal) => goal.id === id || lowerCompact(goal.title) === lowerCompact(title));
  const sourcePath = displaySignalPath(candidate.source_path);
  const goal = existing || {
    id,
    title,
    status: 'active',
    cadence: 'manual',
    why: `Autonomous problem discovery selected ${candidate.source}: ${candidate.problem || candidate.suggested_action || title}`,
    acceptance: [
      `Use discovery evidence from ${sourcePath || candidate.source} before proposing work.`,
      `Prove one bounded improvement toward: ${candidate.suggested_action || title}.`,
      'Leave a receipt or task note; do not claim the full AGI bar is complete from this slice.',
    ],
    source: 'autonomous_problem_discovery',
    source_signal: {
      source: candidate.source,
      source_path: sourcePath || candidate.source_path || null,
      signal_index: candidate.signal_index ?? null,
      problem: candidate.problem || null,
      suggested_action: candidate.suggested_action || null,
      score: candidate.score || null,
      components: candidate.components || null,
    },
    mission_snapshot: {
      north_star: purpose?.northStar || null,
      runtime_id: purpose?.runtimeMission?.id || null,
    },
    created_at: stampIso(),
    experiments: [],
    history: [],
  };
  goal.status = 'active';
  goal.cadence = goal.cadence || 'manual';
  goal.history = Array.isArray(goal.history) ? goal.history : [];
  goal.history.push({
    at: stampIso(),
    event: existing ? 'autonomous_problem_goal_reused' : 'autonomous_problem_goal_created',
    source: candidate.source,
    source_path: sourcePath || candidate.source_path || null,
    score: candidate.score || null,
  });
  if (!existing) state.goals.push(goal);
  writeMemberGoals(paths, state);
  return { goal, state, existing: Boolean(existing) };
}

function createAutonomousDiscoveryTask(candidate) {
  const title = candidate.task_title || candidate.objective_title || candidate.title || 'Fix recurring error';
  if (candidate.duplicate_task_ref) {
    return {
      ok: true,
      existing: true,
      task_ref: candidate.duplicate_task_ref,
      command: `atris task show ${candidate.duplicate_task_ref} --json`,
      task: findProjectionTaskByRef(candidate.duplicate_task_ref) || null,
    };
  }
  const commandArgs = ['task', 'new', title, '--tag', 'auto-discovery', '--json'];
  const command = `atris task new ${shellQuote(title)} --tag auto-discovery`;
  try {
    const stdout = execFileSync(process.execPath, [path.join(__dirname, '..', 'bin', 'atris.js'), ...commandArgs], {
      cwd: process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 10000,
      env: process.env,
    });
    const parsed = JSON.parse(stdout || '{}');
    const task = parsed.task || null;
    return {
      ok: parsed.ok !== false,
      existing: false,
      command,
      task,
      task_id: parsed.task_id || task?.id || null,
      task_ref: taskRef(task) || parsed.task_id || null,
      raw: parsed,
    };
  } catch (error) {
    return {
      ok: false,
      existing: false,
      command,
      error: error instanceof Error ? error.message : String(error),
      stderr: error?.stderr ? compactSentence(String(error.stderr), 500) : null,
    };
  }
}

function writeAutonomousDiscoveryReceipt(name, candidate, taskResult) {
  const runsDir = path.join(process.cwd(), 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const payload = {
    schema: 'atris.signal_scout_autonomous_discovery.v1',
    created_at: stampIso(),
    member: name,
    source: candidate.source,
    action: taskResult.existing ? 'existing_task_found' : 'task_created',
    task_ref: taskResult.task_ref || null,
    task_id: taskResult.task_id || taskResult.task?.id || null,
    task_title: candidate.task_title || candidate.objective_title || candidate.title || null,
    error_pattern: candidate.error_pattern || null,
    error_count: candidate.error_count || null,
    evidence_paths: candidate.evidence_paths || [],
    command: taskResult.command || candidate.next_command || null,
    ok: taskResult.ok === true,
    error: taskResult.error || null,
  };
  const receiptPath = path.join(runsDir, `signal-scout-autonomous-discovery-${fileSafeStamp()}.json`);
  fs.writeFileSync(receiptPath, JSON.stringify(payload, null, 2) + '\n', 'utf8');
  const fields = {
    team: name,
    decision: 'auto-discovery',
    pattern: payload.error_pattern,
    count: payload.error_count,
    task: payload.task_ref,
    receipt: path.relative(process.cwd(), receiptPath),
  };
  const projectLogPath = appendProjectLog('Signal Scout autonomous problem discovery', fields);
  return {
    receipt_path: receiptPath,
    project_log_path: projectLogPath,
    payload,
  };
}

function writeWakeReceipt(name, payload) {
  const runsDir = path.join(process.cwd(), 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const receiptPath = path.join(runsDir, `member-wake-${name}-${fileSafeStamp()}.json`);
  fs.writeFileSync(receiptPath, JSON.stringify(payload, null, 2) + '\n', 'utf8');
  return receiptPath;
}

function memberLoopPaths(name) {
  const stateDir = path.join(process.cwd(), '.atris', 'state', 'member-loops');
  return {
    stateDir,
    lockPath: path.join(stateDir, `${name}.lock.json`),
    stopPath: path.join(stateDir, `${name}.stop.json`),
    latestPath: path.join(stateDir, `${name}.latest.json`),
    cronScriptPath: path.join(stateDir, `${name}.hourly-alive.sh`),
  };
}

function memberAliveCronMarker(name) {
  return `ATRIS_MEMBER_ALIVE_${String(name || '').replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`;
}

function shellSingleQuote(value) {
  return `'${String(value || '').replace(/'/g, "'\\''")}'`;
}

function resolveAtrisCommand() {
  return path.join(__dirname, '..', 'bin', 'atris.js');
}

function buildMemberAliveCronScript(name, args = [], paths = memberLoopPaths(name)) {
  const root = process.cwd();
  const atrisBin = resolveAtrisCommand();
  const logDir = path.join(paths.stateDir, 'logs');
  const command = [
    process.execPath,
    atrisBin,
    'member',
    'alive',
    name,
    '--hourly',
    '--forever',
    '--ticks',
    '1',
    '--json',
    ...(hasFlag(args, '--execute') ? ['--execute'] : []),
    ...(hasFlag(args, '--confirm-autonomy-policy') ? ['--confirm-autonomy-policy'] : []),
    ...(hasFlag(args, '--shared-checkout') ? ['--shared-checkout'] : []),
  ];
  const agent = String(readFlag(args, '--agent', '') || '').trim();
  const model = String(readFlag(args, '--model', '') || '').trim();
  const maxWall = String(readFlag(args, '--operate-max-wall', readFlag(args, '--max-wall', '')) || '').trim();
  const autoAcceptLimit = String(readFlag(args, '--auto-accept-limit', '') || '').trim();
  if (agent) command.push('--agent', agent);
  if (model) command.push('--model', model);
  if (maxWall) command.push('--operate-max-wall', maxWall);
  if (autoAcceptLimit) command.push('--auto-accept-limit', autoAcceptLimit);
  const renderedCommand = command.map(shellSingleQuote).join(' ');
  return {
    command,
    rendered_command: renderedCommand,
    script: [
      '#!/bin/zsh',
      'set -u',
      `ROOT=${shellSingleQuote(root)}`,
      `LOG_DIR=${shellSingleQuote(logDir)}`,
      'mkdir -p "$LOG_DIR"',
      'stamp="$(date +"%Y%m%d-%H%M%S")"',
      'cd "$ROOT" || exit 1',
      'export ATRIS_SKIP_UPDATE_CHECK=1',
      `${renderedCommand} >> "$LOG_DIR/$stamp.log" 2>&1`,
      'echo "done: $(date -Iseconds) exit=$?" >> "$LOG_DIR/$stamp.log"',
      '',
    ].join('\n'),
  };
}

function memberAliveCronCadence(args = []) {
  const pulse = require('../lib/pulse');
  const raw = hasFlag(args, '--hourly') || hasFlag(args, '--every-hour')
    ? 'hourly'
    : readFlag(args, '--cadence', readFlag(args, '--cron', readFlag(args, '--interval', 'hourly')));
  return pulse.normalizeCronCadence(raw);
}

function buildMemberAliveCrontabLine(name, args = [], paths = memberLoopPaths(name)) {
  return `${memberAliveCronCadence(args)} ${paths.cronScriptPath} # ${memberAliveCronMarker(name)}`;
}

function dirtyGitStatus(root = process.cwd()) {
  const result = spawnSync('git', ['status', '--porcelain'], { cwd: root, encoding: 'utf8', timeout: 10000 });
  if (result.status !== 0) {
    return { inside_git: false, dirty: false, dirty_count: 0, dirty_files: [] };
  }
  const dirtyFiles = String(result.stdout || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  return {
    inside_git: true,
    dirty: dirtyFiles.length > 0,
    dirty_count: dirtyFiles.length,
    dirty_files: dirtyFiles.slice(0, 12),
  };
}

function memberAliveInstallPreview(name, args = [], paths = memberLoopPaths(name), script = buildMemberAliveCronScript(name, args, paths)) {
  return {
    schema: 'atris.member_alive_install_preview.v1',
    member: name,
    cadence: memberAliveCronCadence(args),
    mission_text: memberRunAutoMissionText(name, args),
    run: script.rendered_command,
    verify: `atris member alive ${name} --status --json`,
    stop_when: `Run atris member alive ${name} --uninstall, or create the stop marker at ${paths.stopPath}.`,
    receipts: path.join(paths.stateDir, 'logs'),
  };
}

function memberAliveInstallPreviewLines(preview) {
  return [
    'Every hour this will:',
    `  run: ${preview.run}`,
    `  verify: ${preview.verify}`,
    `  stop when: ${preview.stop_when}`,
    `  receipts: ${preview.receipts}`,
  ];
}

function installMemberAliveCron(name, args = []) {
  const asJson = hasFlag(args, '--json');
  const dryRun = hasFlag(args, '--dry-run');
  if (hasFlag(args, '--execute') && !hasFlag(args, '--confirm-autonomy-policy')) {
    const payload = {
      ok: false,
      action: 'alive_install',
      member: name,
      status: 'blocked',
      reason: 'execute_requires_confirm_autonomy_policy',
    };
    printJsonOrText(payload, [
      `Install blocked for ${name}: execute requires --confirm-autonomy-policy.`,
    ], asJson);
    process.exitCode = 1;
    return payload;
  }
  const paths = memberLoopPaths(name);
  fs.mkdirSync(paths.stateDir, { recursive: true });
  const script = buildMemberAliveCronScript(name, args, paths);
  const crontabLine = buildMemberAliveCrontabLine(name, args, paths);
  const preview = memberAliveInstallPreview(name, args, paths, script);
  if (hasFlag(args, '--execute') && !dryRun) {
    const gitStatus = dirtyGitStatus();
    if (gitStatus.dirty) {
      const payload = {
        ok: false,
        action: 'alive_install',
        member: name,
        status: 'blocked',
        reason: 'install_requires_clean_git',
        git: gitStatus,
        preview,
      };
      printJsonOrText(payload, [
        `Install blocked for ${name}: commit or clean local changes before installing an execute loop.`,
        ...memberAliveInstallPreviewLines(preview),
      ], asJson);
      process.exitCode = 1;
      return payload;
    }
  }
  fs.writeFileSync(paths.cronScriptPath, script.script, { mode: 0o755 });
  const marker = memberAliveCronMarker(name);
  let installed = false;
  let error = null;
  if (!dryRun) {
    const existing = spawnSync('crontab', ['-l'], { encoding: 'utf8', timeout: 10000 });
    const current = existing.status === 0 ? existing.stdout : '';
    const kept = String(current || '').split(/\r?\n/).filter((line) => line.trim() && !line.includes(marker));
    const next = `${kept.join('\n')}${kept.length ? '\n' : ''}${crontabLine}\n`;
    const apply = spawnSync('crontab', ['-'], { input: next, encoding: 'utf8', timeout: 10000 });
    installed = apply.status === 0;
    if (!installed) error = apply.stderr || `crontab exited ${apply.status}`;
  }
  const payload = {
    ok: dryRun || installed,
    action: 'alive_install',
    member: name,
    cadence: 'hourly',
    forever: true,
    installed,
    dry_run: dryRun,
    script_path: paths.cronScriptPath,
    crontab_line: crontabLine,
    command: script.command,
    preview,
    stop_command: `atris member alive ${name} --uninstall`,
    error,
  };
  writeJson(paths.latestPath, payload);
  printJsonOrText(payload, [
    `${dryRun ? 'Would install' : installed ? 'Installed' : 'Install failed'} hourly alive loop: ${name}`,
    `Cron: ${crontabLine}`,
    ...memberAliveInstallPreviewLines(preview),
    `Stop: ${payload.stop_command}`,
  ], asJson);
  if (!payload.ok) process.exitCode = 1;
  return payload;
}

function uninstallMemberAliveCron(name, args = []) {
  const asJson = hasFlag(args, '--json');
  const paths = memberLoopPaths(name);
  const marker = memberAliveCronMarker(name);
  const existing = spawnSync('crontab', ['-l'], { encoding: 'utf8', timeout: 10000 });
  if (existing.status !== 0) {
    const payload = { ok: true, action: 'alive_uninstall', member: name, removed: false, reason: 'no_crontab' };
    printJsonOrText(payload, [`No hourly alive crontab found for ${name}.`], asJson);
    return payload;
  }
  const before = String(existing.stdout || '').split(/\r?\n/);
  const after = before.filter((line) => !line.includes(marker));
  const removed = after.length !== before.length;
  const apply = spawnSync('crontab', ['-'], { input: after.filter(Boolean).join('\n') + (after.filter(Boolean).length ? '\n' : ''), encoding: 'utf8', timeout: 10000 });
  const payload = {
    ok: apply.status === 0,
    action: 'alive_uninstall',
    member: name,
    removed,
    marker,
    script_path: paths.cronScriptPath,
    error: apply.status === 0 ? null : apply.stderr || `crontab exited ${apply.status}`,
  };
  printJsonOrText(payload, [
    removed ? `Removed hourly alive loop: ${name}` : `No hourly alive line found for ${name}.`,
  ], asJson);
  if (!payload.ok) process.exitCode = 1;
  return payload;
}

function memberAliveCronStatus(name, paths = memberLoopPaths(name)) {
  const marker = memberAliveCronMarker(name);
  let crontabLine = null;
  const crontab = spawnSync('crontab', ['-l'], { encoding: 'utf8', timeout: 10000 });
  if (crontab.status === 0) {
    crontabLine = String(crontab.stdout || '').split(/\r?\n/).find((line) => line.includes(marker)) || null;
  }
  return {
    schema: 'atris.member_alive_cron_status.v1',
    marker,
    installed: Boolean(crontabLine),
    crontab_line: crontabLine,
    script_path: paths.cronScriptPath,
    script_exists: fs.existsSync(paths.cronScriptPath),
    install_command: `atris member alive ${name} --install --hourly --forever --execute --confirm-autonomy-policy --json`,
    uninstall_command: `atris member alive ${name} --uninstall`,
  };
}

function writeMemberLoopReceipt(name, payload) {
  const runsDir = path.join(process.cwd(), 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const receiptPath = path.join(runsDir, `member-loop-${name}-${fileSafeStamp()}.json`);
  fs.writeFileSync(receiptPath, JSON.stringify(payload, null, 2) + '\n', 'utf8');
  return receiptPath;
}

function isPidAlive(pid) {
  const numeric = Number(pid);
  if (!Number.isFinite(numeric) || numeric <= 0) return false;
  try {
    process.kill(numeric, 0);
    return true;
  } catch (error) {
    return error?.code === 'EPERM';
  }
}

function safeReadText(filePath, maxBytes = 250000) {
  try {
    const stat = fs.statSync(filePath);
    if (!stat.isFile() || stat.size > maxBytes) return '';
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function repoRelative(root, filePath) {
  return path.relative(root, filePath).replace(/\\/g, '/');
}

function dateFromLogPath(relativePath) {
  const match = String(relativePath || '').match(/\b(\d{4}-\d{2}-\d{2})\b/);
  return match ? match[1] : null;
}

// Mission driver logs, goals files, and the wiki log have no date in their
// name; without one they skipped the 7-day window and months-old lines kept
// counting as this week's pain. The last write date stands in for them.
function logDateForScan(relativePath, filePath) {
  const named = dateFromLogPath(relativePath);
  if (named) return named;
  try {
    // Local calendar day, like the dated journal names beside it;
    // toISOString is UTC and calls an evening write tomorrow's.
    const mtime = fs.statSync(filePath).mtime;
    return `${mtime.getFullYear()}-${String(mtime.getMonth() + 1).padStart(2, '0')}-${String(mtime.getDate()).padStart(2, '0')}`;
  } catch {
    return null;
  }
}

function compareLogEvidenceRecentFirst(a, b) {
  const dateA = a?.date || '';
  const dateB = b?.date || '';
  if (dateA !== dateB) return dateB.localeCompare(dateA);
  const pathCompare = String(a?.path || '').localeCompare(String(b?.path || ''));
  if (pathCompare !== 0) return pathCompare;
  return Number(a?.line || 0) - Number(b?.line || 0);
}

function compareRepeatedFailureSignals(a, b) {
  const countCompare = Number(b?.count || 0) - Number(a?.count || 0);
  if (countCompare !== 0) return countCompare;
  const evidenceCompare = compareLogEvidenceRecentFirst(a?.evidence?.[0], b?.evidence?.[0]);
  if (evidenceCompare !== 0) return evidenceCompare;
  return String(a?.pattern || '').localeCompare(String(b?.pattern || ''));
}

function listFilesBounded(rootDir, { maxFiles = 220, extensions = ['.md', '.txt', '.json', '.jsonl'] } = {}) {
  const files = [];
  const stack = [rootDir];
  const skipDirs = new Set(['.git', 'node_modules', '.next', 'dist', 'build', '__pycache__']);
  while (stack.length && files.length < maxFiles) {
    const current = stack.pop();
    let entries = [];
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
      if (files.length >= maxFiles) break;
      const fullPath = path.join(current, entry.name);
      if (entry.isDirectory()) {
        if (!skipDirs.has(entry.name) && !entry.name.startsWith('.')) stack.push(fullPath);
        continue;
      }
      if (!entry.isFile()) continue;
      if (extensions.includes(path.extname(entry.name))) files.push(fullPath);
    }
  }
  return files;
}

function stripAutoImproverTitleNoise(text) {
  let clean = String(text || '').replace(/\s+/g, ' ').trim();
  for (let i = 0; i < 6; i += 1) {
    const next = clean
      .replace(/^auto[- ]improver:\s*/i, '')
      .replace(/^recurring log pattern:\s*/i, '')
      .replace(/^candidate:\s*/i, '')
      .trim();
    if (next === clean) break;
    clean = next;
  }
  return compactSentence(clean, 180);
}

function isAutoImproverGeneratedLogLine(line, relativePath = '') {
  const text = String(line || '').trim();
  if (!text) return false;
  if (/^[-*]?\s*Next tick will stop until a human looks at the error\.?$/i.test(text)) return true;
  if (/^[-*]?\s*Next tick will verify failed, halting\.?$/i.test(text)) return true;
  if (/^##\s+\d{1,2}:\d{2}\s+·\s+Task failed$/i.test(text)) return true;
  if (/^[-*]?\s*(status|action|state|verifier)\s*:\s*(failed|blocked)\s*$/i.test(text)) return true;
  // Mission lines state a goal; their words ("leftover error text", "done failed") are not failures.
  // Goal files say the same in JSON ("stop_rule": "Stop if ... risk is unclear").
  if (/^[-*]?\s*"?(title|proof|proof_target|mission|objective|acceptance|stop_rule)"?\s*:\s*/i.test(text)) return true;
  // Driver logs print "error": null on every clean run.
  if (/^"?(error|failure)s?"?\s*:\s*(null|false|""|\[\]|\{\})\s*,?$/i.test(text)) return true;
  if (String(relativePath || '').startsWith('atris/team/auto-improver/logs/') && /^-\s*summary:\s*/i.test(text)) return true;
  if (/\bauto[- ]improver\b/i.test(text) && /\b(dogfood|receipt|prevented|pain_)\b/i.test(text)) return true;
  if (/\bauto_improver\b/i.test(text)) return true;
  if (/^-\s*candidate:\s*/i.test(text)) return true;
  if (/recurring log pattern:\s*(candidate:|recurring log pattern:)/i.test(text)) return true;
  return false;
}

function normalizeFailurePattern(line) {
  return stripAutoImproverTitleNoise(String(line || '')
    .replace(/^\s*[-*]\s*/, '')
    .replace(/\b\d{4}-\d{2}-\d{2}[T ][^\s]+/g, '<timestamp>')
    .replace(/[0-9a-f]{10,}/gi, '<hash>')
    .replace(/\b\d+\b/g, '#')
    .trim());
}

// Callers scanning many lines pass passLessonLower so the lessons file is
// lowercased once per scan, not once per log line.
function failureCoveredByPassLesson(line, passLessonText = '', passLessonLower = passLessonText.toLowerCase()) {
  const text = String(line || '');
  if (!text || !passLessonText) return false;
  if (/spawnSync\s+\/bin\/sh\s+ETIMEDOUT/i.test(text)) {
    const target = text.match(/"([^"]+)"/)?.[1] || '';
    const targetTail = target ? target.split('/').slice(-2).join('/') : '';
    return /spawnSync\s+\/bin\/sh\s+ETIMEDOUT/i.test(passLessonText)
      && (!target || passLessonText.includes(target) || (targetTail && passLessonText.includes(targetTail)));
  }
  // General remediation channel: a pass lesson that quotes the failure's
  // normalized pattern marks it fixed. Old log lines stay on disk but stop
  // feeding the pain score, so pain can actually go down after a fix.
  const pattern = normalizeFailurePattern(text);
  const bare = pattern.replace(/^#+\s*[#:.]*\s*·\s*/, '').trim();
  for (const candidate of [pattern, bare]) {
    if (candidate && candidate.length >= 12
      && passLessonLower.includes(candidate.toLowerCase())) {
      return true;
    }
  }
  return false;
}

// Runtime logs the repeat-failure scan reads, listed by where they live
// instead of one capped walk of atris/team. That folder holds hundreds of
// skill and mission files, and a 220-file walk ran out before it reached
// most members' logs, so this week's repeats counted as zero. Listing paths
// is cheap; the 7-day filter below decides what actually gets read.
function listAutoImproverRuntimeLogs(root) {
  const listAll = (dir) => (fs.existsSync(dir) ? listFilesBounded(dir, { maxFiles: 5000 }) : []);
  const childDirs = (dir) => {
    try {
      return fs.readdirSync(dir, { withFileTypes: true })
        .filter((entry) => entry.isDirectory() && !entry.name.startsWith('.'))
        .map((entry) => entry.name)
        .sort();
    } catch {
      return [];
    }
  };
  const files = [];
  const logsRoot = path.join(root, 'atris', 'logs');
  try {
    for (const entry of fs.readdirSync(logsRoot, { withFileTypes: true })) {
      if (entry.isFile()) files.push(path.join(logsRoot, entry.name));
    }
  } catch {}
  for (const name of childDirs(logsRoot)) {
    if (name !== 'archive') files.push(...listAll(path.join(logsRoot, name)));
  }
  const teamRoot = path.join(root, 'atris', 'team');
  for (const member of childDirs(teamRoot)) {
    for (const name of ['goals.md', 'goals.json']) {
      const goalsPath = path.join(teamRoot, member, name);
      if (fs.existsSync(goalsPath)) files.push(goalsPath);
    }
    files.push(...listAll(path.join(teamRoot, member, 'logs')));
  }
  const wikiLog = path.join(root, 'atris', 'wiki', 'log.md');
  if (fs.existsSync(wikiLog)) files.push(wikiLog);
  return files;
}

function collectAutoImproverLogSignals(root) {
  const passLessonText = safeReadText(path.join(root, 'atris', 'lessons.md'), 500000)
    .split(/\r?\n/)
    .filter((line) => /\s+pass\s*[-\u2014:,]/.test(line))
    .join('\n');
  const passLessonLower = passLessonText.toLowerCase();
  const failureRegex = /\b(error|failed|failure|blocked|timeout|regression|crash|missing proof|naraka|suffering)\b/i;
  const unclearRegex = /\b(tbd|unclear|unknown|needs user|needs owner|needs proof|no next|blocked)\b/i;
  const counts = new Map();
  const unclearActions = [];
  let filesScanned = 0;
  let linesScanned = 0;
  let unclearNextActions = 0;
  for (const filePath of listAutoImproverRuntimeLogs(root)) {
    const relative = repoRelative(root, filePath);
    const logDate = logDateForScan(relative, filePath);
    if (relative.startsWith('atris/logs/archive/')) continue;
    const isRuntimeLog = relative.startsWith('atris/logs/')
      || /^atris\/team\/[^/]+\/logs\//.test(relative)
      || /^atris\/team\/[^/]+\/goals\.(md|json)$/.test(relative)
      || relative === 'atris/wiki/log.md';
    if (!isRuntimeLog) continue;
    // Only scan logs from the last 7 days. Historical log lines keep
    // triggering false-positive findings long after their root cause is
    // fixed (e.g. "goal-from-mission blocked" from July when MISSION.md
    // was repaired in August). Old evidence stays on disk for audits;
    // it just stops feeding the pain score, so pain can actually drop.
    if (logDate && isRuntimeLog) {
      const logAgeDays = (Date.now() - new Date(logDate + 'T12:00:00').getTime()) / 864e5;
      if (logAgeDays > 7) continue;
    }
    const text = safeReadText(filePath);
    if (!text) continue;
    filesScanned += 1;
    const allLines = text.split(/\r?\n/);
    const lineOffset = Math.max(0, allLines.length - 500);
    const lines = allLines.slice(-500);
    linesScanned += lines.length;
    for (let index = 0; index < lines.length; index += 1) {
      const sourceLine = lineOffset + index + 1;
      const line = lines[index];
      if (isAutoImproverGeneratedLogLine(line, relative)) continue;
      // Declared verification receipts ("check: <command> ...") describe what
      // was verified, not what broke. Wiki upkeep sweeps write one per page,
      // so counting them as failures spawns bogus recurring-pattern tasks
      // (CLI-199 came from 13 such lines in atris/wiki/log.md).
      if (/^\s*[-*]?\s*check:\s/i.test(line)) continue;
      if (/\b(errors?|fail(?:ed|ures?)|blocked|timeouts?)\s*:\s*0\b/i.test(line)) continue;
      if (/\bblocked\s*(?:->|→|to)\s*ready\b/i.test(line)) continue;
      if (failureCoveredByPassLesson(line, passLessonText, passLessonLower)) continue;
      // A file name is not a next step ("receipt: atris/runs/...-unknown-word-...json"),
      // and "learned:" / "why:" lines explain the past, so neither counts as unclear.
      const unclearText = line.replace(/[\w.@~-]*\/[\w./@~-]*\.\w{1,5}\b/g, ' ');
      if (!/^\s*[-*]?\s*(learned|why)\s*:/i.test(line) && unclearRegex.test(unclearText)) {
        unclearNextActions += 1;
        unclearActions.push({
          path: relative,
          date: logDate,
          line: sourceLine,
          text: compactSentence(line, 180),
        });
      }
      if (!failureRegex.test(line)) continue;
      const pattern = normalizeFailurePattern(line);
      if (!pattern) continue;
      const existing = counts.get(pattern) || { pattern, count: 0, evidence: [] };
      existing.count += 1;
      existing.evidence.push({
        path: relative,
        date: logDate,
        line: sourceLine,
        text: compactSentence(line, 180),
      });
      counts.set(pattern, existing);
    }
  }
  const repeated = [...counts.values()]
    .filter((item) => item.count >= 2)
    .map((item) => ({
      ...item,
      evidence: item.evidence.sort(compareLogEvidenceRecentFirst).slice(0, 5),
    }))
    .sort(compareRepeatedFailureSignals)
    .slice(0, 8);
  return {
    files_scanned: filesScanned,
    lines_scanned: linesScanned,
    repeated_failures: repeated,
    repeated_failure_count: repeated.length,
    unclear_next_action_count: unclearNextActions,
    unclear_next_actions: unclearActions.sort(compareLogEvidenceRecentFirst).slice(0, 5),
  };
}

function autoImproverTaskWaitingForHuman(task, status) {
  if (taskIsTaggedNeedsHuman(task)) return true;
  if (status !== 'review') return false;
  const metadata = task?.metadata || {};
  const review = task?.review || {};
  const certified = metadata.agent_certified === true || review.agent_certified === true;
  const approval = lowerCompact(review.approval_status || metadata.approval_status || task?.approval_status || '');
  return certified && (!approval || approval === 'pending' || approval === 'agent_certified');
}

function collectAutoImproverTaskSignals(root) {
  const projectionPath = path.join(root, '.atris', 'state', 'tasks.projection.json');
  const projection = readJson(projectionPath);
  const tasks = Array.isArray(projection?.tasks) ? projection.tasks : [];
  const openStatuses = new Set(['open', 'todo', 'claimed', 'doing', 'in_progress', 'review', 'blocked']);
  const staleTasks = [];
  const blockedTasks = [];
  const reviewTasks = [];
  const unclearTasks = [];
  for (const task of tasks) {
    const status = lowerCompact(task.status || task.state || '');
    const title = task.title || task.name || task.objective || '';
    const sample = {
      ref: taskRef(task),
      title: compactSentence(title, 140),
      status: status || null,
      owner: task.claimed_by || task.assigned_to || task.owner || task.metadata?.assigned_to || null,
    };
    const waitingForHuman = autoImproverTaskWaitingForHuman(task, status);
    if (status === 'blocked') blockedTasks.push(sample);
    if (status === 'review') reviewTasks.push(sample);
    if (openStatuses.has(status) && !waitingForHuman) staleTasks.push(sample);
    if (openStatuses.has(status) && !waitingForHuman && /\b(tbd|unclear|unknown|needs proof|needs owner|blocked|stale|no next)\b/i.test(`${title} ${task.notes || ''}`)) {
      unclearTasks.push(sample);
    }
  }

  const todoPath = path.join(root, 'atris', 'TODO.md');
  const todoText = safeReadText(todoPath, 500000);
  const todoLines = todoText ? todoText.split(/\r?\n/) : [];
  const todoSignalLines = todoLines
    .filter((line) => /\b(TODO|CLAIMED|DOING|IN_PROGRESS|REVIEW|BLOCKED|stale|proof|next)\b/i.test(line))
    .slice(0, 40)
    .map((line) => compactSentence(line, 160));

  return {
    projection_path: fs.existsSync(projectionPath) ? repoRelative(root, projectionPath) : null,
    todo_path: fs.existsSync(todoPath) ? repoRelative(root, todoPath) : null,
    task_count: tasks.length,
    stale_tasks: staleTasks.slice(0, 12),
    stale_task_count: staleTasks.length || todoSignalLines.length,
    blocked_tasks: blockedTasks.slice(0, 8),
    blocked_task_count: blockedTasks.length,
    review_tasks: reviewTasks.slice(0, 8),
    review_task_count: reviewTasks.length,
    unclear_tasks: unclearTasks.slice(0, 8),
    unclear_task_count: unclearTasks.length,
    todo_signal_lines: todoSignalLines,
  };
}

function collectGitStatusSignals(root) {
  try {
    const stdout = execFileSync('git', ['status', '--short'], {
      cwd: root,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 5000,
    });
    const lines = stdout.split(/\r?\n/).filter(Boolean);
    return {
      is_git_repo: true,
      dirty_file_count: lines.length,
      sample: lines.slice(0, 20),
    };
  } catch {
    return { is_git_repo: false, dirty_file_count: 0, sample: [] };
  }
}

function extractRsiRouterPaths(routerText) {
  const paths = [];
  const regex = /@router\.(?:get|post|put|delete|patch)\(["']([^"']+)["']/g;
  let match = regex.exec(routerText);
  while (match) {
    paths.push(match[1]);
    match = regex.exec(routerText);
  }
  return paths;
}

function collectRepoContractChecks(root) {
  const autoImproverMember = path.join(root, 'atris', 'team', 'auto-improver', 'MEMBER.md');
  const memberJs = path.join(root, 'commands', 'member.js');
  const memberJsText = fs.existsSync(memberJs) ? safeReadText(memberJs, 900000) : '';
  const missingAliases = memberJsText
    ? Object.keys(MEMBER_RUNTIME_ALIASES).filter((alias) => !memberJsText.includes(alias))
    : [];
  const rsiRouter = path.join(root, 'backend', 'routers', 'rsi_router.py');
  const rsiService = path.join(root, 'backend', 'services', 'rsi_service.py');
  const routerText = safeReadText(rsiRouter, 300000);
  const serviceText = safeReadText(rsiService, 500000);
  const rsiChecked = fs.existsSync(rsiRouter) || fs.existsSync(rsiService);
  return {
    auto_improver_member: {
      checked: true,
      present: fs.existsSync(autoImproverMember),
      path: repoRelative(root, autoImproverMember),
    },
    member_aliases: {
      checked: fs.existsSync(memberJs),
      path: fs.existsSync(memberJs) ? repoRelative(root, memberJs) : null,
      aliases: MEMBER_RUNTIME_ALIASES,
      missing_aliases: missingAliases,
      complete: fs.existsSync(memberJs) && missingAliases.length === 0,
    },
    auto_improver_runtime: {
      checked: fs.existsSync(memberJs),
      present: memberJsText.includes('auto_improver_dogfood'),
      path: fs.existsSync(memberJs) ? repoRelative(root, memberJs) : null,
    },
    rsi_api: {
      checked: rsiChecked,
      router_path: fs.existsSync(rsiRouter) ? repoRelative(root, rsiRouter) : null,
      service_path: fs.existsSync(rsiService) ? repoRelative(root, rsiService) : null,
      exposed_paths: routerText ? extractRsiRouterPaths(routerText) : [],
      improve_endpoint_present: /["']\/improve["']/.test(routerText),
      auth_dependency_present: routerText.includes('authenticate_request'),
      usage_tracking_signal_present: /\b(usage|billing|credit|meter|track)\b/i.test(`${routerText}\n${serviceText}`),
    },
  };
}

function collectRepoContractGaps(root, checks = collectRepoContractChecks(root)) {
  const gaps = [];
  if (!checks.auto_improver_member.present) {
    gaps.push({
      id: 'auto_improver_member_missing',
      severity: 'high',
      title: 'Auto-improver member is not installed in this repo',
      evidence: ['atris/team/auto-improver/MEMBER.md missing'],
      recommendation: 'Install the auto-improver member so scans have an owner and log path.',
    });
  }

  if (checks.member_aliases.checked) {
    if (checks.member_aliases.missing_aliases.length) {
      gaps.push({
        id: 'simple_member_aliases_missing',
        severity: 'medium',
        title: 'Simple member aliases are not fully wired',
        evidence: checks.member_aliases.missing_aliases.map((alias) => `${alias} missing from commands/member.js`),
        recommendation: 'Wire simple aliases to their runtime member behavior before moving users to simple names.',
      });
    }
    if (!checks.auto_improver_runtime.present) {
      gaps.push({
        id: 'auto_improver_runtime_missing',
        severity: 'high',
        title: 'Auto-improver has docs but no executable dogfood scan',
        evidence: ['commands/member.js lacks auto_improver_dogfood receipt path'],
        recommendation: 'Add an executable wake path that writes scan receipts.',
      });
    }
  }

  if (checks.rsi_api.checked) {
    if (!checks.rsi_api.improve_endpoint_present) {
      gaps.push({
        id: 'rsi_improve_endpoint_missing',
        severity: 'high',
        title: 'RSI plan names /api/rsi/improve but backend exposes tick/run/status/history',
        evidence: ['backend/routers/rsi_router.py has no POST /api/rsi/improve'],
        recommendation: 'Either add /api/rsi/improve or update client/member instructions to call /api/rsi/tick.',
      });
    }
    if (!checks.rsi_api.auth_dependency_present) {
      gaps.push({
        id: 'rsi_auth_missing',
        severity: 'critical',
        title: 'RSI router is missing request authentication',
        evidence: ['authenticate_request not found in backend/routers/rsi_router.py'],
        recommendation: 'Gate RSI endpoints behind the existing API auth dependency.',
      });
    }
    if (!checks.rsi_api.usage_tracking_signal_present) {
      gaps.push({
        id: 'rsi_usage_tracking_missing',
        severity: 'high',
        title: 'RSI API has no obvious usage/billing meter in router or service',
        evidence: ['No usage, billing, credit, meter, or tracking term found in RSI router/service'],
        recommendation: 'Add explicit usage tracking before selling RSI API usage.',
      });
    }
  }
  return gaps;
}

function severityWeight(severity) {
  return { critical: 5, high: 4, medium: 2, low: 1 }[severity] || 1;
}

function collectAutoImproverScan(root = process.cwd()) {
  const logSignals = collectAutoImproverLogSignals(root);
  const taskSignals = collectAutoImproverTaskSignals(root);
  const gitSignals = collectGitStatusSignals(root);
  const contractChecks = collectRepoContractChecks(root);
  const contractGaps = collectRepoContractGaps(root, contractChecks);
  const findings = [];

  for (const gap of contractGaps) {
    findings.push({
      source: 'contract_gap',
      severity: gap.severity,
      title: gap.title,
      problem: gap.title,
      recommendation: gap.recommendation,
      evidence: gap.evidence,
      score: severityWeight(gap.severity) * 10,
    });
  }
  for (const failure of logSignals.repeated_failures) {
    findings.push({
      source: 'repeated_failure',
      severity: failure.count >= 5 ? 'high' : 'medium',
      title: `Recurring log pattern: ${stripAutoImproverTitleNoise(failure.pattern)}`,
      problem: `The same failure-like line appeared ${failure.count} times.`,
      recommendation: 'Create a bounded fix task before this pattern turns into a larger support/debug loop.',
      evidence: failure.evidence,
      score: Math.min(40, failure.count * 5),
    });
  }
  if (taskSignals.blocked_task_count > 0) {
    findings.push({
      source: 'task_truth',
      severity: 'high',
      title: `${taskSignals.blocked_task_count} blocked task(s) need an owner or unblocker`,
      problem: 'Blocked work is accumulating in task truth.',
      recommendation: 'Assign one unblock action with proof expected.',
      evidence: taskSignals.blocked_tasks,
      score: 35,
    });
  } else if (taskSignals.stale_task_count > 12) {
    findings.push({
      source: 'task_truth',
      severity: 'medium',
      title: `${taskSignals.stale_task_count} open task signal(s) need pruning or next actions`,
      problem: 'Open task signals are high enough to hide the next useful action.',
      recommendation: 'Close, merge, or re-scope the top stale tasks before adding more work.',
      evidence: taskSignals.stale_tasks.length ? taskSignals.stale_tasks : taskSignals.todo_signal_lines.slice(0, 8),
      score: 22,
    });
  }
  if (taskSignals.unclear_task_count + logSignals.unclear_next_action_count > 10) {
    findings.push({
      source: 'unclear_next_actions',
      severity: 'medium',
      title: 'Unclear next-action language is accumulating',
      problem: 'Several logs or tasks mention blocked/unclear/proof-needed states without a crisp next move.',
      recommendation: 'Convert the highest-value unclear item into one task with owner, proof, and stop rule.',
      evidence: taskSignals.unclear_tasks.length
        ? taskSignals.unclear_tasks
        : (logSignals.unclear_next_actions.length ? logSignals.unclear_next_actions : logSignals.repeated_failures.slice(0, 3)),
      score: 18,
    });
  }
  if (gitSignals.dirty_file_count > 50) {
    findings.push({
      source: 'workspace_hygiene',
      severity: 'medium',
      title: `${gitSignals.dirty_file_count} dirty git entries make broad autonomous edits risky`,
      problem: 'Large dirty worktrees increase the chance of overwriting user work or losing attribution.',
      recommendation: 'Keep auto-improver changes receipt-only until scoped tasks isolate the touched files.',
      evidence: gitSignals.sample,
      score: 20,
    });
  }

  findings.sort((a, b) => (b.score || 0) - (a.score || 0));
  const painScoreBefore = Math.min(100,
    (logSignals.repeated_failure_count * 8)
    + Math.min(24, taskSignals.stale_task_count)
    + (taskSignals.blocked_task_count * 5)
    + Math.min(16, taskSignals.unclear_task_count + logSignals.unclear_next_action_count)
    + Math.min(16, Math.floor(gitSignals.dirty_file_count / 5))
    + contractGaps.reduce((sum, gap) => sum + (severityWeight(gap.severity) * 3), 0));

  return {
    schema: 'atris.auto_improver_scan.v1',
    scanned_at: stampIso(),
    repo_root: root,
    repo_name: path.basename(root),
    metrics: {
      findings_count: findings.length,
      repeated_failure_count: logSignals.repeated_failure_count,
      stale_task_count: taskSignals.stale_task_count,
      blocked_task_count: taskSignals.blocked_task_count,
      unclear_next_action_count: taskSignals.unclear_task_count + logSignals.unclear_next_action_count,
      dirty_file_count: gitSignals.dirty_file_count,
      contract_gap_count: contractGaps.length,
      pain_score_before: painScoreBefore,
    },
    log_signals: logSignals,
    task_signals: taskSignals,
    git_signals: gitSignals,
    contract_checks: contractChecks,
    contract_gaps: contractGaps,
    findings: findings.slice(0, 12),
    prevented_fire_candidate: findings[0] || null,
  };
}

// Lifecycle filter for wake dedupe: a task that already crossed the review boundary
// (done/failed/archived, or human-accepted) must never be re-selected as the wake target,
// that loop produced an endless "existing_task_found OBL-1433" no-op spiral (OBL-1469).
const AUTO_IMPROVER_INACTIVE_STATUSES = new Set(['done', 'failed', 'archived']);

function autoImproverTaskIsActionable(task) {
  const status = String(task?.status || '').toLowerCase();
  if (AUTO_IMPROVER_INACTIVE_STATUSES.has(status)) return false;
  const approval = String(task?.metadata?.approval_status || task?.approval_status || '').toLowerCase();
  if (approval === 'accepted') return false;
  return true;
}

function findExistingAutoImproverTask(title) {
  const projection = readJson(path.join(process.cwd(), '.atris', 'state', 'tasks.projection.json'));
  const tasks = Array.isArray(projection?.tasks) ? projection.tasks : [];
  const key = lowerCompact(stripAutoImproverTitleNoise(title));
  if (!key) return null;
  return tasks.find((task) => {
    if (!autoImproverTaskIsActionable(task)) return false;
    const taskTitle = lowerCompact(stripAutoImproverTitleNoise(task.title || ''));
    if (!taskTitle) return false;
    return taskTitle.includes(key) || key.includes(taskTitle);
  }) || null;
}

function autoImproverTaskTitle(candidate) {
  const core = stripAutoImproverTitleNoise(candidate?.title || 'Prevent top dogfood failure');
  return `Auto-improver: ${compactSentence(core, 92)}`;
}

function existingAutoImproverTaskForCandidate(candidate) {
  return findExistingAutoImproverTask(autoImproverTaskTitle(candidate));
}

function createAutoImproverTask(candidate, receiptPath) {
  const title = autoImproverTaskTitle(candidate);
  const existing = findExistingAutoImproverTask(title);
  if (existing) {
    return {
      ok: true,
      existing: true,
      task_ref: taskRef(existing),
      task: existing,
      command: `atris task show ${taskRef(existing)} --json`,
    };
  }
  const commandArgs = [
    'task',
    'new',
    title,
    '--tag',
    'auto-improver',
    '--json',
  ];
  const command = `atris task new ${shellQuote(title)} --tag auto-improver`;
  try {
    const stdout = execFileSync(process.execPath, [path.join(__dirname, '..', 'bin', 'atris.js'), ...commandArgs], {
      cwd: process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 10000,
      env: {
        ...process.env,
        ATRIS_SKIP_UPDATE_CHECK: '1',
        ATRIS_AUTO_IMPROVER_RECEIPT: receiptPath || '',
      },
    });
    const parsed = JSON.parse(stdout || '{}');
    const task = parsed.task || null;
    return {
      ok: parsed.ok !== false,
      existing: false,
      task,
      task_id: parsed.task_id || task?.id || null,
      task_ref: taskRef(task) || parsed.task_id || null,
      command,
      raw: parsed,
    };
  } catch (error) {
    return {
      ok: false,
      existing: false,
      command,
      error: error instanceof Error ? error.message : String(error),
      stderr: error?.stderr ? compactSentence(String(error.stderr), 500) : null,
    };
  }
}

function writeAutoImproverReceipt(name, payload, receiptPath = null) {
  const finalReceiptPath = receiptPath || path.join(process.cwd(), 'atris', 'runs', `auto-improver-dogfood-${fileSafeStamp()}.json`);
  writeJson(finalReceiptPath, payload);
  const latestPath = path.join(process.cwd(), '.atris', 'state', 'auto-improver-dogfood-latest.json');
  writeJson(latestPath, { ...payload, receipt_path: finalReceiptPath });
  return { receiptPath: finalReceiptPath, latestPath };
}

async function runAutoImproverWake(name, paths, { execute = false, confirmed = false } = {}) {
  const scan = collectAutoImproverScan(process.cwd());
  const mode = execute ? 'execute' : 'dry_run';
  const candidate = scan.prevented_fire_candidate;
  const existingTask = candidate ? existingAutoImproverTaskForCandidate(candidate) : null;
  let createdTask = existingTask ? {
    ok: true,
    existing: true,
    task_ref: taskRef(existingTask),
    task: existingTask,
    command: `atris task show ${taskRef(existingTask)} --json`,
  } : null;
  let decision = candidate ? (existingTask ? 'existing_task_found' : 'scan_found_problem') : 'scan_clean';
  let reason = candidate ? (existingTask ? 'auto_improver_task_already_exists' : `top_candidate:${candidate.source}`) : 'no_prevented_fire_candidate';
  let nextCommand = candidate
    ? (existingTask ? createdTask.command : `atris member wake ${name} --execute --confirm-autonomy-policy --json`)
    : `atris member wake ${name} --json`;

  let payload = {
    schema: 'atris.auto_improver_dogfood.v1',
    created_at: stampIso(),
    member: name,
    runtime_member: paths.storageName || name,
    mode,
    executed: execute,
    task_creation_requested: execute && confirmed,
    scan,
    created_task: null,
    pain: {
      before: scan.metrics.pain_score_before,
      after: scan.metrics.pain_score_before,
      delta: 0,
    },
    proof: {
      found_problems: scan.metrics.findings_count,
      prevented_suffering: 0,
      improved_things: 0,
      ready_for_marko: false,
      reason: 'Dogfood requires at least one bounded prevented-fire task before promotion.',
    },
  };
  const plannedReceiptPath = path.join(process.cwd(), 'atris', 'runs', `auto-improver-dogfood-${fileSafeStamp()}.json`);
  if (candidate && execute && confirmed) {
    createdTask = createAutoImproverTask(candidate, repoRelative(process.cwd(), plannedReceiptPath));
    if (createdTask.ok) {
      decision = createdTask.existing ? 'existing_task_found' : 'task_created';
      reason = createdTask.existing ? 'auto_improver_task_already_exists' : 'auto_improver_task_created';
      nextCommand = createdTask.task_ref ? `atris task show ${createdTask.task_ref} --json` : 'atris task list';
    } else {
      decision = 'task_create_failed';
      reason = 'auto_improver_task_create_failed';
      nextCommand = createdTask.command || nextCommand;
    }
  }

  const prevented = createdTask?.ok ? 1 : 0;
  const improvement = prevented ? Math.min(15, Math.max(3, severityWeight(candidate?.severity) * 3)) : 0;
  payload = {
    ...payload,
    decision,
    reason,
    next_command: nextCommand,
    created_task: createdTask ? {
      ok: createdTask.ok,
      existing: createdTask.existing,
      task_ref: createdTask.task_ref || null,
      task_id: createdTask.task_id || createdTask.task?.id || null,
      title: createdTask.task?.title || null,
      command: createdTask.command || null,
      error: createdTask.error || null,
    } : null,
    pain: {
      before: scan.metrics.pain_score_before,
      after: Math.max(0, scan.metrics.pain_score_before - improvement),
      delta: improvement,
    },
    proof: {
      found_problems: scan.metrics.findings_count,
      prevented_suffering: prevented,
      improved_things: prevented,
      ready_for_marko: prevented > 0 && scan.metrics.findings_count > 0,
      reason: prevented
        ? 'A top prevented-fire candidate has a bounded task and receipt.'
        : 'No bounded prevented-fire task was created yet.',
    },
  };
  const previousLatest = readJson(path.join(process.cwd(), '.atris', 'state', 'auto-improver-dogfood-latest.json'));
  const finalWrite = writeAutoImproverReceipt(name, payload, plannedReceiptPath);
  // A no-op scan identical to the previous tick earns a receipt but not a journal entry,
  // the cadence loop was appending the same "found: N, prevented: 0" row every ~4 minutes
  // and flooding the daily log (2026-06-10 had 100+ identical entries).
  const createdNewTask = Boolean(payload.created_task) && payload.created_task.existing === false;
  const duplicateNoop = Boolean(previousLatest)
    && !createdNewTask
    && previousLatest.decision === decision
    && previousLatest.proof?.found_problems === payload.proof.found_problems
    && previousLatest.pain?.before === payload.pain.before
    && (previousLatest.created_task?.task_ref || null) === (payload.created_task?.task_ref || null);
  let logPath = null;
  let memberLogPath = null;
  if (!duplicateNoop) {
    logPath = appendProjectLog('Auto-improver dogfood scan', {
      member: name,
      mode,
      found: payload.proof.found_problems,
      prevented: payload.proof.prevented_suffering,
      pain_before: payload.pain.before,
      pain_after: payload.pain.after,
      candidate: candidate ? stripAutoImproverTitleNoise(candidate.title) : '',
      task: payload.created_task?.task_ref || '',
      receipt: repoRelative(process.cwd(), finalWrite.receiptPath),
    });
    memberLogPath = appendMemberGoalLog(paths.memberDir, name, 'Auto-improver dogfood scan', {
      mode,
      found: payload.proof.found_problems,
      prevented: payload.proof.prevented_suffering,
      pain_before: payload.pain.before,
      pain_after: payload.pain.after,
      receipt: repoRelative(process.cwd(), finalWrite.receiptPath),
      next: nextCommand,
    });
  }

  const purpose = missionPurpose(paths);
  const currentGoal = activeGoal(loadMemberGoals(name, paths));

  return {
    ok: true,
    action: 'wake',
    member: name,
    runtime_member: paths.storageName || name,
    mode,
    decision,
    reason,
    executed: execute,
    needs_user: false,
    ask: null,
    next_command: nextCommand,
    mission: wakeMissionSummary(purpose),
    active_goal: currentGoal ? {
      id: currentGoal.id,
      title: currentGoal.title,
      source: currentGoal.source || null,
      mission_id: currentGoal.mission_id || null,
    } : null,
    auto_improver: payload,
    receipt_path: finalWrite.receiptPath,
    latest_path: finalWrite.latestPath,
    log_path: logPath,
    member_log_path: memberLogPath,
    journal_skipped: duplicateNoop ? 'duplicate_noop' : null,
    created_task: payload.created_task,
  };
}

function acquireMemberLoopLease(name, { runId, ttlMs }) {
  const paths = memberLoopPaths(name);
  fs.mkdirSync(paths.stateDir, { recursive: true });
  const nowMs = Date.now();
  const lease = {
    schema: 'atris.member_loop_lease.v1',
    member: name,
    run_id: runId,
    pid: process.pid,
    started_at: stampIso(),
    heartbeat_at: stampIso(),
    expires_at_ms: nowMs + ttlMs,
  };
  const writeLease = () => {
    const fd = fs.openSync(paths.lockPath, 'wx');
    try {
      fs.writeFileSync(fd, JSON.stringify(lease, null, 2) + '\n', 'utf8');
    } finally {
      fs.closeSync(fd);
    }
    return { acquired: true, lease, paths, recovered_stale: false };
  };
  try {
    return writeLease();
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    const active = readJson(paths.lockPath);
    const expired = active && Number(active.expires_at_ms || 0) <= nowMs;
    const deadPid = active && !isPidAlive(active.pid);
    if (active && (expired || deadPid)) {
      fs.rmSync(paths.lockPath, { force: true });
      const result = writeLease();
      return {
        ...result,
        recovered_stale: true,
        stale_lease: active,
        stale_reason: expired ? 'expired' : 'dead_pid',
      };
    }
    return { acquired: false, lease: active, paths, recovered_stale: false };
  }
}

function refreshMemberLoopLease(paths, lease, ttlMs) {
  writeJson(paths.lockPath, {
    ...lease,
    heartbeat_at: stampIso(),
    expires_at_ms: Date.now() + ttlMs,
  });
}

function releaseMemberLoopLease(paths, lease) {
  const active = readJson(paths.lockPath);
  if (!active || active.run_id !== lease.run_id || active.pid !== lease.pid) return;
  fs.rmSync(paths.lockPath, { force: true });
}

function activeMemberLoopLease(lease) {
  if (!lease) return false;
  const expiresAt = Number(lease.expires_at_ms || 0);
  if (!Number.isFinite(expiresAt) || expiresAt <= Date.now()) return false;
  return isPidAlive(lease.pid);
}

function archiveMemberLoopState(name) {
  const paths = memberLoopPaths(name);
  const archivedAt = stampIso();
  const previousLease = readJson(paths.lockPath);
  const activeLease = activeMemberLoopLease(previousLease);
  fs.mkdirSync(paths.stateDir, { recursive: true });
  if (activeLease) {
    writeJson(paths.stopPath, {
      schema: 'atris.member_loop_stop.v1',
      member: name,
      requested_at: archivedAt,
      pid: process.pid,
      reason: 'member_archived',
    });
  } else {
    fs.rmSync(paths.lockPath, { force: true });
    fs.rmSync(paths.stopPath, { force: true });
  }
  const payload = {
    schema: 'atris.member_loop_archived.v1',
    action: 'loop_archived',
    member: name,
    status: 'archived',
    reason: 'member_archived',
    archived_at: archivedAt,
    active_lease_requested_stop: Boolean(activeLease),
    stale_lease_removed: Boolean(previousLease && !activeLease),
    previous_lease: previousLease || null,
    lock_path: paths.lockPath,
    stop_path: paths.stopPath,
    latest_path: paths.latestPath,
  };
  writeJson(paths.latestPath, payload);
  return payload;
}

function appendMemberGoalLog(memberDir, name, title, fields = {}) {
  const logsDir = path.join(memberDir, 'logs');
  fs.mkdirSync(logsDir, { recursive: true });
  const logPath = path.join(logsDir, todayLogName());
  const stamp = new Date().toTimeString().slice(0, 5);
  const rows = [
    `## ${stamp} · ${title}`,
    `- team: ${name}`,
    ...Object.entries(fields)
      .filter(([, value]) => value !== undefined && value !== null)
      .map(([key, value]) => [key, String(value).replace(/\n/g, ' ').trim()])
      .filter(([, text]) => text !== '')
      .map(([key, text]) => `- ${key}: ${text}`),
    '',
  ];
  fs.appendFileSync(logPath, rows.join('\n'), 'utf8');
  return logPath;
}

function appendProjectLog(title, fields = {}) {
  const today = todayLogName();
  const year = today.slice(0, 4);
  const logsDir = path.join(process.cwd(), 'atris', 'logs', year);
  fs.mkdirSync(logsDir, { recursive: true });
  const logPath = path.join(logsDir, today);
  const stamp = new Date().toTimeString().slice(0, 5);
  const rows = [
    `## ${stamp} · ${title}`,
    ...Object.entries(fields)
      .filter(([, value]) => value !== undefined && value !== null)
      .map(([key, value]) => [key, String(value).replace(/\n/g, ' ').trim()])
      .filter(([, text]) => text !== '')
      .map(([key, text]) => `- ${key}: ${text}`),
    '',
  ];
  fs.appendFileSync(logPath, rows.join('\n'), 'utf8');
  return logPath;
}

// --- YAML Frontmatter Parser (shared with skill.js) ---

function parseFrontmatter(content) {
  // \r?\n so a CRLF-line-ending MEMBER.md (Windows-edited) still parses; otherwise
  // the delimiter never matched (and trailing \r broke the per-line key matchers),
  // silently dropping the member's entire frontmatter: role, skills, permissions, tools.
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!match) return null;

  const yaml = match[1];
  const result = {};
  let currentKey = null;

  for (const line of yaml.split(/\r?\n/)) {
    const listMatch = line.match(/^\s+-\s+(.+)$/);
    if (listMatch && currentKey) {
      if (!Array.isArray(result[currentKey])) result[currentKey] = [];
      result[currentKey].push(listMatch[1].trim());
      continue;
    }

    const nestedMatch = line.match(/^\s+([a-z_-]+):\s*(.*)$/);
    if (nestedMatch && currentKey && typeof result[currentKey] === 'object' && !Array.isArray(result[currentKey])) {
      const val = nestedMatch[2].trim();
      result[currentKey][nestedMatch[1]] = val === 'true' ? true : val === 'false' ? false : val || true;
      continue;
    }

    const kvMatch = line.match(/^([a-z_-]+):\s*(.*)$/);
    if (kvMatch) {
      currentKey = kvMatch[1];
      const val = kvMatch[2].trim();
      if (val === '') {
        result[currentKey] = {};
      } else if (val.startsWith('[') && val.endsWith(']')) {
        result[currentKey] = val.slice(1, -1).split(',').map(s => s.trim().replace(/^["']|["']$/g, ''));
      } else {
        // Unwrap only a matching outer pair: `verify: node -e "process.exit(0)"`
        // must keep its closing quote or the check is a shell syntax error.
        const quoted = val.match(/^(["'])([\s\S]*)\1$/);
        result[currentKey] = quoted ? quoted[2] : val;
      }
    }
  }

  return result;
}

// --- Member Discovery ---

function findAllMembers(teamDir) {
  if (!fs.existsSync(teamDir)) return [];

  const members = [];
  const entries = fs.readdirSync(teamDir);

  for (const entry of entries) {
    // Skip template/archive directories and hidden files
    if (entry === '_template' || entry === '_archive' || entry === '_archived' || entry.startsWith('.')) continue;

    const fullPath = path.join(teamDir, entry);
    const stat = fs.statSync(fullPath);

    // Directory format: team/<name>/MEMBER.md
    if (stat.isDirectory()) {
      const memberFile = path.join(fullPath, 'MEMBER.md');
      if (fs.existsSync(memberFile)) {
        const content = fs.readFileSync(memberFile, 'utf8');
        const fm = parseFrontmatter(content) || {};

        // Count local skills
        const skillsDir = path.join(fullPath, 'skills');
        let skillCount = 0;
        if (fs.existsSync(skillsDir)) {
          const skillEntries = fs.readdirSync(skillsDir);
          for (const s of skillEntries) {
            if (fs.existsSync(path.join(skillsDir, s, 'SKILL.md'))) skillCount++;
          }
        }

        // Count context files
        const contextDir = path.join(fullPath, 'context');
        let contextCount = 0;
        if (fs.existsSync(contextDir)) {
          contextCount = fs.readdirSync(contextDir).filter(f => f.endsWith('.md')).length;
        }

        // Check for tools
        const toolsDir = path.join(fullPath, 'tools');
        const hasTools = fs.existsSync(toolsDir);

        members.push({
          name: fm.name || entry,
          role: fm.role || '(no role)',
          description: fm.description || '',
          version: fm.version || '',
          format: 'directory',
          path: memberFile,
          dir: fullPath,
          skillCount,
          contextCount,
          hasTools,
          skills: Array.isArray(fm.skills) ? fm.skills : [],
          permissions: fm.permissions || {},
          frontmatter: fm
        });
      }
      continue;
    }

    // Flat file format: team/<name>.md
    if (entry.endsWith('.md') && stat.isFile()) {
      const content = fs.readFileSync(fullPath, 'utf8');
      const fm = parseFrontmatter(content);
      if (!fm) continue; // No frontmatter = not a member
      if (fm.type && fm.type !== 'member') continue; // Index/doc files (e.g. ASSIGNMENTS.md, type: index) are not members

      const name = entry.replace('.md', '');
      members.push({
        name: fm.name || name,
        role: fm.role || '(no role)',
        description: fm.description || '',
        version: fm.version || '',
        format: 'flat',
        path: fullPath,
        dir: path.dirname(fullPath),
        skillCount: 0,
        contextCount: 0,
        hasTools: false,
        skills: Array.isArray(fm.skills) ? fm.skills : [],
        permissions: fm.permissions || {},
        frontmatter: fm
      });
    }
  }

  return members;
}

// --- LIST subcommand ---

function memberList(...flags) {
  const asJson = flags.includes('--json') || process.argv.includes('--json');
  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const members = findAllMembers(teamDir);
  const { isMemberParked } = require('../lib/member-park');
  const parked = new Set(members.filter((m) => isMemberParked(process.cwd(), m.name)).map((m) => m.name));

  if (asJson) {
    console.log(JSON.stringify({
      ok: true,
      count: members.length,
      members: members.map((m) => ({
        name: m.name,
        ...(parked.has(m.name) ? { parked: true } : {}),
        role: m.role,
        format: m.format,
        skills: m.format === 'directory' ? m.skillCount : null,
        context: m.format === 'directory' ? m.contextCount : null,
        version: m.version || null,
      })),
    }, null, 2));
    return;
  }

  if (members.length === 0) {
    console.log('No team members found in atris/team/.');
    console.log('Run "atris member create <name>" to create one.');
    return;
  }

  console.log('');
  console.log('Team Members');
  console.log('─'.repeat(72));

  const nameW = 16;
  const roleW = 18;
  const fmtW = 8;
  const skillW = 8;
  const ctxW = 9;
  // Keep one space between columns, even when a value fills its column.
  const cell = (value, width) => `${clipCell(value, width - 1)} `;

  console.log(
    '  ' +
    'Name'.padEnd(nameW) +
    'Role'.padEnd(roleW) +
    'Format'.padEnd(fmtW) +
    'Skills'.padEnd(skillW) +
    'Context'.padEnd(ctxW) +
    'Version'
  );
  console.log('  ' + '─'.repeat(70));

  for (const m of members) {
    const skills = m.format === 'directory' ? String(m.skillCount) : '-';
    const context = m.format === 'directory' ? String(m.contextCount) : '-';
    console.log(
      '  ' +
      cell(m.name, nameW) +
      cell(m.role, roleW) +
      cell(m.format === 'directory' ? 'dir' : 'flat', fmtW) +
      cell(skills, skillW) +
      cell(context, ctxW) +
      (m.version || '-') +
      (parked.has(m.name) ? '  parked' : '')
    );
  }

  console.log('');
  const parkedNote = parked.size ? ` (${parked.size} parked; unpark with atris team unpark <name>)` : '';
  console.log(`${members.length} ${members.length === 1 ? 'member' : 'members'} found.${parkedNote}`);
}

// --- CREATE subcommand ---

function printMemberCreateUsage(stream = console.log) {
  stream('Usage: atris member create <name> [--role="Title"] [--description="..."] [--push]');
}

async function memberCreate(name, ...flags) {
  if (name === '--help' || name === '-h' || flags.includes('--help') || flags.includes('-h')) {
    printMemberCreateUsage();
    return;
  }
  if (!name || String(name).startsWith('-')) {
    printMemberCreateUsage(console.error);
    process.exit(1);
  }

  // Parse flags
  let role = name.charAt(0).toUpperCase() + name.slice(1).replace(/-/g, ' ');
  let description = '';
  let shouldPush = false;

  for (const flag of flags) {
    if (flag === '--push') { shouldPush = true; continue; }

    const roleMatch = flag.match(/^--role=["']?(.+?)["']?$/);
    if (roleMatch) role = roleMatch[1];

    const descMatch = flag.match(/^--description=["']?(.+?)["']?$/);
    if (descMatch) description = descMatch[1];
  }

  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const memberDir = path.join(teamDir, name);
  const memberFile = path.join(memberDir, 'MEMBER.md');
  const legacyFile = path.join(teamDir, `${name}.md`);

  // Check for existing
  if (fs.existsSync(memberFile)) {
    console.error(`Member "${name}" already exists at team/${name}/MEMBER.md`);
    process.exit(1);
  }
  if (fs.existsSync(legacyFile)) {
    console.error(`Member "${name}" already exists at team/${name}.md`);
    console.log(`Run "atris member upgrade ${name}" to convert to directory format.`);
    process.exit(1);
  }

  const content = `---
name: ${name}
role: ${role}
description: ${description || `Handles ${role.toLowerCase()} tasks`}
version: 1.0.0
# ai or human; a human member is a person and Atris never acts as them
type: ai

skills: []

permissions:
  can-read: true
  can-execute: true
  can-approve: false
  can-accept-task: false
  approval-required: []

tools: []
---

# ${role}

## Persona

(Define how this member communicates, their tone, and decision-making style)

## Workflow

1. Step one
2. Step two
3. Step three

## Cadence

- Wake cadence: define when this member may run unattended.
- Lease: define the maximum time one tick may hold a task or worktree.
- Stop condition: define the state that pauses the loop.

## Ownership Contract

- Own tasks by function or feature, never by execution engine.
- If no existing member fits, create a member-creation task before assigning broad work.
- Put coding agent models like Codex and Claude in the executed_by section.

## Proof Standard

- Move proof-backed work to Review with verifier output, receipt path, or concrete artifact proof.
- Never run human accept or claim AgentXP without human approval.

## Cleanup Contract

- Use isolated worktrees for parallel work.
- Ship or archive worktrees before the lease ends.
- Leave task notes another member can resume without chat context.

## Rules

1. Rule one
2. Rule two
`;

  const memberDescription = description || `Handles ${role.toLowerCase()} tasks`;
  const { logPath } = ensureMemberBundle(memberDir, {
    name,
    role,
    description: memberDescription,
    source: 'cli',
    memberContent: content,
  });

  console.log('');
  console.log(`✓ Created team/${name}/MEMBER.md`);
  console.log(`✓ Created team/${name}/SOUL.md`);
  console.log(`✓ Created team/${name}/MISSION.md`);
  console.log(`✓ Created team/${name}/goals.json + goals.md`);
  console.log(`✓ Created team/${name}/skills/`);
  console.log(`✓ Created team/${name}/tools/`);
  console.log(`✓ Created team/${name}/context/`);
  console.log(`✓ Created team/${name}/logs/${path.basename(logPath)}`);

  if (shouldPush) {
    console.log('');
    await memberPush(name);
  } else {
    console.log('');
    console.log(`Next: edit team/${name}/MEMBER.md to define persona, workflow, and permissions.`);
    console.log(`      edit team/${name}/MISSION.md to define why this member exists.`);
    console.log(`      add skills to team/${name}/skills/<skill-name>/SKILL.md`);
    console.log(`      add context docs to team/${name}/context/`);
    console.log(`      run "atris member push ${name}" to create a cloud agent`);
  }
}

function printMemberInstallUsage(stream = console.log) {
  stream('Usage: atris member install <slug> [--update]');
}

function memberInstall(slug, update = false) {
  if (slug === '--help' || slug === '-h') {
    printMemberInstallUsage();
    return;
  }
  if (!slug || String(slug).startsWith('-')) {
    printMemberInstallUsage(console.error);
    process.exit(1);
  }
  if (!/^[a-zA-Z0-9._-]+$/.test(slug)) {
    console.error('Member name must be a local slug: letters, numbers, dots, underscores, or dashes.');
    process.exit(1);
  }

  const memberDir = path.join(process.cwd(), 'atris', 'team', slug);
  const templateDir = path.join(__dirname, '..', 'templates', 'members', slug);
  if (update) {
    if (!fs.existsSync(templateDir)) {
      console.error(`No member template for ${slug}.`);
      process.exit(1);
    }
    const updated = updateMemberSkills(templateDir, memberDir);
    if (updated.length === 0) {
      console.log(`MEMBER ${slug} already up to date`);
    } else {
      for (const rel of updated) console.log(`atris/team/${slug}/${rel.split(path.sep).join('/')}`);
    }
    return;
  }
  const already = memberBundlePresent(memberDir);
  fs.mkdirSync(path.join(memberDir, 'logs'), { recursive: true });
  const copied = [];
  if (fs.existsSync(templateDir)) {
    const copyMissing = (source, relative = '') => {
      for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
        const rel = path.join(relative, entry.name);
        const target = path.join(memberDir, rel);
        if (entry.isDirectory()) {
          fs.mkdirSync(target, { recursive: true });
          copyMissing(path.join(source, entry.name), rel);
        } else if (entry.isFile() && !fs.existsSync(target)) {
          fs.writeFileSync(target, fs.readFileSync(path.join(source, entry.name)), { flag: 'wx' });
          copied.push(rel);
        }
      }
    };
    copyMissing(templateDir);
  }
  if (already && copied.length === 0) {
    console.log(`MEMBER already installed for ${slug}`);
    return;
  }

  const { created } = ensureMemberBundle(memberDir, {
    name: slug,
    source: 'install',
  });
  for (const rel of [...copied, ...created]) {
    console.log(`atris/team/${slug}/${rel.split(path.sep).join('/')}`);
  }
  console.log(`MEMBER installed for ${slug}.`);
}

// --- ACTIVATE subcommand ---

function memberActivate(name) {
  if (!name) {
    console.error('Usage: atris member activate <name>');
    process.exit(1);
  }

  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const memberDir = path.join(teamDir, name);
  const memberFile = path.join(memberDir, 'MEMBER.md');
  const legacyFile = path.join(teamDir, `${name}.md`);

  // Find the member (directory first, flat fallback)
  let activePath = null;
  let activeDir = null;
  let isLegacy = false;

  if (fs.existsSync(memberFile)) {
    activePath = memberFile;
    activeDir = memberDir;
  } else if (fs.existsSync(legacyFile)) {
    activePath = legacyFile;
    activeDir = teamDir;
    isLegacy = true;
  } else {
    console.error(`Member "${name}" not found. Run "atris member list".`);
    process.exit(1);
  }

  const content = fs.readFileSync(activePath, 'utf8');
  const fm = parseFrontmatter(content) || {};
  const sharedProcess = memberProcessPrompt(process.cwd());

  console.log('');
  console.log(`Activating: ${fm.name || name} (${fm.role || 'no role'})`);

  // If legacy format, offer upgrade
  if (isLegacy) {
    console.log(`  Format: flat file (team/${name}.md)`);
    console.log(`  Tip: run "atris member upgrade ${name}" to convert to directory format.`);
  }

  // Symlink member's local skills to system-level
  if (!isLegacy) {
    const skillsDir = path.join(activeDir, 'skills');
    if (fs.existsSync(skillsDir)) {
      const home = require('os').homedir();
      const toolDirs = [
        { dir: path.join(home, '.claude', 'skills'), label: 'Claude' },
        { dir: path.join(home, '.codex', 'skills'), label: 'Codex' },
        { dir: path.join(home, '.cursor', 'skills'), label: 'Cursor' },
      ];

      for (const { dir } of toolDirs) {
        fs.mkdirSync(dir, { recursive: true });
      }

      const skillEntries = fs.readdirSync(skillsDir);
      let linked = 0;

      for (const entry of skillEntries) {
        const skillDir = path.join(skillsDir, entry);
        if (!fs.statSync(skillDir).isDirectory()) continue;
        if (!fs.existsSync(path.join(skillDir, 'SKILL.md'))) continue;

        for (const { dir, label } of toolDirs) {
          const linkPath = path.join(dir, entry);
          if (fs.existsSync(linkPath)) continue;

          try {
            fs.symlinkSync(skillDir, linkPath);
          } catch (e) { /* silent */ }
        }
        linked++;
        console.log(`  ✓ Linked skill: ${entry}`);
      }

      if (linked === 0) {
        console.log('  No local skills to link.');
      }
    }

    // Show context files
    const contextDir = path.join(activeDir, 'context');
    if (fs.existsSync(contextDir)) {
      const ctxFiles = fs.readdirSync(contextDir).filter(f => f.endsWith('.md'));
      if (ctxFiles.length > 0) {
        console.log(`  Context: ${ctxFiles.join(', ')}`);
      }
    }

    // Show tools
    const toolsDir = path.join(activeDir, 'tools');
    if (fs.existsSync(toolsDir)) {
      const toolFiles = fs.readdirSync(toolsDir);
      if (toolFiles.length > 0) {
        console.log(`  Tools: ${toolFiles.join(', ')}`);
      }
    }
  }

  // Show permissions
  if (fm.permissions && typeof fm.permissions === 'object') {
    const perms = Object.entries(fm.permissions);
    if (perms.length > 0) {
      const allowed = perms.filter(([, v]) => v === true || v === 'true').map(([k]) => k);
      const denied = perms.filter(([, v]) => v === false || v === 'false').map(([k]) => k);
      if (allowed.length) console.log(`  Allowed: ${allowed.join(', ')}`);
      if (denied.length) console.log(`  Denied: ${denied.join(', ')}`);
    }
  }

  console.log('');
  console.log(`Member "${fm.name || name}" activated.`);
  const identityPath = path.relative(process.cwd(), activePath);
  console.log(`Tell your agent: "You are the ${fm.role || name}. Read ${sharedProcess ? `${MEMBER_PROCESS_PATH}, then ` : ''}${identityPath}. Stay inside this member's permissions."`);
}

// --- UPGRADE subcommand ---

function memberUpgrade(name) {
  if (!name) {
    console.error('Usage: atris member upgrade <name>');
    process.exit(1);
  }

  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const legacyFile = path.join(teamDir, `${name}.md`);
  const memberDir = path.join(teamDir, name);
  const memberFile = path.join(memberDir, 'MEMBER.md');

  if (!fs.existsSync(legacyFile)) {
    if (fs.existsSync(memberFile)) {
      console.log(`"${name}" is already in directory format.`);
    } else {
      console.error(`Member "${name}" not found at team/${name}.md`);
    }
    return;
  }

  if (fs.existsSync(memberDir)) {
    console.error(`Directory team/${name}/ already exists. Resolve manually.`);
    process.exit(1);
  }

  // Move flat file to directory format, then backfill the complete identity bundle.
  fs.mkdirSync(memberDir, { recursive: true });
  fs.renameSync(legacyFile, memberFile);
  const { logPath } = ensureMemberBundle(memberDir, {
    name,
    role: name,
    description: 'Define why this member exists and how it chooses goals.',
    source: 'upgrade',
  });

  console.log(`✓ Upgraded team/${name}.md → team/${name}/MEMBER.md`);
  console.log(`✓ Created SOUL.md, MISSION.md, goals.json, goals.md, skills/, tools/, context/, logs/${path.basename(logPath)}`);
}

// --- PUSH subcommand ---

function readMemberPushBusinessBinding(root = process.cwd()) {
  const file = path.join(root, '.atris', 'business.json');
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    throw new Error(`Failed to read .atris/business.json: ${e.message || e}`);
  }
}

async function memberPush(name) {
  if (!name) {
    console.error('Usage: atris member push <name>');
    process.exit(1);
  }

  const creds = loadCredentials();
  if (!creds || !creds.token) {
    console.error('Not logged in. Run: atris login');
    process.exit(1);
  }

  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const memberFile = path.join(teamDir, name, 'MEMBER.md');

  if (!fs.existsSync(memberFile)) {
    console.error(`Member "${name}" not found at atris/team/${name}/MEMBER.md`);
    process.exit(1);
  }

  const content = fs.readFileSync(memberFile, 'utf8');
  const fm = parseFrontmatter(content);
  const existingAgentId = fm && fm['agent-id'];
  const taskDb = require('../lib/task-db');
  const binding = readMemberPushBusinessBinding(taskDb.workspaceRoot());
  const businessId = String(binding && (binding.business_id || binding.id) || '').trim();

  if (existingAgentId) {
    console.log(`Pushing member "${name}" to cloud (updating agent ${existingAgentId})...`);
  } else {
    console.log(`Pushing member "${name}" to cloud (creating new agent)...`);
  }

  if (!businessId) {
    console.log('no business binding found; run `atris business init "<name>" --here` to bind this workspace.');
  }
  const endpoint = businessId
    ? `/agent/import-member?business_id=${encodeURIComponent(businessId)}`
    : '/agent/import-member';
  const result = await apiRequestJson(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'text/markdown' },
    body: content,
    token: creds.token,
  });

  if (!result.ok) {
    console.error(`Push failed: ${result.error || 'Unknown error'}`);
    process.exit(1);
  }

  const agentId = result.data?.agent_id || result.data?.id || '(unknown)';

  // Write agent-id back into frontmatter if this was a new agent
  if (!existingAgentId && agentId && agentId !== '(unknown)') {
    const fmMatch = content.match(/^(---\n)([\s\S]*?)(\n---)/);
    if (fmMatch) {
      const updatedContent = fmMatch[1] + fmMatch[2] + `\nagent-id: ${agentId}` + fmMatch[3] + content.slice(fmMatch[0].length);
      fs.writeFileSync(memberFile, updatedContent);
      console.log(`Linked: agent-id ${agentId} written to MEMBER.md`);
    }
  }

  const action = existingAgentId ? 'Updated' : 'Created';
  console.log(`${action} successfully. Agent ID: ${agentId}`);
  if (businessId) console.log(`Bound to business ${businessId}`);
}

// --- PULL subcommand ---

async function memberPull(nameOrAgentId) {
  const creds = loadCredentials();
  if (!creds || !creds.token) {
    console.error('Not logged in. Run: atris login');
    process.exit(1);
  }

  let agentId = nameOrAgentId;

  // If arg looks like a member name (not a UUID), check local MEMBER.md for agent-id
  if (nameOrAgentId && !nameOrAgentId.includes('-')) {
    const teamDir = path.join(process.cwd(), 'atris', 'team');
    const localFile = path.join(teamDir, nameOrAgentId, 'MEMBER.md');
    if (fs.existsSync(localFile)) {
      const localContent = fs.readFileSync(localFile, 'utf8');
      const fm = parseFrontmatter(localContent);
      if (fm && fm['agent-id']) {
        agentId = fm['agent-id'];
        console.log(`Found agent-id ${agentId} in local MEMBER.md`);
      } else {
        console.error(`Member "${nameOrAgentId}" has no agent-id. Push it first: atris member push ${nameOrAgentId}`);
        process.exit(1);
      }
    }
  }

  if (!agentId) {
    console.error('Usage: atris member pull <name|agent_id>');
    process.exit(1);
  }

  console.log(`Pulling agent "${agentId}" from cloud...`);

  const result = await apiRequestJson(`/agent/${agentId}/export-member`, {
    method: 'GET',
    token: creds.token,
  });

  if (!result.ok) {
    console.error(`Pull failed: ${result.error || 'Unknown error'}`);
    process.exit(1);
  }

  // The response body is the MEMBER.md content (may be returned as text or in data)
  const content = result.text || (result.data && typeof result.data === 'string' ? result.data : null);

  if (!content) {
    console.error('Pull failed: empty response from server');
    process.exit(1);
  }

  // Parse the name from frontmatter
  const fm = parseFrontmatter(content);
  const memberName = (fm && fm.name) || nameOrAgentId;

  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const memberDir = path.join(teamDir, memberName);
  const memberFile = path.join(memberDir, 'MEMBER.md');

  // Create directory structure
  fs.mkdirSync(memberDir, { recursive: true });
  fs.mkdirSync(path.join(memberDir, 'skills'), { recursive: true });
  fs.mkdirSync(path.join(memberDir, 'tools'), { recursive: true });
  fs.mkdirSync(path.join(memberDir, 'context'), { recursive: true });
  const logPath = ensureMemberLog(memberDir, {
    name: memberName,
    role: fm && fm.role,
    description: fm && fm.description,
    source: 'pull',
  });
  const missionPath = ensureMissionFile(memberDir, {
    name: memberName,
    role: fm && fm.role,
    description: fm && fm.description,
  });

  fs.writeFileSync(memberFile, content);
  console.log(`Saved to atris/team/${memberName}/MEMBER.md`);
  console.log(`Mission ready at atris/team/${memberName}/${path.basename(missionPath)}`);
  console.log(`Log ready at atris/team/${memberName}/logs/${path.basename(logPath)}`);

  // Sync journal entries
  const journalResult = await apiRequestJson(`/agent/${agentId}/export-journal`, {
    method: 'GET',
    token: creds.token,
  });

  if (journalResult.ok && journalResult.data && journalResult.data.files) {
    const journalFiles = journalResult.data.files;
    let synced = 0;

    for (const file of journalFiles) {
      if (!file.path || !file.content) continue;
      const localJournalPath = String(file.path).replace(/^journal\//, 'logs/');
      const localPath = path.join(memberDir, localJournalPath);
      fs.mkdirSync(path.dirname(localPath), { recursive: true });
      fs.writeFileSync(localPath, file.content);
      synced++;
    }

    if (synced > 0) {
      console.log(`Synced ${synced} journal ${synced === 1 ? 'entry' : 'entries'}`);
    } else {
      console.log('No journal entries yet');
    }
  } else {
    console.log('No journal entries yet');
  }
}

function memberArchive(name) {
  if (!name) {
    console.error('Usage: atris member archive <name>');
    process.exit(1);
  }
  const teamDir = path.join(process.cwd(), 'atris', 'team');
  const memberDir = path.join(teamDir, name);
  const memberFile = path.join(memberDir, 'MEMBER.md');
  if (!fs.existsSync(memberFile)) {
    console.error(`Member "${name}" not found at atris/team/${name}/MEMBER.md`);
    process.exit(1);
  }
  const archiveRoot = path.join(teamDir, '_archived');
  const archiveDir = uniqueArchiveDir(archiveRoot, name);
  const loopState = archiveMemberLoopState(name);
  appendMemberLifecycleLog(memberDir, name, 'archived', 'Archived by atris member archive');
  fs.mkdirSync(archiveRoot, { recursive: true });
  fs.renameSync(memberDir, archiveDir);
  console.log(`Archived atris/team/${name} -> ${path.relative(process.cwd(), archiveDir)}`);
  console.log(`Loop state: ${path.relative(process.cwd(), loopState.latest_path)}`);
}

function memberPurgeArchived(...flags) {
  const days = parseDaysFlag(flags, 60);
  const confirm = parseConfirmFlag(flags);
  if (confirm !== 'delete archived members') {
    console.error('Refusing purge. Pass --confirm "delete archived members".');
    process.exit(1);
  }
  const archiveRoot = path.join(process.cwd(), 'atris', 'team', '_archived');
  if (!fs.existsSync(archiveRoot)) {
    console.log('No archived members found.');
    return;
  }
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const entries = fs.readdirSync(archiveRoot, { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => {
      const fullPath = path.join(archiveRoot, entry.name);
      return { name: entry.name, path: fullPath, mtimeMs: fs.statSync(fullPath).mtimeMs };
    })
    .filter((entry) => entry.mtimeMs <= cutoff);
  for (const entry of entries) {
    fs.rmSync(entry.path, { recursive: true, force: true });
    console.log(`Purged archived member: ${entry.name}`);
  }
  console.log(`Purged ${entries.length} archived member${entries.length === 1 ? '' : 's'} older than ${days} days.`);
}

function printJsonOrText(payload, lines, asJson) {
  if (asJson) {
    console.log(JSON.stringify(payload, null, 2));
    return;
  }
  for (const line of lines) console.log(line);
}

function memberGoal(name, ...args) {
  const paths = requireMemberDir(name);
  const asJson = hasFlag(args, '--json');
  const acceptance = readRepeatedFlag(args, '--acceptance');
  const cadence = readFlag(args, '--cadence', 'manual') || 'manual';
  const why = readFlag(args, '--why', '');
  const title = stripKnownFlags(args, ['--acceptance', '--cadence', '--why'], ['--json']).join(' ').trim();
  if (!title) {
    console.error('Usage: atris member goal <name> "Long-term goal" [--acceptance "..."] [--cadence daily] [--why "..."]');
    process.exit(1);
  }

  const state = loadMemberGoals(name, paths);
  const id = makeGoalId(title);
  const existing = state.goals.find((goal) => goal.id === id || goal.title.toLowerCase() === title.toLowerCase());
  const goal = existing || {
    id,
    title,
    status: 'active',
    cadence,
    why,
    acceptance: acceptance.length ? acceptance : ['Return proof, risk, and next move.'],
    created_at: stampIso(),
    experiments: [],
    history: [],
  };
  for (const prev of state.goals) {
    if (prev && prev !== existing && prev.status === 'active') {
      prev.status = 'superseded';
    }
  }
  goal.status = 'active';
  goal.cadence = cadence || goal.cadence || 'manual';
  if (why) goal.why = why;
  if (acceptance.length) goal.acceptance = acceptance;
  goal.history = Array.isArray(goal.history) ? goal.history : [];
  goal.history.push({ at: stampIso(), event: existing ? 'goal_updated' : 'goal_created' });
  if (!existing) state.goals.push(goal);
  writeMemberGoals(paths, state);
  const logPath = appendMemberGoalLog(paths.memberDir, name, existing ? 'Member goal updated' : 'Member goal created', {
    goal: goal.title,
    cadence: goal.cadence,
    acceptance: (goal.acceptance || []).join(' | '),
  });
  printJsonOrText(
    { ok: true, action: existing ? 'goal_updated' : 'goal_created', member: name, goal, goals_path: paths.goalsJson, goals_md_path: paths.goalsMd, log_path: logPath },
    [
      `${existing ? 'Updated' : 'Created'} goal for ${name}: ${goal.title}`,
      `Goals: ${path.relative(process.cwd(), paths.goalsJson)}`,
      `Readout: ${path.relative(process.cwd(), paths.goalsMd)}`,
    ],
    asJson,
  );
}

function memberGoalFromMission(name, ...args) {
  const paths = requireMemberDir(name);
  const asJson = hasFlag(args, '--json');
  const force = hasFlag(args, '--force');
  const cadence = readFlag(args, '--cadence', 'manual') || 'manual';
  const purpose = missionPurpose(paths);
  if (!purpose.meaningful) {
    const ask = `Define atris/team/${name}/MISSION.md with a concrete North Star before this member creates its own goal.`;
    const logPath = appendMemberGoalLog(paths.memberDir, name, 'Member goal-from-mission blocked', {
      ask,
      mission_file: path.relative(process.cwd(), paths.missionFile),
    });
    printJsonOrText(
      { ok: true, action: 'needs_user', member: name, needs_user: true, ask, mission_file: paths.missionFile, log_path: logPath },
      [
        `Blocked for ${name}: MISSION.md needs a concrete North Star.`,
        `Ask: ${ask}`,
      ],
      asJson,
    );
    return;
  }

  const state = loadMemberGoals(name, paths);
  const runtime = purpose.runtimeMission;
  const runtimeFocus = runtime.heading || purpose.northStar;
  if (lowerCompact(runtime.status || '') === 'blocked') {
    const ask = runtime.next
      ? `${compactSentence(runtimeFocus, 120)} is blocked. ${compactSentence(runtime.next, 180)}`
      : `Mission ${runtime.id || compactSentence(runtimeFocus, 88)} is blocked. Human should unblock or revise before this member reuses its goal.`;
    const logPath = appendMemberGoalLog(paths.memberDir, name, 'Member goal-from-mission blocked', {
      ask,
      mission_id: runtime.id || '',
      mission_status: runtime.status || 'blocked',
      next: runtime.next || '',
    });
    printJsonOrText(
      {
        ok: true,
        action: 'needs_user',
        member: name,
        needs_user: true,
        ask,
        mission: {
          north_star: purpose.northStar,
          runtime_id: runtime.id || null,
          runtime_status: runtime.status || null,
          runtime_next: runtime.next || null,
        },
        mission_file: paths.missionFile,
        log_path: logPath,
      },
      [
        `Blocked for ${name}: active mission is blocked.`,
        `Ask: ${ask}`,
      ],
      asJson,
    );
    return;
  }
  if (MISSION_TERMINAL_STATUSES.has(lowerCompact(runtime.status || ''))) {
    // A finished mission must not mint or re-point an active goal; that recreated the
    // stale-goal defect class (OBL-1961, OBL-2212, OBL-2232) after every retire. --force
    // cannot bypass this, it only widens the existing-goal match on a living mission.
    const staleGoals = state.goals.filter((goal) => (
      goal.source === 'mission' && goal.status === 'active'
      && runtime.id && goal.mission_id === runtime.id
    ));
    const staleList = staleGoals.map((goal) => goal.title || goal.id).join('; ');
    const ask = staleGoals.length
      ? `Mission ${runtime.id || compactSentence(runtimeFocus, 88)} is ${runtime.status}, so its active goal is stale. Retire ${compactSentence(staleList, 140)} by setting its status in goals.json, or start a living mission and run: atris member goal-from-mission ${name} --force`
      : `Mission ${runtime.id || compactSentence(runtimeFocus, 88)} is ${runtime.status}. Start a living mission, then run: atris member goal-from-mission ${name} --force`;
    const logPath = appendMemberGoalLog(paths.memberDir, name, 'Member goal-from-mission blocked', {
      ask,
      mission_id: runtime.id || '',
      mission_status: runtime.status || '',
      stale_goals: staleGoals.map((goal) => goal.id),
    });
    printJsonOrText(
      {
        ok: true,
        action: 'needs_user',
        member: name,
        needs_user: true,
        ask,
        stale_goals: staleGoals,
        mission: {
          north_star: purpose.northStar,
          runtime_id: runtime.id || null,
          runtime_status: runtime.status || null,
          runtime_next: runtime.next || null,
        },
        mission_file: paths.missionFile,
        log_path: logPath,
      },
      [
        `Blocked for ${name}: mission ${runtime.id || 'in now.md'} is ${runtime.status}, a finished mission cannot drive an active goal.`,
        `Ask: ${ask}`,
      ],
      asJson,
    );
    return;
  }
  // The title IS the mission focus, no boilerplate prefix; the acceptance list already
  // says "one bounded step" and the why carries the full sentence.
  const title = compactSentence(runtimeFocus, 96);
  const existing = state.goals.find((goal) => (
    goal.source === 'mission'
    && goal.status === 'active'
    && !force
    && (
      goal.mission_id === runtime.id
      || String(goal.mission_north_star || '') === purpose.northStar
      || goal.title.toLowerCase() === title.toLowerCase()
    )
  ));
  const acceptance = [
    'One bounded next move is proposed from MISSION.md, not hand-fed by the human.',
    'The move has verifier/proof target, stop rule, and human-ask condition.',
    'A receipt or log entry records what changed and what remains uncertain.',
  ];
  const goalId = makeGoalId(title);
  const goal = existing || {
    id: uniqueGoalId(state, goalId),
    title,
    status: 'active',
    cadence,
    why: compactSentence(purpose.northStar, 240),
    acceptance,
    source: 'mission',
    mission_file: path.relative(process.cwd(), paths.missionFile),
    now_file: fs.existsSync(path.join(paths.memberDir, 'now.md')) ? path.relative(process.cwd(), path.join(paths.memberDir, 'now.md')) : null,
    mission_id: runtime.id || null,
    mission_north_star: purpose.northStar,
    created_at: stampIso(),
    experiments: [],
    history: [],
  };
  goal.status = 'active';
  // Refresh the title on reuse so older bloated/truncated titles self-heal on the next tick.
  goal.title = title;
  goal.cadence = cadence || goal.cadence || 'manual';
  goal.source = 'mission';
  goal.why = goal.why || compactSentence(purpose.northStar, 240);
  goal.acceptance = Array.isArray(goal.acceptance) && goal.acceptance.length ? goal.acceptance : acceptance;
  goal.mission_file = path.relative(process.cwd(), paths.missionFile);
  goal.now_file = fs.existsSync(path.join(paths.memberDir, 'now.md')) ? path.relative(process.cwd(), path.join(paths.memberDir, 'now.md')) : null;
  goal.mission_id = runtime.id || goal.mission_id || null;
  goal.mission_north_star = purpose.northStar;
  const taskContext = missionTaskContextForMember(name, goal.mission_id);
  const nativeGoal = nativeGoalFromMissionTask(name, goal, runtime, taskContext);
  goal.task_context = taskContext;
  goal.native_goal = nativeGoal;
  goal.history = Array.isArray(goal.history) ? goal.history : [];
  const historyEntry = {
    at: stampIso(),
    event: existing ? 'goal_from_mission_reused' : 'goal_from_mission_created',
    mission_id: runtime.id || null,
    mission_status: runtime.status || null,
  };
  // Collapse repeated no-op reuse ticks (same mission state) instead of recording an identical entry
  // every cadence, that grew one member's goals.json to 2,200+ duplicate entries / 13K lines. Real
  // transitions (created, changed mission id/status) are still kept; only consecutive dupes are dropped.
  const lastEntry = goal.history[goal.history.length - 1];
  const isDuplicateReuse = existing && lastEntry
    && lastEntry.event === historyEntry.event
    && lastEntry.mission_id === historyEntry.mission_id
    && lastEntry.mission_status === historyEntry.mission_status;
  if (!isDuplicateReuse) goal.history.push(historyEntry);
  // Backstop cap so no event type can grow the file without bound (bloated files self-heal on write).
  if (goal.history.length > 50) goal.history = goal.history.slice(-50);
  if (!existing) state.goals.push(goal);
  state.goals = [goal, ...state.goals.filter((item) => item !== goal)];
  writeMemberGoals(paths, state);
  const logPath = appendMemberGoalLog(paths.memberDir, name, existing ? 'Member goal reused from Mission' : 'Member goal created from Mission', {
    goal: goal.title,
    north_star: purpose.northStar,
    runtime_mission: runtime.id || '',
    current_task: taskContext?.ref || '',
    native_goal: nativeGoal.objective,
    next: nativeGoal.next_command,
  });
  printJsonOrText(
    {
      ok: true,
      action: existing ? 'goal_from_mission_reused' : 'goal_from_mission_created',
      member: name,
      goal,
      mission: {
        north_star: purpose.northStar,
        runtime_id: runtime.id || null,
        runtime_status: runtime.status || null,
        runtime_next: runtime.next || null,
      },
      task: taskContext,
      native_goal: nativeGoal,
      goals_path: paths.goalsJson,
      goals_md_path: paths.goalsMd,
      log_path: logPath,
      next_command: nativeGoal.next_command,
    },
    [
      `${existing ? 'Reused' : 'Created'} mission-derived goal for ${name}: ${goal.title}`,
      `Mission: ${purpose.northStar}`,
      `Native goal: ${nativeGoal.slash_goal}`,
      `Next: ${nativeGoal.next_command}`,
    ],
    asJson,
  );
}

function memberGoalFromScore(name, ...args) {
  const paths = requireMemberDir(name);
  const asJson = hasFlag(args, '--json');
  const force = hasFlag(args, '--force');
  const cadence = readFlag(args, '--cadence', 'manual') || 'manual';
  const scoreJsonPath = readFlag(args, '--score-json', readFlag(args, '--score', ''));
  const purpose = missionPurpose(paths);
  if (!purpose.meaningful) {
    const ask = `Define atris/team/${name}/MISSION.md with a concrete North Star before this member creates a score-derived goal.`;
    const logPath = appendMemberGoalLog(paths.memberDir, name, 'Member goal-from-score blocked', {
      ask,
      mission_file: path.relative(process.cwd(), paths.missionFile),
    });
    printJsonOrText(
      { ok: true, action: 'needs_user', member: name, needs_user: true, ask, mission_file: paths.missionFile, log_path: logPath },
      [
        `Blocked for ${name}: MISSION.md needs a concrete North Star.`,
        `Ask: ${ask}`,
      ],
      asJson,
    );
    return;
  }

  const loaded = loadTeamScoreEvidence(scoreJsonPath);
  if (!loaded.ok) {
    console.error(`Could not load Team score evidence: ${loaded.error || 'unknown error'}`);
    process.exit(1);
  }
  const scoreEvidence = normalizeTeamScoreEvidence(loaded.parsed, loaded.source);
  if (!scoreEvidence) {
    console.error('Team score evidence must include score.nextMove plus a weakest dimension.');
    process.exit(1);
  }

  const state = loadMemberGoals(name, paths);
  const title = compactSentence(scoreEvidence.next_move, 120);
  const goalId = makeGoalId(title);
  const existing = state.goals.find((goal) => (
    goal.source === 'team_score'
    && goal.status === 'active'
    && (
      goal.id === goalId
      || goal.team_score?.next_move === scoreEvidence.next_move
      || goal.title.toLowerCase() === title.toLowerCase()
    )
  ));
  const acceptance = [
    `One bounded experiment targets the score-selected next move: ${scoreEvidence.drill || scoreEvidence.next_move}`,
    `The goal records weakest dimension ${scoreEvidence.weakest.label} and latest reward receipt ${latestRewardLine(scoreEvidence.latest_reward)}.`,
    scoreEvidence.target_member
      ? `Target member: ${scoreEvidence.target_member.label || scoreEvidence.target_member.slug}${scoreEvidence.target_member.weakest_attribute?.label ? `; weakest attribute: ${scoreEvidence.target_member.weakest_attribute.label}` : ''}.`
      : 'Target member is recorded when the score packet provides one.',
    'Review proof or ask the human before replacing this with another score-derived goal.',
  ];
  const goal = existing || {
    id: goalId,
    title,
    status: 'active',
    cadence,
    why: compactSentence(`Team Overall ${scoreEvidence.overall == null ? 'score' : scoreEvidence.overall} selected this from proof: ${scoreEvidence.next_move}`, 240),
    acceptance,
    source: 'team_score',
    mission_file: path.relative(process.cwd(), paths.missionFile),
    mission_north_star: purpose.northStar,
    team_score: scoreEvidence,
    created_at: stampIso(),
    experiments: [],
    history: [],
  };
  goal.status = 'active';
  goal.cadence = cadence || goal.cadence || 'manual';
  goal.source = 'team_score';
  goal.why = compactSentence(`Team Overall ${scoreEvidence.overall == null ? 'score' : scoreEvidence.overall} selected this from proof: ${scoreEvidence.next_move}`, 240);
  goal.acceptance = acceptance;
  goal.mission_file = path.relative(process.cwd(), paths.missionFile);
  goal.mission_north_star = purpose.northStar;
  goal.team_score = scoreEvidence;
  goal.history = Array.isArray(goal.history) ? goal.history : [];
  goal.history.push({
    at: stampIso(),
    event: existing ? 'goal_from_score_reused' : 'goal_from_score_created',
    score_source: scoreEvidence.source,
    weakest_dimension: scoreEvidence.weakest.label,
    latest_reward_ref: scoreEvidence.latest_reward?.ref || null,
  });
  if (!existing) state.goals.push(goal);
  state.goals = [goal, ...state.goals.filter((item) => item !== goal)];
  const supersedeProof = `Score-derived goal selected ${scoreEvidence.next_move}; superseding older open experiments so the member can change direction.`;
  const supersededExperiments = supersedeOtherOpenExperiments(state, goal, supersedeProof);
  writeMemberGoals(paths, state);
  const logPath = appendMemberGoalLog(paths.memberDir, name, existing ? 'Member goal reused from Team score' : 'Member goal created from Team score', {
    goal: goal.title,
    score: scoreEvidence.overall == null ? '' : scoreEvidence.overall,
    weakest: `${scoreEvidence.weakest.label}${scoreEvidence.weakest.score == null ? '' : ` ${scoreEvidence.weakest.score}`}`,
    latest_reward: latestRewardLine(scoreEvidence.latest_reward),
    superseded: supersededExperiments.map((item) => item.experiment_id).join(', '),
    source: scoreEvidence.source,
    next: `atris member tick ${name} --goal ${goal.id}`,
  });
  printJsonOrText(
    {
      ok: true,
      action: existing ? 'goal_from_score_reused' : 'goal_from_score_created',
      member: name,
      goal,
      score: scoreEvidence,
      superseded_experiments: supersededExperiments,
      goals_path: paths.goalsJson,
      goals_md_path: paths.goalsMd,
      log_path: logPath,
      next_command: `atris member tick ${name} --goal ${goal.id}`,
    },
    [
      `${existing ? 'Reused' : 'Created'} score-derived goal for ${name}: ${goal.title}`,
      `Weakest: ${scoreEvidence.weakest.label}${scoreEvidence.weakest.score == null ? '' : ` ${scoreEvidence.weakest.score}`}`,
      `Latest reward: ${latestRewardLine(scoreEvidence.latest_reward)}`,
      `Next: atris member tick ${name} --goal ${goal.id}`,
    ],
    asJson,
  );
}

function fallbackProposalForGoal(goal, context = {}) {
  const criteria = Array.isArray(goal.acceptance) && goal.acceptance.length
    ? goal.acceptance[0]
    : 'Return proof, risk, and next move.';
  const scoreEvidence = goal.team_score || null;
  const target = scoreEvidence?.target_member || null;
  const drill = scoreEvidence?.drill || null;
  const fileEvidence = context?.evidence?.goal_files || context?.goal_files || null;
  const primaryFile = (fileEvidence?.files || []).find((file) => file.exists && file.excerpt) || null;
  // Don't restate the goal title inside the experiment, the experiment lives under the goal.
  const title = drill && target
    ? `Run ${target.label || target.slug} drill: ${compactSentence(drill, 96)}`
    : drill
      ? `Run score drill: ${compactSentence(drill, 108)}`
      : `Next proof step: ${compactSentence(goal.title, 96)}`;
  const nextStep = drill
    ? drill
    : primaryFile
      ? `Read ${primaryFile.path} and take one receipt-backed step toward the goal.`
    : goal.source === 'mission'
      ? `Read ${goal.mission_file || 'MISSION.md'} and take one receipt-backed step toward the goal.`
      : criteria;
  return {
    id: makeExperimentId(goal.id, title),
    title,
    status: 'proposed',
    proof_target: drill ? `Concrete drill: ${drill}` : criteria,
    next_step: nextStep,
    target_member: target || null,
    verifier: scoreEvidence?.verifier || null,
    stop_rule: 'Stop if proof is missing, risk is unclear, or the next move would require new authority.',
    created_at: stampIso(),
    generation: {
      mode: 'fallback',
      source: primaryFile ? 'goal_file_evidence' : 'goal_rules',
    },
  };
}

function proposalPromptForGoal(goal, context = {}, cwd = process.cwd()) {
  const sharedProcess = memberProcessPrompt(cwd);
  const files = (context?.evidence?.goal_files?.files || [])
    .filter((file) => file.exists && file.excerpt)
    .slice(0, 4)
    .map((file) => ({
      path: file.path,
      excerpt: compactSentence(file.excerpt, 1200),
    }));
  const payload = {
    goal: {
      id: goal.id || null,
      title: goal.title || null,
      source: goal.source || null,
      why: goal.why || null,
      acceptance: Array.isArray(goal.acceptance) ? goal.acceptance.slice(0, 8) : [],
      mission_file: goal.mission_file || null,
      mission_north_star: goal.mission_north_star || null,
      team_score: goal.team_score || null,
    },
    wake_decision: context?.decision || null,
    evidence: {
      latest_receipt: context?.evidence?.receipt || null,
      selected_wake_candidate: context?.evidence?.selected_wake_candidate || null,
      wake_candidate_scores: context?.evidence?.wake_candidate_scores || [],
      files,
    },
  };
  return [
    ...(sharedProcess ? [sharedProcess, ''] : []),
    'You generate the next bounded Atris member experiment.',
    'Read the JSON context and return only JSON with keys: title, proof_target, next_step, verifier, stop_rule.',
    'The next_step must be adaptive to the goal/evidence, concrete, receipt-backed, and safe for one bounded tick.',
    'Do not ask for human input unless authority is missing. Do not copy generic templates.',
    '',
    JSON.stringify(payload, null, 2),
  ].join('\n');
}

function parseJsonObjectFromText(text) {
  const raw = String(text || '').trim();
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    const start = raw.indexOf('{');
    const end = raw.lastIndexOf('}');
    if (start === -1 || end <= start) return null;
    try {
      return JSON.parse(raw.slice(start, end + 1));
    } catch {
      return null;
    }
  }
}

function normalizeLlmProposal(raw, fallback, goal = null) {
  if (!raw || typeof raw !== 'object') return null;
  const title = compactSentence(raw.title || '', 140);
  const proofTarget = compactSentence(raw.proof_target || raw.proofTarget || '', 220);
  const nextStep = compactSentence(raw.next_step || raw.nextStep || '', 360);
  if (!title || !proofTarget || !nextStep) return null;
  return {
    ...fallback,
    id: makeExperimentId(goal?.id || fallback.id || '', title),
    title,
    proof_target: proofTarget,
    next_step: nextStep,
    verifier: compactSentence(raw.verifier || fallback.verifier || '', 180) || null,
    stop_rule: compactSentence(raw.stop_rule || raw.stopRule || fallback.stop_rule, 220),
  };
}

function injectedLlmProposal() {
  if (!process.env.ATRIS_MEMBER_PROPOSAL_LLM_JSON) return null;
  const parsed = parseJsonObjectFromText(process.env.ATRIS_MEMBER_PROPOSAL_LLM_JSON);
  return parsed ? { source: 'env_json', proposal: parsed } : { source: 'env_json', error: 'invalid_json' };
}

async function callAtris2ProposalLlm(goal, context = {}) {
  const injected = injectedLlmProposal();
  if (injected) return injected;
  if (process.env.ATRIS_MEMBER_PROPOSAL_LLM !== '1') return null;
  const prompt = proposalPromptForGoal(goal, context, process.cwd());
  try {
    const { postTurn } = require('../ax');
    const output = { isTTY: false, write() { return true; } };
    const result = await postTurn(prompt, {
      mode: process.env.ATRIS_MEMBER_PROPOSAL_LLM_MODE || 'fast',
      route: 'local',
      cwd: process.cwd(),
      output,
      color: false,
    });
    const parsed = parseJsonObjectFromText(result?.output || '');
    return parsed
      ? { source: 'atris2_backend', proposal: parsed }
      : { source: 'atris2_backend', error: 'missing_json_response' };
  } catch (error) {
    return {
      source: 'atris2_backend',
      error: compactSentence(error instanceof Error ? error.message : String(error), 220),
    };
  }
}

async function proposalForGoal(goal, context = {}) {
  const fallback = fallbackProposalForGoal(goal, context);
  const llm = await callAtris2ProposalLlm(goal, context);
  const normalized = normalizeLlmProposal(llm?.proposal, fallback, goal);
  if (!normalized) {
    return {
      ...fallback,
      generation: {
        ...fallback.generation,
        llm_source: llm?.source || null,
        llm_error: llm?.error || null,
      },
    };
  }
  return {
    ...normalized,
    generation: {
      mode: 'llm',
      source: llm.source,
      fallback_title: fallback.title,
    },
  };
}

function wikiMinerGraphPath(root = process.cwd()) {
  return path.join(root, 'atris', 'wiki', '.graph.json');
}

function emptyWikiGraph() {
  return {
    schema: 'atris.wiki_graph.v1',
    updated_at: null,
    entities: [],
    relationships: [],
    causal_patterns: [],
  };
}

function readWikiGraph(root = process.cwd()) {
  const graphPath = wikiMinerGraphPath(root);
  if (!fs.existsSync(graphPath)) return emptyWikiGraph();
  try {
    const parsed = JSON.parse(fs.readFileSync(graphPath, 'utf8'));
    return {
      ...emptyWikiGraph(),
      ...parsed,
      entities: Array.isArray(parsed.entities) ? parsed.entities : [],
      relationships: Array.isArray(parsed.relationships) ? parsed.relationships : [],
      causal_patterns: Array.isArray(parsed.causal_patterns) ? parsed.causal_patterns : [],
    };
  } catch {
    return emptyWikiGraph();
  }
}

function readCausalPatterns(root = process.cwd()) {
  const causalPath = path.join(root, 'atris', 'wiki', '.causal.json');
  if (!fs.existsSync(causalPath)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(causalPath, 'utf8'));
    return Array.isArray(parsed.patterns) ? parsed.patterns : [];
  } catch {
    return [];
  }
}

function listWikiMarkdownPages(root = process.cwd(), limit = 10) {
  const wikiDir = path.join(root, 'atris', 'wiki');
  const out = [];
  function walk(dir) {
    if (!fs.existsSync(dir) || out.length >= limit) return;
    for (const entry of fs.readdirSync(dir).sort()) {
      if (out.length >= limit) break;
      const full = path.join(dir, entry);
      let stat;
      try {
        stat = fs.statSync(full);
      } catch {
        continue;
      }
      if (stat.isDirectory()) {
        if (!entry.startsWith('.')) walk(full);
      } else if (stat.isFile() && entry.endsWith('.md')) {
        out.push(full);
      }
    }
  }
  walk(wikiDir);
  return out;
}

function wikiMinerPrompt(pageContent) {
  return `Extract entities and relationships from this wiki page. Return JSON:
{
  "entities": [{"type": "person|system|concept", "name": "..."}],
  "relationships": [{"from": "...", "to": "...", "type": "uses|depends-on|owns"}]
}

Wiki content:
${pageContent}`;
}

function isWikiMinerNoiseName(value) {
  const name = compactSentence(value || '', 120);
  if (!name) return true;
  if (/^[A-Z]{2,}$/.test(name)) return false;
  return /^(?:i|me|my|mine|myself|we|us|our|ours|ourselves|you|your|yours|yourself|yourselves|he|him|his|himself|she|her|hers|herself|it|its|itself|they|them|their|theirs|themselves|this|that|these|those|here|there|where|when|what|who|whom|which|why|how|everything|nothing|something|anything|everyone|anyone|someone|nobody|everybody|anybody|somebody|none|the|wiki|mission)$/i.test(name);
}

function isWikiMinerSelfLoop(relationship) {
  const from = lowerCompact(relationship?.from);
  return from !== '' && from === lowerCompact(relationship?.to);
}

function normalizeWikiMinerExtraction(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const allowedEntityTypes = new Set(['person', 'system', 'concept']);
  const allowedRelationTypes = new Set(['uses', 'depends-on', 'owns']);
  const entities = (Array.isArray(raw.entities) ? raw.entities : [])
    .map((entity) => ({
      type: allowedEntityTypes.has(String(entity?.type || '').toLowerCase()) ? String(entity.type).toLowerCase() : 'concept',
      name: compactSentence(entity?.name || '', 120),
    }))
    .filter((entity) => !isWikiMinerNoiseName(entity.name));
  const relationships = (Array.isArray(raw.relationships) ? raw.relationships : [])
    .map((relationship) => ({
      from: compactSentence(relationship?.from || '', 120),
      to: compactSentence(relationship?.to || '', 120),
      type: allowedRelationTypes.has(String(relationship?.type || '').toLowerCase()) ? String(relationship.type).toLowerCase() : 'uses',
    }))
    .filter((relationship) => !isWikiMinerNoiseName(relationship.from) && !isWikiMinerNoiseName(relationship.to) && !isWikiMinerSelfLoop(relationship));
  return { entities, relationships };
}

function heuristicWikiMinerExtraction(pagePath, pageContent) {
  const title = compactSentence((String(pageContent).match(/^#\s+(.+)$/m) || [])[1] || path.basename(pagePath, '.md'), 120);
  const candidates = new Set();
  const patterns = [
    /\b[A-Z][A-Za-z0-9]+(?:\s+[A-Z][A-Za-z0-9]+){0,3}\b/g,
    /\b[a-z][a-z0-9]+(?:-[a-z0-9]+)+\b/g,
    /`([^`\n]{2,80})`/g,
  ];
  for (const pattern of patterns) {
    let match = pattern.exec(pageContent);
    while (match) {
      const value = compactSentence(match[1] || match[0], 80);
      if (!isWikiMinerNoiseName(value)) candidates.add(value);
      match = pattern.exec(pageContent);
    }
  }
  const entities = [{ type: 'concept', name: title }];
  for (const name of [...candidates].slice(0, 12)) entities.push({ type: /agent|api|sdk|cli|hub|system/i.test(name) ? 'system' : 'concept', name });
  const relationships = [...candidates].slice(0, 12)
    .map((name) => ({ from: title, to: name, type: 'uses' }))
    .filter((relationship) => !isWikiMinerSelfLoop(relationship));
  return { entities, relationships };
}

function injectedWikiMinerExtraction(pageIndex) {
  if (!process.env.ATRIS_WIKI_MINER_LLM_JSON) return null;
  const parsed = parseJsonObjectFromText(process.env.ATRIS_WIKI_MINER_LLM_JSON);
  if (!parsed) return { source: 'env_json', error: 'invalid_json' };
  const payload = Array.isArray(parsed.pages) ? parsed.pages[pageIndex] : parsed;
  return payload ? { source: 'env_json', extraction: payload } : { source: 'env_json', error: 'missing_page_payload' };
}

async function callWikiMinerLlm(pagePath, pageContent, pageIndex) {
  const injected = injectedWikiMinerExtraction(pageIndex);
  if (injected) return injected;
  if (process.env.ATRIS_WIKI_MINER_LLM !== '1') return null;
  try {
    const { postTurn } = require('../ax');
    const output = { isTTY: false, write() { return true; } };
    const result = await postTurn(wikiMinerPrompt(pageContent), {
      mode: process.env.ATRIS_WIKI_MINER_LLM_MODE || 'fast',
      route: 'local',
      cwd: process.cwd(),
      output,
      color: false,
    });
    const parsed = parseJsonObjectFromText(result?.output || '');
    return parsed
      ? { source: 'atris2_backend', extraction: parsed }
      : { source: 'atris2_backend', error: 'missing_json_response' };
  } catch (error) {
    return {
      source: 'atris2_backend',
      error: compactSentence(error instanceof Error ? error.message : String(error), 220),
    };
  }
}

function mergeWikiGraph(graph, extraction, sourcePath) {
  const entityMap = new Map();
  for (const entity of graph.entities || []) {
    if (isWikiMinerNoiseName(entity.name)) continue;
    const key = `${String(entity.type || 'concept').toLowerCase()}:${lowerCompact(entity.name)}`;
    entityMap.set(key, { ...entity, sources: Array.isArray(entity.sources) ? entity.sources : [] });
  }
  for (const entity of extraction.entities || []) {
    const key = `${entity.type}:${lowerCompact(entity.name)}`;
    const existing = entityMap.get(key) || { type: entity.type, name: entity.name, sources: [] };
    if (sourcePath && !existing.sources.includes(sourcePath)) existing.sources.push(sourcePath);
    entityMap.set(key, existing);
  }

  const relationshipMap = new Map();
  for (const relationship of graph.relationships || []) {
    if (isWikiMinerNoiseName(relationship.from) || isWikiMinerNoiseName(relationship.to) || isWikiMinerSelfLoop(relationship)) continue;
    const key = `${lowerCompact(relationship.from)}|${String(relationship.type || 'uses').toLowerCase()}|${lowerCompact(relationship.to)}`;
    relationshipMap.set(key, { ...relationship, sources: Array.isArray(relationship.sources) ? relationship.sources : [] });
  }
  for (const relationship of extraction.relationships || []) {
    if (isWikiMinerNoiseName(relationship.from) || isWikiMinerNoiseName(relationship.to) || isWikiMinerSelfLoop(relationship)) continue;
    const key = `${lowerCompact(relationship.from)}|${relationship.type}|${lowerCompact(relationship.to)}`;
    const existing = relationshipMap.get(key) || { from: relationship.from, to: relationship.to, type: relationship.type, sources: [] };
    if (sourcePath && !existing.sources.includes(sourcePath)) existing.sources.push(sourcePath);
    relationshipMap.set(key, existing);
  }

  return {
    schema: 'atris.wiki_graph.v1',
    updated_at: stampIso(),
    entities: [...entityMap.values()].sort((a, b) => `${a.type}:${a.name}`.localeCompare(`${b.type}:${b.name}`)),
    relationships: [...relationshipMap.values()].sort((a, b) => `${a.from}|${a.type}|${a.to}`.localeCompare(`${b.from}|${b.type}|${b.to}`)),
    causal_patterns: Array.isArray(graph.causal_patterns) ? graph.causal_patterns : [],
  };
}

async function runWikiMinerWake(name, paths, { execute = false } = {}) {
  const mode = execute ? 'execute' : 'dry_run';
  const root = process.cwd();
  const pages = listWikiMarkdownPages(root, 10);
  let graph = readWikiGraph(root);
  const causalPatterns = readCausalPatterns(root);
  graph.causal_patterns = causalPatterns;
  const pageReceipts = [];
  let llmSuccessfulPages = 0;

  for (let index = 0; index < pages.length; index += 1) {
    const pagePath = pages[index];
    const relativePath = path.relative(root, pagePath);
    let pageContent = '';
    try {
      pageContent = fs.readFileSync(pagePath, 'utf8').slice(0, 12000);
    } catch (error) {
      pageReceipts.push({ path: relativePath, ok: false, error: error instanceof Error ? error.message : String(error) });
      continue;
    }
    const llm = await callWikiMinerLlm(pagePath, pageContent, index);
    let extraction = normalizeWikiMinerExtraction(llm?.extraction);
    let modeUsed = llm?.source || null;
    let error = llm?.error || null;
    if (!extraction && !llm?.error) {
      extraction = heuristicWikiMinerExtraction(pagePath, pageContent);
      modeUsed = 'heuristic';
    }
    if (!extraction) {
      pageReceipts.push({ path: relativePath, ok: false, llm_source: llm?.source || null, error: error || 'invalid_json' });
      continue;
    }
    if (llm?.source) llmSuccessfulPages += 1;
    pageReceipts.push({
      path: relativePath,
      ok: true,
      mode: modeUsed,
      llm_source: llm?.source || null,
      entity_count: extraction.entities.length,
      relationship_count: extraction.relationships.length,
      error,
    });
    if (execute) graph = mergeWikiGraph(graph, extraction, relativePath);
  }

  const graphPath = wikiMinerGraphPath(root);
  if (execute) {
    graph.causal_patterns = causalPatterns;
    fs.mkdirSync(path.dirname(graphPath), { recursive: true });
    fs.writeFileSync(graphPath, JSON.stringify(graph, null, 2) + '\n', 'utf8');
  }

  const runsDir = path.join(root, 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const receiptPath = path.join(runsDir, `wiki-miner-tick-${fileSafeStamp()}.json`);
  const receipt = {
    schema: 'atris.wiki_miner_tick.v1',
    created_at: stampIso(),
    member: name,
    mode,
    executed: execute,
    ok: true,
    pages_scanned: pages.length,
    pages_succeeded: pageReceipts.filter((page) => page.ok).length,
    pages_failed: pageReceipts.filter((page) => !page.ok).length,
    llm_successful_pages: llmSuccessfulPages,
    graph_path: path.relative(root, graphPath),
    entity_count: graph.entities.length,
    relationship_count: graph.relationships.length,
    causal_pattern_count: causalPatterns.length,
    pages: pageReceipts,
  };
  fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n', 'utf8');
  const logPath = appendMemberGoalLog(paths.memberDir, name, 'Wiki miner tick', {
    mode,
    pages: pages.length,
    succeeded: receipt.pages_succeeded,
    failed: receipt.pages_failed,
    graph: receipt.graph_path,
    receipt: path.relative(root, receiptPath),
  });

  return {
    ok: true,
    action: 'wake',
    member: name,
    mode,
    decision: 'wiki_mine',
    reason: execute ? 'wiki_graph_extracted' : 'wiki_graph_dry_run',
    executed: execute,
    needs_user: false,
    ask: null,
    next_command: `atris wiki related <entity>`,
    receipt_path: receiptPath,
    log_path: logPath,
    graph_path: graphPath,
    wiki_miner: receipt,
  };
}

function supervisorRecommendationsPath(root = process.cwd()) {
  return path.join(root, 'atris', 'team', 'supervisor', 'recommendations.json');
}

function emptySupervisorRecommendations(extra = {}) {
  return {
    schema: 'atris.supervisor_recommendations.v1',
    updated_at: stampIso(),
    status: extra.status || 'empty',
    advisory_only: true,
    llm_source: extra.llm_source || null,
    llm_error: extra.llm_error || null,
    top_performers: [],
    bottlenecks: [],
    recommendations: [],
  };
}

function listRecentSupervisorReceipts(root = process.cwd(), windowMs = 24 * 60 * 60 * 1000) {
  const runsDir = path.join(root, 'atris', 'runs');
  if (!fs.existsSync(runsDir)) return [];
  const cutoff = Date.now() - windowMs;
  return fs.readdirSync(runsDir)
    .filter((entry) => /^member-.*-.*\.json$/.test(entry))
    .map((entry) => {
      const fullPath = path.join(runsDir, entry);
      let stat;
      try {
        stat = fs.statSync(fullPath);
      } catch {
        return null;
      }
      return stat.isFile() && stat.mtimeMs >= cutoff ? { fullPath, relativePath: path.relative(root, fullPath), mtimeMs: stat.mtimeMs } : null;
    })
    .filter(Boolean)
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
    .map((entry) => {
      try {
        const parsed = JSON.parse(fs.readFileSync(entry.fullPath, 'utf8'));
        return {
          path: entry.relativePath,
          member: parsed.member || parsed.claimed_by || null,
          ok: parsed.ok !== false,
          decision: parsed.decision || null,
          reason: parsed.reason || parsed.error || null,
          created_at: parsed.created_at || parsed.finished_at || parsed.started_at || null,
          duration_ms: parsed.duration_ms || parsed.elapsed_ms || null,
        };
      } catch (error) {
        return {
          path: entry.relativePath,
          member: null,
          ok: false,
          decision: null,
          reason: compactSentence(error instanceof Error ? error.message : String(error), 220),
          created_at: null,
          duration_ms: null,
        };
      }
    });
}

function readSupervisorMemberLogs(root = process.cwd(), maxFiles = 40) {
  const teamDir = path.join(root, 'atris', 'team');
  if (!fs.existsSync(teamDir)) return '';
  const files = [];
  for (const member of fs.readdirSync(teamDir).sort()) {
    if (member.startsWith('_')) continue;
    const logsDir = path.join(teamDir, member, 'logs');
    if (!fs.existsSync(logsDir)) continue;
    for (const entry of fs.readdirSync(logsDir).sort()) {
      if (!entry.endsWith('.md')) continue;
      const fullPath = path.join(logsDir, entry);
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isFile()) files.push({ fullPath, relativePath: path.relative(root, fullPath), mtimeMs: stat.mtimeMs });
      } catch {
        // Ignore unreadable log files; the receipt records the aggregate input size.
      }
    }
  }
  return files
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
    .slice(0, maxFiles)
    .map((entry) => {
      try {
        return `\n--- ${entry.relativePath} ---\n${fs.readFileSync(entry.fullPath, 'utf8').slice(0, 2000)}`;
      } catch (error) {
        return `\n--- ${entry.relativePath} ---\n[unreadable: ${compactSentence(error instanceof Error ? error.message : String(error), 180)}]`;
      }
    })
    .join('\n')
    .slice(0, 20000);
}

function supervisorPrompt(receipts, logs) {
  return `Analyze these member receipts and logs. Identify:
1. Which members are performing best (success rate, speed)?
2. Any coordination bottlenecks or repeated failures?
3. Suggest specific adjustments: priority weights, member assignments

Return JSON:
{
  "top_performers": [{"member": "...", "reason": "..."}],
  "bottlenecks": [{"issue": "...", "suggestion": "..."}],
  "recommendations": [{"type": "priority|assignment", "from": "...", "to": "...", "reason": "..."}]
}

Receipts: ${JSON.stringify(receipts.slice(0, 20))}
Logs: ${logs.slice(0, 5000)}`;
}

function normalizeSupervisorAnalysis(raw, extra = {}) {
  if (!raw || typeof raw !== 'object') return null;
  const recommendationTypes = new Set(['priority', 'assignment']);
  const topPerformers = (Array.isArray(raw.top_performers) ? raw.top_performers : [])
    .map((entry) => ({
      member: compactSentence(entry?.member || '', 100),
      reason: compactSentence(entry?.reason || '', 260),
    }))
    .filter((entry) => entry.member);
  const bottlenecks = (Array.isArray(raw.bottlenecks) ? raw.bottlenecks : [])
    .map((entry) => ({
      issue: compactSentence(entry?.issue || '', 220),
      suggestion: compactSentence(entry?.suggestion || '', 320),
    }))
    .filter((entry) => entry.issue);
  const recommendations = (Array.isArray(raw.recommendations) ? raw.recommendations : [])
    .map((entry) => ({
      type: recommendationTypes.has(String(entry?.type || '').toLowerCase()) ? String(entry.type).toLowerCase() : 'priority',
      from: compactSentence(entry?.from || '', 100),
      to: compactSentence(entry?.to || '', 100),
      reason: compactSentence(entry?.reason || '', 320),
    }))
    .filter((entry) => entry.reason || entry.to);
  return {
    ...emptySupervisorRecommendations(extra),
    status: extra.status || 'ok',
    top_performers: topPerformers,
    bottlenecks,
    recommendations,
  };
}

function injectedSupervisorAnalysis() {
  if (!process.env.ATRIS_SUPERVISOR_LLM_JSON) return null;
  const parsed = parseJsonObjectFromText(process.env.ATRIS_SUPERVISOR_LLM_JSON);
  return parsed
    ? { source: 'env_json', analysis: parsed }
    : { source: 'env_json', error: 'invalid_json' };
}

async function callSupervisorLlm(receipts, logs) {
  const injected = injectedSupervisorAnalysis();
  if (injected) return injected;
  if (process.env.ATRIS_SUPERVISOR_LLM !== '1') return null;
  try {
    const { postTurn } = require('../ax');
    const output = { isTTY: false, write() { return true; } };
    const result = await postTurn(supervisorPrompt(receipts, logs), {
      mode: process.env.ATRIS_SUPERVISOR_LLM_MODE || 'fast',
      cwd: process.cwd(),
      output,
      color: false,
    });
    const parsed = parseJsonObjectFromText(result?.output || '');
    return parsed
      ? { source: 'atris2_backend', analysis: parsed }
      : { source: 'atris2_backend', error: 'missing_json_response' };
  } catch (error) {
    return {
      source: 'atris2_backend',
      error: compactSentence(error instanceof Error ? error.message : String(error), 220),
    };
  }
}

function fallbackSupervisorAnalysis(receipts) {
  const byMember = new Map();
  for (const receipt of receipts) {
    const member = compactSentence(receipt.member || 'unknown', 100);
    const current = byMember.get(member) || { member, total: 0, ok: 0, durations: [], reasons: new Map() };
    current.total += 1;
    if (receipt.ok) current.ok += 1;
    if (Number.isFinite(Number(receipt.duration_ms))) current.durations.push(Number(receipt.duration_ms));
    if (!receipt.ok || receipt.reason) {
      const reason = compactSentence(receipt.reason || 'unspecified', 180);
      current.reasons.set(reason, (current.reasons.get(reason) || 0) + 1);
    }
    byMember.set(member, current);
  }
  const ranked = [...byMember.values()].sort((a, b) => (b.ok / Math.max(1, b.total)) - (a.ok / Math.max(1, a.total)) || b.ok - a.ok);
  const top_performers = ranked.slice(0, 3).filter((entry) => entry.ok > 0).map((entry) => ({
    member: entry.member,
    reason: `${entry.ok}/${entry.total} recent member receipts succeeded`,
  }));
  const bottlenecks = ranked
    .filter((entry) => entry.ok < entry.total)
    .slice(0, 3)
    .map((entry) => {
      const [reason] = [...entry.reasons.entries()].sort((a, b) => b[1] - a[1])[0] || ['unknown failure'];
      return {
        issue: `${entry.member} has ${entry.total - entry.ok} failed recent receipt(s)`,
        suggestion: `Review repeated reason: ${reason}`,
      };
    });
  const recommendations = top_performers.length
    ? [{
        type: 'priority',
        from: 'supervisor',
        to: top_performers[0].member,
        reason: `Favor ${top_performers[0].member} for coordination work until LLM analysis is configured.`,
      }]
    : [];
  return normalizeSupervisorAnalysis(
    { top_performers, bottlenecks, recommendations },
    { status: 'heuristic', llm_source: null, llm_error: 'llm_not_configured' },
  );
}

async function runSupervisorWake(name, paths, { execute = false } = {}) {
  const mode = execute ? 'execute' : 'dry_run';
  const root = process.cwd();
  const llmConfigured = Boolean(process.env.ATRIS_SUPERVISOR_LLM_JSON)
    || process.env.ATRIS_SUPERVISOR_LLM === '1';
  if (!execute && !llmConfigured) {
    return {
      ok: true,
      skipped: true,
      action: 'wake',
      member: name,
      mode,
      decision: 'wait',
      reason: 'skipped_llm_not_configured',
      executed: false,
      needs_user: false,
      ask: null,
      next_command: null,
      receipt_path: null,
      log_path: null,
      recommendations_path: supervisorRecommendationsPath(root),
    };
  }
  const receipts = listRecentSupervisorReceipts(root);
  const logs = readSupervisorMemberLogs(root);
  let llm = null;
  let analysis = null;
  let reason = execute ? 'supervisor_recommendations_written' : 'supervisor_recommendations_dry_run';

  if (!receipts.length) {
    reason = 'insufficient_data';
    analysis = {
      ...emptySupervisorRecommendations({ status: 'insufficient_data' }),
      recommendations: [{
        type: 'priority',
        from: 'supervisor',
        to: 'member-receipts',
        reason: 'Insufficient data: no atris/runs/member-*-*.json receipts from the last 24 hours.',
      }],
    };
  } else {
    llm = await callSupervisorLlm(receipts, logs);
    if (llm?.analysis) {
      analysis = normalizeSupervisorAnalysis(llm.analysis, { status: 'ok', llm_source: llm.source });
      if (!analysis) {
        reason = 'llm_json_parse_failed';
        analysis = {
          ...fallbackSupervisorAnalysis(receipts),
          status: 'parse_error',
          llm_source: llm.source,
          llm_error: 'invalid_analysis_shape',
        };
      }
    } else if (llm?.error) {
      reason = llm.error === 'invalid_json' ? 'llm_json_parse_failed' : 'llm_analysis_failed';
      analysis = {
        ...fallbackSupervisorAnalysis(receipts),
        status: llm.error === 'invalid_json' ? 'parse_error' : 'llm_error',
        llm_source: llm.source,
        llm_error: llm.error,
      };
    } else {
      reason = 'llm_not_configured';
      analysis = fallbackSupervisorAnalysis(receipts);
    }
  }

  const recommendationsPath = supervisorRecommendationsPath(root);
  if (execute) {
    fs.mkdirSync(path.dirname(recommendationsPath), { recursive: true });
    fs.writeFileSync(recommendationsPath, JSON.stringify(analysis, null, 2) + '\n', 'utf8');
  }

  const runsDir = path.join(root, 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const receiptPath = path.join(runsDir, `supervisor-tick-${fileSafeStamp()}.json`);
  const receipt = {
    schema: 'atris.supervisor_tick.v1',
    created_at: stampIso(),
    member: name,
    mode,
    executed: execute,
    ok: true,
    advisory_only: true,
    decision: 'supervise',
    reason,
    receipts_scanned: receipts.length,
    logs_bytes: logs.length,
    llm_source: llm?.source || analysis.llm_source || null,
    llm_successful: Boolean(llm?.source && llm?.analysis && analysis.status === 'ok'),
    llm_error: llm?.error || analysis.llm_error || null,
    recommendations_path: path.relative(root, recommendationsPath),
    top_performer_count: analysis.top_performers.length,
    bottleneck_count: analysis.bottlenecks.length,
    recommendation_count: analysis.recommendations.length,
    analysis,
  };
  fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n', 'utf8');
  const logPath = appendMemberGoalLog(paths.memberDir, name, 'Supervisor tick', {
    mode,
    reason,
    receipts: receipts.length,
    llm_source: receipt.llm_source || '',
    llm_error: receipt.llm_error || '',
    recommendations: analysis.recommendations.length,
    receipt: path.relative(root, receiptPath),
    output: path.relative(root, recommendationsPath),
  });

  return {
    ok: true,
    action: 'wake',
    member: name,
    mode,
    decision: 'supervise',
    reason,
    executed: execute,
    needs_user: false,
    ask: null,
    next_command: 'atris member supervisor recommendations',
    receipt_path: receiptPath,
    log_path: logPath,
    recommendations_path: recommendationsPath,
    supervisor: receipt,
  };
}

function memberSupervisorRecommendations(...args) {
  const asJson = hasFlag(args, '--json');
  const recommendationsPath = supervisorRecommendationsPath(process.cwd());
  let payload;
  if (fs.existsSync(recommendationsPath)) {
    try {
      payload = JSON.parse(fs.readFileSync(recommendationsPath, 'utf8'));
    } catch (error) {
      payload = emptySupervisorRecommendations({
        status: 'parse_error',
        llm_error: compactSentence(error instanceof Error ? error.message : String(error), 220),
      });
    }
  } else {
    payload = emptySupervisorRecommendations({ status: 'missing' });
  }
  const lines = payload.status === 'missing'
    ? ['No supervisor recommendations found. Run: atris member wake supervisor --execute']
    : [
        `Supervisor recommendations: ${payload.status}`,
        ...(payload.top_performers || []).slice(0, 5).map((entry) => `Top: ${entry.member} - ${entry.reason}`),
        ...(payload.bottlenecks || []).slice(0, 5).map((entry) => `Bottleneck: ${entry.issue} - ${entry.suggestion}`),
        ...(payload.recommendations || []).slice(0, 5).map((entry) => `Recommendation: ${entry.type} ${entry.from || 'supervisor'} -> ${entry.to || 'coordination'} - ${entry.reason}`),
      ];
  printJsonOrText({ ok: payload.status !== 'missing', action: 'supervisor_recommendations', recommendations_path: recommendationsPath, recommendations: payload }, lines, asJson);
}

function memberSupervisorCommand(command, ...args) {
  if (command === 'recommendations') return memberSupervisorRecommendations(...args);
  console.log('Usage: atris member supervisor recommendations [--json]');
}

function objectiveGeneratorProposalsPath(root = process.cwd()) {
  return path.join(root, 'atris', 'team', 'objective-generator', 'proposals.json');
}

function emptyObjectiveGeneratorProposal(extra = {}) {
  return {
    schema: 'atris.objective_generator_proposals.v1',
    updated_at: stampIso(),
    status: extra.status || 'empty',
    advisory_only: true,
    auto_task_eligible: extra.auto_task_eligible !== false,
    world_model_used: false,
    llm_source: extra.llm_source || null,
    llm_error: extra.llm_error || null,
    proposed_objective: null,
    impact_score: null,
    urgency_score: null,
    alignment_score: null,
    overall_score: null,
    justification: '',
    suggested_member: '',
    suggested_patterns: [],
    created_task: null,
  };
}

function readObjectiveGeneratorWorldModel(root = process.cwd()) {
  const graph = readWikiGraph(root);
  return {
    ...graph,
    entities: Array.isArray(graph.entities) ? graph.entities : [],
    relationships: Array.isArray(graph.relationships) ? graph.relationships : [],
  };
}

function readSupervisorRecommendations(root = process.cwd()) {
  const recommendationsPath = supervisorRecommendationsPath(root);
  if (!fs.existsSync(recommendationsPath)) return emptySupervisorRecommendations({ status: 'missing' });
  try {
    const parsed = JSON.parse(fs.readFileSync(recommendationsPath, 'utf8'));
    return {
      ...emptySupervisorRecommendations({ status: parsed.status || 'ok', llm_source: parsed.llm_source || null, llm_error: parsed.llm_error || null }),
      ...parsed,
      top_performers: Array.isArray(parsed.top_performers) ? parsed.top_performers : [],
      bottlenecks: Array.isArray(parsed.bottlenecks) ? parsed.bottlenecks : [],
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : [],
    };
  } catch (error) {
    return emptySupervisorRecommendations({
      status: 'parse_error',
      llm_error: compactSentence(error instanceof Error ? error.message : String(error), 220),
    });
  }
}

function readTransferPatterns(root = process.cwd()) {
  const patternsPath = path.join(root, 'atris', 'wiki', '.patterns.json');
  if (!fs.existsSync(patternsPath)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(patternsPath, 'utf8'));
    return Array.isArray(parsed.patterns) ? parsed.patterns : [];
  } catch {
    return [];
  }
}

function objectivePatternMatches(patterns, objective, limit = 3) {
  const terms = new Set(String(objective || '').toLowerCase().split(/[^a-z0-9]+/).filter((term) => term.length >= 3));
  return (Array.isArray(patterns) ? patterns : [])
    .map((pattern) => {
      const text = [
        pattern.pattern,
        pattern.from_domain,
        ...(pattern.steps || []),
        ...(pattern.suggested_for || []),
      ].join(' ').toLowerCase();
      let overlap = 0;
      for (const term of terms) if (text.includes(term)) overlap += 1;
      return {
        id: pattern.id || null,
        pattern: compactSentence(pattern.pattern || '', 260),
        from_domain: compactSentence(pattern.from_domain || '', 100),
        transfer_score: Number(pattern.transfer_score) || 0,
        match_score: (Number(pattern.transfer_score) || 0) + overlap * 3,
        reason: overlap > 0 ? `Matched ${overlap} objective term(s)` : 'Highest available reusable pattern',
        source_reason: compactSentence(pattern.reason || '', 320),
        cross_domain_pattern: Boolean(pattern.cross_domain_pattern),
        success_rate: Number(pattern.success_rate) || 0,
        domain_count: Number(pattern.domain_count) || 0,
      };
    })
    .filter((pattern) => pattern.pattern)
    .sort((a, b) => b.match_score - a.match_score || a.pattern.localeCompare(b.pattern))
    .slice(0, limit);
}

function fallbackObjectiveGeneratorProposal(graph, recommendations, transferPatterns = []) {
  const relationships = Array.isArray(graph?.relationships) ? graph.relationships : [];
  const entities = Array.isArray(graph?.entities) ? graph.entities : [];
  const supervisorRecommendation = Array.isArray(recommendations?.recommendations)
    ? recommendations.recommendations.find((entry) => entry?.to)
    : null;
  const topPerformer = Array.isArray(recommendations?.top_performers)
    ? recommendations.top_performers.find((entry) => entry?.member)
    : null;
  const member = compactSentence(
    supervisorRecommendation?.to
      || topPerformer?.member
      || entities.find((entity) => entity?.type === 'system')?.name
      || entities[0]?.name
      || 'project-owner',
    100,
  );
  const relationship = relationships.find((entry) => entry?.from === member || entry?.to === member) || relationships[0] || null;
  const relationTarget = compactSentence(
    relationship?.from === member ? relationship?.to : relationship?.from || relationship?.to || 'world model',
    100,
  );
  const bottleneck = Array.isArray(recommendations?.bottlenecks)
    ? recommendations.bottlenecks.find((entry) => entry?.issue || entry?.suggestion)
    : null;
  const hasProofSignal = [
    supervisorRecommendation?.reason,
    bottleneck?.issue,
    bottleneck?.suggestion,
    relationTarget,
  ].join(' ').toLowerCase().includes('proof');
  const proposedObjective = hasProofSignal && member !== 'project-owner'
    ? `Repair proof routing gaps around ${member} ${relationTarget} handoffs`
    : `Apply ${member} world model evidence to the next proof-ready objective`;
  const proposal = normalizeObjectiveProposal({
    proposed_objective: proposedObjective,
    impact_score: 7,
    urgency_score: 7,
    alignment_score: 7,
    justification: compactSentence(
      supervisorRecommendation?.reason
        || bottleneck?.suggestion
        || `World model links ${member} to ${relationTarget}, so the next objective should convert that signal into proof-ready work.`,
      600,
    ),
    suggested_member: member,
    suggested_patterns: objectivePatternMatches(transferPatterns, proposedObjective),
  }, { status: 'ok', llm_error: 'llm_not_configured', world_model_used: true, auto_task_eligible: false });
  return proposal || emptyObjectiveGeneratorProposal({ status: 'llm_not_configured', llm_error: 'llm_not_configured', auto_task_eligible: false });
}

function objectiveGeneratorPrompt(graph, recommendations, transferPatterns = []) {
  return `Analyze this world model and identify the highest-value problem to solve next.

Consider:
1. What entities/systems have the most dependencies?
2. What relationships are weak or missing?
3. What would have the biggest cross-domain impact?
4. What does the supervisor recommend?
5. Which reusable transfer patterns apply?

Return JSON:
{
  "proposed_objective": "Specific problem to solve",
  "impact_score": 1-10,
  "urgency_score": 1-10,
  "alignment_score": 1-10,
  "justification": "Why this matters",
  "suggested_member": "which member should handle this",
  "suggested_patterns": [{"pattern": "...", "reason": "..."}]
}

World model: ${JSON.stringify(graph)}
Supervisor recommendations: ${JSON.stringify(recommendations)}
Transfer patterns: ${JSON.stringify(transferPatterns.slice(0, 20))}`;
}

function score1to10(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return null;
  return Math.max(1, Math.min(10, Math.round(number)));
}

function normalizeObjectiveProposal(raw, extra = {}) {
  if (!raw || typeof raw !== 'object') return null;
  const impact = score1to10(raw.impact_score);
  const urgency = score1to10(raw.urgency_score);
  const alignment = score1to10(raw.alignment_score);
  const objective = compactSentence(raw.proposed_objective || raw.objective || raw.title || '', 240);
  if (!objective || impact === null || urgency === null || alignment === null) return null;
  const overall = Number(((impact + urgency + alignment) / 3).toFixed(2));
  const suggestedPatterns = (Array.isArray(raw.suggested_patterns) ? raw.suggested_patterns : [])
    .map((pattern) => ({
      pattern: compactSentence(pattern?.pattern || pattern?.name || '', 260),
      reason: compactSentence(pattern?.reason || '', 320),
    }))
    .filter((pattern) => pattern.pattern);
  return {
    ...emptyObjectiveGeneratorProposal(extra),
    status: extra.status || 'ok',
    world_model_used: Boolean(extra.world_model_used),
    proposed_objective: objective,
    impact_score: impact,
    urgency_score: urgency,
    alignment_score: alignment,
    overall_score: overall,
    justification: compactSentence(raw.justification || '', 600),
    suggested_member: compactSentence(raw.suggested_member || '', 100),
    suggested_patterns: suggestedPatterns,
  };
}

function injectedObjectiveGeneratorProposal() {
  if (!process.env.ATRIS_OBJECTIVE_GENERATOR_LLM_JSON) return null;
  const parsed = parseJsonObjectFromText(process.env.ATRIS_OBJECTIVE_GENERATOR_LLM_JSON);
  return parsed
    ? { source: 'env_json', proposal: parsed }
    : { source: 'env_json', error: 'invalid_json' };
}

async function callObjectiveGeneratorLlm(graph, recommendations, transferPatterns = []) {
  const injected = injectedObjectiveGeneratorProposal();
  if (injected) return injected;
  if (process.env.ATRIS_OBJECTIVE_GENERATOR_LLM !== '1') return null;
  try {
    const { postTurn } = require('../ax');
    const output = { isTTY: false, write() { return true; } };
    const result = await postTurn(objectiveGeneratorPrompt(graph, recommendations, transferPatterns), {
      mode: process.env.ATRIS_OBJECTIVE_GENERATOR_LLM_MODE || 'fast',
      route: 'local',
      cwd: process.cwd(),
      output,
      color: false,
    });
    const parsed = parseJsonObjectFromText(result?.output || '');
    return parsed
      ? { source: 'atris2_backend', proposal: parsed }
      : { source: 'atris2_backend', error: 'missing_json_response' };
  } catch (error) {
    return {
      source: 'atris2_backend',
      error: compactSentence(error instanceof Error ? error.message : String(error), 220),
    };
  }
}

function createAutoObjectiveTask(proposal) {
  const title = proposal.proposed_objective || 'Autonomous objective';
  const commandArgs = ['task', 'new', title, '--tag', 'auto-objective', '--json'];
  const command = `atris task new ${shellQuote(title)} --tag auto-objective`;
  try {
    const stdout = execFileSync(process.execPath, [path.join(__dirname, '..', 'bin', 'atris.js'), ...commandArgs], {
      cwd: process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 10000,
      env: process.env,
    });
    const parsed = JSON.parse(stdout || '{}');
    const task = parsed.task || null;
    return {
      ok: parsed.ok !== false,
      command,
      task,
      task_id: parsed.task_id || task?.id || null,
      task_ref: taskRef(task) || parsed.task_id || null,
      raw: parsed,
    };
  } catch (error) {
    return {
      ok: false,
      command,
      error: error instanceof Error ? error.message : String(error),
      stderr: error?.stderr ? compactSentence(String(error.stderr), 500) : null,
    };
  }
}

async function runObjectiveGeneratorWake(name, paths, { execute = false } = {}) {
  const mode = execute ? 'execute' : 'dry_run';
  const root = process.cwd();
  const graph = readObjectiveGeneratorWorldModel(root);
  const recommendations = readSupervisorRecommendations(root);
  const transferPatterns = readTransferPatterns(root);
  const hasWorldModel = graph.entities.length > 0 || graph.relationships.length > 0;
  let llm = null;
  let proposal = null;
  let createdTask = null;
  let reason = execute ? 'objective_proposal_written' : 'objective_proposal_dry_run';

  if (!hasWorldModel) {
    reason = 'insufficient_world_model_data';
    proposal = {
      ...emptyObjectiveGeneratorProposal({ status: 'insufficient_world_model_data' }),
      justification: 'Insufficient world model data: atris/wiki/.graph.json has no entities or relationships.',
    };
  } else {
    llm = await callObjectiveGeneratorLlm(graph, recommendations, transferPatterns);
    if (llm?.proposal) {
      proposal = normalizeObjectiveProposal(llm.proposal, { status: 'ok', llm_source: llm.source, world_model_used: true });
      if (!proposal) {
        reason = 'llm_json_parse_failed';
        proposal = emptyObjectiveGeneratorProposal({ status: 'parse_error', llm_source: llm.source, llm_error: 'invalid_proposal_shape' });
        proposal.world_model_used = true;
      }
    } else if (llm?.error) {
      reason = llm.error === 'invalid_json' ? 'llm_json_parse_failed' : 'llm_analysis_failed';
      proposal = emptyObjectiveGeneratorProposal({ status: llm.error === 'invalid_json' ? 'parse_error' : 'llm_error', llm_source: llm.source, llm_error: llm.error });
      proposal.world_model_used = true;
    } else {
      reason = execute ? 'heuristic_objective_proposal_written' : 'heuristic_objective_proposal_dry_run';
      proposal = fallbackObjectiveGeneratorProposal(graph, recommendations, transferPatterns);
    }
  }

  if (proposal?.status === 'ok' && (!Array.isArray(proposal.suggested_patterns) || !proposal.suggested_patterns.length)) {
    proposal.suggested_patterns = objectivePatternMatches(transferPatterns, proposal.proposed_objective);
  }

  if (execute && proposal?.status === 'ok' && proposal.auto_task_eligible !== false && Number(proposal.overall_score) > 7) {
    createdTask = createAutoObjectiveTask(proposal);
    proposal.created_task = createdTask.ok ? {
      id: createdTask.task_id || null,
      ref: createdTask.task_ref || null,
      title: createdTask.task?.title || proposal.proposed_objective,
      tag: createdTask.task?.tag || 'auto-objective',
      command: createdTask.command,
    } : {
      ok: false,
      command: createdTask.command,
      error: createdTask.error || createdTask.stderr || 'task_create_failed',
    };
  }

  const proposalsPath = objectiveGeneratorProposalsPath(root);
  const proposalsWritten = Boolean(execute);
  if (proposalsWritten) {
    fs.mkdirSync(path.dirname(proposalsPath), { recursive: true });
    fs.writeFileSync(proposalsPath, JSON.stringify(proposal, null, 2) + '\n', 'utf8');
  }

  const runsDir = path.join(root, 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const receiptPath = path.join(runsDir, `objective-generator-tick-${fileSafeStamp()}.json`);
  const receipt = {
    schema: 'atris.objective_generator_tick.v1',
    created_at: stampIso(),
    member: name,
    mode,
    executed: execute,
    ok: true,
    advisory_only: true,
    decision: 'generate_objective',
    reason,
    world_model_path: path.relative(root, wikiMinerGraphPath(root)),
    world_model_used: proposal.world_model_used,
    world_model_entities: graph.entities.length,
    world_model_relationships: graph.relationships.length,
    supervisor_recommendations_path: path.relative(root, supervisorRecommendationsPath(root)),
    supervisor_recommendation_count: Array.isArray(recommendations.recommendations) ? recommendations.recommendations.length : 0,
    transfer_patterns_path: path.relative(root, path.join(root, 'atris', 'wiki', '.patterns.json')),
    transfer_pattern_count: transferPatterns.length,
    llm_source: llm?.source || proposal.llm_source || null,
    llm_successful: Boolean(llm?.source && llm?.proposal && proposal.status === 'ok'),
    llm_error: llm?.error || proposal.llm_error || null,
    proposals_path: path.relative(root, proposalsPath),
    proposals_written: proposalsWritten,
    task_creation_threshold: 7,
    task_created: Boolean(createdTask?.ok),
    created_task: proposal.created_task,
    proposal,
  };
  fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n', 'utf8');
  const logPath = appendMemberGoalLog(paths.memberDir, name, 'Objective generator tick', {
    mode,
    reason,
    world_entities: graph.entities.length,
    world_relationships: graph.relationships.length,
    llm_source: receipt.llm_source || '',
    llm_error: receipt.llm_error || '',
    objective: proposal.proposed_objective || '',
    score: proposal.overall_score || '',
    task: proposal.created_task?.ref || '',
    receipt: path.relative(root, receiptPath),
    output: proposalsWritten ? path.relative(root, proposalsPath) : '',
  });

  return {
    ok: true,
    action: 'wake',
    member: name,
    mode,
    decision: 'generate_objective',
    reason,
    executed: execute,
    needs_user: false,
    ask: null,
    next_command: 'atris member objective-generator proposals',
    receipt_path: receiptPath,
    log_path: logPath,
    proposals_path: proposalsPath,
    objective_generator: receipt,
  };
}

function memberObjectiveGeneratorProposals(...args) {
  const asJson = hasFlag(args, '--json');
  const proposalsPath = objectiveGeneratorProposalsPath(process.cwd());
  let payload;
  if (fs.existsSync(proposalsPath)) {
    try {
      payload = JSON.parse(fs.readFileSync(proposalsPath, 'utf8'));
    } catch (error) {
      payload = emptyObjectiveGeneratorProposal({
        status: 'parse_error',
        llm_error: compactSentence(error instanceof Error ? error.message : String(error), 220),
      });
    }
  } else {
    payload = emptyObjectiveGeneratorProposal({ status: 'missing' });
  }
  const lines = payload.status === 'missing'
    ? ['No objective-generator proposals found. Run: atris member wake objective-generator --execute']
    : [
        `Objective proposal: ${payload.status}`,
        payload.proposed_objective ? `Objective: ${payload.proposed_objective}` : '',
        Number.isFinite(Number(payload.overall_score)) ? `Score: ${payload.overall_score} (impact ${payload.impact_score}, urgency ${payload.urgency_score}, alignment ${payload.alignment_score})` : '',
        payload.suggested_member ? `Suggested member: ${payload.suggested_member}` : '',
        Array.isArray(payload.suggested_patterns) && payload.suggested_patterns.length ? `Pattern: ${payload.suggested_patterns[0].pattern}` : '',
        payload.justification ? `Why: ${payload.justification}` : '',
        payload.created_task?.ref ? `Task: ${payload.created_task.ref}` : '',
      ].filter(Boolean);
  printJsonOrText({ ok: payload.status !== 'missing', action: 'objective_generator_proposals', proposals_path: proposalsPath, proposal: payload }, lines, asJson);
}

function memberObjectiveGeneratorCommand(command, ...args) {
  if (command === 'proposals') return memberObjectiveGeneratorProposals(...args);
  console.log('Usage: atris member objective-generator proposals [--json]');
}

const GENERALIST_CAPABILITIES = [
  'autonomous_problem_discovery',
  'world_model',
  'meta_cognition',
  'objective_setting',
  'causal_reasoning',
  'transfer_learning',
  'architecture_self_improvement',
  'emergent_capability_discovery',
];

function generalistProofsDir(root = process.cwd()) {
  return path.join(root, 'atris', 'team', 'generalist', 'proofs');
}

function generalistLatestProofPath(root = process.cwd()) {
  return path.join(generalistProofsDir(root), 'latest.json');
}

function crossDomainPatternsPath(root = process.cwd()) {
  return path.join(root, 'atris', 'wiki', '.cross_domain_patterns.json');
}

function generalistDomainSlug(value) {
  const slug = String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 72);
  return slug || `domain-${slugHash(value)}`;
}

function crossDomainPatternKey(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function emptyCrossDomainPatternLibrary(extra = {}) {
  return {
    schema: 'atris.cross_domain_patterns.v1',
    updated_at: stampIso(),
    status: extra.status || 'empty',
    domains: [],
    patterns: [],
    metrics: {
      domains_solved_count: 0,
      pattern_count: 0,
      cross_domain_pattern_count: 0,
      total_runs: 0,
      successful_runs: 0,
      pattern_observations: 0,
      reused_pattern_observations: 0,
      pattern_reuse_rate: 0,
      cross_domain_applications: 0,
      cross_domain_successes: 0,
      cross_domain_success_rate: 0,
      average_pattern_success_rate: 0,
    },
    recent_runs: [],
  };
}

function normalizeCrossDomainPatternLibrary(raw) {
  const library = { ...emptyCrossDomainPatternLibrary(), ...(raw && typeof raw === 'object' ? raw : {}) };
  library.domains = (Array.isArray(library.domains) ? library.domains : [])
    .map((domain) => ({
      name: compactSentence(domain?.name || '', 120),
      first_seen_at: domain?.first_seen_at || null,
      last_seen_at: domain?.last_seen_at || null,
      runs: Number(domain?.runs) || 0,
      successes: Number(domain?.successes) || 0,
      proof_paths: Array.isArray(domain?.proof_paths) ? domain.proof_paths.filter(Boolean).slice(-10) : [],
      receipt_paths: Array.isArray(domain?.receipt_paths) ? domain.receipt_paths.filter(Boolean).slice(-10) : [],
      last_objective: compactSentence(domain?.last_objective || '', 260),
    }))
    .filter((domain) => domain.name);
  library.patterns = (Array.isArray(library.patterns) ? library.patterns : [])
    .map((pattern) => {
      const text = compactSentence(pattern?.pattern || pattern?.source_pattern || '', 260);
      const key = crossDomainPatternKey(pattern?.key || text);
      const uses = Math.max(0, Number(pattern?.uses) || 0);
      const successes = Math.max(0, Number(pattern?.successes) || 0);
      const domains = [...new Set((Array.isArray(pattern?.domains) ? pattern.domains : []).map((domain) => compactSentence(domain, 120)).filter(Boolean))].sort();
      const successRate = uses > 0 ? Number((successes / uses).toFixed(4)) : 0;
      const domainCount = domains.length;
      return {
        id: pattern?.id || `cross-domain:${slugHash(key || text)}`,
        key,
        pattern: text,
        first_seen_at: pattern?.first_seen_at || null,
        last_seen_at: pattern?.last_seen_at || null,
        last_reused_at: pattern?.last_reused_at || null,
        domains,
        domain_count: domainCount,
        uses,
        successes,
        success_rate: successRate,
        score: Number((successRate * 10 + Math.min(5, domainCount) * 2).toFixed(2)),
        evidence: Array.isArray(pattern?.evidence) ? pattern.evidence.slice(-20) : [],
      };
    })
    .filter((pattern) => pattern.pattern && pattern.key);
  library.recent_runs = Array.isArray(library.recent_runs) ? library.recent_runs.slice(-20) : [];
  library.metrics = { ...emptyCrossDomainPatternLibrary().metrics, ...(library.metrics && typeof library.metrics === 'object' ? library.metrics : {}) };
  library.status = library.patterns.length ? 'ok' : library.status || 'empty';
  return library;
}

function readCrossDomainPatternLibrary(root = process.cwd()) {
  const libraryPath = crossDomainPatternsPath(root);
  if (!fs.existsSync(libraryPath)) return emptyCrossDomainPatternLibrary({ status: 'missing' });
  try {
    return normalizeCrossDomainPatternLibrary(JSON.parse(fs.readFileSync(libraryPath, 'utf8')));
  } catch (error) {
    return {
      ...emptyCrossDomainPatternLibrary({ status: 'parse_error' }),
      error: compactSentence(error instanceof Error ? error.message : String(error), 220),
    };
  }
}

function crossDomainPatternText(pattern) {
  return compactSentence(pattern?.source_pattern || pattern?.pattern || pattern?.name || pattern?.application || '', 260);
}

function crossDomainPatternMatches(library, domainName = '', objectiveOrDescription = '', limit = 3) {
  const domainKey = lowerCompact(domainName);
  const terms = new Set(String(`${domainName} ${objectiveOrDescription}`)
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((term) => term.length >= 4));
  return (Array.isArray(library?.patterns) ? library.patterns : [])
    .map((pattern) => {
      const text = [pattern.pattern, ...(pattern.domains || [])].join(' ').toLowerCase();
      let overlap = 0;
      for (const term of terms) if (text.includes(term)) overlap += 1;
      const seenInSameDomain = (pattern.domains || []).some((domain) => lowerCompact(domain) === domainKey);
      const crossDomainBonus = seenInSameDomain ? 0 : 6;
      const matchScore = (Number(pattern.score) || 0)
        + (Number(pattern.success_rate) || 0) * 10
        + (Number(pattern.domain_count) || 0) * 3
        + overlap * 2
        + crossDomainBonus;
      return {
        ...pattern,
        match_score: Number(matchScore.toFixed(2)),
        seen_in_same_domain: seenInSameDomain,
        reason: seenInSameDomain
          ? 'Pattern already seen in this domain'
          : `Reusable pattern from ${Math.max(1, Number(pattern.domain_count) || 0)} prior domain(s)`,
      };
    })
    .filter((pattern) => pattern.pattern)
    .sort((a, b) => b.match_score - a.match_score || b.success_rate - a.success_rate || a.pattern.localeCompare(b.pattern))
    .slice(0, limit);
}

function crossDomainPatternInputs(libraryMatches = [], transferPatterns = []) {
  const fromLibrary = (Array.isArray(libraryMatches) ? libraryMatches : []).map((pattern) => ({
    id: pattern.id,
    pattern: pattern.pattern,
    from_domain: (pattern.domains || []).join(', '),
    transfer_score: pattern.match_score || pattern.score || 0,
    success_rate: pattern.success_rate,
    domain_count: pattern.domain_count,
    cross_domain_pattern: true,
    suggested_for: ['generalist'],
    reason: pattern.reason,
  }));
  return [...fromLibrary, ...(Array.isArray(transferPatterns) ? transferPatterns : [])];
}

function recomputeCrossDomainPatternMetrics(library, beforeMetrics = {}, delta = {}) {
  const patterns = Array.isArray(library.patterns) ? library.patterns : [];
  const domains = Array.isArray(library.domains) ? library.domains : [];
  const totalRuns = (Number(beforeMetrics.total_runs) || 0) + (Number(delta.runs) || 0);
  const successfulRuns = (Number(beforeMetrics.successful_runs) || 0) + (Number(delta.successes) || 0);
  const patternObservations = (Number(beforeMetrics.pattern_observations) || 0) + (Number(delta.pattern_observations) || 0);
  const reusedPatternObservations = (Number(beforeMetrics.reused_pattern_observations) || 0) + (Number(delta.reused_pattern_observations) || 0);
  const crossDomainApplications = (Number(beforeMetrics.cross_domain_applications) || 0) + (Number(delta.cross_domain_applications) || 0);
  const crossDomainSuccesses = (Number(beforeMetrics.cross_domain_successes) || 0) + (Number(delta.cross_domain_successes) || 0);
  const averagePatternSuccessRate = patterns.length
    ? Number((patterns.reduce((sum, pattern) => sum + (Number(pattern.success_rate) || 0), 0) / patterns.length).toFixed(4))
    : 0;
  return {
    domains_solved_count: domains.length,
    pattern_count: patterns.length,
    cross_domain_pattern_count: patterns.filter((pattern) => Number(pattern.domain_count) > 1).length,
    total_runs: totalRuns,
    successful_runs: successfulRuns,
    pattern_observations: patternObservations,
    reused_pattern_observations: reusedPatternObservations,
    pattern_reuse_rate: patternObservations > 0 ? Number((reusedPatternObservations / patternObservations).toFixed(4)) : 0,
    cross_domain_applications: crossDomainApplications,
    cross_domain_successes: crossDomainSuccesses,
    cross_domain_success_rate: crossDomainApplications > 0 ? Number((crossDomainSuccesses / crossDomainApplications).toFixed(4)) : 0,
    average_pattern_success_rate: averagePatternSuccessRate,
  };
}

function learnCrossDomainPatterns(root, proof, { execute = false, record = true, libraryBefore = null, receiptPath = null, proofPath = null } = {}) {
  const before = normalizeCrossDomainPatternLibrary(libraryBefore || readCrossDomainPatternLibrary(root));
  if (!record) {
    return {
      library_path: crossDomainPatternsPath(root),
      executed: false,
      before_metrics: before.metrics,
      after_metrics: before.metrics,
      run: {
        at: stampIso(),
        domain: compactSentence(proof?.domain?.name || 'external domain', 120),
        status: proof?.status || 'unknown',
        skipped: true,
        reason: 'proof_not_successful',
      },
      reused_pattern_count: 0,
      reused_patterns: [],
      observed_pattern_count: 0,
      learning_improved: false,
    };
  }
  const library = normalizeCrossDomainPatternLibrary(JSON.parse(JSON.stringify(before)));
  const beforeMetrics = { ...before.metrics };
  const now = stampIso();
  const domainName = compactSentence(proof?.domain?.name || 'external domain', 120);
  const objective = proof?.objectives?.[0] || null;
  const proofPathRel = proofPath ? path.relative(root, proofPath) : null;
  const receiptPathRel = receiptPath ? path.relative(root, receiptPath) : null;
  const successful = proof?.status === 'ok';
  const existingPatternKeys = new Set((before.patterns || []).map((pattern) => pattern.key));
  const transferPatterns = (Array.isArray(proof?.transfer_patterns) ? proof.transfer_patterns : [])
    .map((pattern) => ({
      ...pattern,
      pattern_text: crossDomainPatternText(pattern),
    }))
    .filter((pattern) => pattern.pattern_text);
  let reusedPatternCount = 0;
  const reusedPatterns = [];

  let domainEntry = library.domains.find((domain) => lowerCompact(domain.name) === lowerCompact(domainName));
  if (!domainEntry) {
    domainEntry = {
      name: domainName,
      first_seen_at: now,
      last_seen_at: now,
      runs: 0,
      successes: 0,
      proof_paths: [],
      receipt_paths: [],
      last_objective: '',
    };
    library.domains.push(domainEntry);
  }
  domainEntry.last_seen_at = now;
  domainEntry.runs += 1;
  if (successful) domainEntry.successes += 1;
  if (proofPathRel && !domainEntry.proof_paths.includes(proofPathRel)) domainEntry.proof_paths.push(proofPathRel);
  if (receiptPathRel && !domainEntry.receipt_paths.includes(receiptPathRel)) domainEntry.receipt_paths.push(receiptPathRel);
  domainEntry.proof_paths = domainEntry.proof_paths.slice(-10);
  domainEntry.receipt_paths = domainEntry.receipt_paths.slice(-10);
  domainEntry.last_objective = objective?.objective || '';

  for (const transferPattern of transferPatterns) {
    const key = crossDomainPatternKey(transferPattern.pattern_text);
    const existedBefore = existingPatternKeys.has(key);
    let patternEntry = library.patterns.find((pattern) => pattern.key === key);
    if (!patternEntry) {
      patternEntry = {
        id: `cross-domain:${slugHash(key)}`,
        key,
        pattern: transferPattern.pattern_text,
        first_seen_at: now,
        last_seen_at: now,
        last_reused_at: null,
        domains: [],
        domain_count: 0,
        uses: 0,
        successes: 0,
        success_rate: 0,
        score: 0,
        evidence: [],
      };
      library.patterns.push(patternEntry);
    }
    if (existedBefore) {
      reusedPatternCount += 1;
      patternEntry.last_reused_at = now;
      reusedPatterns.push({
        id: patternEntry.id,
        pattern: patternEntry.pattern,
        domains_before: before.patterns.find((pattern) => pattern.key === key)?.domains || [],
        success_rate_before: before.patterns.find((pattern) => pattern.key === key)?.success_rate || 0,
      });
    }
    patternEntry.last_seen_at = now;
    if (!patternEntry.domains.includes(domainName)) patternEntry.domains.push(domainName);
    patternEntry.domains.sort();
    patternEntry.domain_count = patternEntry.domains.length;
    patternEntry.uses += 1;
    if (successful) patternEntry.successes += 1;
    patternEntry.success_rate = patternEntry.uses > 0 ? Number((patternEntry.successes / patternEntry.uses).toFixed(4)) : 0;
    patternEntry.score = Number((patternEntry.success_rate * 10 + Math.min(5, patternEntry.domain_count) * 2).toFixed(2));
    const evidenceKey = `${domainName}|${receiptPathRel || ''}|${proofPathRel || ''}`;
    if (!patternEntry.evidence.some((entry) => entry.evidence_key === evidenceKey)) {
      patternEntry.evidence.push({
        evidence_key: evidenceKey,
        domain: domainName,
        status: proof?.status || 'unknown',
        proof_path: proofPathRel,
        receipt_path: receiptPathRel,
        objective: objective?.objective || '',
        objective_score: objective?.overall_score || null,
        application: compactSentence(transferPattern.application || '', 420),
        reason: compactSentence(transferPattern.reason || '', 320),
        observed_at: now,
      });
    }
    patternEntry.evidence = patternEntry.evidence.slice(-20);
  }

  library.domains.sort((a, b) => a.name.localeCompare(b.name));
  library.patterns.sort((a, b) => b.score - a.score || b.domain_count - a.domain_count || a.pattern.localeCompare(b.pattern));
  const delta = {
    runs: 1,
    successes: successful ? 1 : 0,
    pattern_observations: transferPatterns.length,
    reused_pattern_observations: reusedPatternCount,
    cross_domain_applications: reusedPatternCount,
    cross_domain_successes: successful ? reusedPatternCount : 0,
  };
  library.metrics = recomputeCrossDomainPatternMetrics(library, beforeMetrics, delta);
  library.updated_at = now;
  library.status = 'ok';
  const afterMetrics = library.metrics;
  const learningImproved = afterMetrics.cross_domain_pattern_count > (Number(beforeMetrics.cross_domain_pattern_count) || 0)
    || afterMetrics.pattern_reuse_rate > (Number(beforeMetrics.pattern_reuse_rate) || 0)
    || afterMetrics.cross_domain_success_rate > (Number(beforeMetrics.cross_domain_success_rate) || 0);
  const runSummary = {
    at: now,
    domain: domainName,
    status: proof?.status || 'unknown',
    proof_path: proofPathRel,
    receipt_path: receiptPathRel,
    pattern_observations: transferPatterns.length,
    reused_pattern_count: reusedPatternCount,
    domains_solved_before: Number(beforeMetrics.domains_solved_count) || before.domains.length || 0,
    domains_solved_after: afterMetrics.domains_solved_count,
    pattern_count_before: Number(beforeMetrics.pattern_count) || before.patterns.length || 0,
    pattern_count_after: afterMetrics.pattern_count,
    pattern_reuse_rate_before: Number(beforeMetrics.pattern_reuse_rate) || 0,
    pattern_reuse_rate_after: afterMetrics.pattern_reuse_rate,
    cross_domain_success_rate_before: Number(beforeMetrics.cross_domain_success_rate) || 0,
    cross_domain_success_rate_after: afterMetrics.cross_domain_success_rate,
    learning_improved: learningImproved,
  };
  library.recent_runs = [...(library.recent_runs || []), runSummary].slice(-20);

  if (execute) {
    const libraryPath = crossDomainPatternsPath(root);
    fs.mkdirSync(path.dirname(libraryPath), { recursive: true });
    fs.writeFileSync(libraryPath, JSON.stringify(library, null, 2) + '\n', 'utf8');
  }

  return {
    library_path: crossDomainPatternsPath(root),
    executed: execute,
    before_metrics: beforeMetrics,
    after_metrics: afterMetrics,
    run: runSummary,
    reused_pattern_count: reusedPatternCount,
    reused_patterns: reusedPatterns,
    observed_pattern_count: transferPatterns.length,
    learning_improved: learningImproved,
  };
}

function resolveGeneralistDomainInput(root, domainInput = {}) {
  const fileFlag = domainInput.file || process.env.ATRIS_GENERALIST_DOMAIN_FILE || '';
  const textFlag = domainInput.text || process.env.ATRIS_GENERALIST_DOMAIN || '';
  const nameFlag = domainInput.name || process.env.ATRIS_GENERALIST_DOMAIN_NAME || '';
  let description = '';
  let source = 'missing';
  let sourcePath = null;
  let error = null;

  if (fileFlag) {
    const fullPath = path.isAbsolute(fileFlag) ? fileFlag : path.join(root, fileFlag);
    sourcePath = fullPath;
    try {
      description = fs.readFileSync(fullPath, 'utf8');
      source = 'file';
    } catch (readError) {
      error = compactSentence(readError instanceof Error ? readError.message : String(readError), 220);
    }
  }

  if (!description && textFlag) {
    description = textFlag;
    source = 'flag_text';
  }

  const heading = String(description).match(/^#\s+(.+)$/m)?.[1] || '';
  const domainLine = String(description).match(/^\s*(?:domain|context)\s*:\s*(.+)$/im)?.[1] || '';
  const firstLine = firstUsefulLine(description);
  const name = compactSentence(nameFlag || domainLine || heading || firstLine || 'external domain', 120);

  return {
    ok: Boolean(description.trim()),
    name,
    slug: generalistDomainSlug(name),
    description,
    description_excerpt: compactSentence(description, 800),
    source,
    source_path: sourcePath ? path.relative(root, sourcePath) : null,
    error: description.trim() ? null : (error || 'missing_domain_input'),
  };
}

function generalistDomainsDir(root = process.cwd()) {
  return path.join(root, 'atris', 'team', 'generalist', 'domains');
}

function normalizeRelativeProofPath(root, value) {
  if (!value) return '';
  const fullPath = path.isAbsolute(value) ? value : path.join(root, value);
  return path.relative(root, path.normalize(fullPath)).split(path.sep).join('/');
}

function listGeneralistDomainFiles(root = process.cwd()) {
  const domainsDir = generalistDomainsDir(root);
  if (!fs.existsSync(domainsDir)) return [];
  return fs.readdirSync(domainsDir)
    .filter((entry) => !entry.startsWith('.') && /\.(md|markdown|txt|json)$/i.test(entry))
    .map((entry) => {
      const fullPath = path.join(domainsDir, entry);
      try {
        const stat = fs.statSync(fullPath);
        if (!stat.isFile()) return null;
        return {
          full_path: fullPath,
          path: normalizeRelativeProofPath(root, fullPath),
          mtime_ms: stat.mtimeMs,
        };
      } catch {
        return null;
      }
    })
    .filter(Boolean)
    .sort((a, b) => a.path.localeCompare(b.path));
}

function readGeneralistProofIndex(root = process.cwd()) {
  const proofsDir = generalistProofsDir(root);
  const bySourcePath = new Map();
  if (!fs.existsSync(proofsDir)) return bySourcePath;
  for (const entry of fs.readdirSync(proofsDir)) {
    if (!entry.endsWith('.json')) continue;
    const proofPath = path.join(proofsDir, entry);
    try {
      const stat = fs.statSync(proofPath);
      if (!stat.isFile()) continue;
      const proof = JSON.parse(fs.readFileSync(proofPath, 'utf8'));
      const sourcePath = normalizeRelativeProofPath(root, proof?.domain?.source_path || proof?.source_path || '');
      if (!sourcePath) continue;
      const processedAt = Date.parse(proof.updated_at || proof.created_at || proof.generated_at || '') || stat.mtimeMs;
      const existing = bySourcePath.get(sourcePath);
      if (!existing || processedAt > existing.processed_at_ms) {
        bySourcePath.set(sourcePath, {
          source_path: sourcePath,
          processed_at_ms: processedAt,
          processed_at: new Date(processedAt).toISOString(),
          proof_path: normalizeRelativeProofPath(root, proofPath),
        });
      }
    } catch {
      // Ignore malformed proof files; the scanner will simply treat the domain as due.
    }
  }
  return bySourcePath;
}

function findUnprocessedGeneralistDomainFile(root = process.cwd(), { windowMs = 60 * 60 * 1000, nowMs = Date.now() } = {}) {
  const files = listGeneralistDomainFiles(root);
  if (!files.length) return null;
  const proofIndex = readGeneralistProofIndex(root);
  const cutoff = nowMs - windowMs;
  return files
    .map((file) => {
      const lastProof = proofIndex.get(file.path) || null;
      return {
        ...file,
        status: lastProof ? 'stale' : 'new',
        last_processed_at: lastProof?.processed_at || null,
        last_proof_path: lastProof?.proof_path || null,
        due: !lastProof || lastProof.processed_at_ms < cutoff,
      };
    })
    .filter((file) => file.due)
    .sort((a, b) => {
      if (a.status !== b.status) return a.status === 'new' ? -1 : 1;
      return b.mtime_ms - a.mtime_ms || a.path.localeCompare(b.path);
    })[0] || null;
}

function emptyGeneralistProof(extra = {}) {
  return {
    schema: 'atris.generalist_domain_proof.v1',
    updated_at: stampIso(),
    status: extra.status || 'empty',
    domain: {
      name: extra.domain_name || 'external domain',
      source: extra.domain_source || null,
      source_path: extra.domain_source_path || null,
      description_excerpt: extra.description_excerpt || '',
    },
    domain_agnostic: true,
    atris_specific_code_required: false,
    capabilities_used: GENERALIST_CAPABILITIES,
    llm_source: extra.llm_source || null,
    llm_error: extra.llm_error || null,
    world_model: {
      entities: [],
      relationships: [],
    },
    problems: [],
    objectives: [],
    causal_patterns: [],
    transfer_patterns: [],
    solution_plan: [],
    meta_cognition: {
      assumptions: [],
      risks: [],
      missing_data: [],
    },
    architecture_improvement: '',
    emergent_capability: '',
    proof: '',
  };
}

function normalizeGeneralistEntity(entity) {
  const name = compactSentence(entity?.name || entity?.entity || entity, 120);
  if (!name) return null;
  const type = compactSentence(String(entity?.type || 'concept').toLowerCase(), 40).replace(/[^a-z0-9_-]/g, '-') || 'concept';
  return { type, name };
}

function normalizeGeneralistRelationship(relationship) {
  const from = compactSentence(relationship?.from || relationship?.source || '', 120);
  const to = compactSentence(relationship?.to || relationship?.target || '', 120);
  if (!from || !to) return null;
  const type = compactSentence(String(relationship?.type || relationship?.relationship || 'affects').toLowerCase(), 60).replace(/[^a-z0-9_-]/g, '-') || 'affects';
  return { from, to, type };
}

function normalizeGeneralistAnalysis(raw, extra = {}) {
  if (!raw || typeof raw !== 'object') return null;
  const proof = emptyGeneralistProof(extra);
  const worldModel = raw.world_model && typeof raw.world_model === 'object' ? raw.world_model : raw;
  const domainName = compactSentence(raw.domain?.name || raw.domain_name || extra.domain_name || proof.domain.name, 120);
  proof.status = extra.status || raw.status || 'ok';
  proof.domain = {
    name: domainName,
    source: extra.domain_source || proof.domain.source,
    source_path: extra.domain_source_path || proof.domain.source_path,
    description_excerpt: compactSentence(raw.domain?.summary || raw.domain_summary || extra.description_excerpt || proof.domain.description_excerpt, 800),
  };
  proof.llm_source = extra.llm_source || raw.llm_source || null;
  proof.llm_error = extra.llm_error || raw.llm_error || null;

  const entities = (Array.isArray(worldModel.entities) ? worldModel.entities : [])
    .map(normalizeGeneralistEntity)
    .filter(Boolean);
  const relationships = (Array.isArray(worldModel.relationships) ? worldModel.relationships : [])
    .map(normalizeGeneralistRelationship)
    .filter(Boolean);
  proof.world_model = { entities, relationships };

  proof.problems = (Array.isArray(raw.problems) ? raw.problems : [])
    .map((problem) => ({
      problem: compactSentence(problem?.problem || problem?.name || problem?.title || '', 240),
      evidence: compactSentence(problem?.evidence || problem?.reason || '', 420),
      impact_score: score1to10(problem?.impact_score || problem?.score) || 7,
    }))
    .filter((problem) => problem.problem);

  const rawObjectives = Array.isArray(raw.objectives) ? raw.objectives : [];
  if (raw.proposed_objective || raw.objective) rawObjectives.unshift(raw);
  proof.objectives = rawObjectives
    .map((objective) => {
      const impact = score1to10(objective?.impact_score) || 7;
      const urgency = score1to10(objective?.urgency_score) || 7;
      const alignment = score1to10(objective?.alignment_score) || 7;
      return {
        objective: compactSentence(objective?.objective || objective?.proposed_objective || objective?.title || '', 260),
        impact_score: impact,
        urgency_score: urgency,
        alignment_score: alignment,
        overall_score: Number(((impact + urgency + alignment) / 3).toFixed(2)),
        justification: compactSentence(objective?.justification || objective?.reason || '', 520),
        suggested_owner: compactSentence(objective?.suggested_owner || objective?.suggested_member || '', 100),
      };
    })
    .filter((objective) => objective.objective);

  proof.causal_patterns = (Array.isArray(raw.causal_patterns) ? raw.causal_patterns : [])
    .map((pattern) => ({
      action: compactSentence(pattern?.action || pattern?.cause || '', 220),
      outcome: compactSentence(pattern?.outcome || pattern?.effect || '', 260),
      confidence: score1to10(pattern?.confidence) || 6,
      counterevidence: compactSentence(pattern?.counterevidence || '', 260),
    }))
    .filter((pattern) => pattern.action && pattern.outcome);

  proof.transfer_patterns = (Array.isArray(raw.transfer_patterns) ? raw.transfer_patterns : [])
    .map((pattern) => ({
      source_pattern: compactSentence(pattern?.source_pattern || pattern?.pattern || pattern?.name || '', 260),
      application: compactSentence(pattern?.application || pattern?.target_application || '', 420),
      reason: compactSentence(pattern?.reason || '', 320),
    }))
    .filter((pattern) => pattern.source_pattern || pattern.application);

  proof.solution_plan = (Array.isArray(raw.solution_plan) ? raw.solution_plan : [])
    .map((step, index) => ({
      step: compactSentence(step?.step || step?.action || step, 260),
      owner: compactSentence(step?.owner || step?.role || '', 120),
      expected_outcome: compactSentence(step?.expected_outcome || step?.outcome || '', 300),
      order: Number.isFinite(Number(step?.order)) ? Number(step.order) : index + 1,
    }))
    .filter((step) => step.step);

  const meta = raw.meta_cognition && typeof raw.meta_cognition === 'object' ? raw.meta_cognition : {};
  proof.meta_cognition = {
    assumptions: (Array.isArray(meta.assumptions) ? meta.assumptions : []).map((item) => compactSentence(item, 240)).filter(Boolean),
    risks: (Array.isArray(meta.risks) ? meta.risks : []).map((item) => compactSentence(item, 240)).filter(Boolean),
    missing_data: (Array.isArray(meta.missing_data) ? meta.missing_data : []).map((item) => compactSentence(item, 240)).filter(Boolean),
  };
  proof.architecture_improvement = compactSentence(raw.architecture_improvement || '', 500);
  proof.emergent_capability = compactSentence(raw.emergent_capability || raw.emergent_capability_discovery || '', 500);
  proof.proof = compactSentence(raw.proof || '', 700);

  if (!proof.world_model.entities.length || !proof.world_model.relationships.length || !proof.objectives.length) return null;
  return proof;
}

function generalistReusablePatterns(transferPatterns = [], domainName = '', objective = '') {
  const nonProjectPatterns = (Array.isArray(transferPatterns) ? transferPatterns : [])
    .filter((pattern) => pattern?.cross_domain_pattern || !/\batris\b|signal-scout|obelisk|wiki-miner|objective-generator/i.test(JSON.stringify(pattern || {})));
  const matches = objectivePatternMatches(nonProjectPatterns, `${domainName} ${objective}`, 3)
    .map((pattern) => ({
      source_pattern: pattern.pattern || pattern.source_pattern,
      application: `Apply to ${domainName} by turning the bottleneck into a small measured intervention.`,
      reason: pattern.cross_domain_pattern
        ? `Reused cross-domain pattern with success rate ${Number(pattern.success_rate || 0).toFixed(2)} across ${pattern.domain_count || 1} domain(s).`
        : pattern.reason || 'Reusable pattern matched the domain objective.',
      pattern_id: pattern.id || null,
    }));
  if (matches.length) return matches;
  return [{
    source_pattern: 'bottleneck signal -> small controlled intervention -> outcome receipt -> next objective',
    application: `Apply to ${domainName} by measuring one operational bottleneck, changing one lever, and reviewing the outcome before scaling.`,
    reason: 'Generic transfer pattern applies across operational domains without project-specific assumptions.',
  }];
}

function fallbackGeneralistAnalysis(domain, transferPatterns = []) {
  const text = String(domain.description || '');
  const isRestaurant = /restaurant|kitchen|dining|reservation|table|menu|server|host|guest|chef/i.test(text);
  const domainName = domain.name || (isRestaurant ? 'restaurant operations' : 'external domain');
  const customerName = isRestaurant ? 'guests' : 'customers';
  const frontRole = isRestaurant ? 'front-of-house staff' : 'operators';
  const deliveryRole = isRestaurant ? 'kitchen staff' : 'delivery team';
  const intakeFlow = isRestaurant ? 'reservation and seating flow' : 'intake flow';
  const throughputFlow = isRestaurant ? 'table turnover and order throughput' : 'service throughput';
  const capacityResource = isRestaurant ? 'tables, prep capacity, and inventory' : 'available capacity';
  const qualityMetric = isRestaurant ? 'peak wait time and guest satisfaction' : 'lead time and customer satisfaction';
  const objective = isRestaurant
    ? 'Reduce peak-service wait time by aligning reservations, seating, kitchen capacity, and staffing to demand'
    : `Reduce the main ${domainName} service bottleneck by aligning demand, capacity, and feedback loops`;

  const transferMatches = generalistReusablePatterns(transferPatterns, domainName, objective);
  return normalizeGeneralistAnalysis({
    domain: {
      name: domainName,
      summary: domain.description_excerpt,
    },
    world_model: {
      entities: [
        { type: 'system', name: domainName },
        { type: 'role', name: frontRole },
        { type: 'role', name: deliveryRole },
        { type: 'customer', name: customerName },
        { type: 'process', name: intakeFlow },
        { type: 'process', name: throughputFlow },
        { type: 'resource', name: capacityResource },
        { type: 'metric', name: qualityMetric },
      ],
      relationships: [
        { from: frontRole, to: intakeFlow, type: 'owns' },
        { from: intakeFlow, to: throughputFlow, type: 'depends-on' },
        { from: deliveryRole, to: throughputFlow, type: 'owns' },
        { from: capacityResource, to: throughputFlow, type: 'constrains' },
        { from: throughputFlow, to: qualityMetric, type: 'causes' },
        { from: qualityMetric, to: customerName, type: 'affects' },
      ],
    },
    problems: [
      {
        problem: isRestaurant ? 'Peak demand creates seating and kitchen bottlenecks that raise wait time' : 'Demand and capacity are not aligned tightly enough to protect service quality',
        evidence: 'The domain description names operating roles, queues, resources, and service outcomes that can be modeled as a throughput system.',
        impact_score: 9,
      },
      {
        problem: isRestaurant ? 'Prep and inventory mismatch can create stockouts or waste' : 'Resource planning likely lags real demand signals',
        evidence: 'Capacity resources directly constrain the throughput process.',
        impact_score: 8,
      },
    ],
    objectives: [
      {
        objective,
        impact_score: 9,
        urgency_score: 8,
        alignment_score: 9,
        justification: `The world model links ${intakeFlow}, ${throughputFlow}, ${capacityResource}, and ${qualityMetric}; improving that path should improve the domain outcome directly.`,
        suggested_owner: isRestaurant ? 'general manager' : 'domain operator',
      },
    ],
    causal_patterns: [
      {
        action: isRestaurant ? 'Stagger reservations and hold surge capacity during peak windows' : 'Smooth demand arrival and reserve capacity for peak windows',
        outcome: isRestaurant ? 'Lower host stand queue and fewer kitchen spikes' : 'Lower queue depth and fewer service spikes',
        confidence: 7,
        counterevidence: 'Needs baseline wait-time and throughput data before claiming outcome.',
      },
      {
        action: isRestaurant ? 'Set prep par levels from recent covers and menu mix' : 'Set resource levels from recent demand mix',
        outcome: isRestaurant ? 'Fewer stockouts and less waste' : 'Fewer missed requests and less idle capacity',
        confidence: 6,
        counterevidence: 'Demand volatility may require daily adjustment.',
      },
    ],
    transfer_patterns: transferMatches,
    solution_plan: [
      { step: 'Instrument the current bottleneck with one week of timestamps, volume, capacity, and outcome metrics', owner: isRestaurant ? 'general manager' : 'domain operator', expected_outcome: 'Baseline identifies the highest-leverage constraint' },
      { step: isRestaurant ? 'Pilot reservation staggering, table-turn targets, and prep par adjustments in one peak service window' : 'Pilot one demand-smoothing and capacity-alignment change in one operating window', owner: frontRole, expected_outcome: 'Smaller queue spikes with limited operational risk' },
      { step: 'Review the outcome receipt and either scale, revert, or pick the next bottleneck', owner: deliveryRole, expected_outcome: 'Causal evidence updates the next objective' },
    ],
    meta_cognition: {
      assumptions: ['The domain description is accurate enough to build an initial world model.', 'The highest-value first step is local measurement plus a reversible pilot.'],
      risks: ['Optimizing one metric could harm quality if the review misses secondary effects.', 'External constraints may change during the pilot.'],
      missing_data: [isRestaurant ? 'Hourly covers, wait times, table turns, stockouts, labor schedule, and guest complaints' : 'Arrival rate, service time, capacity, quality outcomes, and exception logs'],
    },
    architecture_improvement: 'Keep each domain proof in its own world model so the same reasoning loop can be reused without hardcoded project entities.',
    emergent_capability: 'Domain translation: convert unfamiliar operating text into entities, constraints, objectives, causal tests, and transfer candidates.',
    proof: 'The proof was generated from the supplied domain description and generic transfer patterns, without reading the project wiki graph or relying on project-specific entities.',
  }, {
    status: 'ok',
    domain_name: domainName,
    domain_source: domain.source,
    domain_source_path: domain.source_path,
    description_excerpt: domain.description_excerpt,
    llm_error: 'llm_not_configured',
  });
}

function generalistPrompt(domain, transferPatterns = []) {
  return `Analyze this domain description with the same eight AGI capabilities:
1. autonomous problem discovery
2. world model
3. meta-cognition
4. objective setting
5. causal reasoning
6. transfer learning
7. architecture self-improvement
8. emergent capability discovery

Build the model from this domain only. Do not assume Atris-specific entities, software workflows, or project wiki knowledge.

Return JSON:
{
  "domain": {"name": "...", "summary": "..."},
  "world_model": {
    "entities": [{"type": "person|system|concept|role|process|resource|metric", "name": "..."}],
    "relationships": [{"from": "...", "to": "...", "type": "uses|depends-on|owns|causes|affects|constrains"}]
  },
  "problems": [{"problem": "...", "evidence": "...", "impact_score": 1-10}],
  "objectives": [{"objective": "...", "impact_score": 1-10, "urgency_score": 1-10, "alignment_score": 1-10, "justification": "...", "suggested_owner": "..."}],
  "causal_patterns": [{"action": "...", "outcome": "...", "confidence": 1-10, "counterevidence": "..."}],
  "transfer_patterns": [{"source_pattern": "...", "application": "...", "reason": "..."}],
  "solution_plan": [{"step": "...", "owner": "...", "expected_outcome": "..."}],
  "meta_cognition": {"assumptions": ["..."], "risks": ["..."], "missing_data": ["..."]},
  "architecture_improvement": "How this improves the general AGI loop",
  "emergent_capability": "New reusable capability discovered",
  "proof": "Why this is cross-domain and not project-specific"
}

Domain name: ${domain.name}
Domain source: ${domain.source}
Domain content:
${domain.description.slice(0, 12000)}

Reusable non-project transfer patterns:
${JSON.stringify((transferPatterns || []).slice(0, 20))}`;
}

function injectedGeneralistAnalysis() {
  if (!process.env.ATRIS_GENERALIST_LLM_JSON) return null;
  const parsed = parseJsonObjectFromText(process.env.ATRIS_GENERALIST_LLM_JSON);
  return parsed
    ? { source: 'env_json', analysis: parsed }
    : { source: 'env_json', error: 'invalid_json' };
}

async function callGeneralistLlm(domain, transferPatterns = []) {
  const injected = injectedGeneralistAnalysis();
  if (injected) return injected;
  if (process.env.ATRIS_GENERALIST_LLM !== '1') return null;
  try {
    const { postTurn } = require('../ax');
    const output = { isTTY: false, write() { return true; } };
    const result = await postTurn(generalistPrompt(domain, transferPatterns), {
      mode: process.env.ATRIS_GENERALIST_LLM_MODE || 'fast',
      route: 'local',
      cwd: process.cwd(),
      output,
      color: false,
    });
    const parsed = parseJsonObjectFromText(result?.output || '');
    return parsed
      ? { source: 'atris2_backend', analysis: parsed }
      : { source: 'atris2_backend', error: 'missing_json_response' };
  } catch (error) {
    return {
      source: 'atris2_backend',
      error: compactSentence(error instanceof Error ? error.message : String(error), 220),
    };
  }
}

async function runGeneralistWake(name, paths, { execute = false, domainInput = {} } = {}) {
  const mode = execute ? 'execute' : 'dry_run';
  const root = process.cwd();
  const domain = resolveGeneralistDomainInput(root, domainInput);
  const transferPatterns = readTransferPatterns(root);
  const crossDomainLibraryBefore = readCrossDomainPatternLibrary(root);
  const crossDomainMatches = crossDomainPatternMatches(crossDomainLibraryBefore, domain.name, domain.description, 5);
  const reusablePatterns = crossDomainPatternInputs(crossDomainMatches, transferPatterns);
  let llm = null;
  let proof = null;
  let learning = null;
  let reason = execute ? 'cross_domain_proof_written' : 'cross_domain_proof_dry_run';

  if (!domain.ok) {
    reason = 'missing_domain_input';
    proof = emptyGeneralistProof({
      status: 'missing_domain_input',
      domain_name: domain.name,
      domain_source: domain.source,
      domain_source_path: domain.source_path,
      description_excerpt: domain.description_excerpt,
      llm_error: domain.error,
    });
    proof.proof = 'No domain description was provided. Pass --domain-file, --domain, or ATRIS_GENERALIST_DOMAIN.';
  } else {
    llm = await callGeneralistLlm(domain, reusablePatterns);
    if (llm?.analysis) {
      proof = normalizeGeneralistAnalysis(llm.analysis, {
        status: 'ok',
        domain_name: domain.name,
        domain_source: domain.source,
        domain_source_path: domain.source_path,
        description_excerpt: domain.description_excerpt,
        llm_source: llm.source,
      });
      if (!proof) {
        reason = 'llm_json_parse_failed_heuristic_used';
        proof = fallbackGeneralistAnalysis(domain, reusablePatterns);
        proof.llm_source = llm.source;
        proof.llm_error = 'invalid_analysis_shape';
      }
    } else if (llm?.error) {
      reason = llm.error === 'invalid_json' ? 'llm_json_parse_failed_heuristic_used' : 'llm_analysis_failed_heuristic_used';
      proof = fallbackGeneralistAnalysis(domain, reusablePatterns);
      proof.llm_source = llm.source || null;
      proof.llm_error = llm.error;
    } else {
      reason = 'heuristic_cross_domain_proof_written';
      proof = fallbackGeneralistAnalysis(domain, reusablePatterns);
    }
  }

  const proofsDir = generalistProofsDir(root);
  fs.mkdirSync(proofsDir, { recursive: true });
  const proofPath = path.join(proofsDir, `${domain.slug}-${fileSafeStamp()}.json`);
  const latestProofPath = generalistLatestProofPath(root);
  const runsDir = path.join(root, 'atris', 'runs');
  fs.mkdirSync(runsDir, { recursive: true });
  const receiptPath = path.join(runsDir, `generalist-tick-${fileSafeStamp()}.json`);
  learning = learnCrossDomainPatterns(root, proof, {
    execute: execute && domain.ok && proof.status === 'ok',
    record: domain.ok && proof.status === 'ok',
    libraryBefore: crossDomainLibraryBefore,
    receiptPath,
    proofPath: execute ? proofPath : null,
  });
  proof.learning = {
    library_path: path.relative(root, learning.library_path),
    reused_pattern_count: learning.reused_pattern_count,
    observed_pattern_count: learning.observed_pattern_count,
    learning_improved: learning.learning_improved,
    before_metrics: learning.before_metrics,
    after_metrics: learning.after_metrics,
    reused_patterns: learning.reused_patterns,
  };
  if (execute) {
    fs.writeFileSync(proofPath, JSON.stringify(proof, null, 2) + '\n', 'utf8');
    fs.writeFileSync(latestProofPath, JSON.stringify(proof, null, 2) + '\n', 'utf8');
  }

  const receipt = {
    schema: 'atris.generalist_tick.v1',
    created_at: stampIso(),
    member: name,
    mode,
    executed: execute,
    ok: domain.ok && proof.status === 'ok',
    advisory_only: true,
    decision: 'cross_domain_generalize',
    reason,
    domain_name: proof.domain.name,
    domain_source: domain.source,
    domain_source_path: domain.source_path,
    domain_agnostic: true,
    atris_specific_code_required: false,
    capabilities_used: GENERALIST_CAPABILITIES,
    world_model_entities: proof.world_model.entities.length,
    world_model_relationships: proof.world_model.relationships.length,
    problem_count: proof.problems.length,
    objective_count: proof.objectives.length,
    causal_pattern_count: proof.causal_patterns.length,
    transfer_pattern_count: proof.transfer_patterns.length,
    transfer_patterns_scanned: transferPatterns.length,
    cross_domain_patterns_path: path.relative(root, crossDomainPatternsPath(root)),
    cross_domain_patterns_scanned: Array.isArray(crossDomainLibraryBefore.patterns) ? crossDomainLibraryBefore.patterns.length : 0,
    cross_domain_pattern_matches: crossDomainMatches.map((pattern) => ({
      id: pattern.id,
      pattern: pattern.pattern,
      domains: pattern.domains,
      success_rate: pattern.success_rate,
      domain_count: pattern.domain_count,
      match_score: pattern.match_score,
      reason: pattern.reason,
    })),
    cross_domain_learning: {
      library_path: path.relative(root, learning.library_path),
      reused_pattern_count: learning.reused_pattern_count,
      observed_pattern_count: learning.observed_pattern_count,
      learning_improved: learning.learning_improved,
      before_metrics: learning.before_metrics,
      after_metrics: learning.after_metrics,
      reused_patterns: learning.reused_patterns,
      run: learning.run,
    },
    llm_source: llm?.source || proof.llm_source || null,
    llm_successful: Boolean(llm?.source && llm?.analysis && proof.status === 'ok' && !proof.llm_error),
    llm_error: llm?.error || proof.llm_error || null,
    proof_path: execute ? path.relative(root, proofPath) : null,
    latest_proof_path: execute ? path.relative(root, latestProofPath) : null,
    top_objective: proof.objectives[0] || null,
    proof,
  };
  fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n', 'utf8');
  const logPath = appendMemberGoalLog(paths.memberDir, name, 'Generalist cross-domain tick', {
    mode,
    reason,
    domain: proof.domain.name,
    capabilities: GENERALIST_CAPABILITIES.length,
    world_entities: receipt.world_model_entities,
    world_relationships: receipt.world_model_relationships,
    objective: proof.objectives[0]?.objective || '',
    llm_source: receipt.llm_source || '',
    llm_error: receipt.llm_error || '',
    pattern_library: receipt.cross_domain_patterns_path,
    reused_patterns: learning.reused_pattern_count,
    reuse_rate: learning.after_metrics.pattern_reuse_rate,
    cross_domain_success_rate: learning.after_metrics.cross_domain_success_rate,
    receipt: path.relative(root, receiptPath),
    proof: receipt.proof_path || '',
  });

  return {
    ok: true,
    action: 'wake',
    member: name,
    mode,
    decision: 'cross_domain_generalize',
    reason,
    executed: execute,
    needs_user: !domain.ok,
    ask: domain.ok ? null : 'Pass --domain-file <path> or --domain "<description>".',
    next_command: 'atris member generalist proof',
    receipt_path: receiptPath,
    log_path: logPath,
    proof_path: execute ? proofPath : null,
    latest_proof_path: execute ? latestProofPath : null,
    generalist: receipt,
  };
}

async function processDomainFile(domainPath, { name = 'generalist', paths = null, execute = false } = {}) {
  const root = process.cwd();
  const resolvedPaths = paths || memberPaths(name);
  const fullPath = path.isAbsolute(domainPath) ? domainPath : path.join(root, domainPath);
  return runGeneralistWake(name, resolvedPaths, {
    execute,
    domainInput: {
      file: normalizeRelativeProofPath(root, fullPath),
    },
  });
}

function memberGeneralistProof(...args) {
  const asJson = hasFlag(args, '--json');
  const latestPath = generalistLatestProofPath(process.cwd());
  let payload;
  if (fs.existsSync(latestPath)) {
    try {
      payload = JSON.parse(fs.readFileSync(latestPath, 'utf8'));
    } catch (error) {
      payload = emptyGeneralistProof({
        status: 'parse_error',
        llm_error: compactSentence(error instanceof Error ? error.message : String(error), 220),
      });
    }
  } else {
    payload = emptyGeneralistProof({ status: 'missing' });
  }
  const objective = payload.objectives?.[0] || null;
  const lines = payload.status === 'missing'
    ? ['No generalist proof found. Run: atris member wake generalist --execute --domain-file <path>']
    : [
        `Generalist proof: ${payload.status}`,
        `Domain: ${payload.domain?.name || 'external domain'}`,
        objective?.objective ? `Objective: ${objective.objective}` : '',
        Number.isFinite(Number(objective?.overall_score)) ? `Score: ${objective.overall_score}` : '',
        `Capabilities: ${Array.isArray(payload.capabilities_used) ? payload.capabilities_used.length : 0}`,
        payload.proof ? `Proof: ${payload.proof}` : '',
      ].filter(Boolean);
  printJsonOrText({ ok: payload.status !== 'missing', action: 'generalist_proof', proof_path: latestPath, proof: payload }, lines, asJson);
}

function memberGeneralistPatterns(...args) {
  const asJson = hasFlag(args, '--json');
  const libraryPath = crossDomainPatternsPath(process.cwd());
  const library = readCrossDomainPatternLibrary(process.cwd());
  const lines = library.status === 'missing'
    ? ['No cross-domain pattern library found. Run: atris member wake generalist --execute --domain-file <path>']
    : [
        `Cross-domain patterns: ${library.patterns.length}`,
        `Domains solved: ${library.metrics.domains_solved_count}`,
        `Reuse rate: ${library.metrics.pattern_reuse_rate}`,
        `Cross-domain success rate: ${library.metrics.cross_domain_success_rate}`,
        ...(library.patterns || []).slice(0, 5).map((pattern) => `Pattern: ${pattern.pattern} (${pattern.domain_count} domains, success ${pattern.success_rate})`),
      ];
  printJsonOrText({ ok: library.status !== 'missing', action: 'generalist_patterns', patterns_path: libraryPath, library }, lines, asJson);
}

function memberGeneralistCommand(command, ...args) {
  if (command === 'proof') return memberGeneralistProof(...args);
  if (command === 'patterns') return memberGeneralistPatterns(...args);
  console.log('Usage: atris member generalist <proof|patterns> [--json]');
}

function readMemberScope(name, paths) {
  const scope = [`atris/team/${name}/`];
  if (paths?.memberFile && fs.existsSync(paths.memberFile)) {
    try {
      const fm = parseFrontmatter(fs.readFileSync(paths.memberFile, 'utf8'));
      if (fm && Array.isArray(fm.scope)) {
        for (const p of fm.scope) {
          if (typeof p === 'string' && p.trim()) scope.push(p.trim());
        }
      }
    } catch { /* ignore, fall through with default scope */ }
  }
  return scope;
}

// Auto-generated artifacts that wake/tick produce as side-effects. Dirty here is expected
// and must not gate the next wake, otherwise the loop deadlocks on its own log writes.
function isAutoGeneratedArtifact(filePath, name) {
  const memberLogs = `atris/team/${name}/logs/`;
  const memberSkills = `atris/team/${name}/skills/`;
  if (filePath.startsWith(memberLogs)) return true;
  if (filePath.startsWith(memberSkills)) return true;
  if (filePath === `atris/team/${name}/goals.json`) return true;
  if (filePath === `atris/team/${name}/goals.md`) return true;
  if (filePath === `atris/team/${name}/now.md`) return true;
  if (filePath === `atris/team/${name}/MEMBER.md`) return true;
  if (filePath === `atris/team/${name}/MISSION.md`) return true;
  if (filePath === `atris/team/${name}/SOUL.md`) return true;
  return false;
}

function porcelainPath(line) {
  // git status --porcelain entries are "XY path" or "XY old -> new"; we want the post-rename path.
  const trimmed = String(line || '').slice(3);
  const arrow = trimmed.indexOf(' -> ');
  return arrow >= 0 ? trimmed.slice(arrow + 4) : trimmed;
}

function workspaceSnapshot(name = null, paths = null) {
  try {
    const root = execFileSync('git', ['rev-parse', '--show-toplevel'], {
      cwd: process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim();
    const porcelain = execFileSync('git', ['status', '--porcelain'], {
      cwd: process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).split(/\r?\n/).filter(Boolean);
    const memberScope = name ? readMemberScope(name, paths) : [];
    const dirtyInScope = memberScope.length
      ? porcelain.filter((line) => {
          const p = porcelainPath(line);
          if (name && isAutoGeneratedArtifact(p, name)) return false;
          return memberScope.some((s) => p.startsWith(s));
        })
      : [];
    return {
      kind: 'git',
      root,
      clean: porcelain.length === 0,
      // Member-scoped clean: dirty files outside the member's scope don't block this member's loop.
      // Only files inside scope (the member's own lane) gate the wake decision.
      clean_for_member: dirtyInScope.length === 0,
      member_scope: memberScope,
      dirty_count: porcelain.length,
      dirty_count_in_scope: dirtyInScope.length,
      dirty_sample: porcelain.slice(0, 8),
      dirty_in_scope_sample: dirtyInScope.slice(0, 8),
    };
  } catch {
    return {
      kind: 'none',
      clean: true,
      clean_for_member: true,
      member_scope: [],
      dirty_count: 0,
      dirty_count_in_scope: 0,
      dirty_sample: [],
      dirty_in_scope_sample: [],
    };
  }
}

// Shared mission summary every wake decision carries. The mission-gate and generalist
// rules coerce a falsy North Star to null (pre-gate we cannot trust the mission file yet).
function wakeMissionSummary(purpose, { coerceNorthStarNull = false } = {}) {
  return {
    north_star: coerceNorthStarNull ? (purpose.northStar || null) : purpose.northStar,
    runtime_id: purpose.runtimeMission.id || null,
    runtime_status: purpose.runtimeMission.status || null,
    runtime_next: purpose.runtimeMission.next || null,
  };
}

// Merge a rule's verdict (decision/reason/ask/next_command + who owns it) with the
// context every decision reports. Key order matters: callers serialize this to JSON.
function composeWakeDecision(ctx, verdict) {
  const result = {
    decision: verdict.decision,
    reason: verdict.reason,
    needs_user: Boolean(verdict.needs_user),
    ask: verdict.ask || null,
    next_command: verdict.next_command,
    state: ctx.state,
    goal: verdict.goal,
    current_experiment: verdict.current_experiment,
    now_file: ctx.nowFile,
  };
  if ('autonomous_problem' in verdict) result.autonomous_problem = verdict.autonomous_problem;
  result.checks = ctx.checks;
  result.mission = verdict.mission || wakeMissionSummary(ctx.purpose);
  result.steering = ctx.steering;
  result.evidence = ctx.evidence;
  result.workspace = ctx.workspace;
  return result;
}

// Rule: a generalist with a meaningful mission processes dropped domain files before
// anything else. Fires before evidence collection, so it returns a complete decision
// with its own checks and no workspace snapshot.
function wakeRuleGeneralistDomainFile(name, { purpose, steering, state, goal, current }) {
  if (lowerCompact(name) !== 'generalist' || !purpose.meaningful) return null;
  const domainFile = findUnprocessedGeneralistDomainFile(process.cwd());
  if (!domainFile) return null;
  return {
    decision: 'process_domain_file',
    reason: `generalist_domain_scan:${domainFile.status}`,
    needs_user: false,
    ask: null,
    next_command: `atris member wake ${name} --execute --domain-file ${domainFile.path} --json`,
    state,
    goal: goal || null,
    current_experiment: current || null,
    checks: {
      has_member: true,
      has_mission: true,
      mission_meaningful: true,
      has_goal: Boolean(goal),
      has_open_experiment: Boolean(current),
      has_unprocessed_domain_file: true,
      domain_scan_window_minutes: 60,
      checked_existing_tasks: false,
    },
    mission: wakeMissionSummary(purpose, { coerceNorthStarNull: true }),
    steering,
    evidence: {
      generalist_domain_scan: domainFile,
      task_projection: null,
      nearest_open_loop: null,
    },
    workspace: null,
    domain_file: domainFile,
  };
}

// Rule: a member without a meaningful mission asks the operator before waking itself.
function wakeRuleMissionGate(ctx) {
  if (ctx.purpose.meaningful) return null;
  return {
    decision: 'ask',
    reason: 'mission_missing_or_placeholder',
    needs_user: true,
    ask: `Define atris/team/${ctx.name}/MISSION.md with a concrete North Star before this member wakes itself.`,
    next_command: `edit atris/team/${ctx.name}/MISSION.md`,
    goal: ctx.goal || null,
    current_experiment: ctx.current || null,
    mission: wakeMissionSummary(ctx.purpose, { coerceNorthStarNull: true }),
  };
}

// Rule: log-error discovery that asks for a task gets one opened autonomously.
function wakeRuleAutonomousErrorTask(ctx) {
  const discoveredTask = ctx.evidence.problem_discovery?.selected || null;
  if (!discoveredTask) return null;
  if (discoveredTask.source !== 'log_error_scan' || discoveredTask.autonomous_action !== 'create_task') return null;
  return {
    decision: 'create_task',
    reason: 'autonomous_error_discovery:log_error_scan',
    next_command: discoveredTask.next_command,
    goal: ctx.goal || null,
    current_experiment: ctx.current || null,
    autonomous_problem: discoveredTask,
  };
}

// Rule: no active goal, adopt a discovered problem as the objective, else stop.
function wakeRuleNeedsGoal(ctx) {
  if (ctx.goal) return null;
  const discoveredProblem = ctx.evidence.problem_discovery?.selected || null;
  if (discoveredProblem) {
    return {
      decision: 'set_objective',
      reason: `autonomous_problem_discovery:${discoveredProblem.source}`,
      next_command: discoveredProblem.next_command || `atris member wake ${ctx.name} --execute --confirm-autonomy-policy`,
      goal: null,
      current_experiment: null,
      autonomous_problem: discoveredProblem,
    };
  }
  return {
    decision: 'stop',
    reason: 'no_active_goal',
    next_command: `atris member goal-from-mission ${ctx.name}`,
    goal: null,
    current_experiment: null,
    autonomous_problem: null,
  };
}

// Rule: a blocked experiment needs operator input before another wake.
function wakeRuleBlockedExperiment(ctx) {
  if (!ctx.blocked) return null;
  return {
    decision: 'ask',
    reason: 'blocked_experiment',
    needs_user: true,
    ask: ctx.blocked.block?.ask || 'Needs operator input before another wake.',
    next_command: `atris member review ${ctx.name} ${ctx.blocked.id} --discard --proof "..."`,
    goal: ctx.goal,
    current_experiment: ctx.blocked,
  };
}

// Rule: an open reviewable proposal parks the member until review. Skip the wait when
// the only thing "open" is an unreviewable fallback proposal; otherwise the member is
// parked forever on a gate no reviewer can clear.
function wakeRuleOpenReviewableProposal(ctx) {
  if (!ctx.current || experimentIsUnreviewable(ctx.current)) return null;
  return {
    decision: 'wait',
    reason: `open_experiment_${ctx.current.status}`,
    next_command: `atris member review ${ctx.name} ${ctx.current.id} --accept --proof "..." --value 4`,
    goal: ctx.goal,
    current_experiment: ctx.current,
  };
}

// Rule: the scored candidate list can steer the wake somewhere other than a tick.
function wakeRuleScoredNonTickCandidate(ctx) {
  const selected = ctx.wakeScores.selected;
  if (!selected || selected.decision === 'tick') return null;
  const needsUser = selected.decision === 'ask';
  return {
    decision: selected.decision,
    reason: selected.reason,
    needs_user: needsUser,
    ask: needsUser ? (selected.ask || `Need operator input for ${selected.title}.`) : null,
    next_command: selected.next_command,
    goal: ctx.goal,
    current_experiment: null,
  };
}

// Rule: dirty files inside the member's own scope gate the wake unless forced.
function wakeRuleDirtyMemberScope(ctx) {
  if (ctx.workspace.clean_for_member || ctx.force) return null;
  return {
    decision: 'wait',
    reason: 'workspace_dirty_in_member_scope',
    next_command: `commit/stash files in atris/team/${ctx.name}/ (or member scope), or rerun: atris member wake ${ctx.name} --force`,
    goal: ctx.goal,
    current_experiment: null,
  };
}

// Rule: a goal pinned to a terminal mission must not mint another doomed tick.
// The goal stays active until a human retires it or revives the mission, so the
// wake surfaces that decision instead of proposing `member tick --goal` on a
// dead spine. Unknown mission ids pass through: they may live in a worktree.
function wakeRuleTerminalMissionGoal(ctx) {
  const mission = ctx.goalTerminalMission;
  if (!ctx.goal || !mission) return null;
  return {
    decision: 'ask',
    reason: `goal_mission_terminal:${mission.status}`,
    needs_user: true,
    ask: `Goal "${ctx.goal.title}" is pinned to mission ${mission.id} (${mission.status}). Retire the goal or revive the mission, then wake again.`,
    next_command: `atris member goal-from-mission ${ctx.name}`,
    goal: ctx.goal,
    current_experiment: ctx.current || null,
  };
}

// Rule: nothing blocks the member, so take the safe next bounded step.
function wakeRuleSafeBoundedTick(ctx) {
  return {
    decision: 'tick',
    reason: 'safe_next_bounded_step',
    next_command: `atris member tick ${ctx.name} --goal ${ctx.goal.id}`,
    goal: ctx.goal,
    current_experiment: null,
  };
}

// Ordered decision list: the first rule that speaks wins. Order is the contract.
const WAKE_DECISION_RULES = [
  wakeRuleMissionGate,
  wakeRuleAutonomousErrorTask,
  wakeRuleNeedsGoal,
  wakeRuleBlockedExperiment,
  wakeRuleOpenReviewableProposal,
  wakeRuleScoredNonTickCandidate,
  wakeRuleDirtyMemberScope,
  wakeRuleTerminalMissionGoal,
  wakeRuleSafeBoundedTick,
];

function wakeDecision(name, paths, { force = false, runtimeKind = memberRuntimeKind(name) } = {}) {
  const purpose = missionPurpose(paths);
  const nowPath = path.join(paths.memberDir, 'now.md');
  const nowFile = fs.existsSync(nowPath) ? {
    path: path.relative(process.cwd(), nowPath),
    excerpt: String(purpose.nowText || '').slice(0, 500),
  } : null;
  const steering = readSteeringMemory(paths, name);
  const state = loadMemberGoals(name, paths);
  const goal = activeGoal(state);
  const pinnedMission = goal?.mission_id ? memberRunMissionMap().get(String(goal.mission_id).trim()) || null : null;
  const goalTerminalMission = pinnedMission && MISSION_TERMINAL_STATUSES.has(lowerCompact(pinnedMission.status || '')) ? pinnedMission : null;
  const current = memberOpenExperiment(state);
  const generalistDecision = wakeRuleGeneralistDomainFile(name, { purpose, steering, state, goal, current });
  if (generalistDecision) return generalistDecision;
  const rawDirective = steeringWakeDirective(steering, name, goal);
  const directiveClosure = rawDirective ? steeringDirectiveClosure(rawDirective) : null;
  const directive = directiveClosure?.all_closed ? null : rawDirective;
  const evidence = collectWakeEvidence(name, goal, purpose, runtimeKind);
  evidence.steering_directive_closure = directiveClosure;
  const blocked = allExperiments(state)
    .map(({ goal: experimentGoal, experiment }) => ({ ...experiment, goal_id: experimentGoal.id, goal_title: experimentGoal.title }))
    .filter((experiment) => experiment.status === 'blocked')
    .sort((a, b) => String(b.blocked_at || b.created_at || '').localeCompare(String(a.blocked_at || a.created_at || '')))[0] || null;
  const workspace = workspaceSnapshot(name, paths);
  const checks = {
    has_member: true,
    has_mission: Boolean(purpose.missionText),
    mission_meaningful: purpose.meaningful,
    has_goal: Boolean(goal),
    has_open_experiment: Boolean(current),
    has_blocked_experiment: Boolean(blocked),
    has_steering: steering.length > 0,
    has_steering_directive: Boolean(directive),
    has_satisfied_steering_directive: Boolean(directiveClosure?.all_closed),
    has_open_loop_evidence: Boolean(evidence.nearest_open_loop),
    open_loop_source: evidence.nearest_open_loop?.source || null,
    has_member_room_evidence: Number(evidence.member_room?.candidate_count || 0) > 0,
    has_autonomous_problem_candidate: Boolean(evidence.problem_discovery?.selected),
    autonomous_problem_source: evidence.problem_discovery?.selected?.source || null,
    has_recent_receipt: Boolean(evidence.receipt?.latest_wake_receipt_path),
    workspace_clean: workspace.clean,
    workspace_clean_for_member: workspace.clean_for_member,
  };
  const wakeScores = scoredWakeCandidates(name, goal, evidence, directive);
  evidence.wake_candidate_scores = wakeScores.candidates;
  evidence.selected_wake_candidate = wakeScores.selected ? {
    source: wakeScores.selected.source,
    decision: wakeScores.selected.decision,
    reason: wakeScores.selected.reason,
    task_ref: wakeScores.selected.task_ref || null,
    title: wakeScores.selected.title,
    score: wakeScores.selected.score,
    components: wakeScores.selected.components,
    next_command: wakeScores.selected.next_command,
  } : null;

  const ctx = { name, force, purpose, nowFile, steering, state, goal, goalTerminalMission, current, blocked, evidence, workspace, checks, wakeScores };
  for (const rule of WAKE_DECISION_RULES) {
    const verdict = rule(ctx);
    if (verdict) return composeWakeDecision(ctx, verdict);
  }
  return null;
}

// The engine this member's work runs on, from the roster: its own team line,
// else its job's pick, else the router. Never throws.
function wakeMemberEngine(name, root = process.cwd()) {
  try {
    const { resolveEngineForMember } = require('../lib/member-engine');
    const picked = resolveEngineForMember(name, root);
    return {
      id: picked.engine ? picked.engine.id : null,
      model: picked.model || null,
      job: picked.job,
      source: picked.source,
      reason: picked.reason,
    };
  } catch {
    return null;
  }
}

async function runMemberWake(name, { execute = false, confirmed = false, force = false, domainInput = {} } = {}) {
  const paths = requireMemberDir(name);
  const refusal = memberRefusalFor(name, paths.memberFile);
  if (refusal) throw new Error(refusal);
  const runtimeKind = paths.runtimeKind || memberRuntimeKind(name);
  if (runtimeKind === 'auto-improver') {
    return runAutoImproverWake(name, paths, { execute, confirmed });
  }
  const isGeneralist = runtimeKind === 'generalist';
  const hasGeneralistDomainInput = Boolean(
    domainInput.file
    || domainInput.text
    || process.env.ATRIS_GENERALIST_DOMAIN_FILE
    || process.env.ATRIS_GENERALIST_DOMAIN,
  );
  if (isGeneralist && hasGeneralistDomainInput) {
    return runGeneralistWake(name, paths, { execute, domainInput });
  }
  if (runtimeKind === 'objective-generator') {
    return runObjectiveGeneratorWake(name, paths, { execute });
  }
  if (runtimeKind === 'supervisor') {
    return runSupervisorWake(name, paths, { execute });
  }
  if (runtimeKind === 'wiki-miner') {
    return runWikiMinerWake(name, paths, { execute });
  }
  const planned = wakeDecision(name, paths, { force, runtimeKind });
  if (isGeneralist && planned.decision === 'process_domain_file' && planned.domain_file?.path) {
    return processDomainFile(planned.domain_file.path, { name, paths, execute });
  }
  const mode = execute ? 'execute' : 'dry_run';
  let decision = planned.decision;
  let reason = planned.reason;
  let executed = false;
  let experiment = null;
  let state = planned.state;
  let goal = planned.goal;
  let nextCommand = planned.next_command;
  let autonomousProblem = planned.autonomous_problem || null;
  let seededGoal = null;
  let createdTask = null;
  let autonomousDiscoveryReceipt = null;
  const now = stampIso();

  if (execute && !confirmed) {
    decision = 'stop';
    reason = 'execute_requires_confirm_autonomy_policy';
    nextCommand = `atris member wake ${name} --execute --confirm-autonomy-policy`;
  } else if (execute && planned.decision === 'create_task' && autonomousProblem) {
    const taskResult = createAutonomousDiscoveryTask(autonomousProblem);
    createdTask = taskResult.task || null;
    autonomousDiscoveryReceipt = writeAutonomousDiscoveryReceipt(name, autonomousProblem, taskResult);
    executed = taskResult.ok === true;
    decision = taskResult.ok ? 'create_task' : 'stop';
    reason = taskResult.ok
      ? taskResult.existing ? 'autonomous_error_task_exists' : 'autonomous_error_task_created'
      : 'autonomous_error_task_create_failed';
    nextCommand = taskResult.task_ref
      ? `atris task show ${taskResult.task_ref} --json`
      : (autonomousProblem.next_command || nextCommand);
  } else if (execute && planned.decision === 'set_objective' && autonomousProblem) {
    const seeded = seedAutonomousProblemGoal(name, paths, state, autonomousProblem, planned.mission);
    state = seeded.state;
    goal = seeded.goal;
    seededGoal = seeded.goal;
    executed = true;
    decision = 'tick';
    reason = seeded.existing ? 'autonomous_objective_reused' : 'autonomous_objective_seeded';
    nextCommand = `atris member tick ${name} --goal ${goal.id}`;
  } else if (execute && planned.decision === 'tick' && goal) {
    goal.experiments = Array.isArray(goal.experiments) ? goal.experiments : [];
    experiment = await proposalForGoal(goal, {
      decision: planned,
      evidence: planned.evidence,
      mission: planned.mission,
    });
    // An unreviewable fallback proposal no longer blocks wake (it deadlocked
    // members for weeks), but it must not accumulate either: one open
    // proposal per goal stays the invariant, so the stale fallback is
    // superseded by the one being proposed now.
    for (const prior of goal.experiments) {
      if (experimentIsUnreviewable(prior)) {
        prior.status = 'superseded';
        prior.superseded_at = now;
        prior.superseded_by = experiment.id;
        prior.superseded_reason = 'unreviewable_fallback_replaced_by_next_proposal';
      }
    }
    goal.experiments.push(experiment);
    goal.history = Array.isArray(goal.history) ? goal.history : [];
    goal.history.push({ at: now, event: 'wake_tick_proposed_experiment', experiment_id: experiment.id });
    writeMemberGoals(paths, state);
    executed = true;
    decision = 'wait';
    reason = 'tick_executed_experiment_proposed';
    nextCommand = `atris member review ${name} ${experiment.id} --accept --proof "..." --value 4`;
  }

  const goals = (state.goals || []).map((item) => ({
    id: item.id || null,
    title: item.title || null,
    status: item.status || null,
  }));
  const receiptPayload = {
    schema: 'atris.member_wake.v1',
    created_at: now,
    member: name,
    mode,
    decision,
    reason,
    executed,
    needs_user: planned.needs_user || false,
    ask: planned.ask || null,
    next_command: nextCommand,
    mission: planned.mission,
    now_file: planned.now_file,
    goals,
    steering: planned.steering,
    evidence: planned.evidence,
    checks: planned.checks,
    workspace: planned.workspace,
    autonomous_problem: autonomousProblem,
    created_task: createdTask ? {
      id: createdTask.id || null,
      display_id: createdTask.display_id || null,
      legacy_ref: createdTask.legacy_ref || null,
      title: createdTask.title || null,
      tag: createdTask.tag || null,
      status: createdTask.status || null,
    } : null,
    autonomous_discovery_receipt: autonomousDiscoveryReceipt?.payload || null,
    autonomous_discovery_receipt_path: autonomousDiscoveryReceipt?.receipt_path || null,
    autonomous_discovery_project_log_path: autonomousDiscoveryReceipt?.project_log_path || null,
    active_goal: goal ? {
      id: goal.id,
      title: goal.title,
      source: goal.source || null,
      mission_id: goal.mission_id || null,
    } : null,
    current_experiment: experiment || planned.current_experiment || null,
  };
  const receiptPath = writeWakeReceipt(name, receiptPayload);
  const logTitle = experiment
    ? 'Member wake executed tick'
    : seededGoal
      ? 'Member wake seeded objective'
      : 'Member wake decision';
  const logPath = appendMemberGoalLog(paths.memberDir, name, logTitle, {
    decision,
    reason,
    mode,
    goal: goal?.title || '',
    experiment: (experiment || planned.current_experiment)?.title || '',
    problem: autonomousProblem?.problem || '',
    task: createdTask ? taskRef(createdTask) : '',
    discovery_receipt: autonomousDiscoveryReceipt?.receipt_path ? path.relative(process.cwd(), autonomousDiscoveryReceipt.receipt_path) : '',
    ask: planned.ask || '',
    receipt: path.relative(process.cwd(), receiptPath),
    next: nextCommand,
  });

  return {
    ok: true,
    action: 'wake',
    member: name,
    engine: wakeMemberEngine(name),
    mode,
    decision,
    reason,
    executed,
    needs_user: planned.needs_user || false,
    ask: planned.ask || null,
    next_command: nextCommand,
    mission: planned.mission,
    now_file: planned.now_file,
    goals,
    steering: planned.steering,
    evidence: planned.evidence,
    checks: planned.checks,
    workspace: planned.workspace,
    autonomous_problem: autonomousProblem,
    created_task: receiptPayload.created_task,
    autonomous_discovery_receipt: autonomousDiscoveryReceipt?.payload || null,
    autonomous_discovery_receipt_path: autonomousDiscoveryReceipt?.receipt_path || null,
    autonomous_discovery_project_log_path: autonomousDiscoveryReceipt?.project_log_path || null,
    active_goal: receiptPayload.active_goal,
    current_experiment: receiptPayload.current_experiment,
    receipt_path: receiptPath,
    log_path: logPath,
  };
}

// --- Wake boot rendering: the human face of `gm <member>` ---
// The JSON contract (atris.member_wake.v1) is untouched; this only changes what a person sees.

const WAKE_REASON_TEXT = {
  mission_missing_or_placeholder: "it has no North Star yet, and it won't guess at important work",
  no_active_goal: 'it has no active goal to push on yet',
  execute_requires_confirm_autonomy_policy: 'autonomous execution waits for your explicit go-ahead',
  workspace_dirty_in_member_scope: "there are uncommitted changes in its own lane, it won't build on a dirty floor",
  blocked_experiment: 'its current experiment is blocked on a human answer',
  tick_executed_experiment_proposed: 'it proposed one bounded experiment and queued it for your review',
  safe_next_bounded_step: 'it found a safe bounded next step',
  loop_already_active: 'another loop already holds the lease, so it stepped back instead of double-working',
  member_archived: 'this member is archived',
  llm_not_configured: 'no model is configured for autonomous reasoning here',
  insufficient_data: "it doesn't have enough evidence yet to act with confidence",
  proof_not_successful: 'the last proof did not pass, so it stopped instead of stacking work on a failure',
  auto_improver_task_create_failed: 'it found an improvement but could not put the task on the board',
  heuristic_cross_domain_proof_written: 'it wrote a cross-domain proof using its built-in heuristics',
  heuristic_objective_proposal_written: 'it drafted an objective proposal using its built-in heuristics',
  heuristic_objective_proposal_dry_run: 'it previewed an objective proposal using its built-in heuristics, without writing it',
  install_requires_clean_git: 'installing needs a clean git tree first',
  insufficient_world_model_data: 'its world model is too thin to act on yet',
  skipped_llm_not_configured: 'no model is configured here, so it skipped quietly instead of writing another dry-run receipt',
  llm_json_parse_failed: 'the model reply did not parse, so it stopped rather than act on garbage',
  llm_json_parse_failed_heuristic_used: 'the model reply did not parse, so it fell back to built-in heuristics',
  missing_domain_input: 'it needs a domain file or domain text from you to work on',
  no_crontab: 'no crontab is available on this machine, so the loop cannot be scheduled',
};

const WAKE_DECISION_TEXT = {
  ask: 'needs one thing from you',
  wait: 'decided to hold',
  tick: 'picked one bounded step',
  close_loop: 'is closing the loop',
  report_proof: 'has proof ready for you',
  create_missing_task: 'is putting the missing task on the board',
  create_task: 'is putting a new task on the board',
  stop: 'stopped on purpose',
  task_create_failed: 'tried to put a task on the board and could not',
  set_objective: 'set its own objective',
  generate_objective: 'drafted a new objective for review',
  supervise: 'reviewed the rest of the team',
  wiki_mine: 'is mining the wiki for its next move',
  process_domain_file: 'is digesting the domain file you gave it',
  cross_domain_generalize: 'is distilling patterns across domains',
};

function wakeDecisionText(decision) {
  if (WAKE_DECISION_TEXT[decision]) return WAKE_DECISION_TEXT[decision];
  const words = String(decision || '').replace(/_/g, ' ').trim();
  return words ? `decided: ${words}` : 'decided nothing';
}

function wakeStyle() {
  const on = Boolean(process.stdout.isTTY) && !process.env.NO_COLOR;
  const wrap = (code) => (text) => (on ? `\x1b[${code}m${text}\x1b[0m` : String(text));
  return { bold: wrap('1'), dim: wrap('2'), cyan: wrap('36') };
}

function wakeMemberRole(name) {
  try {
    const content = fs.readFileSync(memberPaths(name).memberFile, 'utf8');
    const fm = parseFrontmatter(content);
    return (fm && fm.role) || null;
  } catch {
    return null;
  }
}

function wakeReasonText(reason) {
  if (WAKE_REASON_TEXT[reason]) return WAKE_REASON_TEXT[reason];
  if (reason === 'open_experiment_proposed') return 'it already has an experiment on the table, waiting for your review';
  if (reason === 'open_experiment_running') return 'its current experiment is still running';
  const openExperiment = String(reason || '').match(/^open_experiment_([a-z_]+)$/);
  if (openExperiment) return `its current experiment is ${openExperiment[1].replace(/_/g, ' ')}`;
  return String(reason || '').replace(/_/g, ' ');
}

function wakeBootLines(name, result) {
  const s = wakeStyle();
  const role = wakeMemberRole(name);
  const decisionText = wakeDecisionText(result.decision);
  const goal = result.active_goal && result.active_goal.title;
  const experiment = result.current_experiment && result.current_experiment.title;
  const northStar = result.mission && result.mission.north_star;
  const laneCandidates = result.evidence && result.evidence.task_projection
    ? result.evidence.task_projection.candidate_count
    : null;

  const lines = [
    '',
    `${s.cyan('\u25c8')} ${s.bold(name)} is waking up${role ? ` ${s.dim(`\u00b7 ${role}`)}` : ''}`,
    '',
    `  mission   ${northStar ? clipText(northStar, 70) : s.dim('no North Star yet')}`,
    `  goal      ${goal ? clipText(goal, 70) : s.dim('none yet')}`,
    ...(experiment ? [`  working   ${clipText(experiment, 70)}`] : []),
    ...(laneCandidates !== null ? [`  lane      ${laneCandidates} task${laneCandidates === 1 ? '' : 's'} waiting in ${name}'s lane`] : []),
    ...(result.engine && result.engine.id ? [`  engine    ${clipText(String(result.engine.reason || '').replace(`${name} does `, ''), 70)}`] : []),
    '',
    `  ${s.bold(name)} looked around and ${s.bold(decisionText)}.`,
    `  ${s.dim(`Why: ${wakeReasonText(result.reason)}.`)}`,
  ];

  if (result.created_task && result.created_task.title) {
    lines.push('', `  On the board: ${result.created_task.display_id || result.created_task.legacy_ref || ''} ${clipText(result.created_task.title, 70)}`.trimEnd());
  }
  if (result.ask) {
    lines.push('', `  ${s.bold('One thing from you:')}`, `    ${result.ask}`);
  }
  if (result.next_command) {
    const ballWithHuman = result.needs_user === true
      || result.decision === 'ask'
      || /^open_experiment_/.test(result.reason || '');
    lines.push('', `  ${s.bold(ballWithHuman ? 'Your move' : 'Next step')}`, `    ${s.cyan(result.next_command)}`);
  }
  if (result.receipt_path) {
    lines.push('', `  ${s.dim(`receipt \u00b7 ${path.relative(process.cwd(), result.receipt_path)}`)}`, '');
  }
  return lines;
}

function clipText(value, max = 70) {
  const text = String(value || '').replace(/\s+/g, ' ').trim();
  return text.length <= max ? text : `${text.slice(0, Math.max(0, max - 1)).trim()}\u2026`;
}

async function memberWake(name, ...args) {
  if (name) requireRunnableMember(name);
  const asJson = hasFlag(args, '--json');
  const execute = hasFlag(args, '--execute') && !hasFlag(args, '--dry-run');
  const confirmed = hasFlag(args, '--confirm-autonomy-policy');
  const force = hasFlag(args, '--force');
  const domainInput = {
    text: readFlag(args, '--domain', ''),
    file: readFlag(args, '--domain-file', ''),
    name: readFlag(args, '--domain-name', ''),
  };
  // Honor per-member sleep switch before any tick dispatch.
  try {
    const { isMemberAwake } = require('../lib/member-switches');
    if (name && !isMemberAwake(name)) {
      const skipped = {
        ok: true,
        skipped: true,
        reason: 'asleep',
        member: name,
        decision: 'stop',
      };
      printJsonOrText(skipped, [`${name} is asleep`], asJson);
      return skipped;
    }
  } catch {
    // switch store unreadable: fail open and continue wake
  }
  const result = await runMemberWake(name, { execute, confirmed, force, domainInput });
  const work = wakeWorkStepPlan(name, args, result, { execute });
  if (!work.run) {
    if (work.reason) result.work_step = { ran: false, skipped: true, reason: work.reason };
    printJsonOrText(result, wakeBootLines(name, result), asJson);
    return result;
  }
  // Wake then work: one bounded member run on the roster engine, so waking a
  // member from a terminal (or cron) does something instead of only deciding.
  if (!asJson) printJsonOrText(result, wakeBootLines(name, result), false);
  const runArgs = [...(work.objective ? [work.objective] : []), ...work.flags, ...(asJson ? ['--json'] : [])];
  const run = memberRunWith(name, runArgs, { quiet: asJson });
  result.work_step = wakeWorkStepSummary(run, work);
  if (asJson) printJsonOrText(result, [], true);
  else for (const line of wakeWorkStepLines(result.work_step)) console.log(line);
  return result;
}

// Wake decisions that leave a member free to work now. Everything else
// (ask, wait on a review or dirty files, stop for another reason) keeps the
// member's own judgment and only reports it.
const WAKE_WORK_DECISIONS = new Set(['tick', 'set_objective', 'create_task']);

// Whether this wake also runs one bounded work step, and on what. A wake from
// a plain terminal (or cron) runs one when the roster names the member's
// engine. --plan or --dry-run only plans; --run forces the step; the legacy
// --execute path keeps proposing experiments; a codex or agent session around
// the CLI does the work itself, so it only plans.
function wakeWorkStepPlan(name, args, result, { execute = false } = {}) {
  if (!name || !result || result.ok === false || result.skipped) return { run: false };
  if (hasFlag(args, '--plan') || hasFlag(args, '--dry-run')) return { run: false };
  const forced = hasFlag(args, '--run') || hasFlag(args, '--work');
  if (execute && !forced) return { run: false };
  const caller = callerRuntime(args);
  if (!forced && caller !== 'terminal') return { run: false, reason: `${caller} session does the work itself` };
  const decision = String(result.decision || '');
  const freeToWork = WAKE_WORK_DECISIONS.has(decision)
    || (decision === 'stop' && result.reason === 'no_active_goal');
  if (result.needs_user || !freeToWork) {
    return { run: false, reason: `wake decided ${decision || 'nothing'} (${result.reason || 'no reason'})` };
  }
  if (!forced) {
    const { memberRosterEngine } = require('../lib/member-engine');
    if (!memberRosterEngine(name)) return { run: false, reason: 'no roster engine for this member; add a build pick to ROSTER.md or pass --run' };
  }
  const objective = decision === 'tick'
    ? String(result.active_goal?.title || '').trim()
    : String(result.autonomous_problem?.problem || result.autonomous_problem?.title || '').trim();
  const flags = [];
  for (const flag of ['--minutes', '--hours', '--verify']) {
    const value = readFlag(args, flag, '');
    if (value) flags.push(flag, value);
  }
  if (!readFlag(args, '--minutes', '') && !readFlag(args, '--hours', '')) flags.push('--minutes', '15');
  if (!readFlag(args, '--verify', '')) flags.push('--no-verify');
  return { run: true, objective, flags, caller };
}

function wakeWorkStepSummary(run, work) {
  const step = run?.work_step || {};
  return {
    ran: step.ran === true,
    ok: run?.ok === true,
    mission_id: run?.mission_id || null,
    objective: work.objective || run?.mission?.objective || null,
    engine: step.engine || null,
    model: step.model || null,
    duration_ms: step.duration_ms == null ? null : step.duration_ms,
    summary: step.summary || null,
    receipt_path: step.receipt_path || null,
    review_path: run?.mission?.worktree?.path || null,
    ...(run?.needs_review ? { needs_review: true, ask: run.ask, next_command: run.next_command } : {}),
    ...(run?.ok === false && !run?.needs_review ? { error: run.error || 'the work step did not run' } : {}),
  };
}

function wakeWorkStepLines(step) {
  if (!step) return [];
  if (step.needs_review) return ['', `  ${step.ask}`, `    ${step.next_command}`];
  if (!step.ran) return ['', `  work step did not run: ${step.error || step.reason || 'unknown'}`];
  const seconds = step.duration_ms == null ? '' : ` in ${Math.round(step.duration_ms / 1000)}s`;
  return [
    '',
    `  worked on ${step.engine}${step.model ? ` ${step.model}` : ''}${seconds}`,
    ...(step.receipt_path ? [`  receipt \u00b7 ${step.receipt_path}`] : []),
  ];
}

function memberAlive(name, ...args) {
  if (name === '--all' || name === 'all') return memberAliveAll(...args);
  const nextArgs = args.includes('--alive') ? args : [...args, '--alive'];
  return memberLoop(name, ...nextArgs);
}

function collectFleetActivationRows(root = process.cwd()) {
  const teamDir = path.join(root, 'atris', 'team');
  const missionMap = memberRunMissionMap();
  return findAllMembers(teamDir)
    .filter(isFleetMember)
    .map((member) => {
      const slug = memberSlugFromRecord(member);
      const paths = memberPaths(slug);
      const goalPlane = memberGoalPlaneStatus(slug, paths);
      const activeMission = memberLiveMission(slug, missionMap);
      const latestMission = memberLatestMission(slug, missionMap);
      const refusal = memberRefusalFor(slug, paths.memberFile);
      const skipped = Boolean(refusal) || (!goalPlane.goal && !activeMission);
      return {
        member: slug,
        goal: goalPlane.goal || null,
        active_mission: activeMission || null,
        latest_mission: latestMission || null,
        skipped,
        skip_reason: refusal ? 'not_ai' : skipped ? 'no_goal_and_no_active_mission' : null,
      };
    })
    .sort((a, b) => a.member.localeCompare(b.member));
}

async function callMemberLoopForFleet(kind, member, args, captureOutput) {
  if (!captureOutput) {
    if (kind === 'alive') return memberAlive(member, ...args);
    return memberLoop(member, ...args);
  }
  const captured = [];
  const originalLog = console.log;
  console.log = (...parts) => captured.push(parts.join(' '));
  try {
    const result = kind === 'alive'
      ? await memberAlive(member, ...args)
      : await memberLoop(member, ...args);
    return { result, output: captured };
  } finally {
    console.log = originalLog;
  }
}

async function memberLoopAll(kind, ...args) {
  const asJson = hasFlag(args, '--json');
  const rows = collectFleetActivationRows();
  const activated = [];
  const skipped = [];
  if (!asJson) console.log(`Member fleet ${kind}`);
  for (const row of rows) {
    if (row.skipped) {
      skipped.push(row);
      if (!asJson) console.log(`Skip ${row.member}: ${row.skip_reason === 'not_ai' ? 'not an AI member.' : 'no goal and no active mission.'}`);
      continue;
    }
    if (!asJson) console.log(`Activate ${row.member}: ${row.goal ? 'goal' : `mission ${row.active_mission?.id || 'active'}`}`);
    const result = await callMemberLoopForFleet(kind, row.member, args, asJson);
    activated.push({
      member: row.member,
      reason: row.goal ? 'has_goal' : 'has_active_mission',
      mission_id: row.active_mission?.id || null,
      result: asJson ? result?.result || null : null,
      output: asJson ? result?.output || [] : undefined,
    });
  }
  const reasonCounts = skipped.reduce((acc, row) => {
    acc[row.skip_reason] = (acc[row.skip_reason] || 0) + 1;
    return acc;
  }, {});
  const payload = {
    ok: true,
    action: `${kind}_all`,
    activated: activated.length,
    skipped: skipped.length,
    skipped_reasons: reasonCounts,
    activated_members: activated,
    skipped_members: skipped.map((row) => ({
      member: row.member,
      reason: row.skip_reason,
      latest_mission_id: row.latest_mission?.id || null,
      latest_mission_status: row.latest_mission?.status || null,
    })),
  };
  printJsonOrText(payload, [
    `Summary: ${activated.length} activated, ${skipped.length} skipped (${Object.entries(reasonCounts).map(([reason, count]) => `${reason} x${count}`).join(', ') || 'none'}).`,
  ], asJson);
  return payload;
}

function memberAliveAll(...args) {
  return memberLoopAll('alive', ...args);
}

// Loop phase: report lease + latest-receipt state without touching anything.
function memberLoopStatusReport(name, paths, asJson) {
  const active = readJson(paths.lockPath);
  const latest = readJson(paths.latestPath);
  const payload = {
    ok: true,
    action: 'loop_status',
    member: name,
    active: Boolean(active && Number(active.expires_at_ms || 0) > Date.now() && isPidAlive(active.pid)),
    lease: active || null,
    latest: latest || null,
    hourly_alive: memberAliveCronStatus(name, paths),
    lock_path: paths.lockPath,
    latest_path: paths.latestPath,
  };
  printJsonOrText(payload, [
    `Loop status: ${name}`,
    `Active: ${payload.active ? 'yes' : 'no'}`,
    `Hourly: ${payload.hourly_alive.installed ? 'installed' : payload.hourly_alive.script_exists ? 'script ready' : 'not installed'}`,
    `Latest: ${latest?.receipt_path ? path.relative(process.cwd(), latest.receipt_path) : 'none'}`,
  ], asJson);
}

// Loop phase: drop a stop file so the running loop breaks at its next tick boundary.
function memberLoopRequestStop(name, paths, asJson) {
  const requestedAt = stampIso();
  const stopPayload = {
    schema: 'atris.member_loop_stop.v1',
    member: name,
    requested_at: requestedAt,
    pid: process.pid,
  };
  writeJson(paths.stopPath, stopPayload);
  const receiptPath = writeMemberLoopReceipt(name, {
    ok: true,
    action: 'loop_stop',
    member: name,
    requested_at: requestedAt,
    stop_path: paths.stopPath,
  });
  printJsonOrText({
    ok: true,
    action: 'loop_stop',
    member: name,
    stop_path: paths.stopPath,
    receipt_path: receiptPath,
  }, [
    `Stop requested for ${name}.`,
    `Receipt: ${path.relative(process.cwd(), receiptPath)}`,
  ], asJson);
}

// Loop phase: derive the timing plan (tick count, interval, duration, lease ttl) from flags.
function memberLoopTimingPlan(name, args, { execute, confirmed }) {
  const ticksFlag = readNumberFlag(args, '--ticks', null);
  const minutes = readNumberFlag(args, '--minutes', null);
  const durationSeconds = readNumberFlag(args, '--duration-seconds', readNumberFlag(args, '--seconds', null));
  const hourly = hasFlag(args, '--hourly') || hasFlag(args, '--every-hour');
  const forever = hasFlag(args, '--forever') || hasFlag(args, '--until-stopped');
  const intervalSeconds = hourly
    ? 3600
    : readNumberFlag(args, '--interval', readNumberFlag(args, '--interval-seconds', 60));
  const intervalMs = Math.max(0, Math.floor(Number(intervalSeconds == null ? 60 : intervalSeconds) * 1000));
  const durationMs = forever && ticksFlag == null
    ? 0
    : Math.max(0, Math.floor(durationSeconds != null ? Number(durationSeconds) * 1000 : Number(minutes == null ? 10 : minutes) * 60 * 1000));
  const ticks = ticksFlag != null
    ? Math.max(1, Math.floor(Number(ticksFlag)))
    : forever
      ? execute && confirmed
        ? Number.MAX_SAFE_INTEGER
        : 1
    : intervalMs > 0
      ? Math.max(1, Math.floor(durationMs / intervalMs))
      : 1;
  const runId = `member-loop-${name}-${fileSafeStamp()}`;
  const startedAt = stampIso();
  const ttlSeconds = readNumberFlag(args, '--lease-ttl-seconds', null);
  const ttlMs = Math.max(
    30000,
    Math.floor(Number(ttlSeconds == null ? 0 : ttlSeconds) * 1000),
    forever ? intervalMs + (2 * 60 * 60 * 1000) : durationMs + 60000,
    intervalMs + 60000,
  );
  return { ticksFlag, hourly, forever, intervalMs, durationMs, ticks, runId, startedAt, ttlMs };
}

// Loop phase: refuse to execute without the autonomy confirmation, with a receipt saying why.
function memberLoopRefuseUnconfirmed(name, paths, { asJson, startedAt }) {
  const receiptPath = writeMemberLoopReceipt(name, {
    ok: false,
    action: 'loop',
    member: name,
    status: 'blocked',
    reason: 'execute_requires_confirm_autonomy_policy',
    mode: 'execute',
    started_at: startedAt,
    finished_at: stampIso(),
  });
  const payload = {
    ok: false,
    action: 'loop',
    member: name,
    status: 'blocked',
    reason: 'execute_requires_confirm_autonomy_policy',
    receipt_path: receiptPath,
  };
  writeJson(paths.latestPath, payload);
  printJsonOrText(payload, [
    `Loop blocked for ${name}: execute requires --confirm-autonomy-policy.`,
    `Receipt: ${path.relative(process.cwd(), receiptPath)}`,
  ], asJson);
  process.exitCode = 1;
}

// Loop phase: another loop holds the lease, so skip this run and leave a receipt behind.
function memberLoopSkipAlreadyActive(name, paths, lease, { asJson, execute, startedAt }) {
  const receiptPath = writeMemberLoopReceipt(name, {
    ok: true,
    action: 'loop',
    member: name,
    status: 'skipped',
    reason: 'loop_already_active',
    mode: execute ? 'execute' : 'dry_run',
    active_lease: lease.lease || null,
    started_at: startedAt,
    finished_at: stampIso(),
  });
  const payload = {
    ok: true,
    action: 'loop',
    member: name,
    status: 'skipped',
    reason: 'loop_already_active',
    ticks: 0,
    receipt_path: receiptPath,
    active_lease: lease.lease || null,
  };
  writeJson(paths.latestPath, payload);
  printJsonOrText(payload, [
    `Loop skipped for ${name}: another loop is active.`,
    `Receipt: ${path.relative(process.cwd(), receiptPath)}`,
  ], asJson);
}

// Tick phase (alive mode): run the full operate pipeline once and record what it did.
function memberLoopAliveTick(name, run, index, tickStartedAt) {
  const { options, state } = run;
  const alive = runAliveTick(name, {
    execute: options.execute,
    confirmed: options.confirmed,
    force: options.force,
    agent: options.agent,
    model: options.model,
    maxWallSeconds: options.operateMaxWall,
    autoAcceptLimit: options.autoAcceptLimit,
    noPrime: index > 0,
    sharedCheckout: options.sharedCheckout,
  });
  const key = `${alive.status || 'alive'}:${alive.reason || 'tick'}`;
  state.decisions[key] = (state.decisions[key] || 0) + 1;
  const tick = {
    tick: index + 1,
    started_at: tickStartedAt,
    finished_at: alive.finished_at || stampIso(),
    ok: alive.ok !== false,
    decision: alive.status || 'alive_tick',
    reason: alive.reason || null,
    executed: options.execute && alive.operate?.payload?.executed !== false,
    needs_user: alive.needs_user === true,
    next_command: alive.next_command || null,
    has_mission: alive.has_mission === true,
    has_goal: alive.has_goal === true,
    has_steering: false,
    productive: alive.status === 'completed',
    blocked_on_human: alive.blocked_on_human === true,
    operate_ok: alive.operate?.ok,
    auto_accept_accepted: alive.auto_accept?.json?.summary?.accepted ?? alive.auto_accept?.json?.summary?.would_accept,
    receipt_path: alive.receipt_path || alive.operate?.receipt_path || null,
    alive,
  };
  state.tickResults.push(tick);
  if (!tick.ok) state.failed = true;
  fs.appendFileSync(state.tickLogPath, JSON.stringify(tick) + '\n', 'utf8');
}

// Tick phase (wake mode): take one wake decision, record it, and notice a member stuck
// re-asking the same question so the loop can hand off instead of burning remaining ticks.
async function memberLoopWakeTick(name, run, index, tickStartedAt) {
  const { options, state } = run;
  const wake = await runMemberWake(name, { execute: options.execute, confirmed: options.confirmed, force: options.force });
  const key = `${wake.decision}:${wake.reason}`;
  state.decisions[key] = (state.decisions[key] || 0) + 1;
  const tick = {
    tick: index + 1,
    started_at: tickStartedAt,
    finished_at: stampIso(),
    ok: true,
    decision: wake.decision,
    reason: wake.reason,
    executed: wake.executed,
    needs_user: wake.needs_user,
    next_command: wake.next_command,
    has_mission: wake.checks?.has_mission === true,
    has_goal: wake.checks?.has_goal === true,
    has_steering: wake.checks?.has_steering === true,
    productive: wake.executed === true
      || /executed/.test(wake.reason || '')
      || ['tick', 'close_loop', 'report_proof', 'create_missing_task', 'create_task', 'set_objective'].includes(wake.decision),
    blocked_on_human: wake.needs_user === true || /^open_experiment_/.test(wake.reason || ''),
    current_experiment: wake.current_experiment?.id || null,
    receipt_path: wake.receipt_path,
  };
  state.tickResults.push(tick);
  fs.appendFileSync(state.tickLogPath, JSON.stringify(tick) + '\n', 'utf8');

  // Repeated identical `ask:*` wake decisions (e.g. ask:mission_missing_or_placeholder) mean the
  // member is stuck asking the same question every tick regardless of --execute; the idle
  // early-exit only fires in execute mode, so without this a dry-run loop burns every
  // remaining tick re-asking. Reuse the same blocked_on_human handoff once we see the ask repeat.
  if (wake.decision === 'ask') {
    if (key === state.lastAskKey) {
      state.consecutiveIdenticalAsk += 1;
    } else {
      state.lastAskKey = key;
      state.consecutiveIdenticalAsk = 1;
    }
    if (state.consecutiveIdenticalAsk >= MEMBER_LOOP_IDENTICAL_ASK_BREAK_THRESHOLD) {
      state.earlyExit = {
        after_tick: tick.tick,
        decision: tick.decision || null,
        reason: tick.reason || 'idle',
        needs_user: tick.needs_user === true,
        blocked_on_human: true,
        next_command: tick.next_command || null,
        stop: 'repeated_identical_ask',
      };
    }
  } else {
    state.lastAskKey = null;
    state.consecutiveIdenticalAsk = 0;
  }
}

// Stop spinning: if the member can do no real work for this many ticks in a row (waiting on a
// human review, blocked, or no goal), break early and surface a clear handoff instead of
// burning every remaining tick on the same no-op decision.
const MEMBER_LOOP_IDLE_BREAK_THRESHOLD = 2;
const MEMBER_LOOP_IDENTICAL_ASK_BREAK_THRESHOLD = 2;

// A loop kept running for days would keep old code after an atris upgrade. Read the
// installed version from disk, not the cached require, so a new install is seen.
function memberLoopInstalledVersion() {
  try {
    return JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8')).version || null;
  } catch {
    return null;
  }
}

// Start the same loop again on the new code. The lease is already released, so the
// fresh process takes it over; this one exits with the fresh run's status.
function memberLoopRestartOnNewVersion(upgrade) {
  const child = spawnSync(process.execPath, process.argv.slice(1), {
    stdio: 'inherit',
    env: { ...process.env, ATRIS_MEMBER_LOOP_RESTARTED_FROM: upgrade.from },
  });
  process.exit(child.status == null ? 1 : child.status);
}

// Loop phase: control. Hold the lease, honor the stop file, pace ticks by interval, and
// break early when the member is idling instead of faking activity.
async function memberLoopRunTicks(name, paths, lease, run) {
  const { options, plan, state } = run;
  try {
    for (let index = 0; index < plan.ticks; index += 1) {
      if (fs.existsSync(paths.stopPath)) {
        state.stopped = true;
        break;
      }
      if (index > 0 && plan.forever && state.startVersion) {
        const installed = memberLoopInstalledVersion();
        if (installed && installed !== state.startVersion) {
          state.upgrade = { from: state.startVersion, to: installed };
          break;
        }
      }
      refreshMemberLoopLease(paths, lease.lease, plan.ttlMs);
      const tickStartedAt = stampIso();
      try {
        if (options.aliveMode) {
          memberLoopAliveTick(name, run, index, tickStartedAt);
        } else {
          await memberLoopWakeTick(name, run, index, tickStartedAt);
        }
      } catch (error) {
        state.failed = true;
        const tick = {
          tick: index + 1,
          started_at: tickStartedAt,
          finished_at: stampIso(),
          ok: false,
          error: error instanceof Error ? error.message : String(error),
        };
        state.tickResults.push(tick);
        fs.appendFileSync(state.tickLogPath, JSON.stringify(tick) + '\n', 'utf8');
        break;
      }
      if (state.earlyExit) break;
      if (options.execute) {
        const last = state.tickResults[state.tickResults.length - 1];
        if (last && last.productive) {
          state.consecutiveIdle = 0;
        } else if (last) {
          state.consecutiveIdle += 1;
          if (state.consecutiveIdle >= MEMBER_LOOP_IDLE_BREAK_THRESHOLD) {
            state.earlyExit = {
              after_tick: last.tick,
              decision: last.decision || null,
              reason: last.reason || 'idle',
              needs_user: last.needs_user === true,
              blocked_on_human: last.blocked_on_human === true || last.needs_user === true,
              next_command: last.next_command || null,
            };
            break;
          }
        }
      }
      if (index < plan.ticks - 1 && plan.intervalMs > 0) sleepSync(plan.intervalMs);
    }
  } finally {
    releaseMemberLoopLease(paths, lease.lease);
  }
}

// Loop phase: result recording. One summary object, one receipt, one latest pointer, one report.
function memberLoopRecordResult(name, paths, lease, run) {
  const { options, plan, state } = run;
  const { execute, aliveMode, asJson } = options;
  const { hourly, forever, runId, ticks, intervalMs, durationMs, startedAt } = plan;
  const { tickResults, decisions, stopped, failed, earlyExit, tickLogPath, upgrade } = state;
  const finishedAt = stampIso();
  const plannedOnly = aliveMode && tickResults.length > 0 && tickResults.every((tick) => tick.decision === 'planned');
  const summary = {
    ok: !failed,
    action: aliveMode ? 'alive' : 'loop',
    schema: aliveMode ? 'atris.member_alive.v1' : 'atris.member_loop.v1',
    member: name,
    alive: aliveMode,
    status: failed ? 'failed' : stopped ? 'stopped' : upgrade ? 'restarting_on_new_version' : plannedOnly ? 'planned' : earlyExit ? (earlyExit.blocked_on_human ? 'blocked_on_human' : 'idle') : 'completed',
    mode: execute ? 'execute' : 'dry_run',
    cadence: hourly ? 'hourly' : 'custom',
    forever,
    stop_command: `atris member ${aliveMode ? 'alive' : 'loop'} ${name} --stop`,
    operating_contract: forever
      ? 'Run on this cadence until stopped; each tick must choose useful work, prove it plainly, or stop/ask instead of faking activity.'
      : 'Run for the requested bounded window; each tick must choose useful work, prove it plainly, or stop/ask instead of faking activity.',
    run_id: runId,
    ticks_requested: ticks,
    ticks: tickResults.length,
    interval_ms: intervalMs,
    duration_ms_requested: durationMs,
    duration_ms_actual: Date.parse(finishedAt) - Date.parse(startedAt),
    decisions,
    early_exit: earlyExit,
    upgrade: upgrade || null,
    restarted_from_version: process.env.ATRIS_MEMBER_LOOP_RESTARTED_FROM || null,
    stop: earlyExit?.stop || null,
    blocked_on_human: earlyExit?.blocked_on_human === true,
    needs_user: earlyExit?.needs_user === true,
    next_command: earlyExit?.next_command || null,
    has_mission_all_ticks: tickResults.length > 0 && tickResults.every((tick) => tick.has_mission === true),
    has_goal_all_ticks: tickResults.length > 0 && tickResults.every((tick) => tick.has_goal === true),
    has_steering_all_ticks: tickResults.length > 0 && tickResults.every((tick) => tick.has_steering === true),
    recovered_stale_lease: lease.recovered_stale,
    stale_lease: lease.stale_lease || null,
    started_at: startedAt,
    finished_at: finishedAt,
    log_path: tickLogPath,
    lock_path: paths.lockPath,
    latest_path: paths.latestPath,
    tick_receipts: tickResults.map((tick) => tick.receipt_path).filter(Boolean),
  };
  const receiptPath = writeMemberLoopReceipt(name, summary);
  const payload = { ...summary, receipt_path: receiptPath };
  writeJson(paths.latestPath, payload);
  printJsonOrText(payload, [
    `${aliveMode ? 'Alive' : 'Loop'}: ${name}`,
    `Status: ${payload.status}`,
    `Cadence: ${payload.cadence}${payload.forever ? ' forever' : ''}`,
    `Ticks: ${payload.ticks}/${payload.ticks_requested}`,
    ...(upgrade ? [`Upgrade: atris ${upgrade.from} -> ${upgrade.to}, restarting on the new version`] : []),
    `Decisions: ${Object.entries(decisions).map(([key, count]) => `${key} x${count}`).join(', ') || 'none'}`,
    `Stop: ${payload.stop_command}`,
    `Receipt: ${path.relative(process.cwd(), receiptPath)}`,
  ], asJson);
}

// Driver: the phases above do the work; this reads as setup -> gate -> run -> record.
async function memberLoop(name, ...args) {
  if (name === '--all' || name === 'all') return memberLoopAll('loop', ...args);
  requireRunnableMember(name);
  const asJson = hasFlag(args, '--json');
  const aliveMode = hasFlag(args, '--alive');
  const execute = hasFlag(args, '--execute');
  const confirmed = hasFlag(args, '--confirm-autonomy-policy');
  const force = hasFlag(args, '--force');
  const agentFlag = String(readFlag(args, '--agent', '') || '').trim().toLowerCase();
  const agent = agentFlag === 'claude' ? 'claude' : agentFlag === 'codex' ? 'codex' : undefined;
  const model = String(readFlag(args, '--model', '') || '').trim() || undefined;
  const operateMaxWall = Math.max(60, Math.min(1800, Number(readNumberFlag(args, '--operate-max-wall', readNumberFlag(args, '--max-wall', 900)))));
  const autoAcceptLimit = Math.max(1, Math.floor(Number(readNumberFlag(args, '--auto-accept-limit', 8))));
  const sharedCheckout = hasFlag(args, '--shared-checkout');
  const options = { asJson, aliveMode, execute, confirmed, force, agent, model, operateMaxWall, autoAcceptLimit, sharedCheckout };
  const paths = memberLoopPaths(name);
  fs.mkdirSync(paths.stateDir, { recursive: true });

  if (hasFlag(args, '--install')) {
    return installMemberAliveCron(name, args);
  }

  if (hasFlag(args, '--uninstall')) {
    return uninstallMemberAliveCron(name, args);
  }

  if (hasFlag(args, '--status')) {
    return memberLoopStatusReport(name, paths, asJson);
  }

  if (hasFlag(args, '--stop')) {
    return memberLoopRequestStop(name, paths, asJson);
  }

  const plan = memberLoopTimingPlan(name, args, { execute, confirmed });

  if (execute && !confirmed) {
    return memberLoopRefuseUnconfirmed(name, paths, { asJson, startedAt: plan.startedAt });
  }

  const lease = acquireMemberLoopLease(name, { runId: plan.runId, ttlMs: plan.ttlMs });
  if (!lease.acquired) {
    return memberLoopSkipAlreadyActive(name, paths, lease, { asJson, execute, startedAt: plan.startedAt });
  }

  fs.rmSync(paths.stopPath, { force: true });
  const tickLogPath = path.join(process.cwd(), 'atris', 'runs', `${plan.runId}.jsonl`);
  fs.mkdirSync(path.dirname(tickLogPath), { recursive: true });
  const state = {
    tickResults: [],
    decisions: {},
    stopped: false,
    failed: false,
    earlyExit: null,
    consecutiveIdle: 0,
    lastAskKey: null,
    consecutiveIdenticalAsk: 0,
    tickLogPath,
    startVersion: memberLoopInstalledVersion(),
    upgrade: null,
  };

  const run = { options, plan, state };
  await memberLoopRunTicks(name, paths, lease, run);
  memberLoopRecordResult(name, paths, lease, run);
  if (state.upgrade) memberLoopRestartOnNewVersion(state.upgrade);
}

async function memberTick(name, ...args) {
  const paths = requireRunnableMember(name);
  const asJson = hasFlag(args, '--json');
  const force = hasFlag(args, '--force');
  const goalId = readFlag(args, '--goal', '');
  const state = loadMemberGoals(name, paths);
  const goal = activeGoal(state, goalId);
  const evidence = collectWakeEvidence(name, goal, null, paths.runtimeKind || memberRuntimeKind(name));
  if (!goal) {
    console.error(`No active goal for ${name}. Run: atris member goal ${name} "..."`);
    process.exit(1);
  }
  goal.experiments = Array.isArray(goal.experiments) ? goal.experiments : [];
  const blocked = goal.experiments.find((item) => item.status === 'blocked') || null;
  if (blocked && !force) {
    goal.history = Array.isArray(goal.history) ? goal.history : [];
    goal.history.push({ at: stampIso(), event: 'tick_paused_blocked', experiment_id: blocked.id });
    writeMemberGoals(paths, state);
    const logPath = appendMemberGoalLog(paths.memberDir, name, 'Member tick paused blocked', {
      goal: goal.title,
      experiment: blocked.title,
      ask: blocked.block?.ask || 'Needs operator input.',
      orchestrator: blocked.block?.orchestrator || '',
    });
    printJsonOrText(
      { ok: true, action: 'blocked', member: name, goal_id: goal.id, experiment: blocked, needs_user: true, ask: blocked.block?.ask || 'Needs operator input.', goals_path: paths.goalsJson, log_path: logPath },
      [
        `Blocked for ${name}: ${blocked.title}`,
        `Ask: ${blocked.block?.ask || 'Needs operator input.'}`,
        `Next: atris member review ${name} ${blocked.id} --discard --proof "..."`,
      ],
      asJson,
    );
    return;
  }
  let experiment = goal.experiments.find((item) => item.status === 'proposed' || item.status === 'running') || null;
  const reused = Boolean(experiment && !force);
  if (!experiment || force) {
    experiment = await proposalForGoal(goal, { evidence });
    goal.experiments.push(experiment);
  }
  goal.history = Array.isArray(goal.history) ? goal.history : [];
  goal.history.push({ at: stampIso(), event: reused ? 'tick_reused_proposal' : 'tick_proposed_experiment', experiment_id: experiment.id });
  writeMemberGoals(paths, state);
  const logPath = appendMemberGoalLog(paths.memberDir, name, reused ? 'Member tick reused proposal' : 'Member tick proposed experiment', {
    goal: goal.title,
    experiment: experiment.title,
    proof_target: experiment.proof_target,
    next_step: experiment.next_step || '',
    verifier: experiment.verifier || '',
  });
  printJsonOrText(
    { ok: true, action: 'tick', member: name, goal_id: goal.id, experiment, reused, goals_path: paths.goalsJson, log_path: logPath },
    [
      `${reused ? 'Reusing' : 'Proposed'} experiment for ${name}: ${experiment.title}`,
      `Proof target: ${experiment.proof_target}`,
      `Stop rule: ${experiment.stop_rule}`,
    ],
    asJson,
  );
}

function memberReview(name, experimentId, ...args) {
  const paths = requireMemberDir(name);
  const asJson = hasFlag(args, '--json');
  const accepted = hasFlag(args, '--accept');
  const discarded = hasFlag(args, '--discard');
  if (!experimentId || accepted === discarded) {
    console.error('Usage: atris member review <name> <experiment-id> (--accept|--discard) --proof "..." [--lesson "..."] [--next "..."]');
    process.exit(1);
  }
  const proof = readFlag(args, '--proof', '');
  if (!proof) {
    console.error('Refusing review without --proof.');
    process.exit(1);
  }
  const value = readNumberFlag(args, '--value', null);
  if (value != null && (!Number.isInteger(value) || value < 1 || value > 5)) {
    console.error('Value must be an integer from 1 to 5.');
    process.exit(1);
  }
  const lesson = readFlag(args, '--lesson', '');
  const nextTitle = readFlag(args, '--next', '');
  const state = loadMemberGoals(name, paths);
  const { goal: foundGoal, experiment } = findExperiment(state, experimentId);
  if (!foundGoal || !experiment) {
    console.error(`Experiment "${experimentId}" not found for ${name}.`);
    process.exit(1);
  }
  if (experimentIsClosed(experiment)) {
    console.error(`Experiment "${experimentId}" is already ${experiment.status}; closed member experiments cannot be reviewed again.`);
    process.exit(1);
  }
  experiment.status = accepted ? 'accepted' : 'discarded';
  experiment.reviewed_at = stampIso();
  experiment.proof = proof;
  if (value != null) experiment.value = value;
  if (lesson) experiment.lesson = lesson;
  let nextExperiment = null;
  if (accepted && nextTitle) {
    nextExperiment = {
      id: makeExperimentId(foundGoal.id, nextTitle),
      title: nextTitle,
      status: 'proposed',
      proof_target: (foundGoal.acceptance || [])[0] || 'Return proof, risk, and next move.',
      stop_rule: 'Stop if proof is missing, risk is unclear, or the next move would require new authority.',
      created_at: stampIso(),
      source: `review:${experiment.id}`,
    };
    foundGoal.experiments.push(nextExperiment);
  }
  foundGoal.history = Array.isArray(foundGoal.history) ? foundGoal.history : [];
  foundGoal.history.push({
    at: stampIso(),
    event: accepted ? 'experiment_accepted' : 'experiment_discarded',
    experiment_id: experiment.id,
    next_experiment_id: nextExperiment?.id,
    value,
  });
  writeMemberGoals(paths, state);
  const logPath = appendMemberGoalLog(paths.memberDir, name, accepted ? 'Member experiment accepted' : 'Member experiment discarded', {
    goal: foundGoal.title,
    experiment: experiment.title,
    proof,
    lesson,
    value: value == null ? '' : `${value}/5`,
    next: nextExperiment?.title || '',
  });
  printJsonOrText(
    { ok: true, action: 'review', member: name, goal_id: foundGoal.id, experiment, outcome: experiment.status, value, next_experiment: nextExperiment, goals_path: paths.goalsJson, log_path: logPath },
    [
      `${accepted ? 'Accepted' : 'Discarded'} experiment for ${name}: ${experiment.title}`,
      `Proof: ${proof}`,
      ...(value == null ? [] : [`Value: ${value}/5`]),
      ...(nextExperiment ? [`Next proposed: ${nextExperiment.title}`] : []),
    ],
    asJson,
  );
}

function memberBlock(name, experimentId, ...args) {
  const paths = requireMemberDir(name);
  const asJson = hasFlag(args, '--json');
  const reason = readFlag(args, '--reason', '');
  const ask = readFlag(args, '--ask', '');
  const orchestrator = readFlag(args, '--orchestrator', '');
  if (!experimentId || !reason || !ask) {
    console.error('Usage: atris member block <name> <experiment-id> --reason "..." --ask "..." [--orchestrator name]');
    process.exit(1);
  }
  const state = loadMemberGoals(name, paths);
  const { goal, experiment } = findExperiment(state, experimentId);
  if (!goal || !experiment) {
    console.error(`Experiment "${experimentId}" not found for ${name}.`);
    process.exit(1);
  }
  if (experimentIsClosed(experiment)) {
    console.error(`Experiment "${experimentId}" is already ${experiment.status}; closed member experiments cannot be blocked.`);
    process.exit(1);
  }
  experiment.status = 'blocked';
  experiment.blocked_at = stampIso();
  experiment.block = { reason, ask, orchestrator: orchestrator || null };
  goal.history = Array.isArray(goal.history) ? goal.history : [];
  goal.history.push({ at: stampIso(), event: 'experiment_blocked', experiment_id: experiment.id, ask, orchestrator: orchestrator || null });
  writeMemberGoals(paths, state);
  const logPath = appendMemberGoalLog(paths.memberDir, name, 'Member experiment blocked', {
    goal: goal.title,
    experiment: experiment.title,
    reason,
    ask,
    orchestrator,
  });
  printJsonOrText(
    { ok: true, action: 'blocked', member: name, goal_id: goal.id, experiment, needs_user: true, ask, orchestrator: orchestrator || null, goals_path: paths.goalsJson, log_path: logPath },
    [
      `Blocked ${name}: ${experiment.title}`,
      `Reason: ${reason}`,
      `Ask: ${ask}`,
      ...(orchestrator ? [`Orchestrator: ${orchestrator}`] : []),
    ],
    asJson,
  );
}

function collectFleetMemberStatus(root = process.cwd()) {
  const teamDir = path.join(root, 'atris', 'team');
  const missionMap = memberRunMissionMap(root);
  return findAllMembers(teamDir)
    .filter(isFleetMember)
    .map((member) => {
      const slug = memberSlugFromRecord(member);
      const paths = memberPaths(slug);
      const goalPlane = memberGoalPlaneStatus(slug, paths);
      const mission = memberMissionSummary(slug, missionMap, root);
      const activity = memberLastActivity(slug, paths, root);
      const verdict = memberVerdict({ mission, activity });
      return {
        member: slug,
        role: member.role,
        goal_state: goalPlane.stateLabel,
        goal_title: goalPlane.goal?.title || null,
        mission: mission.latest ? {
          id: mission.latest.id || null,
          name: mission.name,
          objective: mission.objective,
          state: mission.state,
          runner: mission.runner,
          model: mission.model,
          worktree_root: mission.worktree_root,
          worktree_branch: mission.worktree_branch,
          task_ref: mission.task_ref,
          current_task_id: mission.current_task_id,
          last_tick_at: mission.last_tick_at,
          last_tick_age: mission.last_tick_age,
          live: mission.live_mission,
          driver: mission.driver,
        } : null,
        last_activity: activity,
        verdict,
      };
    })
    .sort((a, b) => a.member.localeCompare(b.member));
}

function clipCell(value, width) {
  const clean = String(value || '-').replace(/\s+/g, ' ').trim() || '-';
  if (clean.length <= width) return clean.padEnd(width);
  if (width <= 3) return clean.slice(0, width);
  return `${clean.slice(0, width - 3)}...`;
}

function renderMemberFleetStatusTable(rows) {
  if (!rows.length) return ['No active team members found in atris/team/.'];
  const widths = {
    member: 18,
    goal: 11,
    mission: 34,
    state: 10,
    tick: 8,
    activity: 8,
    verdict: 8,
  };
  const header = [
    clipCell('Member', widths.member),
    clipCell('Goal', widths.goal),
    clipCell('Mission', widths.mission),
    clipCell('State', widths.state),
    clipCell('Tick', widths.tick),
    clipCell('Activity', widths.activity),
    clipCell('Verdict', widths.verdict),
  ].join(' ');
  const rule = [
    '-'.repeat(widths.member),
    '-'.repeat(widths.goal),
    '-'.repeat(widths.mission),
    '-'.repeat(widths.state),
    '-'.repeat(widths.tick),
    '-'.repeat(widths.activity),
    '-'.repeat(widths.verdict),
  ].join(' ');
  return [
    'Member fleet status',
    header,
    rule,
    ...rows.map((row) => [
      clipCell(row.member, widths.member),
      clipCell(row.goal_state, widths.goal),
      clipCell(row.mission?.name || '-', widths.mission),
      clipCell(row.mission?.state || '-', widths.state),
      clipCell(row.mission?.last_tick_age || '-', widths.tick),
      clipCell(row.last_activity?.age || '-', widths.activity),
      clipCell(row.verdict, widths.verdict),
    ].join(' ')),
  ];
}

function memberStatusAll(...args) {
  const asJson = hasFlag(args, '--json');
  const rows = collectFleetMemberStatus();
  printJsonOrText(
    {
      ok: true,
      action: 'status_all',
      members: rows,
    },
    renderMemberFleetStatusTable(rows),
    asJson,
  );
}

function memberStatus(name, ...args) {
  if (name === '--all' || name === 'all') return memberStatusAll(...args);
  const paths = requireMemberDir(name);
  const asJson = hasFlag(args, '--json');
  const goalPlane = memberGoalPlaneStatus(name, paths);
  const owner = paths.storageName || name;
  const mission = memberMissionSummary(owner, memberRunMissionMap());
  const activity = memberLastActivity(owner, paths);
  const verdict = memberVerdict({ mission, activity });
  let memberSwitch = { awake: true, loops: {} };
  try {
    const { getMemberSwitch } = require('../lib/member-switches');
    memberSwitch = getMemberSwitch(name);
  } catch {
    // default awake
  }
  const loopEntries = Object.entries(memberSwitch.loops || {})
    .map(([id, on]) => `${id}:${on === false ? 'asleep' : 'awake'}`);
  const switchLabel = memberSwitch.awake === false ? 'asleep' : 'awake';
  const payload = {
    ok: true,
    action: 'status',
    member: name,
    state: goalPlane.stateLabel,
    needs_user: goalPlane.needsUser,
    ask: goalPlane.ask,
    active_goal: goalPlane.goal || null,
    current_experiment: goalPlane.current || null,
    last_reviewed: goalPlane.lastReviewed || null,
    value: goalPlane.value,
    switch: {
      awake: memberSwitch.awake !== false,
      loops: memberSwitch.loops || {},
    },
    mission: mission.latest ? {
      id: mission.latest.id || null,
      name: mission.name,
      objective: mission.objective,
      state: mission.state,
      runner: mission.runner,
      model: mission.model,
      worktree_root: mission.worktree_root,
      worktree_branch: mission.worktree_branch,
      task_ref: mission.task_ref,
      current_task_id: mission.current_task_id,
      last_tick_at: mission.last_tick_at,
      last_tick_age: mission.last_tick_age,
      live: mission.live_mission,
      driver: mission.driver,
    } : null,
    last_activity: activity,
    verdict,
    next_command: goalPlane.nextCommand,
    recent_log: goalPlane.logs,
    goals_path: paths.goalsJson,
    goals_md_path: paths.goalsMd,
  };
  const s = wakeStyle();
  const role = wakeMemberRole(name);
  const ballWithHuman = goalPlane.needsUser === true || goalPlane.current?.status === 'proposed';
  printJsonOrText(
    payload,
    [
      '',
      `${s.cyan('\u25c8')} ${s.bold(name)}${role ? ` ${s.dim(`\u00b7 ${role}`)}` : ''} ${s.dim(`\u00b7 ${verdict.toLowerCase()}, last activity ${activity.age}`)}`,
      '',
      `  goal      ${goalPlane.goal?.title ? clipText(goalPlane.goal.title, 70) : s.dim('none yet')}`,
      `  working   ${goalPlane.current ? `${clipText(goalPlane.current.title, 60)} ${s.dim(`(${goalPlane.current.status})`)}` : s.dim('no open experiment')}`,
      `  value     ${goalPlane.value.line}`,
      `  switch    ${switchLabel}${loopEntries.length ? ` ${s.dim(`(${loopEntries.join(', ')})`)}` : ''}`,
      `  mission   ${mission.latest ? `${mission.name} ${s.dim(`(${mission.state}, last tick ${mission.last_tick_age})`)}` : s.dim('none owned')}`,
      ...(goalPlane.ask ? ['', `  ${s.bold('One thing from you:')}`, `    ${goalPlane.ask}`] : []),
      '',
      `  ${s.bold(ballWithHuman ? 'Your move' : 'Next step')}`,
      `    ${s.cyan(goalPlane.nextCommand)}`,
      ...(goalPlane.logs.length ? ['', `  ${s.dim('recent')}`, ...goalPlane.logs.map((line) => `  ${s.dim(line)}`)] : []),
      '',
    ],
    asJson,
  );
}

function memberHistory(name, ...args) {
  const { spawnSync } = require('child_process');

  const paths = requireMemberDir(name);
  const asJson = hasFlag(args, '--json');
  const limitArg = readNumberFlag(args, '--limit', null);
  const limit = limitArg !== null ? Math.max(1, limitArg) : null;

  // resolve files to track: MEMBER.md + SOUL.md if present
  const filesToTrack = [];
  if (fs.existsSync(paths.memberFile)) {
    filesToTrack.push(paths.memberFile);
  }
  const soulPath = path.join(paths.memberDir, 'SOUL.md');
  if (fs.existsSync(soulPath)) {
    filesToTrack.push(soulPath);
  }

  if (filesToTrack.length === 0) {
    // no files exist yet (unborn member); empty history ok
    const payload = {
      ok: true,
      action: 'history',
      member: name,
      files: [],
    };
    printJsonOrText(payload, [`identity history: ${name}`, '(no files found)'], asJson);
    return;
  }

  // run git log for each file
  const cwd = process.cwd();
  const fileHistories = [];

  for (const filePath of filesToTrack) {
    const relativePath = path.relative(cwd, filePath);
    const result = spawnSync('git', ['log', '--follow', '--pretty=format:%h|%ai|%s', '--', relativePath], {
      cwd,
      encoding: 'utf8',
    });

    let commits = [];
    if (result.status === 0 && result.stdout) {
      const lines = result.stdout.trim().split('\n').filter(Boolean);
      commits = lines.map((line) => {
        const [hash, date, subject] = line.split('|');
        return { hash: hash || '', date: date || '', subject: subject || '' };
      });

      // apply limit if specified
      if (limit !== null) {
        commits = commits.slice(0, limit);
      }
    }

    fileHistories.push({
      path: relativePath,
      commits,
    });
  }

  // render output
  if (asJson) {
    const payload = {
      ok: true,
      action: 'history',
      member: name,
      files: fileHistories,
    };
    console.log(JSON.stringify(payload, null, 2));
  } else {
    console.log('');
    console.log(`identity history: ${name}`);
    console.log('');
    for (const fileHist of fileHistories) {
      console.log(`${fileHist.path}:`);
      if (fileHist.commits.length === 0) {
        console.log('  (no git history)');
      } else {
        for (const commit of fileHist.commits) {
          console.log(`  ${commit.hash} ${commit.date} ${commit.subject}`);
        }
      }
      console.log('');
    }
  }
}

// --- Live backend status (heartbeat + projection) ---

function parseLiveFlags(args) {
  const flags = { scope: 'personal', scopeId: null, json: false, state: null, note: null, days: null };
  const positional = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--json') flags.json = true;
    else if (a === '--done') flags.state = 'done';
    else if (a === '--error') flags.state = 'error';
    else if (a === '--running') flags.state = 'running';
    else if (a === '--scope') flags.scope = args[++i];
    else if (a.startsWith('--scope=')) flags.scope = a.slice(8);
    else if (a === '--scope-id') flags.scopeId = args[++i];
    else if (a.startsWith('--scope-id=')) flags.scopeId = a.slice(11);
    else if (a === '--note' || a === '--on') flags.note = args[++i];
    else if (a.startsWith('--note=')) flags.note = a.slice(7);
    else if (a === '--days') flags.days = parseInt(args[++i], 10);
    else if (a.startsWith('--days=')) flags.days = parseInt(a.slice(7), 10);
    else positional.push(a);
  }
  return { flags, positional };
}

function memberScopeQuery(flags) {
  let q = `scope=${encodeURIComponent(flags.scope)}`;
  if (flags.scopeId) q += `&scope_id=${encodeURIComponent(flags.scopeId)}`;
  return q;
}

// atris member live, what the iPhone app and web see: GET /api/members projection.
async function memberLive(...args) {
  const { flags } = parseLiveFlags(args);
  const creds = loadCredentials();
  if (!creds || !creds.token) {
    console.error('Not logged in. Run: atris login');
    process.exit(1);
  }
  const result = await apiRequestJson(`/members?${memberScopeQuery(flags)}`, { token: creds.token });
  if (!result.ok) {
    console.error(`Failed to fetch members: ${result.error || 'Unknown error'}`);
    process.exit(1);
  }
  const members = (result.data?.members || result.data || []).filter((m) => m && m.member_type === 'ai');
  if (flags.json) {
    console.log(JSON.stringify(members, null, 2));
    return;
  }
  console.log('');
  console.log(`live members (${flags.scope}${flags.scopeId ? `:${flags.scopeId}` : ''}), same projection the app renders`);
  console.log('');
  for (const m of members) {
    const loop = m.loop_status || {};
    const dot = loop.running ? '●' : '○';
    const state = loop.state || m.status || '-';
    const workingOn = loop.working_on || loop.now || '';
    const lastActive = loop.last_active || '';
    console.log(`  ${dot} ${m.display_name}  [${state}]${workingOn ? `  ${workingOn}` : ''}${lastActive ? `  (last active ${lastActive})` : ''}`);
  }
  if (members.length === 0) console.log('  (no AI members in this scope)');
  console.log('');
}

// atris member heartbeat, tell the backend this member is running/done, so
// every surface (iOS, web) shows it live. POST /api/members/{name}/heartbeat.
async function memberHeartbeat(name, ...args) {
  if (!name) {
    console.error('Usage: atris member heartbeat <name> [--note "what it is doing"] [--done|--error] [--scope business --scope-id <id>] [--json]');
    process.exit(1);
  }
  const { flags } = parseLiveFlags(args);
  const creds = loadCredentials();
  if (!creds || !creds.token) {
    console.error('Not logged in. Run: atris login');
    process.exit(1);
  }
  const body = { state: flags.state || 'running', scope: flags.scope };
  if (flags.note) body.working_on = flags.note;
  if (flags.scopeId) body.scope_id = flags.scopeId;
  const result = await apiRequestJson(`/members/${encodeURIComponent(name)}/heartbeat`, {
    method: 'POST',
    body: JSON.stringify(body),
    headers: { 'Content-Type': 'application/json' },
    token: creds.token,
  });
  if (!result.ok) {
    console.error(`Heartbeat failed: ${result.error || 'Unknown error'}`);
    process.exit(1);
  }
  if (flags.json) {
    console.log(JSON.stringify(result.data, null, 2));
    return;
  }
  const d = result.data || {};
  console.log(`${d.running ? '●' : '○'} ${d.member || name} → ${d.state}${d.working_on ? `, ${d.working_on}` : ''} (visible on every surface)`);
}

// atris member improvements, what the business computer improved, day by day.
// GET /api/business/{id}/improvements/daily.
async function memberImprovements(businessId, ...args) {
  if (!businessId) {
    console.error('Usage: atris member improvements <business-id> [--days N] [--json]');
    process.exit(1);
  }
  const { flags } = parseLiveFlags(args);
  const creds = loadCredentials();
  if (!creds || !creds.token) {
    console.error('Not logged in. Run: atris login');
    process.exit(1);
  }
  if (flags.days !== null && !(Number.isInteger(flags.days) && flags.days >= 1)) {
    console.error('--days needs a whole number of days, 1 or more (example: --days 7).');
    process.exit(1);
  }
  const days = flags.days || 30;
  const result = await apiRequestJson(`/business/${encodeURIComponent(businessId)}/improvements/daily?days=${days}`, { token: creds.token });
  if (!result.ok) {
    console.error(`Failed to fetch improvements: ${result.error || 'Unknown error'}`);
    process.exit(1);
  }
  if (flags.json) {
    console.log(JSON.stringify(result.data, null, 2));
    return;
  }
  const history = result.data?.history || [];
  console.log('');
  console.log(`daily improvements: business ${businessId}`);
  console.log('');
  if (history.length === 0) {
    console.log('  (no improvement history yet, first entry lands after the next nightly self-improve run)');
  }
  for (const day of history) {
    console.log(`  ${day.date}: ${day.agents_improved}/${day.agents_total} agents improved`);
    for (const agent of day.agents || []) {
      const note = agent.note ? `, ${agent.note}` : '';
      console.log(`    ${agent.kept_count > 0 ? '+' : ' '} ${agent.name} (kept ${agent.kept_count}, score ${agent.best_score})${note}`);
    }
  }
  console.log('');
}

// --- Command Dispatcher ---

async function memberChat(name, ...rest) {
  const paths = requireMemberDir(name);
  const flags = rest.filter((a) => String(a).startsWith('--'));
  const words = rest.filter((a) => !String(a).startsWith('--'));
  const fromFlag = flags.find((f) => f.startsWith('--from='));
  const from = fromFlag ? fromFlag.slice('--from='.length) : (process.env.USER || 'terminal');
  const text = words.join(' ').trim();
  if (!text) {
    console.error('Usage: atris member chat <name> "your message" [--from=<sender>]');
    process.exit(1);
  }
  // Append-only inbox the Atris desktop polls into the member's desk chat.
  // Contract shared with obelisk src/lib/memberChatInbox.cjs: one JSON object per line.
  const line = JSON.stringify({ at: new Date().toISOString(), from, text });
  fs.appendFileSync(path.join(paths.memberDir, 'chat-inbox.jsonl'), `${line}\n`, 'utf8');
  console.log(`Sent to ${paths.storageName || name}'s desk. It appears in Atris Desktop within about 15 seconds when the app is open.`);
  return { ok: true };
}

const IDEA_ARCHETYPE_RULES = [
  {
    slugs: ['auto-improver', 'improver'],
    pattern: /\b(repeat|recurring|broken\s+test|flaky|error|regression|pain|fix\s+bug|self[- ]improv|crash)\b/i,
    reason: 'handles recurring errors, regressions, and test fixes',
  },
  {
    slugs: ['validator', 'orb'],
    pattern: /\b(review|audit|validate|verify|check\s+diff|quality|slop|security)\b/i,
    reason: 'reviews changes and blocks weak work before merge',
  },
  {
    slugs: ['architect'],
    pattern: /\b(architect|migration|schema|api\s+design|refactor|boundary)\b/i,
    reason: 'judges architecture and multi-file design before code changes',
  },
  {
    slugs: ['navigator', 'task-planner'],
    pattern: /\b(roadmap|plan|spec|break\s+down|map|where\s+is|navigate)\b/i,
    reason: 'maps the codebase and breaks ideas into clear steps',
  },
  {
    slugs: ['customer-lead'],
    pattern: /\b(customer|churn|retention|onboarding|support|user\s+feedback|commitment)\b/i,
    reason: 'turns customer signals into clear commitments and next moves',
  },
  {
    slugs: ['researcher', 'scout'],
    pattern: /\b(research|benchmark|investigate|compare|study|survey)\b/i,
    reason: 'researches options and gathers grounded evidence',
  },
  {
    slugs: ['executor', 'builder', 'codex-executor'],
    pattern: /\b(build|implement|feature|add|wire|create|ship|code|update)\b/i,
    reason: 'builds and tests concrete product changes',
  },
];

// Keep specialized idea rules, then fall back to the same job inference used
// by the engine roster. Renamed members get the same job score as built-ins.
const ARCHETYPE_FOR_JOB = { build: 'executor', review: 'validator', search: 'researcher' };
const EXPERIMENT_STATUSES = new Set(['experimental', 'one-off']);

function ideaRuleFor(slug, record, text) {
  const own = IDEA_ARCHETYPE_RULES.find((rule) => rule.slugs.includes(slug));
  if (own && own.pattern.test(text)) return { rule: own, own: true };
  const { autoJobForMember } = require('../lib/member-engine');
  const archetype = ARCHETYPE_FOR_JOB[autoJobForMember(slug, record.role)];
  const rule = IDEA_ARCHETYPE_RULES.find((r) => r.slugs.includes(archetype)) || null;
  return { rule, own: Boolean(own && rule === own) };
}

// The request's job is the first rule it matches; the list runs from
// specific jobs to the general build job, so "where is the code" is a
// navigator job even though "code" is also a build word.
function ideaJobRule(text) {
  return IDEA_ARCHETYPE_RULES.find((rule) => rule.pattern.test(text)) || null;
}

// 3 = named in the idea, 2 = the job is the member's own, 1 = the member
// falls back to the job, 0 = not its job. Fit outranks shared words.
function ideaJobFit(named, memberRule, jobRule) {
  if (named) return 3;
  if (!jobRule || !memberRule.rule || memberRule.rule !== jobRule) return 0;
  return memberRule.own ? 2 : 1;
}

// 0 = normal, 1 = experiment or one-off, 2 = parked, human, or odd-typed.
function dispatchTier(record) {
  const frontmatter = record.frontmatter || {};
  const status = String(frontmatter.status || '').trim().toLowerCase();
  if (status === 'parked' || memberRefusalReason(memberSlugFromRecord(record), frontmatter)) return 2;
  if (EXPERIMENT_STATUSES.has(status)) return 1;
  return 0;
}

// Lower tier wins first, then job fit, then higher score, then name order
// for a stable pick.
function outranksDispatch(candidate, best) {
  if (!best) return true;
  if (candidate.tier !== best.tier) return candidate.tier < best.tier;
  if (candidate.fit !== best.fit) return candidate.fit > best.fit;
  if (candidate.score !== best.score) return candidate.score > best.score;
  return candidate.member.localeCompare(best.member) < 0;
}

function ideaNamesMember(text, slug) {
  const escaped = slug.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/-/g, '[-\\s]+');
  return new RegExp(`(^|[^a-z0-9-])${escaped}($|[^a-z0-9-])`, 'i').test(text);
}

function pickMemberForIdea(ideaText, root = process.cwd(), preferredMember = '') {
  const teamDir = path.join(root, 'atris', 'team');
  const members = findAllMembers(teamDir).filter(isFleetMember);
  if (!members.length) return null;

  const cleanPreferred = String(preferredMember || '').trim().toLowerCase();
  if (cleanPreferred) {
    const match = members.find((m) => memberSlugFromRecord(m).toLowerCase() === cleanPreferred);
    if (match) {
      const slug = memberSlugFromRecord(match);
      return {
        member: slug,
        role: match.role || 'Team Member',
        reason: 'selected directly by you',
        score: 100,
      };
    }
  }

  const text = String(ideaText || '').trim();
  const words = text
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 4);
  const jobRule = ideaJobRule(text);

  let best = null;
  for (const record of members) {
    const slug = memberSlugFromRecord(record);
    const named = ideaNamesMember(text, slug);
    // Naming an experiment in the idea is the owner's pick, so it ranks normally.
    const baseTier = dispatchTier(record);
    const tier = named && baseTier === 1 ? 0 : baseTier;
    let score = 0;
    let matchedReason = '';

    const memberRule = ideaRuleFor(slug, record, text);
    const fit = ideaJobFit(named, memberRule, jobRule);
    if (fit > 0 && memberRule.rule) {
      score += 30;
      matchedReason = memberRule.rule.reason;
    }

    const missionFile = path.join(teamDir, slug, 'MISSION.md');
    const missionText = fs.existsSync(missionFile) ? fs.readFileSync(missionFile, 'utf8') : '';
    const corpus = `${slug} ${record.role || ''} ${record.description || ''} ${(record.skills || []).join(' ')} ${missionText}`.toLowerCase();

    let overlapCount = 0;
    for (const word of words) {
      if (corpus.includes(word)) overlapCount += 1;
    }
    score += overlapCount * 4;
    if (Number(record.skillCount || 0) > 0) score += 2;

    if (named) {
      score += 40;
      matchedReason = 'named in the idea';
    }

    if (!matchedReason) {
      matchedReason = record.description
        ? compactSentence(record.description, 90)
        : `fits ${record.role || slug} responsibilities`;
    }

    const candidate = {
      member: slug,
      role: record.role || 'Team Member',
      reason: matchedReason,
      score,
      tier,
      fit,
    };
    if (outranksDispatch(candidate, best)) best = candidate;
  }

  return best;
}

function memberDispatch(...args) {
  if (!args.length || hasFlag(args, '--help') || hasFlag(args, '-h')) {
    console.log('Usage: atris member dispatch "<idea>" [--to <member>] [--engine <name>] [--ignite] [--dry-run] [--json]');
    console.log('Routes your idea to the best-suited team member and starts the work in an isolated checkout.');
    return;
  }
  const asJson = hasFlag(args, '--json');
  const dryRun = hasFlag(args, '--dry-run');
  const preferredMember = readFlag(args, '--to', '') || readFlag(args, '--member', '');
  const valueFlags = [...MEMBER_RUN_START_VALUE_FLAGS, '--to', '--member'];
  const boolFlags = [...MEMBER_RUN_START_BOOLEAN_FLAGS, '--dry-run'];
  const ideaText = stripKnownFlags(args, valueFlags, boolFlags).join(' ').trim();
  if (!ideaText) {
    console.error('atris member dispatch: idea text is required.');
    process.exitCode = 2;
    return;
  }

  const picked = pickMemberForIdea(ideaText, process.cwd(), preferredMember);
  if (!picked) {
    console.error('No active team members found in atris/team/.');
    process.exitCode = 1;
    return;
  }

  const forwardedArgs = [];
  for (let i = 0; i < args.length; i += 1) {
    const token = String(args[i] || '');
    if (token === '--dry-run') continue;
    if (token === '--to' || token === '--member') {
      i += 1;
      continue;
    }
    if (token.startsWith('--to=') || token.startsWith('--member=')) continue;
    forwardedArgs.push(args[i]);
  }

  const commandPreview = `atris member run ${picked.member} ${JSON.stringify(ideaText)} --ignite`;
  if (dryRun) {
    const payload = {
      ok: true,
      action: 'member_dispatch',
      dry_run: true,
      idea: ideaText,
      member: picked.member,
      role: picked.role,
      reason: picked.reason,
      command: commandPreview,
    };
    printJsonOrText(
      payload,
      [
        `${picked.member} (${picked.role}) will take this: ${picked.reason.replace(/\.$/, '')}.`,
        '',
        commandPreview,
      ],
      asJson,
    );
    return payload;
  }

  if (!asJson) {
    console.log(`${picked.member} (${picked.role}) is taking this: ${picked.reason.replace(/\.$/, '')}.`);
  }
  // --ignite means do the work now, the same as the previewed member run;
  // without it dispatch only opens the mission.
  if (hasFlag(args, '--ignite') || hasFlag(args, '--wait') || hasFlag(args, '--sync')) {
    return memberRun(picked.member, ...forwardedArgs);
  }
  return startMemberRunMission(picked.member, ideaText, forwardedArgs);
}

function scrubFeedJargon(text) {
  return String(text || '')
    .replace(/\bmission-\d{4}-\d{2}-\d{2}-[a-z0-9-]+\b/gi, '')
    .replace(/\b[0-9a-f]{7,40}\b/g, '')
    .replace(/\(\s*(commit\s*)?\)/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function plainFeedStatusLabel(mission) {
  const status = String(mission?.status || '').toLowerCase();
  if (mission?.verifier_result?.passed && (status === 'complete' || status === 'ready')) return 'verified and ready';
  if (status === 'complete' || status === 'ready') return 'ready for review';
  if (status === 'running') return 'working now';
  if (status === 'blocked' || status === 'paused') return 'needs your input';
  return 'queued';
}

function buildMemberImpactChain({ summary, verified, goalWhy, nextPush, skills = [] }) {
  const action = compactSentence(scrubFeedJargon(summary || 'Shipped one bounded slice'), 100);
  const rawConsequence = verified
    ? (goalWhy ? scrubFeedJargon(goalWhy) : 'Verified check passed so this slice stays solid')
    : (goalWhy ? scrubFeedJargon(goalWhy) : 'Work is in flight toward a verified check');
  const consequence = compactSentence(rawConsequence, 100);
  const skillHint = Array.isArray(skills) && skills.length ? `Sharpens ${skills[0]} and queues the next optimization` : 'Queues the next optimization automatically';
  const compounding = compactSentence(scrubFeedJargon(nextPush || skillHint), 110);
  return {
    action,
    consequence,
    compounding,
    arrow: `${action} -> ${consequence} -> ${compounding}`,
  };
}

// Rows that only look like work: placeholder goals, wake and blocked
// notices, empty "logged update" rows, and raw commands.
function isFeedFillerText(text) {
  const t = String(text || '').trim();
  if (!t) return true;
  if (/^serve the team as\b/i.test(t)) return true;
  if (/^member (wake|goal-from-mission|goal created|initialized)\b/i.test(t)) return true;
  if (/^\[?logged update\]?$/i.test(t)) return true;
  if (/^(next[_ ]push|verdict):/i.test(t)) return true;
  if (/^[`'"]?atris\s/i.test(t) || /\batris\s+[a-z-]+\s+[a-z-]+\s+--[a-z]/i.test(t)) return true;
  return false;
}

// How a row was checked, in words a reader can follow without the command.
function plainFeedCheckLabel(state, verifierCommand = '') {
  if (state === 'failed') return 'check failed, needs another pass';
  if (state !== 'passed') return 'not checked yet';
  const cmd = String(verifierCommand || '');
  if (/\b(npm|pnpm|yarn)\s+(run\s+)?test\b|--test\b|\bpytest\b|\bjest\b|\bvitest\b/i.test(cmd)) return 'checked: tests passed';
  if (/git\s+diff\s+--check/i.test(cmd)) return 'checked: the change has no whitespace errors';
  if (/\b(lint|eslint|tsc)\b/i.test(cmd)) return 'checked: lint passed';
  return 'checked: its check passed';
}

function feedEntryTimeMs(file, header, fallbackMs) {
  const day = String(file).match(/^(\d{4})-(\d{2})-(\d{2})\.md$/);
  const clock = String(header).match(/^(\d{2}):(\d{2})\b/);
  if (!day) return fallbackMs;
  const ms = new Date(Number(day[1]), Number(day[2]) - 1, Number(day[3]), clock ? Number(clock[1]) : 23, clock ? Number(clock[2]) : 59).getTime();
  return Number.isFinite(ms) ? Math.min(ms, fallbackMs || ms) : fallbackMs;
}

// The feed reads member log entries that say what changed. Mission records
// only hold the assignment, so they are used to name how the work was checked.
function collectMemberWorkFeed(root = process.cwd(), options = {}) {
  const teamDir = path.join(root, 'atris', 'team');
  const members = findAllMembers(teamDir).filter(isFleetMember);
  const filterMember = String(options.member || '').trim().toLowerCase();
  const limit = Number.isFinite(Number(options.limit)) && Number(options.limit) > 0 ? Number(options.limit) : 15;

  const verifierByObjective = new Map();
  for (const mission of memberRunMissionMap(root).values()) {
    const objective = String(mission?.objective || '').trim();
    if (objective && mission?.verifier) verifierByObjective.set(`${mission.owner}\u0000${objective}`, String(mission.verifier));
  }

  const items = [];
  for (const record of members) {
    const slug = memberSlugFromRecord(record);
    if (filterMember && slug.toLowerCase() !== filterMember) continue;
    const logsDir = path.join(teamDir, slug, 'logs');
    if (!fs.existsSync(logsDir)) continue;
    const mDir = path.join(teamDir, slug);
    let goalWhy = null;
    try {
      goalWhy = memberGoalPlaneStatus(slug, { memberDir: mDir, goalsFile: path.join(mDir, 'goals.json') })?.goal?.why || null;
    } catch {}
    const skills = listMemberUnlockedSkills(mDir, record.skills);
    const logFiles = fs.readdirSync(logsDir).filter((f) => f.endsWith('.md')).sort().slice(-7);
    for (const file of logFiles) {
      const fullPath = path.join(logsDir, file);
      let raw = '';
      let mtimeMs = 0;
      try {
        raw = fs.readFileSync(fullPath, 'utf8');
        mtimeMs = fs.statSync(fullPath).mtimeMs || 0;
      } catch {
        continue;
      }
      for (const section of raw.split(/^##\s+/m).slice(1)) {
        const lines = section.trim().split(/\r?\n/);
        const header = lines[0] || '';
        const title = header.replace(/^\d{2}:\d{2}\s*·\s*/, '');
        if (isFeedFillerText(title)) continue;
        const field = (name) => {
          const line = lines.find((l) => new RegExp(`^-\\s*${name}:`, 'i').test(l));
          return line ? line.replace(new RegExp(`^-\\s*${name}:\\s*`, 'i'), '').trim() : '';
        };
        // No summary means nothing was recorded as changed: skip the row.
        const rawSummary = field('summary');
        if (isFeedFillerText(rawSummary)) continue;
        const cleanSummary = compactSentence(scrubFeedJargon(rawSummary), 140);
        if (!cleanSummary || isFeedFillerText(cleanSummary)) continue;
        if (items.some((item) => item.member === slug && item.summary === cleanSummary)) continue;
        const verifierState = (field('verifier').match(/^(passed|failed)/i)?.[1] || '').toLowerCase();
        const passed = verifierState === 'passed';
        const verifierCommand = verifierByObjective.get(`${slug}\u0000${field('mission')}`) || '';
        const rawNextPush = field('next_push') || field('next push');
        const nextPush = isFeedFillerText(rawNextPush) ? '' : compactSentence(scrubFeedJargon(rawNextPush), 110);
        const atMs = feedEntryTimeMs(file, header, mtimeMs);
        const impactChain = buildMemberImpactChain({
          summary: cleanSummary,
          verified: passed,
          goalWhy,
          nextPush,
          skills,
        });
        items.push({
          member: slug,
          role: record.role || 'Team Member',
          at: new Date(atMs).toISOString(),
          at_ms: atMs,
          age: ageLabelFromMs(atMs),
          summary: cleanSummary,
          checked: plainFeedCheckLabel(verifierState, verifierCommand),
          status: passed ? 'verified and ready' : verifierState === 'failed' ? 'check failed' : 'not checked yet',
          verified: passed,
          next_push: nextPush || null,
          impact_chain: impactChain,
        });
      }
    }
  }

  return items
    .sort((a, b) => (b.at_ms || 0) - (a.at_ms || 0))
    .slice(0, limit);
}

function formatMemberFeedRow(item, indent = '') {
  const tail = item.next_push ? ` · next: ${item.next_push}` : '';
  return [
    `${indent}${item.age.padEnd(4)} · ${item.member}: ${item.summary}`,
    `${indent}       ${item.checked}${tail}`,
  ];
}

function memberFeed(...args) {
  if (hasFlag(args, '--help') || hasFlag(args, '-h')) {
    console.log('Usage: atris member feed [--member <name>] [--limit N] [--json]');
    console.log('Shows a plain-language linear feed of real work across your team.');
    return;
  }
  const asJson = hasFlag(args, '--json');
  const memberFilter = readFlag(args, '--member', '') || readFlag(args, '--author', '');
  const limit = readNumberFlag(args, '--limit', 15);
  const feed = collectMemberWorkFeed(process.cwd(), { member: memberFilter, limit });
  const lines = !feed.length
    ? ['no real work yet']
    : ['Team work feed', ...feed.flatMap((item) => formatMemberFeedRow(item))];
  printJsonOrText(
    {
      ok: true,
      action: 'member_feed',
      items: feed,
    },
    lines,
    asJson,
  );
  return feed;
}

function extractMemberNorthStar(memberDir, fallbackDescription = '') {
  const missionPath = path.join(memberDir, 'MISSION.md');
  if (fs.existsSync(missionPath)) {
    try {
      const raw = fs.readFileSync(missionPath, 'utf8');
      const northStarMatch = raw.match(/##\s+North Star\s+([^\n#]+)/i);
      if (northStarMatch && northStarMatch[1].trim()) {
        return compactSentence(northStarMatch[1].trim(), 160);
      }
      const firstPara = raw
        .split(/\r?\n/)
        .map((l) => l.trim())
        .find((l) => l && !l.startsWith('#') && !l.startsWith('-'));
      if (firstPara) return compactSentence(firstPara, 160);
    } catch {}
  }
  return compactSentence(fallbackDescription || 'Execute bounded, verified work in this member lane.', 160);
}

function listMemberUnlockedSkills(memberDir, frontmatterSkills = []) {
  const skills = new Set();
  const skillsDir = path.join(memberDir, 'skills');
  if (fs.existsSync(skillsDir)) {
    try {
      for (const entry of fs.readdirSync(skillsDir)) {
        if (fs.existsSync(path.join(skillsDir, entry, 'SKILL.md'))) skills.add(entry);
      }
    } catch {}
  }
  for (const s of Array.isArray(frontmatterSkills) ? frontmatterSkills : []) {
    if (s && typeof s === 'string') skills.add(s.trim());
  }
  return [...skills];
}

function resolveMemberEngineSeat(memberSlug, root = process.cwd()) {
  const slug = String(memberSlug || '').trim().toLowerCase();
  const engineRole = slug === 'navigator'
    ? 'navigator'
    : (slug === 'validator' || slug === 'architect')
      ? 'validator'
      : 'executor';
  try {
    const { resolveEngineForRoleRanked } = require('../lib/engine-registry');
    const picked = resolveEngineForRoleRanked(engineRole, root, { taskType: engineRole });
    if (picked && picked.engine) {
      return {
        engine_id: picked.engine.id,
        tier: picked.engine.tier || 'pro',
        models: Array.isArray(picked.engine.models) ? picked.engine.models : [],
        role: engineRole,
        reason: picked.reason || `${picked.engine.id} selected for ${engineRole}.`,
      };
    }
  } catch {}
  return {
    engine_id: 'claude',
    tier: 'pro',
    models: ['claude'],
    role: engineRole,
    reason: 'Default engine seat.',
  };
}

function buildMemberSubagentShell(owner, role, engineId, objective, root = process.cwd()) {
  const cleanObjective = compactSentence(objective || `Advance ${owner} roadmap`, 160);
  const verify = inferMemberRunVerifier(owner, cleanObjective, root);
  return {
    role: `${owner} (${role || 'Team Member'})`,
    member: owner,
    engine: engineId || 'claude',
    objective: cleanObjective,
    verify,
    prompt: `You are ${owner} (${role || 'Team Member'}). Read atris/team/${owner}/MEMBER.md, MISSION.md, goals.json, and skills/. Execute one bounded slice for: "${cleanObjective}". Run verify: ${verify}. Report 3 lines: Found, Fixed, Next push.`,
    shell_command: `atris member run ${owner} ${JSON.stringify(cleanObjective)} --engine ${engineId || 'claude'} --ignite`,
  };
}

function buildMemberCard(name, root = process.cwd()) {
  const paths = requireMemberDir(name);
  const owner = paths.storageName || name;
  let fm = {};
  try {
    fm = parseFrontmatter(fs.readFileSync(paths.memberFile, 'utf8')) || {};
  } catch {}
  const goalPlane = memberGoalPlaneStatus(owner, paths);
  const mission = memberMissionSummary(owner, memberRunMissionMap(root), root);
  const activity = memberLastActivity(owner, paths, root);
  const verdict = memberVerdict({ mission, activity });
  const skills = listMemberUnlockedSkills(paths.memberDir, fm.skills);
  const northStar = extractMemberNorthStar(paths.memberDir, fm.description);
  const recentWork = collectMemberWorkFeed(root, { member: owner, limit: 3 });
  const engineSeat = resolveMemberEngineSeat(owner, root);

  const doingNow = mission.latest
    ? {
        summary: compactSentence(scrubFeedJargon(mission.latest.last_summary || mission.objective || mission.name || ''), 120),
        state: plainFeedStatusLabel(mission.latest),
        engine: mission.runner || engineSeat.engine_id || null,
        model: mission.model || null,
        worktree_branch: mission.worktree_branch || null,
        last_tick_age: mission.last_tick_age,
      }
    : null;

  const activeGoalTitle = goalPlane.goal?.title || null;
  const activeGoalWhy = goalPlane.goal?.why || null;
  const activeGoalNextPush = goalPlane.goal?.next_push || null;
  const latestItem = recentWork[0] || null;
  const isVerified = doingNow?.state === 'verified and ready' || Boolean(latestItem?.verified);
  const impactChain = buildMemberImpactChain({
    summary: doingNow?.summary || latestItem?.summary || activeGoalTitle || northStar,
    verified: isVerified,
    goalWhy: activeGoalWhy || northStar,
    nextPush: mission.latest?.last_next_push || activeGoalNextPush || activeGoalTitle,
    skills,
  });

  const nextMove = mission.live
    ? `atris member run ${owner} --mission ${mission.live.id} --ignite`
    : activeGoalTitle
      ? `atris member run ${owner} ${JSON.stringify(activeGoalTitle)} --ignite`
      : `atris interview ${owner}`;
  const roleLabel = fm.role || 'Team Member';
  const subagentShell = buildMemberSubagentShell(
    owner,
    roleLabel,
    engineSeat?.engine_id || 'claude',
    impactChain.compounding || activeGoalTitle || northStar,
    root,
  );

  return {
    member: owner,
    role: roleLabel,
    version: fm.version || '1.0.0',
    verdict,
    last_activity_age: activity.age,
    north_star: northStar,
    engine_seat: engineSeat,
    skills,
    impact_chain: impactChain,
    next_push: impactChain.compounding,
    subagent_shell: subagentShell,
    roadmap: {
      active_goal: activeGoalTitle,
      why: activeGoalWhy,
      acceptance: goalPlane.goal?.acceptance || [],
      doing_now: doingNow,
    },
    actions: {
      go: `atris member go ${owner}`,
      steer: `atris member steer ${owner} "<direction>"`,
      one_on_one: `atris member 1on1 ${owner}`,
      sleep: `atris member sleep ${owner}`,
    },
    recent_work: recentWork,
    next_move: nextMove,
  };
}

function renderMemberCardLines(card) {
  const skillsLabel = card.skills.length ? card.skills.join(', ') : 'none yet';
  const engineLabel = card.engine_seat ? `${card.engine_seat.engine_id} (${card.engine_seat.tier})` : 'auto';
  const goalLabel = card.roadmap.active_goal || 'none set yet (run atris member 1on1 ' + card.member + ')';
  const doingLabel = card.roadmap.doing_now
    ? `${card.roadmap.doing_now.summary} [${card.roadmap.doing_now.state}]`
    : 'idle, ready for next dispatch';
  const recentLines = card.recent_work.length
    ? card.recent_work.map((item) => `  - ${item.age}: ${item.summary} [${item.status}]`)
    : ['  - no verified runs logged yet'];

  return [
    `┌─ ${card.member} · ${card.role} (v${card.version}) · ${card.verdict.toLowerCase()} · engine: ${engineLabel}`,
    `│ North Star: ${card.north_star}`,
    `│ Skills:     ${skillsLabel}`,
    `│ Roadmap:    ${goalLabel}`,
    `│ Doing now:  ${doingLabel}`,
    `│ Loop:       ${card.impact_chain.arrow}`,
    `│ Next push:  ${card.next_push}`,
    `│ Recent work:`,
    ...recentLines,
    `└─ Controls:  go: ${card.actions.go} | 1on1: ${card.actions.one_on_one} | sleep: ${card.actions.sleep}`,
  ];
}

function memberCard(name, ...args) {
  if (hasFlag(args, '--help') || hasFlag(args, '-h') || name === '--help' || name === '-h') {
    console.log('Usage: atris member card <name|--all> [--json]');
    console.log('Shows a member\'s long-horizon roadmap, unlocked skills, current work, and recent wins.');
    return;
  }
  const asJson = hasFlag(args, '--json') || name === '--json';
  if (!name || name === '--all' || name === 'all' || name === '--json') {
    const teamDir = path.join(process.cwd(), 'atris', 'team');
    const coreOrder = ['auto-improver', 'navigator', 'executor', 'validator', 'architect', 'customer-lead', 'researcher'];
    const allSlugs = findAllMembers(teamDir)
      .filter(isFleetMember)
      .map(memberSlugFromRecord);
    const ordered = [
      ...coreOrder.filter((s) => allSlugs.includes(s)),
      ...allSlugs.filter((s) => !coreOrder.includes(s) && hasFlag(args, '--all')),
    ];
    const cards = ordered.map((slug) => buildMemberCard(slug, process.cwd()));
    printJsonOrText(
      { ok: true, action: 'member_card_all', cards },
      cards.flatMap((c) => [...renderMemberCardLines(c), '']),
      asJson,
    );
    return cards;
  }
  const card = buildMemberCard(name, process.cwd());
  printJsonOrText(
    { ok: true, action: 'member_card', card },
    renderMemberCardLines(card),
    asJson,
  );
  return card;
}

function isKnownMemberSlug(token, root = process.cwd()) {
  const clean = String(token || '').trim();
  if (!clean || clean.startsWith('-')) return false;
  return fs.existsSync(path.join(root, 'atris', 'team', clean, 'MEMBER.md'))
    || fs.existsSync(path.join(root, 'atris', 'team', `${clean}.md`));
}

const MEMBER_SUBCOMMANDS = [
  'list', 'roster', 'create', 'install', 'activate', 'upgrade', 'push', 'pull', 'goal',
  'chat', 'tick', 'wake', 'run', 'result', 'go', 'work', 'up', 'steer', 'sleep', 'rest',
  'room', 'day', 'standup', 'handoff', 'dispatch', 'feed', 'board', 'stop', 'card', 'ping',
  'loop', 'alive', 'review', 'block', 'status', 'live', 'heartbeat', 'improvements',
  'report', 'history', 'supervisor', 'export', 'archive', 'tidy', 'help',
];

// `atris member <word>` where the word is neither a member nor a subcommand.
// Points at the nearest name and the team, and exits 1 without running anyone.
function memberUnknownWord(word, root = process.cwd()) {
  const { suggestCommand } = require('../lib/known-commands');
  let names = [];
  try { names = findAllMembers(path.join(root, 'atris', 'team')).map((m) => m.name); } catch {}
  const near = suggestCommand(word, [...MEMBER_SUBCOMMANDS, ...names]);
  console.log(`No member or command named "${word}", so nothing started.`);
  if (near) console.log(`Did you mean: atris member ${near}`);
  if (names.length) console.log(`Your team: ${names.join(', ')}`);
  console.log('To give a member a job: atris member run "<job in a few words>"');
  process.exitCode = 1;
  return { ok: false, reason: 'unknown_word', word, suggestion: near || null };
}

// The job a member does (build, review or search), read from the same team
// roster that picks its engine.
function memberGoJob(owner, root) {
  const byRole = { navigator: 'search', executor: 'build', validator: 'review' };
  try {
    const seat = require('../lib/member-engine').resolveEngineForMember(owner, root);
    return byRole[seat.role] || byRole[seat.job_key] || 'build';
  } catch {
    return 'build';
  }
}

// With no idea given, member go takes the next real job from the task list:
// the oldest open task that fits the member's job. A dry run only looks.
// requireCheck: only tasks with a runnable check count.
function memberGoTask(owner, root, { claim, requireCheck = false }) {
  try {
    const taskDb = require('../lib/task-db');
    const picker = require('../lib/member-task-pick');
    const db = taskDb.open();
    const job = memberGoJob(owner, root);
    const workspaceRoot = taskDb.workspaceRoot(root);
    if (claim) {
      const got = picker.claimTaskForMember(taskDb, db, { workspaceRoot, member: owner, job, requireCheck, recoverClaimed: true });
      return got ? { ...got, job } : null;
    }
    const task = picker.pickTaskForMember(taskDb, db, { workspaceRoot, member: owner, job, requireCheck, recoverClaimed: true });
    return task ? { task, objective: picker.taskObjective(task), job } : null;
  } catch (error) {
    console.error(`could not take a task from the list: ${String(error && error.message || error).split('\n')[0]}`);
    return null;
  }
}

// A pulled task leaves the run in review when the run's check passed (the
// mission is complete, or ready: checked and waiting on a person), else back
// on the list with a one-line reason.
function memberGoFinishTask(owner, task, result, thrown = null) {
  const taskDb = require('../lib/task-db');
  const db = taskDb.open();
  const mission = (result && result.mission) || {};
  const receipt = (result && result.work_step && result.work_step.receipt_path) || mission.receipt_path || '';
  const required = require('../lib/member-task-pick').taskCheck(task).command;
  const checked = mission.verifier_result && mission.verifier_result.passed === true
    && (!required || String(mission.verifier_result.command || '').trim() === required);
  // The commit comes from the member's own work copy, not the main folder.
  const workRoot = (result && result.worktree && result.worktree.path) || (mission.worktree && mission.worktree.path) || undefined;
  const passed = !thrown && result && result.started && ['complete', 'ready'].includes(mission.status) && checked;
  const changedNothing = passed && selfWrittenJob(task) && !runChangedSomething(taskDb, db, task, result, workRoot);
  if (passed && !changedNothing) {
    const proof = [`[verified] ${owner} ran mission ${result.mission_id} and its check passed.`,
      receipt ? `Receipt: ${receipt}` : ''].filter(Boolean).join('\n');
    const ready = taskDb.readyTask(db, { id: task.id, actor: owner, proof, workRoot });
    if (ready.ready !== false) return { id: task.id, title: task.title, outcome: 'review', receipt: receipt || null };
    // Its change already merged and the merge line closed the job.
    if (taskDb.getTask(db, task.id)?.status === 'done') return { id: task.id, title: task.title, outcome: 'done', receipt: receipt || null };
  }
  const ticks = Array.isArray(result && result.ticks) ? result.ticks : [];
  const lastReason = String((ticks[ticks.length - 1] || {}).reason || (ticks[ticks.length - 1] || {}).error || '');
  const outOfTime = /timeout|wall-exceeded/.test(lastReason);
  const why = thrown ? thrown.message
    : changedNothing ? 'the run passed its check but changed nothing: no new commit, no pushed branch, no pull request'
    : outOfTime ? 'ran out of time before the work finished'
    : (result && result.error) || (result && result.started ? 'the check did not pass' : 'the run did not start');
  const reason = String(why || 'the run did not finish').split(/\r?\n/)[0].trim().slice(0, 200);
  try { taskDb.noteTask(db, { id: task.id, actor: owner, content: `Released by ${owner}: ${reason}` }); } catch {}
  // Work staged on a protected surface waits for a person to review it; a
  // member picking the task again would only redo it and stop again.
  let held = false;
  const forReview = Boolean(!thrown && result && result.needs_review === true);
  if (forReview) {
    try {
      held = taskDb.tagTask(db, { id: task.id, actor: owner, add: ['needs-human'] }).tagged === true;
      if (held) taskDb.noteTask(db, { id: task.id, actor: owner, content: `Held for a person to review: ${reason}` });
    } catch {}
  }
  // Third failure in a row: hold the task for a person instead of letting
  // members pick it up again forever.
  if (!held && memberGoFailStreak(taskDb, db, task.id) >= MEMBER_GO_STRIKES) {
    try {
      held = taskDb.tagTask(db, { id: task.id, actor: owner, add: ['needs-human'] }).tagged === true;
      if (held) taskDb.noteTask(db, { id: task.id, actor: owner,
        content: `Held for a person: failed ${MEMBER_GO_STRIKES} times in a row. Last reason: ${reason}` });
    } catch {}
  }
  const released = taskDb.releaseTask(db, { id: task.id, actor: owner });
  const outcome = released.released ? (held ? 'needs_human' : 'released') : 'left_claimed';
  return { id: task.id, title: task.title, outcome, reason, ...(held && forReview ? { held_for: 'review' } : {}) };
}

// A job the member wrote for itself from its mission ("next step toward:").
function selfWrittenJob(task) {
  return String((task && task.source_key) || '').startsWith('self-next:')
    || (task && task.metadata && task.metadata.source === 'member mission');
}

// Did the run leave something for review? A pushed branch, a pull request,
// or a local landing counts, and so does a commit in the work copy that
// changes files since the job started. With no start commit on record there
// is nothing to compare, so the run is taken at its word.
function runChangedSomething(taskDb, db, task, result, workRoot) {
  const landed = result && result.autoland;
  if (landed && (landed.pushed || landed.url || landed.merged)) return true;
  const start = String((taskDb.getTask(db, task.id) || task)?.metadata?.start_commit || '').trim();
  if (!start) return true;
  const cwd = workRoot || task.workspace_root || process.cwd();
  const diff = spawnSync('git', ['diff', '--quiet', start, 'HEAD'], { cwd, encoding: 'utf8' });
  // Exit 0 means no change. Exit 1 means the code differs; anything else
  // could not be read, so the run is taken at its word.
  return diff.status !== 0;
}

const MEMBER_GO_STRIKES = 3;

// Failed runs on a task since its last pass, review, reopen, or a person
// clearing its hold.
function memberGoFailStreak(taskDb, db, taskId) {
  let streak = 0;
  for (const event of taskDb.listTaskEvents(db, { taskId })) {
    const type = event.event_type;
    const payload = event.payload || {};
    if (type === 'message' && /^Released by \S+: /.test(String(payload.content || ''))) streak += 1;
    else if (['proof_ready', 'reviewed', 'reopened'].includes(type)) streak = 0;
    else if (type === 'task_tags_updated' && (payload.removed || []).includes('needs-human')) streak = 0;
  }
  return streak;
}

async function memberSteerOrDispatch(...rawArgs) {
  return memberSteerOrDispatchWith({}, rawArgs);
}

async function memberSteerOrDispatchWith({ pullTask = false } = {}, rawArgs = []) {
  if (hasFlag(rawArgs, '--help') || hasFlag(rawArgs, '-h')) {
    console.log('Usage: atris member steer [member] [--no-ignite] [--detach] [--dry-run] [--json] [--] "<direction>"');
    console.log('       atris member "<direction>" [--dry-run] [--json]');
    console.log('Steers a running member mid-flight or dispatches the best specialist if idle.');
    console.log('  --no-ignite  only reach a live run; with nothing running, start nothing and exit 3');
    console.log('  --detach     when it starts the member, run it in the background and return its pid');
    console.log('  --           everything after it is the direction, never an option');
    return;
  }
  const root = process.cwd();
  // everything after -- is the direction: words a person typed are never options
  const cut = rawArgs.indexOf('--');
  const optionArgs = cut >= 0 ? rawArgs.slice(0, cut) : rawArgs;
  const directionArgs = cut >= 0 ? rawArgs.slice(cut + 1) : [];
  const asJson = hasFlag(optionArgs, '--json');
  const dryRun = hasFlag(optionArgs, '--dry-run');
  const noIgnite = hasFlag(optionArgs, '--no-ignite');
  const detach = hasFlag(optionArgs, '--detach');
  // Set by `member up`: run only a claimed task with a runnable check, never
  // the member's own goal text.
  const needsCheck = pullTask && hasFlag(optionArgs, '--needs-check');
  const valueFlags = new Set(['--engine', '--model', '--verify', '--referee-engine', '--minutes', '--hours', '--max-ticks', '--from']);
  const positionals = [];
  const flagArgs = [];
  for (let i = 0; i < optionArgs.length; i++) {
    const token = String(optionArgs[i] || '');
    if (!token) continue;
    if (token.startsWith('-')) {
      if (token === '--needs-check' || token === '--no-ignite' || token === '--detach') continue;
      flagArgs.push(token);
      if (valueFlags.has(token) && i + 1 < optionArgs.length) {
        flagArgs.push(optionArgs[i + 1]);
        i++;
      }
      continue;
    }
    positionals.push(token);
  }
  for (const token of directionArgs) if (String(token || '')) positionals.push(String(token));

  let targetMember = null;
  let prompt = '';
  let whyPicked = '';
  if (positionals.length > 0 && isKnownMemberSlug(positionals[0], root)) {
    targetMember = positionals[0];
    prompt = positionals.slice(1).join(' ').trim();
    whyPicked = `Explicitly targeted ${targetMember}.`;
  } else {
    prompt = positionals.join(' ').trim();
    const picked = pickMemberForIdea(prompt, root);
    targetMember = picked.member;
    whyPicked = picked.reason || picked.why || `fits ${picked.member} responsibilities`;
  }

  const paths = requireMemberDir(targetMember);
  const owner = paths.storageName || targetMember;
  let fm = {};
  try {
    fm = parseFrontmatter(fs.readFileSync(paths.memberFile, 'utf8')) || {};
  } catch {}
  const goalPlane = memberGoalPlaneStatus(owner, paths);
  const missionMap = memberRunMissionMap(root);
  const missionSummary = memberMissionSummary(owner, missionMap, root);
  // --no-ignite only reaches a live run: with nothing running it starts
  // nothing and touches nothing, and says so
  if (noIgnite && !missionSummary.live) {
    const payload = { ok: false, action: 'member_not_running', member: owner };
    printJsonOrText(payload, [`${owner} is not running, so nothing was sent or started.`], asJson);
    process.exitCode = 3;
    return payload;
  }
  // --detach answers before the background run starts, so the cheap checks
  // run here first: a member that cannot run is refused with the plain reason
  if (detach && !dryRun) {
    const refusal = memberRefusalFor(targetMember, paths.memberFile)
      || (resolveMemberEngineSeat(owner, root).engine_id ? '' : `no engine is set for ${owner}`);
    if (refusal) {
      const payload = { ok: false, action: 'member_run_not_started', member: owner, reason: refusal };
      printJsonOrText(payload, [`${owner} did not start: ${refusal}`], asJson);
      process.exitCode = 1;
      return payload;
    }
  }
  // A human or odd-typed member never takes a task: it would be claimed and
  // then stranded when the run refuses the member.
  const pulled = pullTask && !prompt && !missionSummary.live_mission && !memberRefusalFor(targetMember, paths.memberFile)
    ? memberGoTask(owner, root, { claim: !dryRun, requireCheck: needsCheck })
    : null;
  if (needsCheck && !pulled) {
    const payload = { ok: true, action: 'member_go', mode: 'idle', member: owner, reason: 'no task with a check' };
    printJsonOrText(payload, [`${owner} is idle, no task with a check`], asJson);
    process.exitCode = require('../lib/member-up').IDLE_EXIT;
    return payload;
  }
  const effectivePrompt = prompt
    || pulled?.objective
    || goalPlane.goal?.next_push
    || goalPlane.goal?.title
    || extractMemberNorthStar(paths.memberDir, '');
  const pulledTask = pulled ? { id: pulled.task.id, title: pulled.task.title, job: pulled.job } : null;
  // The supervisor's preview can lose a race. Only the child that claimed
  // the task may announce which job it actually got.
  if (needsCheck && pulledTask && !dryRun && process.connected && process.send) {
    process.send({ type: 'member_task_claimed', member: owner, task: pulledTask }, () => {});
  }
  if (pulled) whyPicked = `${whyPicked} Took the oldest open ${pulled.job} task from the list.`.trim();
  const engineSeat = resolveMemberEngineSeat(owner, root);
  const { autoQueueMemberNextPush, closeMemberHandoffsForReceiver } = require('./mission');
  const subagentShell = buildMemberSubagentShell(owner, fm.role || 'Team Member', engineSeat.engine_id, effectivePrompt, root);

  if (effectivePrompt && !pulled) {
    try {
      autoQueueMemberNextPush(owner, effectivePrompt, missionSummary.live?.objective || '', root);
    } catch {}
  }
  if (!dryRun) {
    try {
      closeMemberHandoffsForReceiver(owner, root);
    } catch {}
  }

  if (missionSummary.live) {
    if (!dryRun) {
      try {
        const liveM = missionSummary.live;
        const targetRoot = liveM.worktree_root || root;
        const missionsFile = path.join(targetRoot, '.atris', 'state', 'missions.jsonl');
        const nextPings = [
          ...(Array.isArray(liveM.pings) ? liveM.pings : []),
          { at: new Date().toISOString(), from: 'operator', text: effectivePrompt },
        ];
        const updatedMission = {
          ...liveM,
          pings: nextPings,
          last_next_push: effectivePrompt,
          updated_at: new Date().toISOString(),
        };
        fs.mkdirSync(path.dirname(missionsFile), { recursive: true });
        fs.appendFileSync(missionsFile, `${JSON.stringify(updatedMission)}\n`, 'utf8');
      } catch {}
    }
    const payload = {
      ok: true,
      action: 'member_steered',
      mode: 'steered_live',
      dry_run: dryRun,
      member: owner,
      mission_id: missionSummary.live.id,
      engine: missionSummary.runner || engineSeat.engine_id,
      prompt: effectivePrompt,
      why: whyPicked,
      subagent_shell: subagentShell,
    };
    const lines = [
      `Steered ${owner} mid-run (${missionSummary.live.id}).`,
      `Direction: ${effectivePrompt}`,
      `Consequence: ${owner} will read this steer on the next loop and adjust course.`,
    ];
    printJsonOrText(payload, lines, asJson);
    return payload;
  }

  // --detach: the same steer runs in the background, so a caller with a
  // short timeout gets started or not-started at once
  if (detach && !dryRun) {
    const { spawn } = require('child_process');
    const childArgs = [...optionArgs.filter(a => a !== '--detach' && a !== '--json'), ...(cut >= 0 ? ['--', ...directionArgs] : [])];
    let child;
    try {
      child = spawn(process.execPath, [process.argv[1], 'member', 'steer', ...childArgs], { cwd: root, detached: true, stdio: 'ignore', env: { ...process.env, ATRIS_SKIP_UPDATE_CHECK: '1' } });
      child.unref();
    } catch (error) {
      const payload = { ok: false, action: 'member_run_not_started', member: owner, error: String(error.message || error) };
      printJsonOrText(payload, [`${owner} did not start: ${payload.error}`], asJson);
      process.exitCode = 1;
      return payload;
    }
    const payload = { ok: true, action: 'member_run_detached', member: owner, pid: child.pid };
    printJsonOrText(payload, [`${owner} started in the background (pid ${child.pid}).`], asJson);
    return payload;
  }

  const command = `atris member run ${owner} ${JSON.stringify(effectivePrompt)} --engine ${engineSeat.engine_id} --ignite`;
  if (dryRun) {
    const payload = {
      ok: true,
      action: 'member_go',
      mode: 'dispatched_idle',
      dry_run: true,
      member: owner,
      engine: engineSeat.engine_id,
      engine_reason: engineSeat.reason,
      prompt: effectivePrompt,
      why: whyPicked,
      task: pulledTask,
      command,
      subagent_shell: subagentShell,
    };
    const lines = [
      `Routed to ${owner} on engine ${engineSeat.engine_id}: ${whyPicked}`,
      ...(pulledTask ? [`Task: ${pulledTask.title}`] : []),
      `Objective: ${effectivePrompt}`,
      `Next: ${command}`,
    ];
    printJsonOrText(payload, lines, asJson);
    return payload;
  }

  if (!asJson) {
    console.log(`Routed to ${owner} on engine ${engineSeat.engine_id}: ${whyPicked}`);
  }
  const hasExplicitEngine = flagArgs.includes('--engine');
  const nextFlags = hasExplicitEngine ? flagArgs : ['--engine', engineSeat.engine_id, ...flagArgs];
  if (!pulled) return memberRun(owner, effectivePrompt, '--ignite', ...nextFlags);
  // A pulled task runs with the check it requires, not the member's own.
  const required = require('../lib/member-task-pick').taskCheck(pulled.task).command;
  const runFlags = required ? [...stripKnownFlags(nextFlags, ['--verify'], []), '--verify', required] : nextFlags;
  let result = null;
  try {
    // The job rides to the merge line so it closes itself when its change merges.
    result = await memberRunWith(owner, [effectivePrompt, '--ignite', ...runFlags], { quiet: asJson, closeTaskIds: [pulled.task.id] });
  } catch (error) {
    memberGoFinishTask(owner, pulled.task, null, error);
    throw error;
  }
  const task = memberGoFinishTask(owner, pulled.task, result);
  const merged = { ...(result || {}), task };
  if (asJson) console.log(JSON.stringify(needsCheck
    ? { task, work_step: { summary: result?.work_step?.summary || null }, error: result?.error || null }
    : merged));
  else if (task.outcome === 'review') console.log(`Task "${task.title}" is ready for review.`);
  else if (task.outcome === 'done') console.log(`Task "${task.title}" merged and closed itself.`);
  else if (task.outcome === 'needs_human' && task.held_for === 'review') console.log(`Task "${task.title}" waits for a person to review it: ${task.reason}`);
  else if (task.outcome === 'needs_human') console.log(`Task "${task.title}" failed three times in a row and now waits for a person: ${task.reason}`);
  else console.log(`Task "${task.title}" went back on the list: ${task.reason}`);
  return merged;
}

async function memberGo(...rawArgs) {
  if (hasFlag(rawArgs, '--help') || hasFlag(rawArgs, '-h')) {
    console.log('Usage: atris member go [member|"<direction>"] [--dry-run] [--json]');
    console.log('Wakes the highest-leverage member on their next_push, or routes a prompt to the right specialist.');
    return;
  }
  const nonFlags = rawArgs.filter((a) => a && !String(a).startsWith('-'));
  if (nonFlags.length > 0) {
    return memberSteerOrDispatchWith({ pullTask: true }, rawArgs);
  }
  const root = process.cwd();
  const teamDir = path.join(root, 'atris', 'team');
  const coreOrder = ['auto-improver', 'executor', 'navigator', 'validator', 'architect', 'customer-lead', 'researcher'];
  let chosen = '';
  for (const slug of coreOrder) {
    const mDir = path.join(teamDir, slug);
    if (!fs.existsSync(path.join(mDir, 'MEMBER.md'))) continue;
    if (!chosen) chosen = slug;
    const gp = memberGoalPlaneStatus(slug, { memberDir: mDir, goalsJson: path.join(mDir, 'goals.json') });
    if (gp?.goal?.next_push || gp?.goal?.title) {
      chosen = slug;
      break;
    }
  }
  if (!chosen) {
    const fallback = findAllMembers(teamDir).filter(isFleetMember)[0];
    if (fallback) chosen = memberSlugFromRecord(fallback);
  }
  return memberSteerOrDispatchWith({ pullTask: true }, [chosen, ...rawArgs]);
}

// Where a running `atris member up` leaves its pid, so a whole-team sleep
// can end it.
function memberUpPidFile(root) {
  return path.join(root, '.atris', 'state', 'member-up.json');
}

// A member slept by name stays asleep for member up until someone wakes it;
// a whole-team sleep only rests the team for now.
function memberSleepingByChoice(latest) {
  return Boolean(latest && latest.status === 'paused' && latest.stop_reason === 'member-sleep'
    && latest.sleep_target === 'member');
}

function memberUpTeam(root) {
  const { isMemberParked } = require('../lib/member-park');
  const missionMap = memberRunMissionMap(root);
  return findAllMembers(path.join(root, 'atris', 'team')).filter(isFleetMember).map((record) => {
    const name = memberSlugFromRecord(record);
    const summary = memberMissionSummary(name, missionMap, root);
    return {
      name,
      parked: isMemberParked(root, name),
      human: Boolean(memberRefusalFor(name, path.join(root, 'atris', 'team', name, 'MEMBER.md'))),
      sleeping: memberSleepingByChoice(summary.latest),
      live: Boolean(summary.live_mission),
    };
  });
}

// The task `member go <name>` would claim, skipping ones already handed out.
// Looks only; the child claims it.
function memberUpPick(root, name, taken) {
  try {
    const taskDb = require('../lib/task-db');
    const { fittingTasks } = require('../lib/member-task-pick');
    const db = taskDb.open();
    const job = memberGoJob(name, root);
    return fittingTasks(taskDb, db, { workspaceRoot: taskDb.workspaceRoot(root), member: name, job, requireCheck: true, recoverClaimed: true })
      .find((task) => !taken.has(task.id)) || null;
  } catch {
    return null;
  }
}

// An empty job list: write the member's next job from its own mission.
function memberUpWriteNextJob(root, name, { dryRun = false } = {}) {
  const taskDb = require('../lib/task-db');
  const { writeSelfNextJob } = require('../lib/member-self-next-job');
  const db = taskDb.open();
  return writeSelfNextJob(taskDb, db, {
    root,
    workspaceRoot: taskDb.workspaceRoot(root),
    member: name,
    job: memberGoJob(name, root),
    dryRun,
  });
}

// Every open task a member could start, with the job it needs.
function memberUpWaiting(root) {
  try {
    const taskDb = require('../lib/task-db');
    const { fittingTasks } = require('../lib/member-task-pick');
    const db = taskDb.open();
    const workspaceRoot = taskDb.workspaceRoot(root);
    return ['build', 'review', 'search'].flatMap((job) => fittingTasks(taskDb, db, { workspaceRoot, job, requireCheck: true })
      .map((task) => ({ id: task.id, title: task.title, job })));
  } catch {
    return [];
  }
}

function memberUpSpawn(root, name, onExit, onClaim) {
  const { spawn } = require('child_process');
  const logDir = path.join(root, '.atris', 'state', 'member-up');
  fs.mkdirSync(logDir, { recursive: true });
  const logFile = path.join(logDir, `${name}.log`);
  const out = fs.openSync(logFile, 'a');
  const start = fs.fstatSync(out).size;
  let child;
  try {
    child = spawn(process.execPath, [path.join(__dirname, '..', 'bin', 'atris.js'), 'member', 'go', name, '--needs-check', '--json'], {
      cwd: root,
      detached: true,
      // Children keep their log handle when the foreground supervisor stops.
      stdio: ['ignore', out, out, 'ipc'],
      env: process.env,
    });
  } finally {
    fs.closeSync(out);
  }
  child.on('message', (message) => {
    if (message?.type === 'member_task_claimed' && message.member === name) onClaim?.(message.task);
  });
  child.on('error', (error) => onExit(null, { ok: false, reason: error.message }));
  child.on('close', (code, signal) => {
    let output = '';
    let fd;
    try {
      fd = fs.openSync(logFile, 'r');
      const size = fs.fstatSync(fd).size;
      const from = Math.max(start, size - 64 * 1024);
      const buf = Buffer.alloc(Math.max(0, size - from));
      const read = fs.readSync(fd, buf, 0, buf.length, from);
      output = buf.subarray(0, read).toString('utf8');
    } catch {} finally {
      if (fd !== undefined) fs.closeSync(fd);
    }
    const { memberUpResult } = require('../lib/member-up');
    onExit(code, memberUpResult(output, '', signal));
  });
  return child;
}

async function memberUp(...args) {
  if (hasFlag(args, '--help') || hasFlag(args, '-h')) {
    console.log('Usage: atris member up [--max N] [--only a,b] [--dry-run]');
    console.log('Keeps the team working: every minute, starts each free member that has a fitting task with a runnable check.');
    console.log('A member with no such task writes its next job from its mission when the mission has a ## Check, then starts it.');
    console.log('Without a check it stays idle. At most one self-written job is open per member, and 3 a day.');
    console.log('The longer a member stays idle, the less often it is checked: 5, 10, 20, then every 30 minutes.');
    console.log('A working member with no new step for 20 minutes is called out as stuck, once until it moves again.');
    console.log('Every 5 minutes it also puts member changes github dropped from its merge line back in, when self-landing is on.');
    console.log('--only limits it to those members. Same as atris member wake 5 or atris member wake a b.');
    console.log('Ctrl-C or atris member sleep --all ends it. Runs it started keep going.');
    return;
  }
  const root = process.cwd();
  const { createMemberUp, runMemberUp, parseMemberUpArgs, DEFAULT_MAX } = require('../lib/member-up');
  const parsed = parseMemberUpArgs(args);
  if (parsed.error) {
    console.error(parsed.error);
    process.exitCode = 1;
    return;
  }
  const { max, only } = parsed;
  const deps = {
    listMembers: () => memberUpTeam(root),
    pickTask: (name, taken) => memberUpPick(root, name, taken),
    writeNextJob: (name, opts) => memberUpWriteNextJob(root, name, opts),
    spawn: (name, onExit, onClaim) => memberUpSpawn(root, name, onExit, onClaim),
    // the start lock handoffs share, so both count what the other started
    reserve: (fn) => require('../lib/handoff-wake').withWakeReservation(path.join(root, '.atris', 'state'), fn),
    now: () => Date.now(),
    jobOf: (name) => memberGoJob(name, root),
    waitingTasks: () => memberUpWaiting(root),
    requeueDropped: () => require('../lib/member-up').memberMaintenance({
      cwd: root,
      codeRoot: path.resolve(__dirname, '..'),
      requeueDropped: () => require('../lib/member-autoland').requeueDroppedAutolands({ cwd: root }),
      waitingTasks: () => memberUpWaiting(root),
    }),
  };
  if (parsed.dryRun) {
    const up = createMemberUp(deps, { max, only, dryRun: true });
    const started = up.check();
    if (!started.length && up.working() >= up.max) {
      console.log(`nothing to start: ${up.working()} already working, the limit is ${up.max}`);
    } else if (!started.length) {
      console.log('nothing to start: no free member has a task with a runnable check');
    }
    return started;
  }
  const pidFile = memberUpPidFile(root);
  fs.mkdirSync(path.dirname(pidFile), { recursive: true });
  fs.writeFileSync(pidFile, JSON.stringify({ pid: process.pid, started_at: new Date().toISOString() }));
  const loop = runMemberUp(deps, { max, only });
  const end = () => loop.stop();
  process.once('SIGINT', end);
  process.once('SIGTERM', end);
  const who = only ? ` for ${only.join(', ')}` : '';
  console.log(`team is up${who} (at most ${max || DEFAULT_MAX} at once). Ctrl-C to stop.`);
  await loop.done;
  process.removeListener('SIGINT', end);
  process.removeListener('SIGTERM', end);
  try {
    if (JSON.parse(fs.readFileSync(pidFile, 'utf8')).pid === process.pid) fs.unlinkSync(pidFile);
  } catch {}
  const working = loop.up.running();
  console.log(working.length ? `team is down; still finishing: ${working.join(', ')}` : 'team is down');
}

// Ends a running `atris member up`. Returns true when one was told to stop.
function stopMemberUp(root) {
  try {
    const { pid } = JSON.parse(fs.readFileSync(memberUpPidFile(root), 'utf8'));
    if (!Number.isInteger(pid) || pid === process.pid) return false;
    process.kill(pid, 'SIGTERM');
    return true;
  } catch {
    return false;
  }
}

function memberSleep(target, ...args) {
  if (hasFlag(args, '--help') || hasFlag(args, '-h') || target === '--help' || target === '-h') {
    console.log('Usage: atris member sleep [member|--all] [--json]');
    console.log('Cleanly parks active member loops so your team rests until you wake them.');
    return;
  }
  const root = process.cwd();
  const asJson = hasFlag(args, '--json') || target === '--json';
  const filterMember = target && !target.startsWith('-') && target !== 'all' ? target.trim().toLowerCase() : '';
  const { loadMissionMap } = require('./mission');
  const missions = loadMissionMap(root);
  const activeStatuses = new Set(['running', 'planning', 'ready']);
  const slept = [];

  for (const m of missions.values()) {
    if (!m || !activeStatuses.has(String(m.status || '').toLowerCase())) continue;
    const owner = String(m.owner || '').trim();
    if (filterMember && owner.toLowerCase() !== filterMember) continue;
    const updated = {
      ...m,
      status: 'paused',
      paused_at: new Date().toISOString(),
      stop_reason: 'member-sleep',
      sleep_target: filterMember ? 'member' : 'all',
      next_action: `sleeping; wake with: atris member go ${owner || ''}`.trim(),
      updated_at: new Date().toISOString(),
    };
    const missionsFile = path.join(root, '.atris', 'state', 'missions.jsonl');
    fs.mkdirSync(path.dirname(missionsFile), { recursive: true });
    fs.appendFileSync(missionsFile, `${JSON.stringify(updated)}\n`, 'utf8');
    slept.push({ mission_id: m.id, member: owner || 'mission-lead', objective: m.objective });
  }

  const supervisorStopped = !filterMember && stopMemberUp(root);
  const payload = {
    ok: true,
    action: 'member_sleep',
    supervisor_stopped: supervisorStopped,
    target: filterMember || 'all',
    slept_count: slept.length,
    slept,
    wake_command: filterMember ? `atris member go ${filterMember}` : 'atris member go',
  };
  const lines = slept.length
    ? [
        `Put ${slept.length} active member loop${slept.length === 1 ? '' : 's'} to sleep.`,
        ...slept.map((s) => `  - ${s.member}: ${s.objective}`),
        `Wake anytime: ${payload.wake_command}`,
      ]
    : [
        `All members are already resting.`,
        `Wake anytime: ${payload.wake_command}`,
      ];
  if (supervisorStopped) lines.unshift('Stopped member up; it starts nobody new.');
  printJsonOrText(payload, lines, asJson);
  return payload;
}

// The member's active goal plus how many times it was set, so a re-agreed
// goal with the same words still counts as the talk's next step.
function oneOnOneGoalMark(name, paths) {
  const goal = (loadMemberGoals(name, paths).goals || []).filter((g) => g && g.status === 'active').pop();
  return goal ? { title: goal.title, mark: `${goal.id}:${(goal.history || []).length}` } : { title: '', mark: '' };
}

function askOneOnOneNextStep(name) {
  const rl = require('readline').createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(`What is ${name}'s next step? `, (answer) => {
    rl.close();
    resolve(String(answer || '').trim());
  }));
}

// A 1-on-1 is a talk with the member in its own voice, and it ends with the
// member's next step saved as its active goal. The member records the step
// itself during the talk; --next or a closing question fills it in otherwise.
async function memberOneOnOne(name, ...args) {
  if (!name || name === '--help' || name === '-h' || hasFlag(args, '--help') || hasFlag(args, '-h')) {
    console.log('Usage: atris member 1on1 <name> [--next "..."]');
    console.log('Talk with a team member in its own voice. The talk ends with its next step saved as its goal.');
    return;
  }
  const paths = requireMemberDir(name);
  const next = readFlag(args, '--next', '');
  const rest = stripKnownFlags(args, ['--next'], []);
  const before = oneOnOneGoalMark(name, paths);
  const { interviewCommand } = require('./interview');
  const code = await interviewCommand([name, ...rest], process.cwd(), { mode: 'one_on_one' });
  if (code) {
    process.exitCode = code;
    return code;
  }
  let after = oneOnOneGoalMark(name, paths);
  if (after.mark === before.mark) {
    const step = next || (process.stdin.isTTY && process.stdout.isTTY ? await askOneOnOneNextStep(name) : '');
    if (step) {
      memberGoal(name, step);
      after = oneOnOneGoalMark(name, paths);
    }
  }
  if (after.title && after.mark !== before.mark) {
    console.log(`${name}'s next step: ${after.title}`);
    return 0;
  }
  console.log(`The 1-on-1 ended without a next step for ${name}.`);
  console.log(`Set one: atris member goal ${name} "..."`);
  process.exitCode = 1;
  return 1;
}

function collectMemberHandoffs(root = process.cwd(), cards = []) {
  const handoffsFile = path.join(root, '.atris', 'state', 'member-handoffs.jsonl');
  const recorded = readJsonlRowsIfExists(handoffsFile, 20)
    .filter((h) => h && h.from && h.to && (h.status || 'open') === 'open')
    .reverse();
  if (recorded.length > 0) return recorded.slice(0, 6);
  const relay = {
    researcher: 'navigator',
    'customer-lead': 'navigator',
    navigator: 'executor',
    architect: 'executor',
    executor: 'validator',
    'auto-improver': 'validator',
  };
  const inferred = [];
  for (const c of cards) {
    const to = relay[c.member];
    if (!to) continue;
    const state = c.roadmap?.doing_now?.state || '';
    if (state === 'verified and ready' || c.verdict === 'ACTIVE') {
      inferred.push({
        id: `relay_${c.member}_${to}`,
        from: c.member,
        to,
        summary: compactSentence(c.roadmap?.doing_now?.summary || c.roadmap?.active_goal || c.next_push, 90),
        status: 'ready',
        next_command: `atris member go ${to}`,
      });
    }
  }
  return inferred.slice(0, 4);
}

function collectMemberOneOnOnes(root = process.cwd(), slugs = []) {
  const queue = [];
  for (const slug of slugs) {
    try {
      const paths = requireMemberDir(slug);
      const gp = memberGoalPlaneStatus(slug, paths);
      if (!gp.goal) {
        queue.push({
          member: slug,
          reason: 'No active roadmap goal set yet',
          command: `atris member 1on1 ${slug}`,
        });
      } else if (gp.needsUser) {
        queue.push({
          member: slug,
          reason: gp.ask || 'Blocked and waiting on your answer',
          command: `atris member 1on1 ${slug}`,
        });
      }
    } catch {}
  }
  return queue;
}

// The env a woken member starts with: its own plain-terminal run, not part of
// the session or mission driver that handed off (those markers would turn the
// run into proof-only mode, a native-goal wait, or a child of the old driver).
const HANDOFF_WAKE_SCRUB_ENV = [
  'CLAUDECODE', 'CLAUDE_CODE_ENTRYPOINT', 'CODEX_SANDBOX', 'CURSOR_AGENT', 'DEVIN_SESSION_ID',
  'CODEX_THREAD_ID', 'CODEX_SESSION_ID', 'ATRIS_AGENT_ID',
  'ATRIS_MISSION_DRIVER_DETACHED', 'ATRIS_MISSION_DRIVER_PARENT_PID',
];

// Start the receiver of a handoff on the handed-off step: the same bounded
// work step `atris member wake <name>` runs (member run, 15 minutes), but
// detached, so the member handing off is not held while the next one works.
function startHandoffReceiver(root, to, step, parentMissionId = null) {
  const env = { ...process.env, ATRIS_CALLER_RUNTIME: 'terminal' };
  for (const name of HANDOFF_WAKE_SCRUB_ENV) delete env[name];
  // The handing-off mission's git guard (a temp folder of wrappers first on
  // PATH) belongs to that mission; the woken run sets up its own.
  env.PATH = String(env.PATH || '').split(path.delimiter)
    .filter((dir) => !path.basename(dir).startsWith(require('../lib/mission-protected-lane').GUARD_DIR_PREFIX))
    .join(path.delimiter);
  // Every woken run is under the fixed handoff seal, whatever handed off:
  // outward commands and merging to master wait for the owner's yes. The
  // parent only says where its yes cards show.
  // The seal goes by environment only, never on the command line the step
  // text shares, and every job the woken run starts inherits it. A step that
  // starts with "-" is quoted so it can never read as an option.
  env.ATRIS_HANDOFF_YES_LOCK = JSON.stringify(require('../lib/yes-lock').handoffSeal());
  if (parentMissionId) env.ATRIS_HANDOFF_YES_LOCK_PARENT = parentMissionId;
  else delete env.ATRIS_HANDOFF_YES_LOCK_PARENT;
  const stepText = /^\s*-/.test(String(step)) ? `step: ${String(step).trim()}` : String(step);
  const res = require('child_process').spawnSync(process.execPath, [
    path.join(__dirname, '..', 'bin', 'atris.js'),
    'member', 'run', to, stepText, '--minutes', '15', '--no-verify', '--detach', '--json',
  ], { cwd: root, env, encoding: 'utf8', timeout: 120000 });
  let payload = null;
  const lines = String(res.stdout || '').trim().split('\n');
  for (let i = lines.length - 1; i >= 0 && !payload; i -= 1) {
    try { payload = JSON.parse(lines.slice(i).join('\n')); } catch {}
  }
  const ok = res.status === 0 && Boolean(payload && payload.ok !== false && payload.mission_id);
  return {
    ok,
    mission_id: payload ? payload.mission_id || null : null,
    pid: payload ? payload.pid || null : null,
    worktree: payload && payload.worktree ? payload.worktree.path || null : null,
    error: ok ? null : String((payload && payload.error) || res.stderr || (res.error && res.error.message) || `member run exited ${res.status}`),
  };
}

// Whether to wake the receiver, and the outcome. Under the test runner a
// handoff only records unless ATRIS_HANDOFF_WAKE=1 asks, so suites that hand
// off never start a real engine by accident.
function wakeOnHandoff(handoff, root, args) {
  const testRun = Boolean(process.env.NODE_TEST_CONTEXT) && process.env.ATRIS_HANDOFF_WAKE !== '1';
  if (hasFlag(args, '--no-wake') || testRun) {
    return {
      status: 'not_started',
      reason: 'not_asked',
      text: `${handoff.to} was not started; the handoff is only written down. to start it: atris member wake ${handoff.to}`,
    };
  }
  const { wakeHandoffReceiver, withWakeReservation } = require('../lib/handoff-wake');
  const parent = handoffParentMission(handoff, root);
  const outcome = wakeHandoffReceiver(handoff, {
    listMembers: () => memberUpTeam(root),
    awake: (name) => {
      try { return require('../lib/member-switches').isMemberAwake(name, root); } catch { return true; }
    },
    engine: (name) => require('../lib/member-engine').memberRosterEngine(name, root),
    start: (name, step) => startHandoffReceiver(root, name, step, parent),
    reserve: (fn) => withWakeReservation(path.join(root, '.atris', 'state'), fn),
  });
  return outcome.status === 'started' ? { ...outcome, yes_lock: 'handoff', yes_lock_parent: parent } : outcome;
}

// The job a handoff came from, only to show the woken run's yes cards on it:
// the mission whose guard this command runs under (a handoff from inside a
// mission tick), else the job a [bet-...] tag in the step names. null when
// neither is found; what the woken run holds never depends on it.
function handoffParentMission(handoff, root) {
  const fromGuard = require('../lib/mission-protected-lane').guardMissionOnPath(process.env.PATH);
  if (fromGuard) return fromGuard;
  const bets = Array.from(String(handoff.summary || '').matchAll(/\[(bet-[A-Za-z0-9._-]+)\]/g)).map((m) => m[1]);
  if (!bets.length) return null;
  const dir = path.join(require('../lib/state-home').atrisHome(), 'state', 'yes-locks');
  let files = [];
  try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.json')); } catch {}
  for (const name of files) {
    try {
      const data = JSON.parse(fs.readFileSync(path.join(dir, name), 'utf8'));
      if (data && data.mission_id && bets.includes(data.bet_id)) return String(data.mission_id);
    } catch {}
  }
  return null;
}

function memberHandoff(from, to, ...args) {
  if (from === '--help' || from === '-h' || hasFlag(args, '--help') || hasFlag(args, '-h')) {
    console.log('Usage: atris member handoff [<from> <to> "<slice>"] [--no-wake] [--json]');
    console.log('Passes a completed slice from one member to the next specialist and queues their next_push.');
    console.log('The next member is started on the slice when it is not already working, unless the team is at its limit.');
    console.log('--no-wake only writes the handoff down.');
    return;
  }
  const root = process.cwd();
  const asJson = from === '--json' || to === '--json' || hasFlag(args, '--json');
  const sliceWords = [to, ...args].filter((a) => a && !String(a).startsWith('-'));
  if (!from || from.startsWith('-') || sliceWords.length < 2) {
    const room = buildMemberRoom(root);
    const lines = room.handoffs.length
      ? [
          'Active Member Handoffs:',
          ...room.handoffs.map((h) => `  - ${h.from} -> ${h.to}: ${h.summary} (run: ${h.next_command})`),
        ]
      : ['No open handoffs right now.'];
    printJsonOrText({ ok: true, action: 'member_handoffs', handoffs: room.handoffs }, lines, asJson);
    return room.handoffs;
  }
  const targetTo = sliceWords[0];
  const summary = sliceWords.slice(1).join(' ').trim();
  const { recordMemberHandoff, updateMemberHandoff, resolveMemberWorkspaceRoot } = require('./mission');
  const recorded = recordMemberHandoff(from, targetTo, summary, root);
  if (!recorded) {
    console.error(`Could not record handoff from ${from} to ${targetTo}. Check member names.`);
    process.exitCode = 1;
    return null;
  }
  const parentRoot = resolveMemberWorkspaceRoot(root);
  // the stored summary is cut at 180 characters; the wake gets the whole step
  const wake = { ...wakeOnHandoff({ ...recorded, summary }, parentRoot, args), at: new Date().toISOString() };
  const handoff = updateMemberHandoff(recorded.id, { wake }, parentRoot) || { ...recorded, wake };
  const lines = [
    `Handoff recorded: ${handoff.from} -> ${handoff.to}`,
    `Slice: ${handoff.summary}`,
    wake.text,
  ];
  printJsonOrText({ ok: true, action: 'member_handoff', handoff }, lines, asJson);
  return handoff;
}

function buildMemberRoom(root = process.cwd()) {
  const teamDir = path.join(root, 'atris', 'team');
  const coreOrder = ['auto-improver', 'navigator', 'executor', 'validator', 'architect', 'customer-lead', 'researcher'];
  const allSlugs = findAllMembers(teamDir)
    .filter(isFleetMember)
    .map(memberSlugFromRecord);
  const ordered = coreOrder.filter((s) => allSlugs.includes(s));
  const cards = ordered.map((slug) => buildMemberCard(slug, root));
  const feed = collectMemberWorkFeed(root, { limit: 6 });

  const standup = cards.map((c) => {
    const status = c.roadmap.doing_now ? c.roadmap.doing_now.state : c.verdict.toLowerCase();
    const latestUpdate = c.roadmap.doing_now?.summary
      || c.recent_work[0]?.summary
      || c.roadmap.active_goal
      || c.north_star;
    return {
      member: c.member,
      role: c.role,
      status,
      engine: c.engine_seat?.engine_id || 'auto',
      skills_count: c.skills.length,
      latest_update: compactSentence(latestUpdate, 92),
      consequence: c.impact_chain.consequence,
      next_push: compactSentence(c.next_push, 84),
      subagent_shell: c.subagent_shell,
      one_on_one: `atris member 1on1 ${c.member}`,
    };
  });

  const handoffs = collectMemberHandoffs(root, cards);
  const oneOnOnes = collectMemberOneOnOnes(root, ordered);

  let readyEngines = [];
  try {
    const { engineRegistryView } = require('../lib/engine-registry');
    readyEngines = engineRegistryView(root)
      .filter((e) => e.health && e.health.status === 'ready')
      .map((e) => ({
        id: e.id,
        tier: e.tier,
        roles: e.roles,
        models: e.models,
      }));
  } catch {}

  return {
    schema: 'atris.member.room.v1',
    utopia: {
      percent: 100,
      loop: 'ACTION: Plain prompt or click -> CONSEQUENCE: Verified two-model execution + SKILL.md lesson -> COMPOUNDING: Self-queued next_push + Moneyball engine routing -> UTOPIA: Autonomous team that improves forever',
    },
    engines: readyEngines,
    members: cards,
    standup,
    handoffs,
    one_on_ones: oneOnOnes,
    feed,
    controls: {
      go: 'atris member go',
      day: 'atris member day',
      handoff: 'atris member handoff <from> <to> "<slice>"',
      steer: 'atris member "<prompt>"',
      one_on_one: 'atris member 1on1 <member>',
      sleep: 'atris member sleep',
      feed: 'atris member feed',
    },
  };
}

async function memberStandupWalk(room, args = []) {
  const asJson = hasFlag(args, '--json');
  const limit = Number(readNumberFlag(args, '--limit', 0)) || room.standup.length;
  const rawDecisions = readFlag(args, '--decisions', '');
  const scripted = rawDecisions
    ? rawDecisions.split('|').map((s) => s.trim())
    : [];
  const slice = room.standup.slice(0, Math.max(1, limit));
  const { autoQueueMemberNextPush } = require('./mission');
  const results = [];

  let rl = null;
  if (!scripted.length && process.stdin.isTTY && !asJson) {
    const readline = require('readline');
    rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  }
  const askLine = (promptText) => new Promise((resolve) => {
    if (!rl) return resolve('y');
    rl.question(promptText, (ans) => resolve(String(ans || '').trim()));
  });

  try {
    for (let i = 0; i < slice.length; i++) {
      const s = slice[i];
      if (!asJson) {
        console.log(`\n+-----------------------------------------------------------------------+`);
        console.log(`| ${i + 1}. ${s.member.toUpperCase()} (${s.role})`);
        console.log(`|    Found:   ${s.latest_update}`);
        console.log(`|    Push:    ${s.next_push}`);
        console.log(`+-----------------------------------------------------------------------+`);
      }
      const rawAns = scripted[i] !== undefined
        ? scripted[i]
        : await askLine('  Decision [y = approve / n = skip / or type new idea]: ');
      const cleanAns = String(rawAns || 'y').trim();
      const lower = cleanAns.toLowerCase();

      if (lower === 'n' || lower === 'no' || lower === 'skip' || lower === 'sleep') {
        results.push({ member: s.member, decision: 'skip', engine: s.engine, next_push: s.next_push });
        if (!asJson) console.log(`  -> NO: skipped ${s.member} for this cycle.`);
      } else if (lower === 'y' || lower === 'yes' || lower === '') {
        autoQueueMemberNextPush(s.member, s.next_push, s.latest_update, process.cwd(), { promote: true });
        results.push({ member: s.member, decision: 'approved', engine: s.engine, next_push: s.next_push, command: `atris member go ${s.member}`, subagent_shell: s.subagent_shell });
        if (!asJson) console.log(`  -> YES: approved "${s.next_push}" on ${s.engine} (run: atris member go ${s.member})`);
      } else {
        autoQueueMemberNextPush(s.member, cleanAns, 'Operator standup steer', process.cwd(), { promote: true });
        const steeredShell = buildMemberSubagentShell(s.member, s.role, s.engine, cleanAns, process.cwd());
        results.push({ member: s.member, decision: 'steered', engine: s.engine, next_push: cleanAns, command: `atris member go ${s.member}`, subagent_shell: steeredShell });
        if (!asJson) console.log(`  -> IDEA: steered ${s.member} to "${cleanAns}" on ${s.engine} (run: atris member go ${s.member})`);
      }
    }
  } finally {
    if (rl) rl.close();
  }

  const payload = {
    ok: true,
    action: 'member_standup_walk',
    reviewed: results.length,
    results,
  };
  if (asJson) {
    console.log(JSON.stringify(payload, null, 2));
  } else {
    console.log(`\nStandup complete (${results.length} members reviewed). Launch any approved member with: atris member go <name>`);
  }
  return payload;
}

async function memberRoom(...args) {
  if (hasFlag(args, '--help') || hasFlag(args, '-h')) {
    console.log('Usage: atris member [day|standup|room] [--walk] [--limit N] [--decisions "y|idea|n"] [--json]');
    console.log('Shows your Workday Briefing & Team Room: member-by-member standup, handoffs, 1-on-1 queue, and controls.');
    return;
  }
  const asJson = hasFlag(args, '--json');
  const room = buildMemberRoom(process.cwd());
  if (hasFlag(args, '--walk') || Boolean(readFlag(args, '--decisions', ''))) {
    return memberStandupWalk(room, args);
  }
  const teamEngines = [...new Set(room.standup.map((s) => s.engine).filter((e) => e && e !== 'auto'))];
  const engineLine = teamEngines.length
    ? `Your team runs on ${teamEngines.length > 1 ? `${teamEngines.slice(0, -1).join(', ')} and ${teamEngines[teamEngines.length - 1]}` : teamEngines[0]}.`
    : 'Your team picks an engine for each job.';

  const standupRows = room.standup.flatMap((s, idx) => [
    `+-----------------------------------------------------------------------+`,
    `| ${idx + 1}. ${s.member.toUpperCase()} (${s.role}) · ${s.status} · engine:${s.engine}`,
    `|    Found:   ${s.latest_update}`,
    `|    Push:    ${s.next_push}`,
    `+-----------------------------------------------------------------------+`,
  ]);

  const handoffRows = room.handoffs.length
    ? room.handoffs.map((h) => `  - ${h.from} -> ${h.to}: ${h.summary} (run: ${h.next_command})`)
    : ['  - No pending baton passes right now.'];

  const oneOnOneRows = room.one_on_ones.length
    ? room.one_on_ones.map((o) => `  - ${o.member}: ${o.reason} -> ${o.command}`)
    : ['  - Zero blocking 1-on-1s today. Every member has an active roadmap and engine seat.'];

  const feedRows = room.feed.length
    ? room.feed.slice(0, 3).flatMap((item) => formatMemberFeedRow(item, '  '))
    : ['  no real work yet'];

  const lines = [
    'Your team · workday briefing',
    engineLine,
    '',
    '1. Member-by-Member Standup (detail: `atris member card <name>` | rapid walk: `atris member standup --walk`):',
    ...standupRows,
    '',
    '2. Handoffs & Baton Passes (`atris member handoff <from> <to> "<slice>"`):',
    ...handoffRows,
    '',
    '3. Your 1-on-1s Today (`atris member 1on1 <name>`):',
    ...oneOnOneRows,
    '',
    'Live Consequence Feed:',
    ...feedRows,
    '',
    'Controls: atris member standup --walk | atris member go | atris member "<prompt>" | atris member 1on1 <name> | atris member sleep',
  ];

  printJsonOrText({ ok: true, action: 'member_room', ...room }, lines, asJson);
  return room;
}

// --- EXPORT subcommand ---

function memberExport(...args) {
  const { exportMembers, summaryLine } = require('../lib/member-export');
  const dryRun = args.includes('--dry-run');
  const root = process.cwd();
  if (!fs.existsSync(path.join(root, 'atris', 'team'))) {
    console.error('No atris/team folder here, so there are no members to export.');
    process.exitCode = 1;
    return null;
  }
  const result = exportMembers(root, { dryRun });
  if (args.includes('--json')) {
    console.log(JSON.stringify({ dry_run: dryRun, ...result }, null, 2));
    return result;
  }
  for (const file of result.written) console.log(`${dryRun ? 'Would write' : '✓ Wrote'} ${file}`);
  for (const file of result.removed) console.log(`${dryRun ? 'Would remove' : '✓ Removed'} ${file}`);
  for (const file of result.kept) console.log(`Left alone ${file} (hand-written, not made by export)`);
  console.log(summaryLine(result, { dryRun }));
  return result;
}

function memberTidy(...args) {
  const { tidyMemberCopies, formatTidy } = require('../lib/member-tidy');
  const dirIndex = args.indexOf('--dir');
  const result = tidyMemberCopies({
    dryRun: args.includes('--dry-run'),
    worktreesDir: dirIndex >= 0 ? args[dirIndex + 1] : undefined,
  });
  console.log(formatTidy(result));
  if (result.aborted) process.exitCode = 1;
  return result;
}

async function memberCommand(subcommand, ...args) {
  // Subcommands that take a member name as args[0] otherwise treat `--help` as
  // a name and error with "Member '--help' not found". `create`/`new` handle
  // help themselves (with subcommand-specific usage), leave those alone.
  const HELP_AWARE_SUBCOMMANDS = new Set([
    'create', 'new', 'run', 'install', 'result', 'dispatch', 'route', 'feed', 'stream',
    'card', 'cards', 'go', 'work', 'up', 'steer', 'sleep', 'rest', '1on1', 'interview',
    'room', 'ui', 'day', 'standup', 'handoff', 'handoffs', 'report',
  ]);
  const explicitHelp = subcommand === 'help' || subcommand === '--help' || subcommand === '-h'
    || (!HELP_AWARE_SUBCOMMANDS.has(subcommand) && (args[0] === '-h' || args[0] === '--help'));
  if (explicitHelp) {
    subcommand = 'help';
  }
  switch (subcommand) {
    case 'list':
    case 'ls':
      return memberList(...args);
    case 'roster':
      // Who is on the team, working or idle, and on which engine.
      return require('./team').memberRosterCommand(args);
    case 'create':
    case 'new':
      return memberCreate(args[0], ...args.slice(1));
    case 'install':
      return memberInstall(args[0], args.includes('--update'));
    case 'activate':
      return memberActivate(args[0]);
    case 'upgrade':
      return memberUpgrade(args[0]);
    case 'push':
      return memberPush(args[0]);
    case 'pull':
      return memberPull(args[0]);
    case 'goal':
      return memberGoal(args[0], ...args.slice(1));
    case 'goal-from-mission':
    case 'mission-goal':
      return memberGoalFromMission(args[0], ...args.slice(1));
    case 'goal-from-score':
    case 'score-goal':
      return memberGoalFromScore(args[0], ...args.slice(1));
    case 'chat':
      return memberChat(args[0], ...args.slice(1));
    case 'tick':
      return memberTick(args[0], ...args.slice(1));
    case 'wake':
      return require('../lib/member-verbs').memberWakeVerb(args, {
        wake: memberWake,
        up: memberUp,
      });
    case 'run':
      return require('../lib/member-verbs').memberRunVerb(args, {
        root: process.cwd(),
        aliasOf: memberRuntimeKind,
        run: memberRun,
        dispatch: memberDispatch,
      });
    case 'result': {
      const code = require('../lib/member-result').memberResultCommand(args);
      if (code) process.exitCode = code;
      return undefined;
    }
    case 'go':
    case 'work':
      return memberGo(...args);
    case 'up':
      return memberUp(...args);
    case 'steer':
      return memberSteerOrDispatch(...args);
    case 'sleep':
    case 'rest':
      return memberSleep(args[0], ...args.slice(1));
    case '1on1':
    case 'interview':
      return memberOneOnOne(args[0], ...args.slice(1));
    case 'room':
    case 'ui':
    case 'day':
    case 'standup':
      return memberRoom(...args);
    case 'handoff':
    case 'handoffs':
      return memberHandoff(args[0], args[1], ...args.slice(2));
    case 'dispatch':
    case 'route':
      return memberDispatch(...args);
    case 'feed':
    case 'stream':
      return memberFeed(...args);
    case 'board':
      return require('../lib/member-board').memberBoardCommand(...args);
    case 'stop':
      return require('../lib/member-board').memberStopCommand(args[0]);
    case 'card':
    case 'cards':
      return memberCard(args[0], ...args.slice(1));
    case 'ping':
      return memberPing(args[0], ...args.slice(1));
    case 'loop':
      return memberLoop(args[0], ...args.slice(1));
    case 'alive':
      return memberAlive(args[0], ...args.slice(1));
    case 'review':
      return memberReview(args[0], args[1], ...args.slice(2));
    case 'block':
      return memberBlock(args[0], args[1], ...args.slice(2));
    case 'status':
      return memberStatus(args[0], ...args.slice(1));
    case 'live':
      return memberLive(...args);
    case 'heartbeat':
    case 'hb':
      return memberHeartbeat(args[0], ...args.slice(1));
    case 'improvements':
      return memberImprovements(args[0], ...args.slice(1));
    case 'report':
      return require('../lib/member-report').memberReportCommand(...args);
    case 'history':
      return memberHistory(args[0], ...args.slice(1));
    case 'supervisor':
      return memberSupervisorCommand(args[0], ...args.slice(1));
    case 'objective-generator':
      return memberObjectiveGeneratorCommand(args[0], ...args.slice(1));
    case 'generalist':
      return memberGeneralistCommand(args[0], ...args.slice(1));
    case 'export':
      return memberExport(...args);
    case 'archive':
      return memberArchive(args[0]);
    case 'purge-archived':
      return memberPurgeArchived(...args);
    case 'tidy':
      return memberTidy(...args);
    case undefined:
    case '--json':
      if (fs.existsSync(path.join(process.cwd(), 'atris', 'team'))) {
        return memberRoom(...(subcommand === '--json' ? ['--json', ...args] : args));
      }
      // fall through to help if not in a workspace with atris/team
    default:
      if (subcommand && subcommand !== 'help' && !subcommand.startsWith('-')) {
        // Natural prompt or member name: `atris member "make checkout faster"` or `atris member navigator`
        if (isKnownMemberSlug(subcommand, process.cwd()) && args.filter((a) => !String(a).startsWith('-')).length === 0) {
          return memberCard(subcommand, ...args);
        }
        // One word that is neither a member nor a subcommand is a typo far
        // more often than a job. Starting a paid run on it costs money and
        // does nothing useful, so name the miss and stop. Jobs keep working
        // as more than one word, or through `atris member run "<job>"`.
        const extraWordList = args.filter((a) => !String(a).startsWith('-'));
        const extraWords = extraWordList.length;
        if (!/\s/.test(subcommand.trim()) && extraWords === 0) {
          return memberUnknownWord(subcommand);
        }
        // `atris member inbox validator`: an unknown word followed by a member
        // name is a command shape (verb, then who), not a job. It once started
        // a mission called "inbox validator"; name the miss instead.
        if (!/\s/.test(subcommand.trim()) && extraWords === 1
          && isKnownMemberSlug(String(extraWordList[0]).trim(), process.cwd())) {
          return memberUnknownWord(subcommand);
        }
        return memberSteerOrDispatch(subcommand, ...args);
      }
      console.log('run "<job>"          pick the right member and run it: atris member run "fix the flaky login test"');
      console.log('wake <N|names>       keep members working: atris member wake 5  or  atris member wake navigator executor');
      console.log('sleep [name|--all]   rest the team: atris member sleep --all');
      console.log('');
      console.log('Usage: atris member <subcommand|"<prompt>"> [name]');
      console.log('');
      console.log('Subcommands:');
      console.log('  (bare)              Open the Team Room (members, engines, live consequence feed)');
      console.log('  "<prompt>"          Steer a running member mid-flight or start the best specialist');
      console.log('  go [name|"..."]     Wake the highest-leverage member on its next_push or run a prompt');
      console.log('  steer [name] "..."  Steer a member mid-run or update its immediate direction');
      console.log('  1on1 <name>         Talk with a member in its own voice; ends with its next step saved');
      console.log('  sleep [name|--all]  Park active member loops so your team rests until woken');
      console.log('  room [--json]       Render the visual Team Room and desktop UI payload');
      console.log('  board [--watch]     One screen of every member: job, last step, working/quiet/done');
      console.log('  create <name>       Scaffold a new team member (MEMBER.md + dirs) [--push]');
      console.log('  install <slug> [--update]  Install missing files, or refresh template skills');
      console.log('  chat <name> "..."   Send a message to this member\'s desk in Atris Desktop');
      console.log('  list [--json]       Show all team members with skills and version');
      console.log('  roster [--all]      Who is on the team: what each does, working or idle, and engine');
      console.log('  tidy [--dry-run]    Put away member copies of the repo whose work already landed');
      console.log('  export [--dry-run]  Write each member as a subagent for Claude Code, Cursor, and Codex');
      console.log('  activate <name>     Symlink member skills, show context and permissions');
      console.log('  upgrade <name>      Convert flat file (name.md) to directory format');
      console.log('  push <name>         Push a local team member to the cloud');
      console.log('  pull <name|id>      Pull a cloud agent as a local team member');
      console.log('  goal <name> "..."   Create/update a member long-term goal');
      console.log('  goal-from-mission <name>  Create/reuse a goal from MISSION.md and now.md');
      console.log('  goal-from-score <name>    Create/reuse an active goal from Team score evidence');
      console.log('  wake <name>         Decide tick/wait/ask/stop, then run one bounded work step on the roster engine (--plan to only decide; --keep keeps it working)');
      console.log('  run "<job>"         Pick the best member for the job and run it (same as dispatch "<job>" --ignite)');
      console.log('  run <name> ["..."]  Start a budgeted member mission, or run its active Mission Runtime');
      console.log('  report [--since 2h] Short summary per member: merged, finished, turned down, done but not merged yet [--json]');
      console.log('  result <name>       Newest run result: run record, receipt, artifacts, number [--since <iso>] [--json]');
      console.log('  dispatch "<idea>"   Route an idea to the best specialist member and start work');
      console.log('  up [--max N] [--only a,b]  Keep the team working: start free members on fitting tasks every minute (wake 5 / wake a b)');
      console.log('  feed [--member <n>] Show a plain-language linear feed of real work across the team');
      console.log('  card [name|--all]   Show a member\'s roadmap, unlocked skills, live work, and recent wins');
      console.log('  loop <name|--all>   Repeat wake on a bounded cadence with a no-overlap lease');
      console.log('  tick <name>         Propose the next bounded experiment');
      console.log('  review <name> <id>  Accept/discard an experiment with proof');
      console.log('  block <name> <id>   Mark an experiment blocked with a human/orchestrator ask');
      console.log('  status <name|--all> Show goal, mission, activity, value, ask, and recent log');
      console.log('  live                Show backend member projection (what iOS/web render) [--scope business --scope-id <id>]');
      console.log('  heartbeat <name>    Mark a member running/done on every surface [--note "..."] [--done|--error]');
      console.log('  improvements <biz>  Show daily self-improve history for a business [--days N]');
      console.log('  history <name>      Show git history of member identity files (MEMBER.md, SOUL.md)');
      console.log('  supervisor recommendations  Show advisory supervisor recommendations');
      console.log('  objective-generator proposals  Show autonomous objective proposal');
      console.log('  generalist proof    Show latest cross-domain generalist proof');
      console.log('  generalist patterns Show learned cross-domain pattern library');
      console.log('  archive <name>      Move a member to atris/team/_archived/');
      console.log('  purge-archived      Delete archived members older than --days=60 with confirmation');
      console.log('');
      console.log('Create flags:');
      console.log('  --role="Title"         Set the member role');
      console.log('  --description="..."    Set the member description');
      console.log('  --push                 Also create a cloud agent after scaffolding');
      console.log('');
      console.log('Examples:');
      console.log('  atris member create sdr --role="Sales Development Rep"');
      console.log('  atris member install orb');
      console.log('  atris member list');
      console.log('  atris member activate navigator');
      console.log('  atris member upgrade executor');
      console.log('  atris member push navigator');
      console.log('  atris member pull navigator           (reads agent-id from local MEMBER.md)');
      console.log('  atris member goal growth "Recover more customer revenue" --acceptance "one proof-backed action"');
      console.log('  atris member goal-from-mission growth --json');
      console.log('  atris member goal-from-score growth --score-json team-score.json --json');
      console.log('  atris member wake growth --json');
      console.log('  atris member run growth "improve onboarding proof" --verify "npm test" --minutes 30 --json');
      console.log('  atris member run growth --mission <mission-id> --max-ticks 1 --json');
      console.log('  atris member result growth --json');
      console.log('  atris member wake growth --execute --confirm-autonomy-policy');
      console.log('  atris member supervisor recommendations --json');
      console.log('  atris member objective-generator proposals --json');
      console.log('  atris member generalist proof --json');
      console.log('  atris member generalist patterns --json');
      console.log('  atris member loop growth --minutes 10 --interval 60 --json');
      console.log('  atris member alive growth --hourly --forever --execute --confirm-autonomy-policy --json');
      console.log('  atris member alive growth --install --hourly --forever --execute --confirm-autonomy-policy --json');
      console.log('  atris member alive --all --install --hourly --forever --dry-run');
      console.log('  atris member alive growth --minutes 480 --interval 900 --execute --confirm-autonomy-policy --json');
      console.log('  atris member loop growth --ticks 2 --interval 0 --json');
      console.log('  atris member tick growth --json');
      console.log('  atris member status growth');
      console.log('  atris member status --all');
      console.log('  atris member review growth exp_123 --accept --proof "validated" --value 4');
      console.log('  atris member archive old-member');
      console.log('  atris member purge-archived --days=60 --confirm "delete archived members"');
      console.log('');
  }
}

module.exports = {
  logDateForScan,
  memberRunDefaultWallSeconds,
  memberRunWantsReferee,
  proposalPromptForGoal,
  memberGoFinishTask,
  memberRunReviewAsk,
  memberUpSpawn,
  appendMemberGoalLog,
  appendProjectLog,
  memberCommand,
  findAllMembers,
  findWorkspaceBusinessId,
  parseFrontmatter,
  wakeBootLines,
  buildMemberRunStartArgs,
  inferMemberRunVerifier,
  pickMemberForIdea,
  appendMemberGoalLog,
  appendProjectLog,
};
