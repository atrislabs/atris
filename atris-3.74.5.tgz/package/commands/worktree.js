'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { hasFlag, readFlag } = require('../lib/arg-parser');
const { stampLatestOpenBriefForWorktree } = require('../lib/brief-ledger');
const { isConductorArtifact, isConductorUntracked } = require('../lib/conductor-artifacts');
const { fixMapDocs } = require('../lib/map-refs');
const { sleepSync } = require('../lib/sleep-sync');
const close = require('./close');

// Files atris regenerates on its own. Unstaged churn in them is restored
// before ship commits, unless the commit message names the file. The task
// projection is rewritten by any task command run in a work folder, and two
// parallel landings that each carry a copy always clash.
const REGEN_ADAPTER_FILES = ['AGENTS.md', 'CLAUDE.md', 'GEMINI.md', '.atris/state/tasks.projection.json'];
const COMMAND_MAX_BUFFER_BYTES = 64 * 1024 * 1024;
// Push also runs local hooks. Backend startup and regression checks alone can
// exceed the short network-only allowance used by fetch and discovery.
const GIT_PUSH_TIMEOUT_MS = 5 * 60 * 1000;
const GIT_OID_PATTERN = /^[0-9a-f]{40,64}$/;
const ONE_LAP_PROOF_REF_PATTERN = /^refs\/atris\/one-lap\/([0-9a-f]{40,64})$/;
const DAY_MS = 24 * 60 * 60 * 1000;
const SHIP_HEALTH_SOURCE = 'ship-health:experiments-daily';

function gitNetworkEnvironment(source = process.env, cwd = process.cwd()) {
  const env = { ...source, GIT_TERMINAL_PROMPT: '0' };
  // Custom commands may be wrappers that do not accept OpenSSH flags.
  // Leave Git's own command/config/program precedence intact.
  if (source.GIT_SSH_COMMAND || source.GIT_SSH) return env;
  const configured = spawnSync('git', ['config', '--get', 'core.sshCommand'], {
    cwd, encoding: 'utf8', env: source, timeout: 5000, killSignal: 'SIGKILL',
  });
  if (configured.status === 0 && String(configured.stdout || '').trim()) return env;
  env.GIT_SSH_COMMAND = 'ssh -o BatchMode=yes -o ConnectTimeout=10 -o ServerAliveInterval=15';
  return env;
}

// A killed network call leaves stderr empty; name the timeout instead.
function gitFailureDetail(result) {
  if (result && result.error && result.error.code === 'ETIMEDOUT') return 'timed out';
  return [result && result.stdout, result && result.stderr]
    .map(output => String(output || '').trim()).filter(Boolean).join('\n');
}

function runGit(args, { cwd = process.cwd(), check = true, timeout } = {}) {
  const network = ['fetch', 'push', 'ls-remote'].includes(args[0]);
  // Only network calls need the SSH probe; local calls skip its extra git spawn.
  const defaultTimeout = args[0] === 'push' ? GIT_PUSH_TIMEOUT_MS : network ? 30000 : undefined;
  const options = { cwd, encoding: 'utf8', timeout: timeout ?? defaultTimeout,
    killSignal: 'SIGKILL', env: network ? gitNetworkEnvironment(process.env, cwd) : undefined };
  let result = spawnSync('git', args, options);
  // Linked checkouts share config. A concurrent start must not silently lose
  // its owner/base metadata, but real config errors still stop immediately.
  for (let retry = 1; args[0] === 'config' && retry < 3 && configLocked(result); retry += 1) {
    sleepSync(100 * retry);
    result = spawnSync('git', args, options);
  }
  if (check && result.status !== 0) {
    const detail = gitFailureDetail(result);
    throw new Error(detail === 'timed out' ? `git ${args[0]} timed out` : (detail || `git ${args.join(' ')} failed`));
  }
  return result;
}

function configLocked(result) {
  return result.status !== 0 && /could not lock config file/i.test(`${result.stderr || ''}${result.stdout || ''}`);
}

function runCommand(command, { cwd = process.cwd(), check = true } = {}) {
  const result = spawnSync(command, {
    cwd,
    encoding: 'utf8',
    shell: true,
    stdio: 'pipe',
    maxBuffer: COMMAND_MAX_BUFFER_BYTES,
  });
  if (result.error) throw result.error;
  if (check && result.status !== 0) {
    const msg = (result.stderr || result.stdout || `${command} failed`).trim();
    throw new Error(msg);
  }
  return result;
}

function statusSnapshot(root) {
  const result = runGit(['status', '--porcelain=v1', '--untracked-files=all'], { cwd: root, check: false });
  if (result.status !== 0) return [];
  return result.stdout
    .split(/\r?\n/)
    .map((line) => line.trimEnd())
    .filter(Boolean);
}

function newStatusRows(before, after) {
  const seen = new Set(before);
  return after.filter((row) => !seen.has(row));
}

function readOneLapProofBinding(root, branch) {
  const sidecarPath = path.join(root, '.atris', 'agent-worktree.json');
  let sidecar = null;
  try {
    sidecar = JSON.parse(fs.readFileSync(sidecarPath, 'utf8'));
  } catch (error) {
    if (error && error.code !== 'ENOENT') throw new Error('one-lap proof metadata is unreadable');
  }
  const metadata = sidecar && sidecar.one_lap_proof;
  const configured = runGit(['config', '--get', `branch.${branch}.atris-proof-ref`], { cwd: root, check: false });
  const configuredRef = configured.status === 0 ? String(configured.stdout || '').trim() : '';
  if (!metadata && !configuredRef) return null;
  if (!metadata || !configuredRef) throw new Error('one-lap proof binding is incomplete');

  const proofRef = String(metadata.ref || '');
  const sourceCommit = String(metadata.commit || '');
  const sourceTree = String(metadata.tree || '');
  const refMatch = proofRef.match(ONE_LAP_PROOF_REF_PATTERN);
  if (!refMatch || proofRef !== configuredRef || !GIT_OID_PATTERN.test(sourceCommit) || !GIT_OID_PATTERN.test(sourceTree)) {
    throw new Error('one-lap proof binding is invalid');
  }
  const resolvedCommit = runGit(['rev-parse', '--verify', `${proofRef}^{commit}`], { cwd: root, check: false });
  const resolvedTree = runGit(['rev-parse', '--verify', `${proofRef}^{tree}`], { cwd: root, check: false });
  if (resolvedCommit.status !== 0 || String(resolvedCommit.stdout || '').trim() !== sourceCommit || refMatch[1] !== sourceCommit) {
    throw new Error('one-lap proof commit no longer matches its retained ref');
  }
  if (resolvedTree.status !== 0 || String(resolvedTree.stdout || '').trim() !== sourceTree) {
    throw new Error('one-lap proof tree no longer matches its retained ref');
  }
  return { ref: proofRef, commit: sourceCommit, tree: sourceTree };
}

function worktreeTree(root, source) {
  const result = runGit(source === 'index'
    ? ['write-tree']
    : ['rev-parse', '--verify', 'HEAD^{tree}'], { cwd: root, check: false });
  if (result.status !== 0) throw new Error(`could not resolve the ${source} tree for one-lap proof`);
  return String(result.stdout || '').trim();
}

function assertOneLapProofTree(root, binding, source) {
  if (!binding) return;
  if (worktreeTree(root, source) !== binding.tree) {
    throw new Error(`one-lap ${source} tree differs from the independently verified proof tree`);
  }
}

function repoRoot(cwd = process.cwd()) {
  return runGit(['rev-parse', '--show-toplevel'], { cwd }).stdout.trim();
}

function slugify(value, fallback = 'task', limit = 48) {
  const slug = String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, limit)
    .replace(/-+$/g, '');
  return slug || fallback;
}

function stamp(now = new Date()) {
  return now.toISOString().replace(/[-:]/g, '').replace(/\.\d+Z$/, '').replace('T', '-');
}

function branchName(member, task, now = new Date()) {
  return `codex/${slugify(member, 'member', 24)}-${slugify(task, 'task', 36)}-${stamp(now)}`;
}

// The newest earlier run of this same member+job, if its commits never reached
// the base, so a retry continues that work instead of redoing it. Only the
// newest run counts: once it landed or did nothing, anything older is stale.
function lastRunBranch(root, owner, task, base, skip) {
  const prefix = `codex/${slugify(owner, 'member', 24)}-${slugify(task, 'task', 36)}-`;
  const listed = runGit(['for-each-ref', '--format=%(refname:short)', `refs/heads/${prefix}*`], { cwd: root, check: false });
  if (listed.status !== 0) return null;
  // Only exact runs of this job (stamp plus optional same-second number), so
  // "fix-login" never matches "fix-login-page".
  const runs = listed.stdout.split('\n').map((name) => name.trim())
    .map((name) => ({ name, run: name.slice(prefix.length).match(/^(\d{8}-\d{6})(?:-(\d+))?$/) }))
    .filter(({ name, run }) => run && name !== skip)
    .sort((a, b) => b.run[1].localeCompare(a.run[1]) || Number(b.run[2] || 1) - Number(a.run[2] || 1));
  if (!runs.length) return null;
  const newest = runs[0].name;
  const cherry = runGit(['cherry', base, newest], { cwd: root, check: false });
  if (cherry.status !== 0) return null;
  return cherry.stdout.split('\n').some((line) => line.startsWith('+')) ? newest : null;
}

// True only when git proves the branch no longer merges cleanly with the base.
// merge-tree --write-tree exits 1 on conflict; an error or old git keeps the
// resume as before.
function conflictsWithBase(root, base, branch) {
  const result = runGit(['merge-tree', '--write-tree', '--name-only', base, branch], { cwd: root, check: false });
  return result.status === 1;
}

function defaultWorktreePath(root, member, task, now = new Date()) {
  const name = `${slugify(member, 'member', 24)}-${slugify(task, 'task', 36)}-${stamp(now)}`;
  return path.join(path.dirname(root), '.agent-worktrees', path.basename(root), name);
}

function parseWorktrees(text) {
  const out = [];
  let current = {};
  for (const raw of `${text}\n`.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) {
      if (current.worktree) {
        let branch = current.branch || 'detached';
        branch = branch.replace(/^refs\/heads\//, '');
        const item = { path: current.worktree, branch, head: current.HEAD || '' };
        if (current.locked) item.locked = true;
        if (current.prunable) item.prunable = true;
        out.push(item);
      }
      current = {};
      continue;
    }
    const idx = line.indexOf(' ');
    if (idx === -1) {
      current[line] = true;
    } else {
      current[line.slice(0, idx)] = line.slice(idx + 1);
    }
  }
  return out;
}

function listWorktrees(root = repoRoot()) {
  return parseWorktrees(runGit(['worktree', 'list', '--porcelain'], { cwd: root }).stdout);
}

// Duplicate flight guard. On 2026-08-07 two agents were dispatched onto the
// same map rewrite 44 seconds apart: fleet dispatch claims a task first, but a
// direct `worktree start` had no pre-check beyond the target path existing.
// Refuse only the same task slug. A shared word on an unrelated flight is not
// a collision (dispatch-cli-900 must not block dispatch-cli-901).
const AGENT_FLIGHT_NAME_PATTERN = /^codex\/(.+)-(\d{8}-\d{6})$/;
const FLIGHT_WINDOW_MS = 24 * 60 * 60 * 1000;
const FLIGHT_STOPWORDS = new Set([
  'fix', 'add', 'update', 'make', 'change', 'new', 'task', 'work', 'repo',
  'cli', 'atris', 'backend', 'the', 'a', 'an', 'and', 'for', 'to', 'of', 'in', 'on',
]);

function flightStampMs(stampText) {
  const m = /^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})$/.exec(String(stampText || ''));
  if (!m) return null;
  const [, year, month, day, hour, minute, second] = m.map(Number);
  if (month < 1 || month > 12 || day < 1 || day > 31 || hour > 23 || minute > 59 || second > 59) return null;
  return Date.UTC(year, month - 1, day, hour, minute, second);
}

function taskTokens(value) {
  return String(value || '')
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter(Boolean)
    .filter((token) => !FLIGHT_STOPWORDS.has(token));
}

// codex/<owner>-<task-slug>-<YYYYMMDD-HHMMSS>: drop the owner segment and the
// stamp, and what is left is the task the flight is working on.
function parseAgentFlightName(name) {
  const text = String(name || '').trim().replace(/^refs\/heads\//, '');
  const match = AGENT_FLIGHT_NAME_PATTERN.exec(text);
  if (!match) return null;
  const stampMs = flightStampMs(match[2]);
  if (stampMs === null) return null;
  const segments = match[1].split('-').filter(Boolean);
  if (segments.length < 2) return null;
  return {
    name: text,
    owner: segments[0],
    taskSlug: segments.slice(1).join('-'),
    stamp: match[2],
    stampMs,
    tokens: taskTokens(segments.slice(1).join('-')),
  };
}

function remoteAgentBranchNames(root) {
  // One ls-remote, best effort: offline dispatchers still get the local view.
  const result = runGit(['ls-remote', '--heads', 'origin'], { cwd: root, check: false, timeout: 10000 });
  if (result.status !== 0) return [];
  return String(result.stdout || '')
    .split(/\r?\n/)
    .map((line) => (line.split(/\s+/)[1] || '').replace(/^refs\/heads\//, '').trim())
    .filter(Boolean);
}

function inFlightAgentFlights({ root = repoRoot(), now = new Date(), windowMs = FLIGHT_WINDOW_MS } = {}) {
  const nowMs = now.getTime();
  const flights = new Map();
  const add = (name, kind) => {
    const flight = parseAgentFlightName(name);
    if (!flight) return;
    // Branch age comes from the stamp in the name, never a git log per branch.
    if (kind !== 'worktree' && nowMs - flight.stampMs > windowMs) return;
    const existing = flights.get(flight.name);
    if (existing && existing.kind === 'worktree') return;
    flights.set(flight.name, { ...flight, kind });
  };
  for (const wt of listWorktrees(root)) add(wt.branch, 'worktree');
  const local = runGit(['branch', '--format=%(refname:short)'], { cwd: root, check: false });
  if (local.status === 0) {
    for (const name of String(local.stdout || '').split(/\r?\n/)) add(name, 'branch');
  }
  for (const name of remoteAgentBranchNames(root)) add(name, 'branch');
  return [...flights.values()].sort((a, b) => b.stampMs - a.stampMs);
}

function collidingFlights(flights, taskSlug) {
  const wanted = String(taskSlug || '').trim().toLowerCase();
  if (!wanted) return [];
  return flights.filter((flight) => String(flight.taskSlug || '').toLowerCase() === wanted);
}

function describeFlightAge(flight, nowMs = Date.now()) {
  const minutes = Math.max(0, Math.round((nowMs - flight.stampMs) / 60000));
  if (minutes < 60) return `${minutes}m old`;
  return `${Math.floor(minutes / 60)}h${minutes % 60}m old`;
}

function refExists(root, ref) {
  return runGit(['rev-parse', '--verify', `${ref}^{commit}`], { cwd: root, check: false }).status === 0;
}

function currentBranch(root = repoRoot()) {
  return runGit(['branch', '--show-current'], { cwd: root, check: false }).stdout.trim();
}

function detachedShipBranch(root) {
  return `codex/${path.basename(root)}`;
}

function createDetachedShipBranch(root, branch) {
  if (refExists(root, `refs/heads/${branch}`) || refExists(root, `refs/remotes/origin/${branch}`)) {
    console.error(`blocked: detached head branch already exists: ${branch}`);
    return false;
  }
  const created = runGit(['switch', '-c', branch], { cwd: root, check: false });
  if (created.status !== 0) {
    console.error(`blocked: detached head branch create failed: ${branch}`);
    console.error((created.stderr || created.stdout || '').trim());
    return false;
  }
  console.log(`ship: detached head, created branch ${branch}`);
  return true;
}

function currentUpstream(root) {
  const result = runGit(['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}'], { cwd: root, check: false });
  return result.status === 0 ? result.stdout.trim() : '';
}

function remoteHead(root) {
  // The saved origin/HEAD survives branch renames. Ask the remote before
  // trusting it, keeping the offline fallback when the remote is unavailable.
  const remote = runGit(['remote', 'get-url', 'origin'], { cwd: root, check: false });
  if (remote.status === 0) {
    const live = runGit(['ls-remote', '--symref', 'origin', 'HEAD'], { cwd: root, check: false, timeout: 5000 });
    const match = live.status === 0 && String(live.stdout || '').match(/^ref: refs\/heads\/(.+)\s+HEAD$/m);
    if (match) {
      const head = `origin/${match[1]}`;
      if (!refExists(root, head)) {
        const fetched = runGit(['fetch', 'origin', `refs/heads/${match[1]}:refs/remotes/${head}`], { cwd: root, check: false, timeout: 5000 });
        if (fetched.status !== 0 || !refExists(root, head)) {
          throw new Error('could not fetch the remote default branch; stop and retry when the remote is available');
        }
      }
      return head;
    }
  }
  const result = runGit(['symbolic-ref', '--quiet', '--short', 'refs/remotes/origin/HEAD'], { cwd: root, check: false });
  return result.status === 0 ? result.stdout.trim() : '';
}

function normalizeTargetRef(root, target) {
  const value = String(target || '').trim();
  if (!value) return '';
  const remotes = runGit(['remote'], { cwd: root, check: false }).stdout.split(/\r?\n/);
  const preferRemote =
    !value.startsWith('origin/') &&
    !value.startsWith('refs/') &&
    value !== 'HEAD' &&
    !/^[0-9a-f]{7,40}$/i.test(value) &&
    remotes.includes('origin');
  const remoteRef = value.startsWith('origin/') ? value : `origin/${value}`;
  if (preferRemote && refExists(root, remoteRef)) return remoteRef;
  if (preferRemote) return remoteRef;
  if (refExists(root, value)) return value;
  if (refExists(root, remoteRef)) return remoteRef;
  if (value.startsWith('origin/') || remotes.includes('origin')) return remoteRef;
  return value;
}

function defaultMainlineBase(root) {
  const head = remoteHead(root);
  if (head && refExists(root, head)) return head;
  for (const candidate of ['origin/main', 'origin/master']) {
    if (refExists(root, candidate)) return candidate;
  }
  return 'HEAD';
}

function defaultStartBase(root) {
  const upstream = currentUpstream(root);
  const mainline = defaultMainlineBase(root);
  // Always refresh before cutting a worktree: a stale origin/master base sent
  // an engine off to rebuild work that had already landed (2026-07-09, packs
  // one-click flight rebuilt the stars backend from a base two PRs behind).
  refreshRemoteRef(root, mainline);
  if (!upstream || !refExists(root, upstream)) return mainline;
  if (mainline === 'HEAD' || mainline === upstream) return upstream;
  // A launcher upstream that is behind the mainline is a stale cut point
  // (2026-07-05: a stale origin/task branch sent two flights into rebase
  // conflicts). Start from the mainline unless the upstream carries new work.
  refreshRemoteRef(root, upstream);
  const behind = runGit(['merge-base', '--is-ancestor', upstream, mainline], { cwd: root, check: false });
  return behind.status === 0 ? mainline : upstream;
}

function defaultShipTarget(root) {
  const branch = currentBranch(root);
  if (branch) {
    const configured = runGit(['config', '--get', `branch.${branch}.atris-base`], { cwd: root, check: false }).stdout.trim();
    if (configured && refExists(root, configured)) return configured;
  }
  const head = remoteHead(root);
  if (head && refExists(root, head)) return head;
  for (const candidate of ['origin/main', 'origin/master']) {
    if (refExists(root, candidate)) return candidate;
  }
  return 'HEAD';
}

function refreshRemoteRef(root, ref) {
  if (!ref.startsWith('origin/')) return;
  const remoteBranch = ref.slice('origin/'.length);
  const fetched = runGit(['fetch', 'origin', remoteBranch], { cwd: root, check: false, timeout: 5000 });
  return fetched.status === 0 ? '' : (gitFailureDetail(fetched) || 'fetch failed');
}

function baseBranchName(ref) {
  return String(ref || '').replace(/^refs\/heads\//, '').replace(/^origin\//, '');
}

function statusCounts(root, {
  ignoredUnstagedFiles = new Set(),
  ignoredUntrackedFiles = new Set(),
  ignoreUntracked = null,
  ignoreAny = null,
} = {}) {
  if (!fs.existsSync(root)) return null;
  // -uall expands untracked directories to individual files so ignoredUntrackedFiles
  // and ignoreUntracked can match exact paths (plain porcelain collapses them to "?? dir/").
  const expandUntracked = ignoredUntrackedFiles.size
    || typeof ignoreUntracked === 'function'
    || typeof ignoreAny === 'function';
  const statusArgs = expandUntracked ? ['status', '--porcelain', '-uall'] : ['status', '--porcelain'];
  const result = runGit(statusArgs, { cwd: root, check: false });
  if (result.status !== 0) return null;
  let staged = 0;
  let unstaged = 0;
  let untracked = 0;
  for (const line of result.stdout.split(/\r?\n/).filter(Boolean)) {
    const file = line.slice(3);
    if (typeof ignoreAny === 'function' && ignoreAny(file)) continue;
    if (ignoredUnstagedFiles.has(file) && line[0] === ' ' && line[1] !== ' ') continue;
    if (line.startsWith('??')) {
      if (ignoredUntrackedFiles.has(file)) continue;
      if (typeof ignoreUntracked === 'function' && ignoreUntracked(file)) continue;
      untracked += 1;
      continue;
    }
    if (line[0] !== ' ') staged += 1;
    if (line[1] !== ' ') unstaged += 1;
  }
  return { staged, unstaged, untracked };
}

// Remove conductor plumbing from the index after a broad `git add -A`, so the commit
// records engine output only. Paths that were never staged are simply not listed.
// GitHub refuses a merge with "Base branch was modified" when another PR
// merged into the same base a moment earlier; the same merge succeeds on a
// second try. On 2026-10-15 five parallel dispatches lost three landings to
// it. Retry only that message, a few times, with a short wait.
const BASE_MODIFIED_PATTERN = /Base branch was modified/i;
function mergePrWithRetry(mergeArgs, root, { run = spawnSync, wait = sleepSync, attempts = 4 } = {}) {
  let merged = run('gh', mergeArgs, { cwd: root, encoding: 'utf8' });
  for (let attempt = 1; attempt < attempts && merged.status !== 0
    && BASE_MODIFIED_PATTERN.test(`${merged.stderr || ''}${merged.stdout || ''}`); attempt += 1) {
    console.log(`merge: base branch moved, retrying (${attempt + 1}/${attempts})`);
    wait(1500 * attempt);
    merged = run('gh', mergeArgs, { cwd: root, encoding: 'utf8' });
  }
  return merged;
}

function unstageConductorArtifacts(root) {
  const staged = runGit(['diff', '--cached', '--name-only'], { cwd: root, check: false });
  if (staged.status !== 0) return [];
  const added = runGit(['diff', '--cached', '--name-only', '--diff-filter=A'], { cwd: root, check: false });
  const newFiles = new Set(String(added.stdout || '').split(/\r?\n/).filter(Boolean));
  // A file this commit would add under .atris/ is the tool's own state, never work.
  const drop = String(staged.stdout || '').split(/\r?\n/).filter(Boolean)
    .filter((file) => isConductorArtifact(file) || (newFiles.has(file) && isConductorUntracked(file)));
  if (drop.length) runGit(['reset', '-q', 'HEAD', '--', ...drop], { cwd: root, check: false });
  return drop;
}

function changedFiles(root, args) {
  const result = runGit([...args, '--', ...REGEN_ADAPTER_FILES], { cwd: root, check: false });
  if (result.status !== 0) return new Set();
  return new Set(result.stdout.split(/\r?\n/).filter(Boolean));
}

function restoreRegeneratedAdapterChurn(root, message, { dryRun = false } = {}) {
  const unstaged = changedFiles(root, ['diff', '--name-only']);
  const staged = changedFiles(root, ['diff', '--cached', '--name-only']);
  const commitMessage = String(message || '');
  const skipped = REGEN_ADAPTER_FILES.filter(
    (file) => unstaged.has(file) && !staged.has(file) && !commitMessage.includes(file)
  );
  if (!skipped.length) return [];
  console.log(`ship: skipped regenerated adapter churn: ${skipped.join(', ')}`);
  if (!dryRun) runGit(['checkout', '--', ...skipped], { cwd: root });
  return skipped;
}

function swarloClaim(root, { channel, taskKey, content }) {
  const script = path.join(root, 'scripts', 'swarlo.py');
  if (!fs.existsSync(script)) return 'skip: scripts/swarlo.py not found';
  const result = spawnSync('python3', [script, 'claim', channel, taskKey, content], { cwd: root, encoding: 'utf8' });
  const output = `${result.stdout || ''}${result.stderr || ''}`.trim();
  if (result.status === 0) return output || `claimed ${taskKey}`;
  return `skip: swarlo claim failed: ${output || result.status}`;
}

function printStatus() {
  const root = repoRoot();
  const worktrees = listWorktrees(root);
  const primary = worktrees[0]?.path;
  for (const wt of worktrees) {
    const counts = statusCounts(wt.path);
    const tags = [];
    if (wt.path === primary) tags.push('primary');
    if (path.resolve(wt.path) === path.resolve(root)) tags.push('current');
    const tagText = tags.length ? ` [${tags.join(' ')}]` : '';
    if (!counts) {
      console.log(`${wt.path}${tagText} branch=${wt.branch} missing=true`);
      continue;
    }
    console.log(`${wt.path}${tagText} branch=${wt.branch} staged=${counts.staged} unstaged=${counts.unstaged} untracked=${counts.untracked}`);
  }
}

// Programmatic core shared by `atris worktree start` and `atris mission start
// --worktree`: creates the branch + isolated checkout + identity sidecar and
// returns the facts. Throws on failure; callers own messaging and next steps.
//
// checkoutBase (what the branch is cut from) and shipBase (what `atris
// worktree ship` targets, recorded as branch.<branch>.atris-base) are kept
// separate on purpose. checkoutBase defaults to the launcher's own
// upstream/default remote base, so the agent starts from current work.
// shipBase defaults to the remote mainline for agent/member worktrees regardless of
// what branch the launcher happened to have checked out. recording the
// launcher's own feature branch as the ship target false-landed two PRs on
// 2026-07-04 (ship merged into the launcher's branch, never reached master).
// --base/--target still overrides both when the caller wants a different
// checkout point and ship target on purpose.
function createAgentWorktree({ root = repoRoot(), member = '', agent = '', task, branch: branchOverride, path: pathOverride, base: baseOverride, now = new Date() } = {}) {
  const owner = member || agent;
  if (!owner || !task) throw new Error('createAgentWorktree: owner (member/agent) and task required');
  // Pin the caller's flight base, or resolve it once for this new flight.
  const mainline = baseOverride || defaultMainlineBase(root);
  // Every new flight pays down completed checkout debt before adding another
  // full repo copy. Branches and commits survive worktree removal, while real
  // uncommitted changes remain protected by cleanupWorktrees.
  let reapedBeforeStart = [];
  let cachePrunedBeforeStart = [];
  try {
    const cleaned = cleanupWorktrees({ root, base: mainline, apply: true, by: 'atris worktree start' });
    reapedBeforeStart = cleaned.removed;
    cachePrunedBeforeStart = cleaned.cachePruned;
  } catch {}
  let branch = branchOverride || branchName(owner, task, now);
  let target = path.resolve(pathOverride || defaultWorktreePath(root, owner, task, now));
  // Two runs of the same job in the same second get the same name; number
  // the later one instead of failing it.
  if (!pathOverride && !branchOverride) {
    const baseBranch = branch;
    const baseTarget = target;
    for (let n = 2; fs.existsSync(target) && n < 100; n += 1) {
      branch = `${baseBranch}-${n}`;
      target = `${baseTarget}-${n}`;
    }
  }
  // Agent/member worktrees always cut from the mainline: honoring the
  // launcher checkout's upstream let a dispatch inherit another session's
  // in-progress feature branch (2026-07-09: an auth fix arrived carrying 13
  // unpushed commits from a parallel session and could not merge).
  const checkoutBase = normalizeTargetRef(root, mainline);
  const shipBase = checkoutBase;
  if (fs.existsSync(target)) throw new Error(`worktree path already exists: ${target}`);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const staleBase = refreshRemoteRef(root, checkoutBase);
  // A retry of the same job starts from the last run's unlanded commits; it
  // still ships to the mainline.
  let resumedFrom = (!pathOverride && !branchOverride)
    ? lastRunBranch(root, owner, task, checkoutBase, branch)
    : null;
  // A last run that now conflicts with the mainline would hand its conflict
  // to the retry, which then cannot land on the first try. Start fresh; the
  // old branch keeps its commits.
  let skippedResume = null;
  if (resumedFrom && conflictsWithBase(root, checkoutBase, resumedFrom)) {
    skippedResume = resumedFrom;
    resumedFrom = null;
    console.error(`note: the last run's branch ${skippedResume} no longer merges cleanly with ${checkoutBase}, so this run starts fresh; that branch keeps its commits`);
  }
  const startPoint = resumedFrom || checkoutBase;
  const ref = `refs/heads/${branch}`;
  const existed = runGit(['show-ref', '--verify', '--quiet', ref], { cwd: root, check: false }).status !== 1;
  const baseCommit = runGit(['rev-parse', '--verify', `${startPoint}^{commit}`], { cwd: root, check: false });
  const startCommit = baseCommit.status === 0 ? baseCommit.stdout.trim() : '';
  // With no local copy the start fails on its own; only a real cut gets the warning.
  if (staleBase && startCommit) {
    console.error(`warning: could not refresh ${checkoutBase} (${staleBase.split('\n')[0]}); the new worktree starts from the local copy, which may be behind`);
  }
  const discardFailedStart = () => {
    if (existed || !startCommit) return;
    const registered = listWorktrees(root).find((wt) => wt.branch === branch);
    if (registered) {
      if (!fs.existsSync(target) || fs.realpathSync(registered.path) !== fs.realpathSync(target)
        || registered.head !== startCommit) return;
      const dirt = statusCounts(target, { ignoreUntracked: isConductorUntracked });
      if (!dirt || dirt.staged || dirt.unstaged || dirt.untracked) return;
      // No engine has started. Normal removal still refuses unexpected dirt.
      runGit(['worktree', 'remove', target], { cwd: root });
    }
    if (!fs.existsSync(target)) runGit(['update-ref', '-d', ref, startCommit], { cwd: root });
  };
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const added = runGit(['worktree', 'add', '-b', branch, target, startPoint], { cwd: root, check: false });
    if (added.status === 0) break;
    // Git can create the branch before failing to write its tracking config.
    // Drop only that untouched ref, never an existing branch or a checkout.
    if (!/already exists|already used by worktree/i.test(added.stderr || '')) discardFailedStart();
    if (!configLocked(added) || attempt === 2) {
      throw new Error(String(added.stderr || added.stdout || 'worktree start failed').trim());
    }
    sleepSync(100 * (attempt + 1));
  }
  // A resumed branch takes in what the mainline gained since, or a job that
  // keeps resuming drifts further behind every run until it clashes
  // (2026-10-15: five long jobs sat 103 to 129 commits behind). The clash
  // check above proved this merge is clean; if git still refuses, the run
  // keeps the old start instead of failing.
  if (resumedFrom) {
    const caughtUp = runGit(['merge', '--no-edit', '-m', `Merge ${checkoutBase} into ${branch}`, checkoutBase], { cwd: target, check: false });
    if (caughtUp.status !== 0) runGit(['merge', '--abort'], { cwd: target, check: false });
  }
  try {
    runGit(['config', `branch.${branch}.atris-base`, shipBase], { cwd: target });
    runGit(['config', `branch.${branch}.atris-owner`, owner], { cwd: target });
    runGit(['config', `branch.${branch}.atris-task`, task], { cwd: target });
    fs.mkdirSync(path.join(target, '.atris'), { recursive: true });
    fs.writeFileSync(
      path.join(target, '.atris', 'agent-worktree.json'),
      JSON.stringify({
        agent: agent || null,
        member: member || null,
        owner,
        task,
        branch,
        base: shipBase,
        checkout_base: checkoutBase,
        resumed_from: resumedFrom,
        skipped_resume: skippedResume,
        workspace_root: root,
        created_at: now.toISOString(),
      }, null, 2) + '\n',
      'utf8'
    );
  } catch (error) {
    discardFailedStart();
    throw error;
  }
  return { path: target, branch, base: shipBase, checkoutBase, resumedFrom, skippedResume, owner, reapedBeforeStart, cachePrunedBeforeStart };
}

function startWorktree(args) {
  const root = repoRoot();
  const member = readFlag(args, '--member');
  const agent = readFlag(args, '--agent');
  const owner = member || agent;
  const task = readFlag(args, '--task');
  if (!owner || !task) {
    console.error('Usage: atris worktree start --member <member>|--agent <name> --task "<short task>" [--claim] [--force]');
    return 2;
  }
  const memberFile = member ? path.join(root, 'atris', 'team', member, 'MEMBER.md') : '';
  if (memberFile && !fs.existsSync(memberFile)) {
    console.error(`warning: no member persona at ${path.relative(root, memberFile)}`);
  }

  const force = hasFlag(args, '--force');
  const now = new Date();
  const flights = inFlightAgentFlights({ root, now });
  const active = flights.filter((flight) => flight.kind === 'worktree');
  const repoName = path.basename(findPrimaryRoot(root));
  console.log(`flights: ${active.length} active agent ${active.length === 1 ? 'worktree' : 'worktrees'} for ${repoName}`);
  const collisions = collidingFlights(flights, slugify(task, 'task', 36));
  if (collisions.length) {
    const label = force ? 'warning' : 'refusing';
    for (const flight of collisions) {
      console.error(`${label}: overlapping flight ${flight.name} (${describeFlightAge(flight, now.getTime())})`);
    }
    console.error(`${label}: another flight may already be doing this work`);
    if (!force) {
      console.error('refusing: pass --force to start anyway');
      return 2;
    }
  }

  let created;
  try {
    created = createAgentWorktree({
      root,
      member,
      agent,
      task,
      branch: readFlag(args, '--branch'),
      path: readFlag(args, '--path'),
      base: readFlag(args, '--base') || readFlag(args, '--target'),
    });
  } catch (e) {
    console.error(`refusing: ${e.message}`);
    return 2;
  }
  const { path: target, branch, base } = created;

  if (created.reapedBeforeStart.length) {
    console.log(`cleanup: reaped ${created.reapedBeforeStart.length} completed ${created.reapedBeforeStart.length === 1 ? 'worktree' : 'worktrees'}`);
  }
  if (created.cachePrunedBeforeStart.length) {
    console.log(`cleanup: pruned ${created.cachePrunedBeforeStart.length} generated ${created.cachePrunedBeforeStart.length === 1 ? 'cache' : 'caches'}`);
  }

  const counts = statusCounts(root);
  if (counts && (counts.staged || counts.unstaged || counts.untracked)) {
    console.log(`note: primary checkout is dirty staged=${counts.staged} unstaged=${counts.unstaged} untracked=${counts.untracked}`);
  }
  console.log(`path: ${target}`);
  console.log(`branch: ${branch}`);
  console.log(`${member ? 'member' : 'agent'}: ${owner}`);
  if (hasFlag(args, '--claim')) {
    const channel = readFlag(args, '--swarlo-channel', 'general');
    const taskKey = readFlag(args, '--swarlo-task-key') || `${slugify(owner, 'agent', 24)}-${slugify(task, 'task', 36)}`;
    const content = readFlag(args, '--swarlo-content') || `${owner} owns ${task} in ${target}`;
    console.log(`swarlo_channel: ${channel}`);
    console.log(`swarlo_claim: ${swarloClaim(target, { channel, taskKey, content })}`);
  }
  console.log(`base: ${base}`);
  console.log(`next: cd ${target}`);
  return 0;
}

function createOrFindPr(root, branch, targetRef, title, dryRun) {
  const targetBranch = baseBranchName(targetRef);
  // `gh pr view` (no --state filter) returns ANY PR for this branch name,
  // including one already MERGED or CLOSED. A worktree branch that ships
  // more than once (this same branch, more commits, another `worktree ship`)
  // would then reuse the dead PR number: `gh pr merge <dead pr> --merge`
  // exits 0 with just a warning (never fails), so the new commits silently
  // never land while the ship command still reports success. Only reuse a
  // PR that is still OPEN; anything else gets a fresh one.
  const existing = spawnSync('gh', ['pr', 'view', '--json', 'number,url,state', '--jq', '"\\(.number) \\(.url) \\(.state)"'], {
    cwd: root,
    encoding: 'utf8',
  });
  if (existing.status === 0 && existing.stdout.trim()) {
    const parts = existing.stdout.trim().split(/\s+/);
    const state = parts.pop();
    if (state === 'OPEN') return parts.join(' ');
  }
  const body = [
    'Automated Atris worktree ship.',
    '',
    `Branch: ${branch}`,
    `Target: ${targetBranch}`,
  ].join('\n');
  if (dryRun) return `dry-run: gh pr create --base ${targetBranch} --head ${branch}`;
  // An engine that produced nothing leaves a branch level with its base. Asking
  // GitHub for a PR there fails with "No commits between ...", and that throw used
  // to escape the flight and abort the whole run. Say it plainly instead.
  const ahead = runGit(['rev-list', '--count', `${targetRef}..HEAD`], { cwd: root, check: false });
  if (ahead.status === 0 && String(ahead.stdout || '').trim() === '0') {
    console.log('pr: skipped (no commits ahead of base)');
    return '';
  }
  const created = spawnSync(
    'gh',
    ['pr', 'create', '--base', targetBranch, '--head', branch, '--title', title, '--body', body],
    { cwd: root, encoding: 'utf8' }
  );
  if (created.status !== 0) {
    throw new Error((created.stderr || created.stdout || 'gh pr create failed').trim());
  }
  return created.stdout.trim();
}

function prMergeRef(prOutput) {
  const text = String(prOutput || '').trim();
  if (!text || text.startsWith('dry-run:')) return '';
  return text.split(/\s+/)[0];
}

function shipHelp() {
  console.log('Usage: atris worktree ship --message "<commit>" --verify "<cmd>" [--merge] [--target <ref>] [--local]');
  console.log('');
  console.log('  --target <ref>  override the default landing target (default: branch atris-base, else origin default branch)');
  console.log('  --local         merge into the local primary checkout instead of pushing and opening a PR');
  console.log('  --no-map-refresh  skip the automatic refresh of moved map line references');
  console.log('  unstaged regenerated adapter files are skipped unless staged first or named in --message');
  console.log('  recommended flight verify: npm run test:fast && node --test <focused files>');
}

function deniedLaneForShip(root, branch, message) {
  try {
    const { DENIED_TAGS } = require('../lib/fleet');
    const refs = new Set();
    for (const source of [String(branch || ''), String(message || '')]) {
      for (const m of source.toUpperCase().matchAll(/([A-Z]{2,6}-\d+)/g)) refs.add(m[1]);
      for (const m of source.toLowerCase().matchAll(/([a-z]{2,6})-(\d+)/g)) refs.add(`${m[1].toUpperCase()}-${m[2]}`);
    }
    if (!refs.size) return null;
    const projectionPath = path.join(findPrimaryRoot(root), '.atris', 'state', 'tasks.projection.json');
    if (!fs.existsSync(projectionPath)) return null;
    const projection = JSON.parse(fs.readFileSync(projectionPath, 'utf8'));
    for (const task of projection.tasks || []) {
      const ids = [task.display_id, task.legacy_ref].filter(Boolean).map(v => String(v).toUpperCase());
      if (!ids.some(id => refs.has(id))) continue;
      const tags = [task.tag, ...(task.metadata?.todo_tags || [])].filter(Boolean).map(t => String(t).toLowerCase());
      const hit = tags.find(t => DENIED_TAGS.includes(t));
      if (hit) return { taskId: ids[0], tag: hit };
    }
    return null;
  } catch {
    return null;
  }
}

function findPrimaryRoot(root) {
  const worktrees = listWorktrees(root);
  return worktrees[0]?.path || root;
}

function shellQuote(value) {
  const text = String(value || '');
  if (/^[A-Za-z0-9_./:@+-]+$/.test(text)) return text;
  return `'${text.replace(/'/g, `'"'"'`)}'`;
}

function experimentHealthProbe(statePath) {
  const script = [
    "const fs=require('fs')",
    'const state=JSON.parse(fs.readFileSync(process.argv[1],\'utf8\'))',
    'const last=Date.parse(state.last_run_date)',
    `process.exit(Number.isFinite(last)&&Date.now()-last<=${DAY_MS}?0:1)`,
  ].join(';');
  return `${shellQuote(process.execPath)} -e ${shellQuote(script)} ${shellQuote(statePath)}`;
}

function runShipHealthCheck(workspaceRoot, options = {}) {
  try {
    const now = options.now ? new Date(options.now) : new Date();
    const statePath = path.join(workspaceRoot, '.atris', 'state', 'experiments-daily.json');
    const state = fs.existsSync(statePath)
      ? JSON.parse(fs.readFileSync(statePath, 'utf8'))
      : {};
    const rawLastRunDate = state && state.last_run_date;
    const lastRunMs = rawLastRunDate ? Date.parse(rawLastRunDate) : null;
    if (rawLastRunDate && !Number.isFinite(lastRunMs)) {
      throw new Error('experiment state date is unreadable');
    }

    const ageMs = Number.isFinite(lastRunMs) ? now.getTime() - lastRunMs : null;
    if (ageMs !== null && ageMs <= DAY_MS) return { healthy: true, filed: false };

    const days = ageMs === null ? 1 : Math.max(1, Math.floor(ageMs / DAY_MS));
    console.log(`health check failed: no verified experiment in ${days} days. shipping still works, the metabolism does not.`);
    const filed = close.upsertSourceFlag({
      what: 'no verified experiment has run in over a day',
      owner: 'operator',
      lane: 'code',
      ttlDays: 1,
      source: SHIP_HEALTH_SOURCE,
      closeCondition: 'a verified experiment ran within 24 hours',
      probe: experimentHealthProbe(statePath),
    }, workspaceRoot, { now });
    return { healthy: false, ...filed };
  } catch (error) {
    console.log(`health check skipped: ${String(error && error.message || error).toLowerCase()}. shipping still works.`);
    return { healthy: null, filed: false, error };
  }
}

const MAP_REFRESH_COMMIT_MESSAGE = 'Refresh map references that moved';
const MAP_REFRESH_TRAILER = 'Co-authored-by: Atris <299057014+atris-builder[bot]@users.noreply.github.com>';

// Rewrites map line refs whose code moved (the same fix `atris doc-health
// --fix-refs` applies), then commits only the rewritten map files. A human-only
// remainder or an error never blocks the ship; pass --no-map-refresh to skip.
function refreshMovedMapRefs(root, args = []) {
  if (hasFlag(args, '--no-map-refresh')) return { skipped: true, refreshed: 0, left: 0 };
  try {
    const { changes, left } = fixMapDocs(root);
    if (changes.length) {
      const docs = [...new Set(changes.map(change => change.doc))];
      runGit(['add', '--', ...docs], { cwd: root });
      runGit(['commit', '-m', MAP_REFRESH_COMMIT_MESSAGE, '-m', MAP_REFRESH_TRAILER], { cwd: root });
      console.log(`map: refreshed ${changes.length} moved references`);
    } else {
      console.log('map: references current');
    }
    if (left.length) {
      console.log(`map: ${left.length} references need a human; run atris doc-health --fix-refs to see them`);
    }
    return { skipped: false, refreshed: changes.length, left: left.length };
  } catch (error) {
    const message = String((error && error.message) || error).toLowerCase().replace(/\s+/g, ' ').trim();
    console.log(`map: refresh skipped (${message}); the ship continues`);
    return { skipped: false, refreshed: 0, left: 0, error };
  }
}

function shipWorktree(args) {
  if (hasFlag(args, '--help') || hasFlag(args, '-h') || args[0] === 'help') {
    shipHelp();
    return 0;
  }
  const root = repoRoot();
  const dryRun = hasFlag(args, '--dry-run');
  const noPr = hasFlag(args, '--no-pr');
  const localMode = hasFlag(args, '--local') || hasFlag(args, '--local-merge');
  const merge = hasFlag(args, '--merge');
  const message = readFlag(args, '--message') || readFlag(args, '-m');
  const verify = readFlag(args, '--verify');
  let branch = currentBranch(root);
  const worktrees = listWorktrees(root);
  const primary = worktrees[0]?.path;
  const targetRef = normalizeTargetRef(root, readFlag(args, '--target') || defaultShipTarget(root));

  if (!branch && path.resolve(root) === path.resolve(primary)) {
    console.error('blocked: detached head on the primary checkout');
    return 2;
  }
  if (!branch) {
    branch = detachedShipBranch(root);
    if (!createDetachedShipBranch(root, branch)) return 2;
  }
  if (branch === 'master' || branch === 'main') {
    console.error('blocked: ship from a feature worktree branch, not master/main');
    return 2;
  }
  if (path.resolve(root) === path.resolve(primary) && !hasFlag(args, '--allow-primary')) {
    console.error('blocked: ship from an isolated worktree, not the primary checkout');
    return 2;
  }
  // Denied lanes are checked at dispatch, but a flight that was staffed
  // before a task entered a denied lane (or killed mid-flight) could still
  // ship: a payments command self-landed twice this way on 2026-07-26. The
  // ship gate is the last door, so it re-checks.
  if (!hasFlag(args, '--allow-denied-lane')) {
    const denied = deniedLaneForShip(root, branch, message);
    if (denied) {
      console.error(`blocked: this branch carries ${denied.taskId} which sits in the protected ${denied.tag} lane; a human lands it (or pass --allow-denied-lane on written order)`);
      return 2;
    }
  }

  let oneLapProof = null;
  try {
    oneLapProof = readOneLapProofBinding(root, branch);
  } catch (error) {
    console.error(`blocked: ${error.message}`);
    return 3;
  }
  const proofTreeMatches = (source) => {
    try {
      assertOneLapProofTree(root, oneLapProof, source);
      return true;
    } catch (error) {
      console.error(`blocked: ${error.message}`);
      return false;
    }
  };

  refreshRemoteRef(root, targetRef);
  const skippedAdapters = restoreRegeneratedAdapterChurn(root, message, { dryRun });
  const ignoredUnstagedFiles = dryRun ? new Set(skippedAdapters) : new Set();
  // Conductor plumbing must not make the checkout look dirty, or a flight where the
  // engine wrote nothing commits the fleet's own prompt file and calls it work.
  const counts = statusCounts(root, { ignoredUnstagedFiles, ignoreUntracked: isConductorUntracked })
    || { staged: 0, unstaged: 0, untracked: 0 };
  const dirty = counts.staged || counts.unstaged || counts.untracked;
  if (dirty && !message) {
    console.error('blocked: --message is required when there are local changes to commit');
    return 2;
  }

  if (dirty) {
    console.log(`commit: ${message}`);
    if (!dryRun) {
      runGit(['add', '-A'], { cwd: root });
      // `add -A` sweeps in the fleet's own prompt file and friends. Drop them from the
      // index so a work commit carries work, not harness plumbing. Safe when absent.
      unstageConductorArtifacts(root);
      if (!proofTreeMatches('index')) return 3;
      runGit(['commit', '-m', message], { cwd: root });
      if (!proofTreeMatches('head')) return 3;
    }
  } else {
    console.log('commit: skipped (no local changes)');
    if (!dryRun && !proofTreeMatches('head')) return 3;
  }

  if (dryRun) {
    console.log('map: skipped (dry-run)');
  } else {
    refreshMovedMapRefs(root, args);
  }

  if (verify) {
    const beforeVerify = dryRun ? [] : statusSnapshot(root);
    console.log(`verify: ${verify}`);
    if (!dryRun) runCommand(verify, { cwd: root });
    const afterVerifyRows = dryRun ? [] : statusSnapshot(root);
    const verifyDelta = newStatusRows(beforeVerify, afterVerifyRows);
    // This check exists to catch a verifier that writes files. Conductor plumbing was
    // already present before the verifier ran, so counting it here blocks a clean ship.
    const afterVerify = dryRun
      ? { staged: 0, unstaged: 0, untracked: 0 }
      : statusCounts(root, { ignoreUntracked: isConductorUntracked })
        || { staged: 0, unstaged: 0, untracked: 0 };
    if (!dryRun && (afterVerify.staged || afterVerify.unstaged || afterVerify.untracked)) {
      console.error(
        `blocked: verifier left checkout dirty staged=${afterVerify.staged} ` +
          `unstaged=${afterVerify.unstaged} untracked=${afterVerify.untracked}`
      );
      if (verifyDelta.length) {
        console.error(`new after verify: ${verifyDelta.slice(0, 8).join(', ')}`);
      }
      return 3;
    }
    if (!dryRun && !proofTreeMatches('head')) return 3;
  } else {
    console.log('verify: skipped (no --verify)');
  }

  const mergeCheck = dryRun
    ? { status: 0, stdout: 'dry-run' }
    : runGit(['merge-tree', '--write-tree', targetRef, 'HEAD'], { cwd: root, check: false });
  if (mergeCheck.status !== 0) {
    console.error(`blocked: branch does not merge cleanly into ${targetRef}`);
    console.error((mergeCheck.stderr || mergeCheck.stdout || '').trim());
    return 3;
  }
  console.log(`merge_check: ${targetRef} clean`);

  if (localMode) {
    console.log('push: skipped (local mode)');
    if (merge) {
      console.log('merge: requested (local mode)');
      if (!dryRun) {
        const targetBranch = baseBranchName(targetRef);
        const primaryBranch = currentBranch(primary);
        if (primaryBranch !== targetBranch) {
          const switched = runGit(['switch', targetBranch], { cwd: primary, check: false });
          if (switched.status !== 0) {
            throw new Error((switched.stderr || switched.stdout || `git switch ${targetBranch} failed`).trim());
          }
        }
        const primaryCounts = statusCounts(primary, { ignoreUntracked: isConductorUntracked }) || { staged: 0, unstaged: 0, untracked: 0 };
        if (primaryCounts.staged || primaryCounts.unstaged || primaryCounts.untracked) {
          throw new Error(
            `primary checkout dirty staged=${primaryCounts.staged} ` +
            `unstaged=${primaryCounts.unstaged} untracked=${primaryCounts.untracked}`
          );
        }
        runGit(['merge', '--no-ff', branch, '-m', `Merge ${branch}`], { cwd: primary });
        console.log('merge: merged (local mode)');
      }
    }
    console.log('pr: skipped (local mode)');
    if (merge && !dryRun) runShipHealthCheck(primary || root);
    console.log('done: worktree shipped');
    return 0;
  }

  console.log(`push: origin ${branch}`);
  if (!dryRun) runGit(['push', '-u', 'origin', branch], { cwd: root });

  if (!noPr || merge) {
    const title = message || branch;
    const pr = createOrFindPr(root, branch, targetRef, title, dryRun);
    console.log(`pr: ${pr}`);
    if (merge) {
      console.log('merge: requested');
      if (!dryRun) {
        const mergeRef = prMergeRef(pr);
        const mergeArgs = ['pr', 'merge'];
        if (mergeRef) mergeArgs.push(mergeRef);
        mergeArgs.push('--merge');
        const merged = mergePrWithRetry(mergeArgs, root);
        if (merged.status !== 0) throw new Error((merged.stderr || merged.stdout || 'gh pr merge failed').trim());
        // `gh pr merge` on an already-merged PR exits 0 with a warning
        // instead of failing, which would otherwise report a false landing.
        if (/already merged/i.test(`${merged.stdout}${merged.stderr}`)) {
          throw new Error(`gh pr merge reported the PR was already merged (stale PR reused): ${(merged.stdout || merged.stderr).trim()}`);
        }
        // A merge queue accepts the request before merging. Deleting its head
        // here closes the PR and cancels that request, so confirm the outcome.
        const confirmation = spawnSync('gh', ['pr', 'view', mergeRef, '--json', 'state,mergedAt'], { cwd: root, encoding: 'utf8' });
        if (confirmation.status !== 0) {
          throw new Error('could not confirm the merge; the source branch was kept');
        }
        let state;
        try { state = JSON.parse(confirmation.stdout); } catch {
          throw new Error('could not read the merge result; the source branch was kept');
        }
        if (state.state === 'OPEN' && !state.mergedAt) {
          console.log('merge: pending; kept the source branch while required checks finish');
          return 0;
        }
        if (state.state !== 'MERGED' || !state.mergedAt) {
          throw new Error('the change was not merged; the source branch was kept');
        }
        console.log('merge: merged');
        const deleted = runGit(['push', 'origin', '--delete', branch], { cwd: root, check: false });
        if (deleted.status === 0) {
          console.log(`merge: remote branch deleted ${branch}`);
        } else {
          const deleteOutput = (deleted.stderr || deleted.stdout || 'remote branch delete failed').trim();
          console.log(`merge: remote branch delete skipped: ${deleteOutput}`);
        }
      }
    }
  } else {
    console.log('pr: skipped (--no-pr)');
  }

  try {
    stampLatestOpenBriefForWorktree(root, {
      result: 'pass',
      note: `worktree ship completed into ${targetRef}`,
    }, { worktree: root });
  } catch {}
  if (merge && !dryRun) runShipHealthCheck(primary || root);
  console.log('done: worktree shipped');
  return 0;
}

function guard(args) {
  const root = repoRoot();
  const worktrees = listWorktrees(root);
  const primary = worktrees[0]?.path;
  if (path.resolve(root) === path.resolve(primary) && !hasFlag(args, '--allow-primary')) {
    console.error('blocked: this is the primary checkout; create an agent worktree first');
    console.error('run: atris worktree start --member <member>|--agent <name> --task "<short task>" --claim');
    return 2;
  }
  // Conductor plumbing (worktree metadata, the fleet prompt written for this very
  // engine, runtime scratch, the brief ledger) must not count as dirt, otherwise the
  // harness blocks the engine with the harness's own files.
  const counts = statusCounts(root, { ignoreUntracked: isConductorUntracked });
  if (counts && (counts.staged || counts.unstaged || counts.untracked) && !hasFlag(args, '--allow-dirty')) {
    console.error(`blocked: checkout is dirty staged=${counts.staged} unstaged=${counts.unstaged} untracked=${counts.untracked}`);
    return 3;
  }
  console.log('atris worktree guard: ok');
  return 0;
}

function prune(args) {
  const cmd = ['worktree', 'prune', '--verbose'];
  if (!hasFlag(args, '--apply')) cmd.push('--dry-run');
  const result = runGit(cmd, { cwd: repoRoot(), check: false });
  const output = `${result.stdout || ''}${result.stderr || ''}`.trim();
  console.log(output || (hasFlag(args, '--apply') ? 'no stale worktree registrations removed' : 'no stale worktree registrations found'));
  return result.status || 0;
}

const PROTECTED_BRANCHES = new Set(['main', 'master']);

// A worktree fresh off `worktree start` is merged into base by definition
// (zero commits yet), so without a grace window the janitor reaps it while
// the engine that requested it is still booting inside.
const WORKTREE_REAP_GRACE_MS = 60 * 60 * 1000;
const COMPLETED_UNMERGED_REAP_MS = WORKTREE_REAP_GRACE_MS;
const GENERATED_WORKTREE_CACHE_DIRS = [
  '.derivedData',
  '.next',
  '.swiftpm',
  '.cache/swiftpm',
  'node_modules/.cache',
];

function worktreeWithinReapGrace(worktreePath, now = Date.now()) {
  try {
    return now - fs.statSync(worktreePath).mtimeMs < WORKTREE_REAP_GRACE_MS;
  } catch {
    return false;
  }
}

function completedAgentOutputAgeMs(worktreePath, now = Date.now()) {
  try {
    const output = path.join(worktreePath, '.codex-last-message.txt');
    return now - fs.statSync(output).mtimeMs;
  } catch {
    return null;
  }
}

function canonicalPath(value) {
  try {
    return fs.realpathSync(value);
  } catch {
    return path.resolve(value);
  }
}

// null means the scan failed: we cannot tell who is inside, so callers keep
// every folder. An empty list would read as "nobody is here" and delete.
function listActiveProcessCwds() {
  const result = spawnSync('lsof', ['-n', '-a', '-d', 'cwd', '-F', 'n'], {
    encoding: 'utf8',
    maxBuffer: COMMAND_MAX_BUFFER_BYTES,
  });
  if (result.error || result.status !== 0) return null;
  return String(result.stdout || '')
    .split(/\r?\n/)
    .filter((line) => line.startsWith('n'))
    .map((line) => canonicalPath(line.slice(1)))
    .filter(Boolean);
}

// Absolute paths named on each program's command line, including flag values
// like --require=/x.js. A program can run a script from a work folder while
// its current folder is elsewhere; the folder scan alone misses it. The list
// prints arguments unquoted, so a path with a space is also kept as the rest
// of the line from where it starts; the folder match is a prefix check.
function parseProcessArgPaths(psOutput) {
  const paths = new Set();
  const starts = /(?:^|\s)(?:[^\s=]*=)?(?=\/)/g;
  for (const raw of String(psOutput || '').split(/\r?\n/)) {
    const line = raw.trim();
    for (const match of line.matchAll(starts)) {
      const rest = line.slice(match.index + match[0].length);
      const token = rest.split(/\s/, 1)[0];
      if (token.length > 1) paths.add(token);
      if (rest.length > token.length) paths.add(rest);
    }
  }
  return [...paths];
}

function listActiveProcessArgPaths() {
  const result = spawnSync('ps', ['-axww', '-o', 'args='], {
    encoding: 'utf8',
    maxBuffer: COMMAND_MAX_BUFFER_BYTES,
  });
  if (result.error || result.status !== 0) return [];
  return parseProcessArgPaths(result.stdout);
}

// Everything a running program is anchored to: its current folder plus any
// script path on its command line.
function listActiveProcessPaths() {
  const cwds = listActiveProcessCwds();
  if (!Array.isArray(cwds)) return cwds;
  return cwds.concat(listActiveProcessArgPaths());
}

function worktreeHasActiveProcess(worktreePath, activeCwds) {
  if (!Array.isArray(activeCwds)) return true;
  const resolved = canonicalPath(worktreePath);
  const prefix = `${resolved}${path.sep}`;
  return activeCwds.some((cwd) => {
    const active = canonicalPath(cwd);
    return active === resolved || active.startsWith(prefix);
  });
}

// Every work-folder removal leaves one line naming who removed it and why, in
// the main checkout's state so the line outlives the folder it describes.
function recordWorktreeRemoval(root, { path: removedPath, branch = '', by, reason }) {
  try {
    const common = runGit(['rev-parse', '--path-format=absolute', '--git-common-dir'], { cwd: root, check: false });
    const main = common.status === 0 ? path.dirname(common.stdout.trim()) : root;
    const file = path.join(main, '.atris', 'state', 'worktree_removals.jsonl');
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.appendFileSync(file, `${JSON.stringify({
      at: new Date().toISOString(), path: removedPath, branch: branch || null, by, reason, pid: process.pid,
    })}\n`);
  } catch {}
}

function pruneGeneratedWorktreeCaches(worktreePath, { apply = false } = {}) {
  const candidates = [];
  const pruned = [];
  for (const relative of GENERATED_WORKTREE_CACHE_DIRS) {
    const target = path.join(worktreePath, relative);
    if (!fs.existsSync(target)) continue;
    const ignored = runGit(['check-ignore', '-q', '--', relative], { cwd: worktreePath, check: false });
    if (ignored.status !== 0) continue;
    const item = { worktree: worktreePath, path: target, relative };
    candidates.push(item);
    if (!apply) continue;
    try {
      fs.rmSync(target, { recursive: true, force: true });
      pruned.push(item);
    } catch (error) {
      item.error = String((error && error.message) || error);
    }
  }
  return { candidates, pruned };
}

function cleanupWorktrees({ root = repoRoot(), base: baseOverride = '', apply = false, activeCwds: activeCwdsOverride, by = 'atris worktree cleanup' } = {}) {
  const worktrees = listWorktrees(root);
  const primary = worktrees[0]?.path ? path.resolve(worktrees[0].path) : '';
  const current = path.resolve(root);
  const activeCwds = Array.isArray(activeCwdsOverride) ? activeCwdsOverride.map(canonicalPath) : listActiveProcessPaths();
  const base = normalizeTargetRef(root, baseOverride || defaultShipTarget(root));
  refreshRemoteRef(root, base);
  const candidates = [];
  const kept = [];
  const removed = [];
  const cacheCandidates = [];
  const cachePruned = [];
  const pruneCachesForKept = (wtPath) => {
    if (worktreeWithinReapGrace(wtPath)) return;
    const caches = pruneGeneratedWorktreeCaches(wtPath, { apply });
    cacheCandidates.push(...caches.candidates);
    cachePruned.push(...caches.pruned);
  };

  for (const wt of worktrees) {
    const wtPath = path.resolve(wt.path);
    const item = { path: wt.path, branch: wt.branch, head: wt.head };
    if (wtPath === primary) {
      kept.push({ ...item, reason: 'primary_checkout' });
      continue;
    }
    if (wtPath === current) {
      kept.push({ ...item, reason: 'current_checkout' });
      continue;
    }
    if (wt.locked) {
      kept.push({ ...item, reason: 'locked' });
      continue;
    }
    if (PROTECTED_BRANCHES.has(wt.branch)) {
      kept.push({ ...item, reason: 'protected_branch' });
      continue;
    }
    if (worktreeHasActiveProcess(wtPath, activeCwds)) {
      kept.push({ ...item, reason: activeCwds ? 'active_process' : 'process_scan_failed' });
      continue;
    }
    const rawCounts = statusCounts(wt.path);
    const counts = statusCounts(wt.path, { ignoreAny: isConductorArtifact });
    if (!rawCounts || !counts) {
      kept.push({ ...item, reason: 'missing_or_unreadable' });
      continue;
    }
    if (counts.staged || counts.unstaged || counts.untracked) {
      pruneCachesForKept(wtPath);
      kept.push({ ...item, reason: 'dirty', staged: counts.staged, unstaged: counts.unstaged, untracked: counts.untracked });
      continue;
    }
    if (!wt.head) {
      pruneCachesForKept(wtPath);
      kept.push({ ...item, reason: 'missing_head' });
      continue;
    }
    const artifactOnlyDirty = Boolean(
      (rawCounts.staged || rawCounts.unstaged || rawCounts.untracked)
      && !(counts.staged || counts.unstaged || counts.untracked)
    );
    const merged = runGit(['merge-base', '--is-ancestor', wt.head, base], { cwd: root, check: false }).status === 0;
    if (!merged) {
      const completedAgeMs = completedAgentOutputAgeMs(wtPath);
      if (completedAgeMs === null || completedAgeMs < COMPLETED_UNMERGED_REAP_MS) {
        pruneCachesForKept(wtPath);
        kept.push({
          ...item,
          reason: completedAgeMs === null ? 'unmerged' : 'completed_unmerged_retention',
          ...(completedAgeMs === null ? {} : { retention_hours: 1 }),
        });
        continue;
      }
      const candidate = {
        ...item,
        reason: 'completed_unmerged_checkout_expired',
        branch_preserved: true,
        artifact_only_dirty: artifactOnlyDirty,
      };
      candidates.push(candidate);
      if (!apply) continue;
      const removeArgs = ['worktree', 'remove'];
      if (artifactOnlyDirty) removeArgs.push('--force');
      removeArgs.push(wt.path);
      const removedResult = runGit(removeArgs, { cwd: root, check: false });
      if (removedResult.status === 0) {
        removed.push(candidate);
        recordWorktreeRemoval(root, { path: wt.path, branch: wt.branch, by, reason: candidate.reason });
      } else {
        kept.push({ ...item, reason: 'remove_failed', error: (removedResult.stderr || removedResult.stdout || '').trim() });
      }
      continue;
    }
    if (worktreeWithinReapGrace(wtPath)) {
      kept.push({ ...item, reason: 'fresh_worktree_grace' });
      continue;
    }
    const candidate = { ...item, reason: 'merged_into_base', artifact_only_dirty: artifactOnlyDirty };
    candidates.push(candidate);
    if (!apply) continue;
    const removeArgs = ['worktree', 'remove'];
    if (artifactOnlyDirty) removeArgs.push('--force');
    removeArgs.push(wt.path);
    const removedResult = runGit(removeArgs, { cwd: root, check: false });
    if (removedResult.status === 0) {
      removed.push(candidate);
      recordWorktreeRemoval(root, { path: wt.path, branch: wt.branch, by, reason: candidate.reason });
    } else {
      kept.push({ ...item, reason: 'remove_failed', error: (removedResult.stderr || removedResult.stdout || '').trim() });
    }
  }

  return { apply, base, candidates, removed, kept, cacheCandidates, cachePruned };
}

function cleanup(args) {
  const asJson = hasFlag(args, '--json');
  const result = cleanupWorktrees({
    root: repoRoot(),
    base: readFlag(args, '--base'),
    apply: hasFlag(args, '--apply'),
  });
  if (asJson) {
    console.log(JSON.stringify({ ok: true, ...result }, null, 2));
    return 0;
  }
  const action = result.apply ? 'removed' : 'candidate';
  console.log(`cleanup: ${result.apply ? 'applied' : 'dry-run'} base=${result.base}`);
  console.log(`${action}s: ${result.apply ? result.removed.length : result.candidates.length}`);
  for (const item of result.apply ? result.removed : result.candidates) {
    console.log(`${action}: ${item.path} branch=${item.branch} reason=${item.reason}`);
  }
  const cacheAction = result.apply ? 'cache_pruned' : 'cache_candidate';
  console.log(`${cacheAction}s: ${result.apply ? result.cachePruned.length : result.cacheCandidates.length}`);
  for (const item of result.apply ? result.cachePruned : result.cacheCandidates) {
    console.log(`${cacheAction}: ${item.path}`);
  }
  console.log(`kept: ${result.kept.length}`);
  if (!result.apply && result.candidates.length) console.log('next: atris worktree cleanup --apply');
  return 0;
}

function guide() {
  console.log('Atris worktree agent recipe');
  console.log('');
  console.log('Default: stay in the current checkout for small, clean, single-agent fixes.');
  console.log('Use a worktree for dirty launchers, parallel agents, risky edits, releases, or long proof runs.');
  console.log('');
  console.log('1. Start isolated work when needed:');
  console.log('   atris worktree start --member <member> --task "<task>" --claim');
  console.log('   atris worktree start --agent <agent> --task "<task>"');
  console.log('');
  console.log('2. Move into the printed path:');
  console.log('   cd <printed path>');
  console.log('   atris worktree guard');
  console.log('');
  console.log('3. Tie work to mission/member state when relevant:');
  console.log('   atris mission start "<objective>" --owner <member> --verify "<cmd>"');
  console.log('   atris member goal-from-mission <member>');
  console.log('   atris member tick <member>');
  console.log('   atris mission tick <id> --verify --complete-on-pass');
  console.log('');
  console.log('4. Ship only from the isolated worktree:');
  console.log('   atris worktree ship --message "<commit>" --verify "<cmd>" --merge [--target <ref>]');
  console.log('   --target <ref> overrides the default landing target (default: branch atris-base, else origin default branch)');
  console.log('   recommended verify: npm run test:fast && node --test <focused files>');
  console.log('');
  console.log('5. Cleanup is part of creation and the janitor; run it directly any time:');
  console.log('   atris worktree cleanup');
  console.log('   atris worktree cleanup --apply');
  console.log('');
  console.log('Notes: start uses the current upstream/default remote base, not dirty local HEAD.');
  console.log('Start reaps completed checkouts first. Cleanup preserves branches and source changes, skips live work, and prunes only ignored build caches.');
  console.log('Use `atris worktree status` to see all worktrees and dirty counts.');
  return 0;
}

function help() {
  console.log('Usage: atris worktree <guide|start|ship|status|guard|prune|cleanup>');
  console.log('');
  console.log('  atris worktree guide');
  console.log('  atris worktree start --member <member>|--agent <name> --task "<task>" [--claim] [--force]');
  console.log('    --force         start even when another recent flight shares a task word');
  console.log('  atris worktree ship --message "<commit>" --verify "<cmd>" [--merge] [--target <ref>] [--local]');
  console.log('    --target <ref>  override the default landing target (default: branch atris-base, else origin default branch)');
  console.log('    --local         merge into the local primary checkout instead of pushing and opening a PR');
  console.log('    --no-map-refresh  skip the automatic refresh of moved map line references');
  console.log('    recommended verify: npm run test:fast && node --test <focused files>');
  console.log('  atris worktree status');
  console.log('  atris worktree guard [--allow-primary] [--allow-dirty]');
  console.log('  atris worktree prune [--apply]');
  console.log('  atris worktree cleanup [--apply] [--json] [--base origin/master]  reap completed checkouts and ignored build caches');
}

function worktreeCommand(args = []) {
  const sub = args[0] || 'status';
  const rest = args.slice(1);
  if (sub === '--help' || sub === '-h' || sub === 'help') {
    help();
    return 0;
  }
  if (sub === 'guide' || sub === 'recipe') return guide();
  if (sub === 'start') return startWorktree(rest);
  if (sub === 'ship') return shipWorktree(rest);
  if (sub === 'status') {
    printStatus();
    return 0;
  }
  if (sub === 'guard') return guard(rest);
  if (sub === 'prune') return prune(rest);
  if (sub === 'cleanup' || sub === 'clean') return cleanup(rest);
  help();
  return 2;
}

module.exports = {
  branchName,
  collidingFlights,
  mergePrWithRetry,
  createAgentWorktree,
  deniedLaneForShip,
  createOrFindPr,
  cleanupWorktrees,
  defaultMainlineBase,
  defaultStartBase,
  gitFailureDetail,
  gitNetworkEnvironment,
  describeFlightAge,
  flightStampMs,
  listActiveProcessPaths,
  listWorktrees,
  parseAgentFlightName,
  parseProcessArgPaths,
  parseWorktrees,
  normalizeTargetRef,
  recordWorktreeRemoval,
  refreshMovedMapRefs,
  slugify,
  taskTokens,
  statusCounts,
  swarloClaim,
  runShipHealthCheck,
  worktreeCommand,
  worktreeHasActiveProcess,
};
