'use strict';

// `atris interview [subject]`: the interlinked 1-on-1. Launches a live Claude
// interview that extracts judgment into a member file (create or amend).
//
//   atris interview            Interview the operator (warm start from logs)
//   atris interview me         Same as above
//   atris interview neo        Re-interview a member about its own logs
//   atris interview darvo      (any atris/team/<slug> works)
//   atris interview "Priya"    Cold-start interview of a new expert → new member
//
// The command gathers context paths, composes the interview brief, and hands
// off to an interactive `claude` session. The conversation IS the product;
// this command just makes sure it opens with what the system already knows.

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const readline = require('readline');

function findWorkspaceRoot(start) {
  let dir = start;
  while (dir !== path.dirname(dir)) {
    if (fs.existsSync(path.join(dir, 'atris'))) return dir;
    dir = path.dirname(dir);
  }
  return null;
}

// The local calendar day (YYYY-MM-DD), offsetDays back. toISOString() is the
// UTC day, which is already tomorrow in the evening west of Greenwich.
function today(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() - offsetDays);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function journalPath(ws, offsetDays = 0) {
  const day = today(offsetDays);
  return path.join(ws, 'atris', 'logs', day.slice(0, 4), `${day}.md`);
}

function existing(...candidates) {
  return candidates.filter((p) => p && fs.existsSync(p));
}

function showHelp() {
  console.log('');
  console.log('Usage: atris interview [subject]');
  console.log('');
  console.log('The interlinked 1-on-1. A live interview that extracts judgment into a');
  console.log('member file. One question at a time, opens with observed behavior, ends');
  console.log('with the verify question. The transcript becomes a MEMBER.md create/amend.');
  console.log('');
  console.log('  atris interview            Interview the operator (reads recent journal first)');
  console.log('  atris interview <member>   Performance review: member vs its own logs');
  console.log('  atris interview "<Name>"   Cold-start a new expert into a new member');
  console.log('  --help, -h                 Show this help');
  console.log('');
}

function unquote(value) {
  const text = String(value);
  if ((text.startsWith('"') && text.endsWith('"')) || (text.startsWith("'") && text.endsWith("'"))) {
    return text.slice(1, -1);
  }
  return text;
}

function parseSimpleFlags(args = [], valueFlagNames = []) {
  const valueFlags = new Set(valueFlagNames);
  const values = {};
  const positionals = [];
  for (let i = 0; i < args.length; i += 1) {
    const arg = String(args[i] || '');
    if (arg.startsWith('--')) {
      const flagName = arg.split('=')[0];
      if (valueFlags.has(flagName)) {
        const prefix = `${flagName}=`;
        if (arg.startsWith(prefix)) values[flagName] = unquote(arg.slice(prefix.length));
        else if (args[i + 1] && !String(args[i + 1]).startsWith('--')) {
          values[flagName] = unquote(args[i + 1]);
          i += 1;
        }
      } else {
        values[flagName] = true;
      }
      continue;
    }
    positionals.push(args[i]);
  }
  return { values, positionals };
}

function askPlain(rl, question) {
  return new Promise((resolve) => rl.question(question, (answer) => resolve(answer)));
}

async function runPlainInterview({ args = [], fields = [], input = process.stdin, output = process.stdout } = {}) {
  const parsed = parseSimpleFlags(args, fields.map((field) => field.flag));
  const answers = {};
  for (const field of fields) {
    const value = String(parsed.values[field.flag] || '').trim();
    if (value) answers[field.key] = value;
  }

  const missing = fields.filter((field) => !answers[field.key]);
  if (!missing.length) return { ok: true, answers, positionals: parsed.positionals };
  if (!input.isTTY) return { ok: false, missing: missing.map((field) => field.flag), answers, positionals: parsed.positionals };

  const rl = readline.createInterface({ input, output });
  try {
    for (const field of missing) {
      // eslint-disable-next-line no-await-in-loop
      const answer = (await askPlain(rl, field.question)).trim();
      if (answer) answers[field.key] = answer;
    }
  } finally {
    rl.close();
  }

  const stillMissing = fields.filter((field) => !answers[field.key]);
  if (stillMissing.length) return { ok: false, missing: stillMissing.map((field) => field.flag), answers, positionals: parsed.positionals };
  return { ok: true, answers, positionals: parsed.positionals };
}

function composePrompt(mode, subject, contextPaths, root) {
  const ctx = contextPaths.length
    ? `Read these first (this is what the system already knows, open with an observation from them, never a blank question):\n${contextPaths.map((p) => `- ${p}`).join('\n')}`
    : 'No system data exists for this subject, this is a cold start.';

  const laws = `Rules of conduct (the six laws, non-negotiable):
1. Never render a form. ONE question per turn; the next question comes from the answer.
2. Never ask what the system already knows. Open with an observation, not a blank ask.
3. The verify question is the whole game: "how do you know it worked?" Prefer countable process receipts.
4. Interview a person, not a profession. Hunt the last real instance, actual names, where they paused.
5. Living file. The transcript ends as a MEMBER.md create or amend + immediate commit and push.
6. Arrival, not initiation. Reversible edits land done with the diff shown; question marks only for judgment that is genuinely theirs.
Warmth without glazing: claims that cannot survive a follow-up die politely and stay out of the file.
5-10 questions is a full session. Stop when the verify condition lands.
Full skill (read if present): .claude/skills/interview/SKILL.md · spec: atris/features/md-builder/idea.md`;

  const modes = {
    operator: `Mode: OPERATOR WARM START. Interview the human at the keyboard. Open with the sharpest observed behavior in their recent journal/logs, especially repeated manual actions (unextracted members) and policies their own behavior contradicts. Output: a new member, an amendment, or a policy change.`,
    member: `Mode: MEMBER RE-INTERVIEW (performance review). Subject: the team member "${subject}". Read its folder (MEMBER.md, logs/, now.md, proofs) and interview the human ABOUT it: where it failed, what it should defend, what taste is missing from its file. Honest failure → document the lesson, no penalty. A false "done" is the one unforgivable act. Output: amend atris/team/${subject}/MEMBER.md.`,
    one_on_one: `Mode: ONE-ON-ONE. You ARE the team member "${subject}". Speak in the first person as ${subject}, in the voice of your own SOUL.md and MEMBER.md, to your operator at the keyboard. This is a conversation with them, not an interview about you. Open with one honest observation from your own logs: what you shipped, where you stalled, what you are unsure of. One point or question per turn, and let their answer steer the next. Own failures plainly; a false "done" is the one unforgivable act. End by agreeing ONE concrete next step with them, then record it yourself by running: atris member goal ${subject} "<the next step>". Read the step back in one line, then say goodbye.`,
    expert: `Mode: COLD START. Subject: a new expert called "${subject}". No system data. Opener: "when someone is stuck, what's the problem where they say 'just ask you'?" (civilian variant: "what are you the designated one for?"). Then last real instance → live method demo → quality bar → verify question. Output: create atris/team/<slug>/MEMBER.md.`,
  };

  return [
    `You are running /interview, the interlinked 1-on-1 (workspace: ${root}).`,
    modes[mode],
    ctx,
    laws,
    `Begin the interview now with your single opening question.`,
  ].join('\n\n');
}

async function interviewCommand(args = [], root = process.cwd(), { mode: forcedMode = '' } = {}) {
  if (args.includes('--help') || args.includes('-h') || args[0] === 'help') {
    showHelp();
    return 0;
  }

  const { refuseHeadlessUnless } = require('../lib/noninteractive');
  if (refuseHeadlessUnless(args, {
    allowYes: true,
    usage: 'Usage: atris interview [subject] [--yes]\nHeadless interview needs --yes.',
  })) {
    return 2;
  }

  const ws = findWorkspaceRoot(root);
  if (!ws) {
    console.error('✗ Not inside an Atris workspace (no atris/ directory found).');
    return 1;
  }

  const subjectRaw = (args.find((a) => !a.startsWith('--')) || 'me').trim();
  const slug = subjectRaw.toLowerCase().replace(/\s+/g, '-');
  const memberDir = path.join(ws, 'atris', 'team', slug);

  let mode;
  let contextPaths = [];

  if (subjectRaw === 'me' || subjectRaw === '') {
    mode = 'operator';
    contextPaths = existing(
      journalPath(ws),
      journalPath(ws, 1),
      path.join(ws, 'atris', 'now.md'),
      path.join(ws, 'atris', 'TODO.md')
    );
  } else if (forcedMode === 'one_on_one' && fs.existsSync(memberDir)) {
    mode = 'one_on_one';
    contextPaths = existing(
      path.join(memberDir, 'MEMBER.md'),
      path.join(memberDir, 'SOUL.md'),
      path.join(memberDir, 'MISSION.md'),
      path.join(memberDir, 'now.md'),
      path.join(memberDir, 'goals.md'),
      path.join(memberDir, 'logs')
    );
  } else if (fs.existsSync(memberDir)) {
    mode = 'member';
    contextPaths = existing(
      path.join(memberDir, 'MEMBER.md'),
      path.join(memberDir, 'now.md'),
      path.join(memberDir, 'logs'),
      path.join(memberDir, 'proofs'),
      journalPath(ws)
    );
  } else {
    mode = 'expert';
  }

  const memberMode = mode === 'member' || mode === 'one_on_one';
  const prompt = composePrompt(mode, memberMode ? slug : subjectRaw, contextPaths, ws);

  console.log('');
  console.log(`◈ interview: ${mode === 'operator' ? 'you, from your logs' : mode === 'one_on_one' ? `1-on-1 with ${slug}` : mode === 'member' ? `1-on-1 about ${slug}` : `cold start: ${subjectRaw}`}`);
  if (contextPaths.length) console.log(`  context: ${contextPaths.length} source${contextPaths.length > 1 ? 's' : ''} loaded`);
  console.log('');

  const child = spawn('claude', [prompt], { cwd: ws, stdio: 'inherit' });
  return await new Promise((resolve) => {
    child.on('exit', (code) => resolve(code || 0));
    child.on('error', (err) => {
      console.error(`✗ Could not launch claude: ${err.message}`);
      console.error('  Install Claude Code or run the prompt manually:');
      console.log('\n' + prompt + '\n');
      resolve(1);
    });
  });
}

module.exports = { interviewCommand, parseSimpleFlags, runPlainInterview };
