'use strict';

// `atris pulse` - the durable overnight self-improvement heartbeat for atris-cli.
//
//   atris pulse tick      run ONE self-improvement tick (what launchd calls)
//   atris pulse status    liveness, reward sum, ghost-tick detection
//   atris pulse install   write the tick script + install a launchd agent
//   atris pulse uninstall remove the launchd agent
//   atris pulse run       run N ticks in the foreground (manual / testing)
//
// One tick: lock -> 'started' receipt -> run mission engine -> verify -> write
// 'finished' receipt (pulse_agi_loop_receipts.jsonl) + reward scorecard
// (scorecards.jsonl, gated) -> release lock. The whole point is that this fires
// from launchd, so it self-improves overnight without Claude Code open.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const pulse = require('../lib/pulse');
const rsi = require('../lib/rsi-record');
const { DEFAULT_CLAUDE_RUNNER_MODEL } = require('../lib/runner-command');
const { hasFlag } = require('../lib/arg-parser');

// Preserve the existing rule that the next token is a value, even if it is a flag.
function readFollowingFlag(args, name, fallback = null) {
  const i = args.indexOf(name);
  if (i === -1 || i === args.length - 1) return fallback;
  return args[i + 1];
}
function wantsJson(args) {
  return hasFlag(args, '--json');
}

function helpText() {
  return `
Usage: atris pulse <tick|status|install|uninstall|run> [options]

Durable overnight self-improvement heartbeat.

Commands:
  tick        Run one heartbeat tick
  status      Show liveness, reward, and ghost-tick detection
  install     Install the launchd heartbeat
  uninstall   Remove the launchd heartbeat
  run         Run bounded ticks in the foreground

Options:
  --json                 Print machine-readable output
  --no-claude            Do not spawn Claude-backed mission work
  --no-verify            Skip verifier command
  --verify "<cmd>"       Verifier for changed-work ticks (default: npm test if package.json exists, else none)
  --cadence "<cron>"     Cron cadence for install
  --days <n>             Auto-expire installed heartbeat after n days
  --hours <n>            Auto-expire installed heartbeat after n hours
  --no-keep-awake        Install without holding the Mac awake for the window (macOS)
  --no-autopilot         install/tick: never fall back to autopilot (only campaigns and due missions)
  --no-campaigns         tick: skip pushing campaigns (atris campaign tick)
  --model <id>           Runner model alias/id for installed heartbeat
  --runner-profile <n>   Runner profile for installed heartbeat (e.g. atris-fast)
  --runner-bin <path>    Runner binary for installed heartbeat
  --runner-template <s>  Runner command template for installed heartbeat
  --max-ticks <n>        Number of foreground ticks for run
  --help, -h             Show this help

Tip: \`atris loop start --overnight\` is the one front door to this.
`.trim();
}

function showHelp() {
  process.stdout.write(`${helpText()}\n`);
  return { ok: true, action: 'pulse_help' };
}

function emit(obj, asJson) {
  if (asJson) {
    process.stdout.write(`${JSON.stringify(obj, null, 2)}\n`);
  }
  return obj;
}

// --- engine: run one mission-run-due tick via the real CLI ---

function runMissionEngine(root, { noClaude = false, timeoutMs = 600000 } = {}) {
  const cliPath = path.join(__dirname, '..', 'bin', 'atris.js');
  const args = ['mission', 'run', '--due', '--max-ticks', '1', '--complete-on-pass', '--json'];
  if (noClaude) args.push('--no-claude');
  const result = spawnSync(process.execPath, [cliPath, ...args], {
    cwd: root,
    encoding: 'utf8',
    timeout: timeoutMs,
    env: { ...process.env, ATRIS_SKIP_UPDATE_CHECK: '1' },
  });
  let payload = null;
  try {
    payload = JSON.parse(result.stdout || '{}');
  } catch {}
  // Map the mission-run result to a normalized actor outcome.
  const reason = payload && payload.reason ? payload.reason
    : (result.status === 0 ? 'completed' : 'error');
  return {
    actor: 'mission_run_due',
    ok: result.status === 0,
    reason, // 'completed' | 'no_due_mission' | 'error' | ...
    status: result.status,
    payload,
    stdout: String(result.stdout || '').slice(-2000),
    stderr: String(result.stderr || '').slice(-2000),
  };
}

// Fallback worker: one headless autopilot tick. This is the path that reaches
// proposeCandidateHorizons - i.e. where the member AUTHORS a new goal when no
// mission is due, instead of idling.
function runAutopilotTick(root, { timeoutMs = 600000 } = {}) {
  const cliPath = path.join(__dirname, '..', 'bin', 'atris.js');
  const args = ['autopilot', '--auto', '--iterations=1'];
  const result = spawnSync(process.execPath, [cliPath, ...args], {
    cwd: root,
    encoding: 'utf8',
    timeout: timeoutMs,
    env: { ...process.env, ATRIS_SKIP_UPDATE_CHECK: '1' },
  });
  return {
    actor: 'autopilot',
    ok: result.status === 0,
    reason: result.status === 0 ? 'completed' : 'error',
    status: result.status,
    stdout: String(result.stdout || '').slice(-2000),
    stderr: String(result.stderr || '').slice(-2000),
  };
}

// Campaigns first: one bounded push on the next campaign here that has work
// (atris campaign tick). A campaign mission can outlast a mission tick, so it gets
// up to 50 minutes; the campaign run lock keeps two drivers off one campaign.
const CAMPAIGN_TICK_MS = 50 * 60 * 1000;
function runCampaignEngine(root, { timeoutMs = CAMPAIGN_TICK_MS } = {}) {
  const cliPath = path.join(__dirname, '..', 'bin', 'atris.js');
  const result = spawnSync(process.execPath, [cliPath, 'campaign', 'tick', '--json'], {
    cwd: root,
    encoding: 'utf8',
    timeout: timeoutMs,
    env: { ...process.env, ATRIS_SKIP_UPDATE_CHECK: '1' },
  });
  let payload = null;
  try {
    payload = JSON.parse(result.stdout || '{}');
  } catch {}
  const idle = Boolean(payload && payload.picked === null);
  return {
    actor: 'campaign_tick',
    ok: result.status === 0,
    reason: idle ? 'no_campaign_work' : (payload && payload.reason) || (result.status === 0 ? 'advanced' : 'error'),
    idle,
    status: result.status,
    payload,
    stdout: String(result.stdout || '').slice(-2000),
    stderr: String(result.stderr || '').slice(-2000),
  };
}

// The full heartbeat composition: push a campaign that has work, else continue a
// due mission, else author+pursue a new goal via autopilot. This is the /loop
// skill's logic, encoded for OS cron.
function runEngine(root, { noClaude = false, autopilotFallback = true, campaigns = true, timeoutMs = 600000 } = {}) {
  if (campaigns && !noClaude) {
    const campaign = runCampaignEngine(root);
    if (!campaign.idle) return campaign;
  }
  const mission = runMissionEngine(root, { noClaude, timeoutMs });
  if (pulse.shouldFallbackToAutopilot({ missionReason: mission.reason, autopilotFallback, noClaude })) {
    const ap = runAutopilotTick(root, { timeoutMs });
    return { ...ap, fell_back_from: 'no_due_mission' };
  }
  return mission;
}

function gitChangedFiles(root) {
  try {
    const r = spawnSync('git', ['-C', root, 'status', '--porcelain'], { encoding: 'utf8', timeout: 15000 });
    if (r.status !== 0) return [];
    return String(r.stdout || '')
      .split('\n')
      .map((l) => l.slice(3).trim())
      .filter(Boolean);
  } catch {
    return [];
  }
}

// A cheap snapshot of the working tree: current HEAD + the set of dirty files.
// Comparing two snapshots gives a tick's ACTUAL contribution (a new commit, or
// files it newly dirtied) - never the whole pre-existing dirty tree.
function gitSnapshot(root) {
  let head = null;
  try {
    const r = spawnSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8', timeout: 15000 });
    if (r.status === 0) head = String(r.stdout || '').trim();
  } catch {}
  return { head, dirty: new Set(gitChangedFiles(root)) };
}

// 30 min: the full suite takes ~8 min alone but 15+ under concurrent mission
// load; a 10-min cap turned green suites into false verify FAILs (tick 159).
function runVerify(root, verifyCmd, timeoutMs = 1800000) {
  if (!verifyCmd) return { passed: null, cmd: null };
  const { envWithNodeDir } = require('../lib/spawn-env');
  const r = spawnSync(verifyCmd, {
    cwd: root,
    shell: true,
    encoding: 'utf8',
    timeout: timeoutMs,
    env: envWithNodeDir({ ...process.env, ATRIS_SKIP_UPDATE_CHECK: '1', ATRIS_AGENT_PROOF_ONLY: '0' }),
  });
  return { passed: r.status === 0, cmd: verifyCmd, status: r.status };
}

function refreshOrbPolicyLessons(root, ingestion, now = new Date()) {
  if (!ingestion || ingestion.historical_failures < 1) return null;
  const {
    loadHistory,
    mineProofPolicy,
    writePolicyLessons,
    syncLessonsMd,
  } = require('../lib/policy-lessons');
  const mined = mineProofPolicy(loadHistory(root), {
    now,
    orbWindowDays: ingestion.summary && ingestion.summary.days,
  });
  const statePath = writePolicyLessons(root, mined);
  const lessonsMd = syncLessonsMd(root, mined);
  const orbLesson = mined.lessons.find((lesson) => lesson.id === 'orb-job-failures') || null;
  return {
    status: orbLesson ? orbLesson.status : null,
    state_path: statePath,
    lessons_md_path: lessonsMd.path,
    lessons_md_written: lessonsMd.written,
  };
}

// --- atris pulse tick ---

function tickCommand(args, root = process.cwd()) {
  const asJson = wantsJson(args);
  const noClaude = hasFlag(args, '--no-claude');
  const noVerify = hasFlag(args, '--no-verify');
  const verifyCmd = noVerify ? null : readFollowingFlag(args, '--verify', pulse.defaultVerifyCmd(root));
  const startedAt = Date.now();

  // Detect a previous tick that died mid-run before we take the lock.
  const priorReceipts = pulse.readPulseReceipts(root);
  const priorStale = pulse.detectStaleTick(priorReceipts);

  const lock = pulse.acquireLock(root);
  if (!lock.acquired) {
    const out = { ok: false, action: 'pulse_tick', skipped: true, reason: 'locked', age_ms: lock.ageMs };
    if (!asJson) process.stdout.write('pulse: previous tick still running; skipped.\n');
    return emit(out, asJson);
  }

  const tickIndex = pulse.nextTickIndex(root);
  let orbIngestion = {
    summary: null,
    improvement_candidates: [],
    scorecards_written: 0,
    historical_failures: 0,
  };
  let orbPolicy = null;
  let orbIngestError = null;
  try {
    orbIngestion = pulse.ingestOrbScorecard(root);
    orbPolicy = refreshOrbPolicyLessons(root, orbIngestion);
  } catch (error) {
    orbIngestError = String(error && error.message ? error.message : error);
  }
  const signalExitCode = { SIGINT: 130, SIGTERM: 143 };
  let interrupted = false;
  const finishInterrupted = (signal) => {
    if (interrupted) return;
    interrupted = true;
    try {
      pulse.appendPulseReceipt(root, pulse.buildInterruptedPulseReceipt({
        tickIndex,
        signal,
        startedAt,
        prevTickStale: priorStale.stale,
      }));
    } catch {}
    try {
      pulse.releaseLock(root);
    } catch {}
    process.exit(signalExitCode[signal] || 1);
  };
  process.once('SIGINT', finishInterrupted);
  process.once('SIGTERM', finishInterrupted);

  // 'started' receipt - if the tick dies after this, the orphan surfaces as a ghost.
  pulse.appendPulseReceipt(root, pulse.buildPulseReceipt({
    tickIndex,
    phase: 'started',
    prevTickStale: priorStale.stale,
    orbScorecard: orbIngestion.summary,
    improvementCandidates: orbIngestion.improvement_candidates,
    orbIngestError,
  }));

  // Dream-RSI: record this tick as one attempt when the workspace has the
  // recorder. Best-effort; a missing or failing recorder never changes the
  // tick's outcome. The engine spawns claude-backed runners by default.
  const rsiLog = (m) => { if (!asJson) process.stderr.write(`rsi: ${m}\n`); };
  const rsiAttempt = rsi.beginAttempt(root, { lane: rsi.IMPROVE_LANE, engine: 'claude', log: rsiLog });
  const rsiBefore = rsiAttempt ? rsi.gitSnapshot(root) : null;
  let rsiOutcome = null;

  let engine;
  let verify = { passed: null, cmd: verifyCmd };
  try {
    // Non-git workspaces made producedWork permanently false (empty git delta),
    // so every tick scored 0 no matter what the engine wrote. Fall back to a
    // filesystem snapshot when git is absent.
    const isRepo = fs.existsSync(path.join(root, '.git'));
    const before = isRepo ? gitSnapshot(root) : pulse.fsSnapshot(root);
    engine = runEngine(root, { noClaude, autopilotFallback: !hasFlag(args, '--no-autopilot'), campaigns: !hasFlag(args, '--no-campaigns') });
    const after = isRepo ? gitSnapshot(root) : pulse.fsSnapshot(root);
    // This tick's ACTUAL contribution: files it newly dirtied, or a new commit.
    // Pre-existing dirt is excluded so reward isn't re-credited every tick.
    let changedFiles;
    let committed = false;
    if (isRepo) {
      changedFiles = [...after.dirty].filter((f) => !before.dirty.has(f));
      committed = Boolean(before.head && after.head && before.head !== after.head);
    } else {
      changedFiles = pulse.diffFsSnapshots(before, after);
    }
    const producedWork = committed || changedFiles.length > 0;

    // Verify only matters when the tick produced work; a no-op tick skips it.
    if (producedWork && verifyCmd) {
      verify = runVerify(root, verifyCmd);
    } else if (verifyCmd) {
      verify = { passed: null, cmd: verifyCmd, skipped: true };
    }

    const elapsedMs = Date.now() - startedAt;
    const reward = pulse.scoreTick({
      verifyPassed: verify.passed,
      producedWork,
      actorOk: engine.ok,
      actorReason: engine.reason,
    });
    const changedTail = committed
      ? ' - committed'
      : (changedFiles.length ? ` - ${changedFiles.length} file(s) changed` : '');
    const what = engine.actor === 'campaign_tick'
      ? `campaign ${(engine.payload && engine.payload.campaign && engine.payload.campaign.id) || ''} ${engine.reason}${changedTail}`.replace(/\s+/g, ' ')
      : engine.actor === 'autopilot'
      ? `autopilot authored/advanced a goal${changedTail}`
      : engine.reason === 'no_due_mission'
        ? 'no due mission; heartbeat alive (no-op)'
        : `mission ${engine.reason}${changedTail}`;

    rsiOutcome = {
      status: !engine.ok || verify.passed === false ? 'failed' : producedWork ? 'shipped' : 'nothing',
      verify: verify.passed === true ? 'pass' : verify.passed === false ? 'fail' : 'skipped',
      elapsed_s: Math.round(elapsedMs / 100) / 10,
      engine_calls: 1,
      reason: String(what || '').slice(0, 200),
    };

    const receipt = pulse.buildPulseReceipt({
      tickIndex,
      phase: 'finished',
      actor: engine.actor,
      actorOk: engine.ok,
      actorReason: engine.reason,
      verifyCmd: verify.cmd,
      verifyPassed: verify.passed,
      changedFiles,
      what,
      elapsedMs,
      prevTickStale: priorStale.stale,
      reward,
      orbScorecard: orbIngestion.summary,
      improvementCandidates: orbIngestion.improvement_candidates,
      orbIngestError,
    });
    pulse.appendPulseReceipt(root, receipt);

    // Revive the reward channel - but only when there is signal (gate noise).
    let scorecardWritten = false;
    if (pulse.shouldWriteScorecard({ reward })) {
      pulse.appendScorecard(root, pulse.buildPulseScorecardRow({
        reward,
        verifyPassed: verify.passed,
        what,
        changedFiles,
        elapsedMs,
        model: process.env.ATRIS_RUNNER_MODEL || process.env.ATRIS_CLAUDE_MODEL || DEFAULT_CLAUDE_RUNNER_MODEL,
        orbScorecard: orbIngestion.summary,
        improvementCandidates: orbIngestion.improvement_candidates,
      }));
      scorecardWritten = true;
    }

    // Closure sweep rides the heartbeat: escalate overdue open loops once a
    // day without a human invoking atris close sweep. Never fails the tick.
    let closure = null;
    try {
      const { scanState, sweepState } = require('./close');
      const scanned = scanState(root);
      const swept = sweepState(root);
      closure = {
        open: swept.open,
        overdue: swept.overdue.length,
        escalated_today: swept.escalated_today,
        scanned: {
          opened: scanned.opened.length,
          auto_closed: scanned.auto_closed.length,
        },
      };
    } catch { /* closure ledger optional */ }

    // Rewrite the live vitals page so an open browser tab shows this tick.
    try { require('../lib/improve-vitals-html').writeVitalsHtml(root); } catch { /* page is a bonus */ }

    const out = {
      ok: true,
      action: 'pulse_tick',
      tick_index: tickIndex,
      actor: engine.actor,
      actor_reason: engine.reason,
      verify_passed: verify.passed,
      reward,
      scorecard_written: scorecardWritten,
      changed_files: changedFiles,
      prev_tick_stale: priorStale.stale,
      elapsed_ms: elapsedMs,
      receipts_path: pulse.pulseReceiptsPath(root),
      orb_scorecard: orbIngestion.summary,
      orb_improvement_candidates: orbIngestion.improvement_candidates,
      orb_scorecards_written: orbIngestion.scorecards_written,
      orb_policy_lesson: orbPolicy,
    };
    if (orbIngestError) out.orb_ingest_error = orbIngestError;
    if (closure) out.closure = closure;
    if (!asJson) {
      const ghost = priorStale.stale ? ` (recovered ghost tick #${priorStale.tick_index || '?'})` : '';
      const r = reward > 0 ? `+${reward}` : String(reward);
      process.stdout.write(`pulse tick #${tickIndex}: ${what} - verify ${verify.passed === null ? 'n/a' : verify.passed ? 'pass' : 'FAIL'} - reward ${r}${ghost}\n`);
      if (orbIngestion.summary && orbIngestion.summary.fail > 0) {
        process.stdout.write(`orb: ${orbIngestion.summary.fail} failed job${orbIngestion.summary.fail === 1 ? '' : 's'} in the ${orbIngestion.summary.days}-day window; ${orbIngestion.scorecards_written} new improvement candidate${orbIngestion.scorecards_written === 1 ? '' : 's'} recorded.\n`);
      }
      if (closure && closure.overdue > 0) {
        process.stdout.write(`closure: ${closure.overdue} open loop${closure.overdue === 1 ? '' : 's'} overdue, run: atris close sweep\n`);
      }
    }
    return emit(out, asJson);
  } catch (err) {
    // Surface the death instead of leaving a silent orphan 'started' receipt.
    pulse.appendPulseReceipt(root, pulse.buildPulseReceipt({
      tickIndex,
      phase: 'finished',
      actor: 'mission_run_due',
      actorOk: false,
      actorReason: 'error',
      what: `tick crashed: ${err && err.message ? err.message : String(err)}`,
      elapsedMs: Date.now() - startedAt,
      reward: -1,
      orbScorecard: orbIngestion.summary,
      improvementCandidates: orbIngestion.improvement_candidates,
      orbIngestError,
    }));
    const out = {
      ok: false,
      action: 'pulse_tick',
      tick_index: tickIndex,
      error: err && err.message ? err.message : String(err),
      orb_scorecard: orbIngestion.summary,
      orb_improvement_candidates: orbIngestion.improvement_candidates,
      orb_scorecards_written: orbIngestion.scorecards_written,
      orb_policy_lesson: orbPolicy,
    };
    if (orbIngestError) out.orb_ingest_error = orbIngestError;
    rsiOutcome = {
      status: 'failed',
      verify: 'skipped',
      elapsed_s: Math.round((Date.now() - startedAt) / 100) / 10,
      engine_calls: 1,
      reason: String(err && err.message ? err.message : err).slice(-200),
    };
    if (!asJson) process.stdout.write(`pulse tick #${tickIndex} crashed: ${out.error}\n`);
    return emit(out, asJson);
  } finally {
    process.removeListener('SIGINT', finishInterrupted);
    process.removeListener('SIGTERM', finishInterrupted);
    if (rsiAttempt) {
      const delta = rsi.gitDelta(root, rsiBefore);
      rsi.finishAttempt(root, rsiAttempt, {
        commits: delta.commits,
        files: delta.files,
        ...(rsiOutcome || {
          status: 'failed',
          verify: 'skipped',
          elapsed_s: Math.round((Date.now() - startedAt) / 100) / 10,
          engine_calls: 1,
          reason: 'tick ended without an outcome',
        }),
      }, { log: rsiLog });
    }
    pulse.releaseLock(root);
  }
}

// --- atris pulse status ---

function crontabHasActiveMarker(crontab, markers = pulse.PULSE_MARKER) {
  const markerList = (Array.isArray(markers) ? markers : [markers]).filter(Boolean);
  return String(crontab || '')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('#'))
    .some((line) => markerList.some((marker) => line.includes(marker)));
}

function cronInstalled(markers = pulse.PULSE_MARKER, commandSpawn = spawnSync) {
  try {
    const r = commandSpawn('crontab', ['-l'], { encoding: 'utf8', timeout: 10000 });
    if (r.status !== 0) return false;
    return crontabHasActiveMarker(r.stdout, markers);
  } catch {
    return false;
  }
}

function pulseExpiryBreadcrumbPath(root) {
  return path.join(root, '.atris', 'state', 'pulse-expired.json');
}

function readPulseExpiryBreadcrumb(root) {
  try {
    const raw = fs.readFileSync(pulseExpiryBreadcrumbPath(root), 'utf8').trim();
    const candidates = [];
    if (raw) candidates.push(raw, ...raw.split('\n').reverse());
    for (const candidate of candidates) {
      try {
        const parsed = JSON.parse(candidate);
        if (parsed
          && typeof parsed.expired_at === 'string'
          && typeof parsed.state_home === 'string'
          && typeof parsed.renew_command === 'string') {
          return parsed;
        }
      } catch {}
    }
  } catch {}
  return null;
}

function clearPulseExpiryBreadcrumb(root) {
  const file = pulseExpiryBreadcrumbPath(root);
  try {
    if (!fs.existsSync(file)) return false;
    fs.rmSync(file, { force: true });
    return true;
  } catch {
    return false;
  }
}

function statusCommand(args, root = process.cwd(), options = {}) {
  const asJson = wantsJson(args);
  const slot = pulse.resolvePulseSlot(root, options.homeDir ? { homeDir: options.homeDir } : {});
  const receipts = pulse.readPulseReceipts(root);
  const summary = pulse.summarizePulse(receipts);
  const label = `com.atris.pulse.${slot.marker.toLowerCase().replace(/^atris_pulse_/, '').replace(/[^a-z0-9]+/g, '-')}`;
  const homeDir = options.homeDir || os.homedir();
  const plistPath = path.join(homeDir, 'Library', 'LaunchAgents', `${label}.plist`);
  const legacyCronInstalled = cronInstalled(slot.markers, options.spawnSync || spawnSync);
  const installed = fs.existsSync(plistPath) || legacyCronInstalled;
  const expiryBreadcrumb = installed ? null : readPulseExpiryBreadcrumb(root);
  const writeOutput = options.writeOutput || ((text) => process.stdout.write(text));
  const out = {
    ok: true,
    action: 'pulse_status',
    cron_installed: installed,
    launchd_installed: fs.existsSync(plistPath),
    legacy_cron_installed: legacyCronInstalled,
    label,
    plist_path: plistPath,
    expiry_breadcrumb: expiryBreadcrumb,
    state_home: slot.activeStateHome,
    marker: slot.activeMarker,
    install_state_home: slot.stateHome,
    install_marker: slot.marker,
    legacy_slot: slot.legacyMatches,
    ...summary,
  };
  if (!asJson) {
    writeOutput([
      `pulse: ${installed ? 'scheduler installed' : 'scheduler not installed (run: atris pulse install)'}`,
      expiryBreadcrumb ? `heartbeat expired on ${expiryBreadcrumb.expired_at}; renew with: ${expiryBreadcrumb.renew_command}` : '',
      `state home: ${slot.activeStateHome} marker: ${slot.activeMarker}`,
      `ticks: ${summary.total_ticks} | reward: ${summary.reward_sum} | verify pass/fail: ${summary.verify_pass}/${summary.verify_fail}`,
      `last tick: ${summary.last_tick_ts || 'never'} (verify ${summary.last_verify_passed === null ? 'n/a' : summary.last_verify_passed ? 'pass' : 'fail'})`,
      summary.stale.stale ? `stale: ${summary.stale.reason}${summary.stale.tick_index ? ` (ghost tick #${summary.stale.tick_index})` : ''}` : 'liveness: fresh',
      summary.orphan_ticks.length ? `orphan (crashed) ticks: ${summary.orphan_ticks.join(', ')}` : '',
    ].filter(Boolean).join('\n') + '\n');
  }
  return emit(out, asJson);
}

// --- atris pulse install / uninstall ---

function resolveAtrisBin(commandSpawn = spawnSync) {
  // Prefer a globally linked `atris`; fall back to this checkout's bin.
  const which = commandSpawn('which', ['atris'], { encoding: 'utf8', timeout: 8000 });
  if (which.status === 0 && which.stdout.trim()) return which.stdout.trim();
  return `${process.execPath} ${path.join(__dirname, '..', 'bin', 'atris.js')}`;
}

// The dirs holding the binaries the engine spawns by bare name (claude, node,
// git, atris). Baked into the cron script's PATH so a minimal cron environment
// can still find them. Missing tools just contribute nothing.
function resolveEngineBinDirs(extraBins = [], commandSpawn = spawnSync) {
  const dirs = new Set([path.dirname(process.execPath)]); // node
  for (const tool of ['ax', 'claude', 'git', 'atris']) {
    const r = commandSpawn('which', [tool], { encoding: 'utf8', timeout: 8000 });
    if (r.status === 0 && r.stdout.trim()) dirs.add(path.dirname(r.stdout.trim()));
  }
  for (const bin of [process.env.ATRIS_RUNNER_BIN, process.env.ATRIS_CLAUDE_BIN, ...extraBins]) {
    const configured = String(bin || '').trim();
    if (configured && configured.includes(path.sep)) dirs.add(path.dirname(configured));
    if (configured && !configured.includes(path.sep)) {
      const r = commandSpawn('which', [configured], { encoding: 'utf8', timeout: 8000 });
      if (r.status === 0 && r.stdout.trim()) dirs.add(path.dirname(r.stdout.trim()));
    }
  }
  dirs.add(path.join(os.homedir(), '.local', 'bin')); // common claude location
  return Array.from(dirs);
}

function stripMarkedCrontabLines(crontab, markers) {
  const markerList = Array.isArray(markers) ? markers : [markers];
  return String(crontab || '')
    .split('\n')
    .filter((line) => line && !markerList.some((marker) => marker && line.includes(marker)))
    .join('\n');
}

function installCommand(args, root = process.cwd(), options = {}) {
  const asJson = wantsJson(args);
  const commandSpawn = options.spawnSync || spawnSync;
  const writeOutput = options.writeOutput || ((text) => process.stdout.write(text));
  const slot = pulse.resolvePulseSlot(root, options.homeDir ? { homeDir: options.homeDir } : {});
  const cadenceInput = readFollowingFlag(args, '--cadence', pulse.DEFAULT_CADENCE_CRON);
  let cron;
  try {
    cron = pulse.normalizeCronCadence(cadenceInput);
  } catch (error) {
    const out = {
      ok: false,
      action: 'pulse_install',
      reason: 'invalid_cadence',
      detail: error && error.message ? error.message : String(error),
      cadence: cadenceInput,
    };
    if (!asJson) process.stdout.write(`pulse install failed: ${out.detail}\n`);
    return emit(out, asJson);
  }
  let expiry;
  try {
    expiry = pulse.normalizeExpiryDuration({
      hours: readFollowingFlag(args, '--hours', null),
      days: readFollowingFlag(args, '--days', '7'),
    });
  } catch (error) {
    const out = {
      ok: false,
      action: 'pulse_install',
      reason: 'invalid_expiry',
      detail: error && error.message ? error.message : String(error),
      hours: readFollowingFlag(args, '--hours', null),
      days: readFollowingFlag(args, '--days', '7'),
    };
    if (!asJson) process.stdout.write(`pulse install failed: ${out.detail}\n`);
    return emit(out, asJson);
  }
  const verifyCmd = readFollowingFlag(args, '--verify', pulse.defaultVerifyCmd(root));
  const model = readFollowingFlag(args, '--model', process.env.ATRIS_RUNNER_MODEL || process.env.ATRIS_CLAUDE_MODEL || DEFAULT_CLAUDE_RUNNER_MODEL);
  const runnerProfile = readFollowingFlag(args, '--runner-profile', process.env.ATRIS_RUNNER_PROFILE || '');
  const runnerBin = readFollowingFlag(args, '--runner-bin', process.env.ATRIS_RUNNER_BIN || process.env.ATRIS_CLAUDE_BIN || '');
  const runnerCommandTemplate = readFollowingFlag(args, '--runner-template', process.env.ATRIS_RUNNER_COMMAND_TEMPLATE || process.env.ATRIS_CLAUDE_COMMAND_TEMPLATE || '');
  const deadlineEpoch = Math.floor(Date.now() / 1000) + expiry.seconds;

  fs.mkdirSync(slot.stateHome, { recursive: true });
  const scriptPath = path.join(slot.stateHome, 'tick.sh');
  const label = `com.atris.pulse.${slot.marker.toLowerCase().replace(/^atris_pulse_/, '').replace(/[^a-z0-9]+/g, '-')}`;
  const homeDir = options.homeDir || os.homedir();
  const launchAgentsDir = path.join(homeDir, 'Library', 'LaunchAgents');
  const plistPath = path.join(launchAgentsDir, `${label}.plist`);
  // Resolve the real bin dirs the engine spawns by bare name, so launchd's
  // minimal PATH doesn't break the worker spawn (claude lives in ~/.local/bin).
  const pathDirs = resolveEngineBinDirs([runnerBin], commandSpawn);
  const script = pulse.buildTickScript({
    root,
    atrisBin: resolveAtrisBin(commandSpawn),
    stateHome: slot.stateHome,
    deadlineEpoch,
    marker: slot.marker,
    model,
    runnerProfile,
    runnerBin,
    runnerCommandTemplate,
    verifyCmd,
    pathDirs,
    launchLabel: label,
    launchPlistPath: plistPath,
    // Baked into every tick: a night of campaigns only, no invented goals.
    tickFlags: ['--no-autopilot', '--no-campaigns'].filter((flag) => hasFlag(args, flag)),
  });
  fs.writeFileSync(scriptPath, script, { mode: 0o755 });

  fs.mkdirSync(path.join(slot.stateHome, 'logs'), { recursive: true });
  fs.mkdirSync(launchAgentsDir, { recursive: true });
  fs.writeFileSync(plistPath, pulse.buildLaunchAgentPlist({ label, scriptPath, cron, stateHome: slot.stateHome }), 'utf8');

  // Strip old cron entries while migrating existing installations.
  const existing = commandSpawn('crontab', ['-l'], { encoding: 'utf8', timeout: 10000 });
  const prior = existing.status === 0 ? String(existing.stdout || '') : '';
  const cleaned = stripMarkedCrontabLines(prior, slot.markers);
  const legacyHad = slot.markers.some((marker) => prior.includes(marker));
  if (existing.status === 0 && legacyHad) commandSpawn('crontab', ['-'], { input: cleaned ? `${cleaned}\n` : '', encoding: 'utf8', timeout: 10000 });
  const uid = options.uid != null ? options.uid : process.getuid();
  commandSpawn('launchctl', ['bootout', `gui/${uid}/${label}`], { encoding: 'utf8', timeout: 10000 });
  const apply = commandSpawn('launchctl', ['bootstrap', `gui/${uid}`, plistPath], { encoding: 'utf8', timeout: 10000 });
  const expiryBreadcrumbCleared = apply.status === 0 && clearPulseExpiryBreadcrumb(root);
  const cadenceMapping = pulse.launchIntervalFromCadence({ cron });
  // Tests pass their own spawnSync and never get a real caffeinate unless they ask.
  const wantsKeepAwake = apply.status === 0 && process.platform === 'darwin' && !hasFlag(args, '--no-keep-awake')
    && (!options.spawnSync || options.holdKeepAwake);
  const keepAwake = wantsKeepAwake ? (options.holdKeepAwake || holdKeepAwake)(slot.stateHome, expiry.seconds) : null;

  const out = {
    ok: apply.status === 0,
    action: 'pulse_install',
    script_path: scriptPath,
    state_home: slot.stateHome,
    marker: slot.marker,
    legacy_migrated: slot.legacyMatches,
    label,
    plist_path: plistPath,
    crontab_line: null,
    removed_legacy_crontab: legacyHad,
    cadence_fallback: cadenceMapping.fallback,
    cadence: cron,
    cadence_input: cadenceInput,
    expires_in_days: expiry.days,
    expires_in_hours: expiry.hours,
    expires_in_seconds: expiry.seconds,
    deadline_epoch: deadlineEpoch,
    runner_profile: runnerProfile || null,
    runner_bin: runnerBin || null,
    runner_template_configured: Boolean(runnerCommandTemplate),
    expiry_breadcrumb_cleared: expiryBreadcrumbCleared,
    keep_awake: keepAwake,
  };
  if (!asJson) {
    if (apply.status === 0) {
      writeOutput([
        `pulse installed. launchd heartbeat fires '${cron}' against ${root}.`,
        `label: ${label}`,
        `plist: ${plistPath}`,
        `script: ${scriptPath}`,
        cadenceMapping.fallback ? `cadence '${cron}' is not directly mappable; using 3600 seconds.` : '',
        `auto-expires in ${expiry.hours ? `${expiry.hours} hours` : `${expiry.days} days`}. stop early: atris pulse uninstall`,
        ...(keepAwake ? [`keeps this Mac awake until then (lid open); atris pulse uninstall lets it sleep.`] : []),
      ].filter(Boolean).join('\n') + '\n');
    } else {
      writeOutput(`pulse install failed to bootstrap ${label}: ${apply.stderr || apply.status}\nplist: ${plistPath}\n`);
    }
  }
  return emit(out, asJson);
}

// The heartbeat only ticks while the Mac is awake. On macOS an overnight install
// holds a no-idle-sleep assertion (caffeinate -i) for exactly the heartbeat's
// window, so a Mac on its own power settings does not sleep through the night.
// Closing the lid still sleeps. Uninstall lets it go. --no-keep-awake skips it.
function keepAwakeFile(stateHome) {
  return path.join(stateHome, 'keep-awake.pid');
}

function releaseKeepAwake(stateHome) {
  const file = keepAwakeFile(stateHome);
  let pid = 0;
  try { pid = Number(fs.readFileSync(file, 'utf8').trim()); } catch { return false; }
  fs.rmSync(file, { force: true });
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try {
    const name = spawnSync('ps', ['-p', String(pid), '-o', 'comm='], { encoding: 'utf8', timeout: 5000 }).stdout.trim();
    if (!/caffeinate$/.test(name)) return false;
    process.kill(pid, 'SIGTERM');
    return true;
  } catch {
    return false;
  }
}

function holdKeepAwake(stateHome, seconds) {
  releaseKeepAwake(stateHome);
  const { spawn } = require('child_process');
  const child = spawn('caffeinate', ['-i', '-t', String(Math.max(60, Math.floor(seconds)))], { detached: true, stdio: 'ignore' });
  child.unref();
  fs.mkdirSync(stateHome, { recursive: true });
  fs.writeFileSync(keepAwakeFile(stateHome), `${child.pid}\n`);
  return { pid: child.pid, seconds: Math.floor(seconds) };
}

function uninstallCommand(args, root = process.cwd(), options = {}) {
  const asJson = wantsJson(args);
  const slot = pulse.resolvePulseSlot(root, options.homeDir ? { homeDir: options.homeDir } : {});
  const commandSpawn = options.spawnSync || spawnSync;
  const homeDir = options.homeDir || os.homedir();
  const label = `com.atris.pulse.${slot.marker.toLowerCase().replace(/^atris_pulse_/, '').replace(/[^a-z0-9]+/g, '-')}`;
  const plistPath = path.join(homeDir, 'Library', 'LaunchAgents', `${label}.plist`);
  const uid = options.uid != null ? options.uid : process.getuid();
  commandSpawn('launchctl', ['bootout', `gui/${uid}/${label}`], { encoding: 'utf8', timeout: 10000 });
  const keepAwakeReleased = (options.releaseKeepAwake || releaseKeepAwake)(slot.stateHome || slot.activeStateHome);
  const plistHad = fs.existsSync(plistPath);
  fs.rmSync(plistPath, { force: true });
  const existing = commandSpawn('crontab', ['-l'], { encoding: 'utf8', timeout: 10000 });
  const prior = String(existing.stdout || '');
  const had = slot.markers.some((marker) => prior.includes(marker));
  const cleaned = stripMarkedCrontabLines(prior, slot.markers);
  let apply = { status: 0 };
  if (existing.status === 0 && had) apply = commandSpawn('crontab', ['-'], { input: cleaned ? cleaned + '\n' : '', encoding: 'utf8', timeout: 10000 });
  const out = {
    ok: apply.status === 0,
    action: 'pulse_uninstall',
    removed: plistHad || had,
    keep_awake_released: keepAwakeReleased,
    label,
    plist_path: plistPath,
    removed_legacy_crontab: had,
    state_home: slot.activeStateHome,
    marker: slot.activeMarker,
    legacy_slot: slot.legacyMatches,
  };
  if (!asJson) process.stdout.write(plistHad || had ? `pulse uninstalled (${label}).\n` : 'pulse: no heartbeat agent found.\n');
  return emit(out, asJson);
}

// --- atris pulse run (foreground N ticks) ---

function runCommand(args, root = process.cwd()) {
  const asJson = wantsJson(args);
  const maxTicks = Math.max(1, Number(readFollowingFlag(args, '--max-ticks', '1')) || 1);
  const passthrough = args.filter((a) => a !== '--max-ticks' && a !== String(maxTicks));
  const results = [];
  for (let i = 0; i < maxTicks; i++) {
    results.push(tickCommand(passthrough.concat(['--json-silent']).filter((a) => a !== '--json'), root));
  }
  const out = { ok: true, action: 'pulse_run', ticks: results.length, results };
  return emit(out, asJson);
}

function pulseCommand(argv = []) {
  const sub = argv[0];
  const rest = argv.slice(1);
  if (sub === '--help' || sub === '-h' || sub === 'help') return showHelp();
  // `pulse <sub> --help` is a help request, not a run, never execute the
  // subcommand (tick/status/etc. have real side effects) just to show usage.
  if (rest.includes('--help') || rest.includes('-h')) return showHelp();
  switch (sub) {
    case 'tick':
      return tickCommand(rest);
    case 'status':
    case undefined:
      return statusCommand(rest);
    case 'install':
      return installCommand(rest);
    case 'uninstall':
      return uninstallCommand(rest);
    case 'run':
      return runCommand(rest);
    default: {
      const asJson = wantsJson(rest);
      const out = { ok: false, action: 'pulse', error: `unknown subcommand: ${sub}`, usage: 'atris pulse tick|status|install|uninstall|run' };
      if (!asJson) process.stdout.write(`${out.error}\nUsage: ${out.usage}\n`);
      return emit(out, asJson);
    }
  }
}

module.exports = {
  pulseCommand,
  statusCommand,
  cronInstalled,
  crontabHasActiveMarker,
  pulseExpiryBreadcrumbPath,
  installCommand,
  runCommand,
  uninstallCommand,
  refreshOrbPolicyLessons,
};
