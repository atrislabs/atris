const fs = require('fs');
const path = require('path');
const gitSpawn = require('../lib/git-spawn');
const { compactErrorPayload, printCliJson } = require('../lib/cli-json');
const { listWorktrees, statusCounts, defaultMainlineBase, listActiveProcessPaths, worktreeHasActiveProcess, recordWorktreeRemoval } = require('./worktree');

const DEFAULT_TTL_DAYS = 7;
const DEFAULT_STALE_HOURS = 48;
const WORKTREE_REAP_GRACE_MS = 60 * 60 * 1000;
const PROTECTED_BRANCHES = new Set(['main', 'master']);

// Through the module object so tests can count git spawns with a spy.
function runGit(args, opts) {
  return gitSpawn.runGit(args, opts);
}

const CHERRY_CACHE_FILE = path.join('.atris', 'state', 'cherry-cache.json');
const CHERRY_CACHE_MAX = 2000;

// Pluralize a count + noun ("1 change", "2 changes").
function countLabel(n, word) {
  return `${n} ${word}${n === 1 ? '' : 's'}`;
}

function repoRoot(cwd = process.cwd()) {
  const result = runGit(['rev-parse', '--show-toplevel'], { cwd, check: false });
  if (result.status !== 0) return '';
  return result.stdout.trim();
}

function hasCommits(root) {
  return runGit(['rev-parse', '--verify', '--quiet', 'HEAD'], { cwd: root, check: false }).status === 0;
}

function refExists(root, ref) {
  return runGit(['rev-parse', '--verify', '--quiet', ref], { cwd: root, check: false }).status === 0;
}

function baseBranch(root, override = '') {
  if (override && refExists(root, override)) return override;
  const mainline = defaultMainlineBase(root);
  if (mainline !== 'HEAD') return mainline;
  for (const candidate of ['main', 'master']) {
    if (refExists(root, candidate)) return candidate;
  }
  return '';
}

function ageDays(unixSeconds, now = Date.now()) {
  return Math.floor((now / 1000 - Number(unixSeconds)) / 86400);
}

function ageHours(unixSeconds, now = Date.now()) {
  return Math.floor((now / 1000 - Number(unixSeconds)) / 3600);
}

function worktreeMtimeMs(worktreePath) {
  try {
    return fs.statSync(worktreePath).mtimeMs;
  } catch {
    return null;
  }
}

function worktreeWithinReapGrace(worktreePath, now = Date.now()) {
  const mtime = worktreeMtimeMs(worktreePath);
  return typeof mtime === 'number' && now - mtime < WORKTREE_REAP_GRACE_MS;
}

function canonicalPath(p) {
  try {
    return fs.realpathSync(p);
  } catch {
    return path.resolve(p);
  }
}

function gitCommonDir(root) {
  for (const args of [['rev-parse', '--path-format=absolute', '--git-common-dir'], ['rev-parse', '--git-common-dir']]) {
    const res = runGit(args, { cwd: root, check: false });
    if (res.status === 0 && res.stdout.trim()) return path.resolve(root, res.stdout.trim());
  }
  return '';
}

function headRefName(headFile) {
  try {
    const m = /^ref: refs\/heads\/(.+)$/.exec(fs.readFileSync(headFile, 'utf8').trim());
    return m ? m[1] : '';
  } catch {
    return '';
  }
}

// Branch checkouts straight from .git/worktrees/<id>/HEAD plus the main
// checkout's HEAD — the live truth, not the board snapshot. A `worktree add`
// still in flight (or a half-registered entry) can leave a branch checked out
// in a directory the snapshot never saw, and git's own `branch -D` refusal
// only consults registrations whose gitdir link is already written.
// pendingFresh marks a fresh registration whose HEAD file does not exist yet:
// an add mid-flight that has not named its branch.
function liveCheckouts(root, now = Date.now()) {
  const bound = new Map();
  let pendingFresh = false;
  const common = gitCommonDir(root);
  if (!common) return { bound, pendingFresh };
  if (path.basename(common) === '.git') {
    const name = headRefName(path.join(common, 'HEAD'));
    const mainPath = path.dirname(common);
    if (name && fs.existsSync(mainPath)) bound.set(name, { path: mainPath, adminDir: common });
  }
  let ids = [];
  try {
    ids = fs.readdirSync(path.join(common, 'worktrees'));
  } catch {
    return { bound, pendingFresh };
  }
  for (const id of ids) {
    const adminDir = path.join(common, 'worktrees', id);
    let stat;
    try {
      stat = fs.statSync(adminDir);
    } catch {
      continue;
    }
    if (!stat.isDirectory()) continue;
    const headFile = path.join(adminDir, 'HEAD');
    const name = headRefName(headFile);
    if (!name) {
      if (!fs.existsSync(headFile) && now - stat.mtimeMs < WORKTREE_REAP_GRACE_MS) pendingFresh = true;
      continue;
    }
    let wtPath = null;
    try {
      wtPath = path.dirname(fs.readFileSync(path.join(adminDir, 'gitdir'), 'utf8').trim());
    } catch {
      // gitdir unwritten or lost: cannot prove which directory is the
      // checkout, so the branch stays claimed — fail safe, prune's job.
    }
    if (wtPath && !fs.existsSync(wtPath)) continue;
    bound.set(name, { path: wtPath, adminDir });
  }
  return { bound, pendingFresh };
}

// The branch's own reflog records when `worktree add -b` (or `git branch`)
// created it. While an add is in flight a just-created target branch is very
// likely the checkout being wired up right now — keep it for this pass.
function branchCreatedWithinGrace(root, name, now = Date.now()) {
  const res = runGit(['reflog', 'show', '--date=unix', name], { cwd: root, check: false });
  if (res.status !== 0) return false;
  const lines = res.stdout.split(/\r?\n/).filter(Boolean);
  const m = /@\{(\d+)\}/.exec(lines[lines.length - 1] || '');
  return Boolean(m) && now - Number(m[1]) * 1000 < WORKTREE_REAP_GRACE_MS;
}

// One receipt line for a branch kept because a live checkout claims it:
// fresh checkouts name the grace, older ones name where the branch is in use.
function checkoutKeepLine(name, bound, now) {
  if (worktreeWithinReapGrace(bound.path || bound.adminDir, now)) {
    return bound.path ? `${bound.path} (fresh_worktree_grace)` : `branch ${name} (fresh_worktree_grace)`;
  }
  return `branch ${name} (checked out in ${bound.path || 'a worktree'})`;
}

function listBranches(root, base = '') {
  // With a base, ask git for ahead counts in the same single spawn
  // (%(ahead-behind:) needs git >= 2.41; on failure we retry without it and
  // collectBoard falls back to per-branch aheadCount). The branch sha comes
  // along in the same spawn so the cherry cache needs no per-branch lookup.
  const format = base
    ? `%(refname:short)%09%(committerdate:unix)%09%(objectname)%09%(ahead-behind:${base})`
    : '%(refname:short)%09%(committerdate:unix)%09%(objectname)';
  const result = runGit(['for-each-ref', 'refs/heads', `--format=${format}`], { cwd: root, check: false });
  if (result.status !== 0) {
    if (base) return listBranches(root);
    return [];
  }
  return result.stdout
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => {
      const [name, date, sha, aheadBehind] = line.split('\t');
      const entry = { name, lastCommitUnix: Number(date) };
      if (sha) entry.sha = sha;
      if (aheadBehind !== undefined) {
        const ahead = Number(aheadBehind.split(' ')[0]);
        if (Number.isFinite(ahead)) entry.ahead = ahead;
      }
      return entry;
    });
}

function aheadCount(root, base, ref) {
  const result = runGit(['rev-list', '--count', `${base}..${ref}`], { cwd: root, check: false });
  if (result.status !== 0) return 0;
  return Number(result.stdout.trim()) || 0;
}

// The subject lines of the commits a ref carries beyond base, oldest last, 
// what a stranded worktree is actually holding, so surfacing it names the work.
function commitSubjects(cwd, base, ref, limit = 6) {
  const result = runGit(['log', '--format=%s', `${base}..${ref}`], { cwd, check: false });
  if (result.status !== 0) return [];
  return result.stdout.split(/\r?\n/).filter(Boolean).slice(0, limit);
}

function cherryStats(root, base, ref) {
  const result = runGit(['cherry', base, ref], { cwd: root, check: false });
  if (result.status !== 0) return { landedElsewhere: 0, unique: 0 };
  let landedElsewhere = 0;
  let unique = 0;
  for (const line of result.stdout.split(/\r?\n/).filter(Boolean)) {
    if (line.startsWith('- ')) landedElsewhere += 1;
    else if (line.startsWith('+ ')) unique += 1;
  }
  return { landedElsewhere, unique };
}

// `git cherry <base> <ref>` depends only on the two commit shas, so its
// counts are cached per (base sha, ref sha) under .atris/state. The cache is
// only written where .atris already exists; a missing or corrupt file means
// recompute. Entries for refs not seen this run are dropped on save.
function cherryCachePath(root) {
  return path.join(root, CHERRY_CACHE_FILE);
}

function loadCherryCache(root) {
  const cache = { file: cherryCachePath(root), entries: {}, used: {}, dirty: false, writable: false };
  try {
    cache.writable = fs.statSync(path.join(root, '.atris')).isDirectory();
  } catch {
    cache.writable = false;
  }
  if (!cache.writable) return cache;
  try {
    const parsed = JSON.parse(fs.readFileSync(cache.file, 'utf8'));
    if (parsed && parsed.version === 1 && parsed.entries && typeof parsed.entries === 'object') {
      cache.entries = parsed.entries;
    }
  } catch {
    cache.entries = {};
  }
  return cache;
}

function validCherryEntry(entry) {
  return entry && Number.isInteger(entry.landedElsewhere) && Number.isInteger(entry.unique)
    && entry.landedElsewhere >= 0 && entry.unique >= 0;
}

function cachedCherryStats(cache, cwd, base, baseSha, ref, refSha) {
  if (!cache || !baseSha || !refSha) return cherryStats(cwd, base, ref);
  const key = `${baseSha}:${refSha}`;
  const hit = cache.entries[key];
  if (validCherryEntry(hit)) {
    cache.used[key] = hit;
    return { landedElsewhere: hit.landedElsewhere, unique: hit.unique };
  }
  // Cherry the exact commits the key names, so a ref that moves mid-run
  // can never file one pair's result under another pair's key.
  const result = runGit(['cherry', baseSha, refSha], { cwd, check: false });
  if (result.status !== 0) return { landedElsewhere: 0, unique: 0 };
  const stats = { landedElsewhere: 0, unique: 0 };
  for (const line of result.stdout.split(/\r?\n/).filter(Boolean)) {
    if (line.startsWith('- ')) stats.landedElsewhere += 1;
    else if (line.startsWith('+ ')) stats.unique += 1;
  }
  cache.used[key] = { ...stats };
  cache.dirty = true;
  return stats;
}

function saveCherryCache(cache) {
  if (!cache || !cache.writable) return;
  const usedKeys = Object.keys(cache.used);
  // Rewrite when something new was computed or something stale can go.
  if (!cache.dirty && usedKeys.length === Object.keys(cache.entries).length) return;
  const entries = {};
  for (const key of usedKeys.slice(-CHERRY_CACHE_MAX)) entries[key] = cache.used[key];
  try {
    fs.mkdirSync(path.dirname(cache.file), { recursive: true });
    const tmp = `${cache.file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, `${JSON.stringify({ version: 1, entries })}\n`);
    fs.renameSync(tmp, cache.file);
  } catch {
    // The cache is only a speedup; a failed write costs a recompute next time.
  }
}

function resolveSha(root, ref) {
  const result = runGit(['rev-parse', '--verify', '--quiet', `${ref}^{commit}`], { cwd: root, check: false });
  return result.status === 0 ? result.stdout.trim() : '';
}

// Board: every branch and worktree with unlanded state, classified.
//   landed, no commits ahead of base; the branch pointer is residue
//   active, has unlanded commits, younger than TTL
//   due, has unlanded commits, older than TTL; --reap collects it
function collectBoard(root, { ttlDays = DEFAULT_TTL_DAYS, staleHours = DEFAULT_STALE_HOURS, base: baseOverride = '', now = Date.now(), light = false } = {}) {
  const base = baseBranch(root, baseOverride);
  if (!base) {
    const err = new Error('no master/main branch found. fix: git checkout -b main');
    err.code = 'LAND_NO_BASE';
    throw err;
  }

  const branches = [];
  const lastCommitMsByBranch = new Map();
  const cherryCache = loadCherryCache(root);
  const baseSha = resolveSha(root, base);
  for (const branch of listBranches(root, base)) {
    if (PROTECTED_BRANCHES.has(branch.name) || branch.name === base.replace(/^origin\//, '')) continue;
    const lastCommitMs = Number(branch.lastCommitUnix) * 1000;
    if (Number.isFinite(lastCommitMs)) lastCommitMsByBranch.set(branch.name, lastCommitMs);
    const ahead = branch.ahead !== undefined ? branch.ahead : aheadCount(root, base, branch.name);
    const age = ageDays(branch.lastCommitUnix, now);
    const hours = ageHours(branch.lastCommitUnix, now);
    const cherry = ahead > 0
      ? cachedCherryStats(cherryCache, root, base, baseSha, branch.name, branch.sha)
      : { landedElsewhere: 0, unique: 0 };
    let state = 'active';
    if (ahead === 0 || (cherry.landedElsewhere > 0 && cherry.unique === 0)) state = 'landed';
    else if (age > ttlDays) state = 'due';
    branches.push({
      name: branch.name,
      ahead,
      ageDays: age,
      ageHours: hours,
      activityHours: hours,
      landedElsewhere: cherry.landedElsewhere,
      uniqueChanges: cherry.unique,
      stale: false,
      state,
    });
  }

  const worktrees = [];
  const all = listWorktrees(root);
  for (const wt of all.slice(1)) {
    const rawBranch = (wt.branch || '').replace(/^refs\/heads\//, '');
    // 'detached' is a marker, not a name: left as-is it reads as a real branch
    // name (hiding the worktree's own commits and, in reap, pushing the word
    // "detached" into the delete list). Treat it as no branch so the worktree
    // is asked directly what it holds.
    const branch = rawBranch === 'detached' ? '' : rawBranch;
    // light mode skips the full `git status` per worktree, the banner summary
    // never reads dirty counts, only worktree mtimes for staleness.
    const counts = (light ? null : statusCounts(wt.path)) || { staged: 0, unstaged: 0, untracked: 0 };
    const dirty = counts.staged + counts.unstaged + counts.untracked;
    const entry = branches.find((b) => b.name === branch) || null;
    // Committed-but-unlanded work is invisible in the dirty count, a clean
    // worktree can still hold commits ahead of base that silently never land.
    // Carry the ahead/unique counts (and, off the light path, the subjects)
    // so a stranded worktree is surfaced by what it is actually holding.
    let ahead = entry ? entry.ahead : 0;
    let unlandedCommits = entry ? entry.uniqueChanges : 0;
    let ageDaysVal = entry ? entry.ageDays : null;
    let subjects = [];
    if (!branch) {
      // Detached HEAD has no row in the branch table, ask the worktree itself.
      const cnt = runGit(['rev-list', '--count', `${base}..HEAD`], { cwd: wt.path, check: false });
      ahead = cnt.status === 0 ? Number(cnt.stdout.trim()) || 0 : 0;
      if (ahead > 0) {
        unlandedCommits = cachedCherryStats(cherryCache, wt.path, base, baseSha, 'HEAD', wt.head).unique;
        const ts = runGit(['log', '-1', '--format=%ct', 'HEAD'], { cwd: wt.path, check: false });
        if (ts.status === 0) ageDaysVal = ageDays(Number(ts.stdout.trim()), now);
        if (!light) subjects = commitSubjects(wt.path, base, 'HEAD');
      }
    } else if (!light && ahead > 0) {
      subjects = commitSubjects(root, base, branch);
    }
    worktrees.push({
      path: wt.path,
      branch,
      dirty,
      ahead,
      unlandedCommits,
      subjects,
      stranded: unlandedCommits > 0,
      ageDays: ageDaysVal,
      ageHours: entry ? entry.ageHours : null,
      state: entry ? entry.state : 'detached',
    });
  }

  const activityByBranch = new Map(branches.map((b) => [b.name, lastCommitMsByBranch.get(b.name)]));
  for (const wt of worktrees) {
    if (!wt.branch || !activityByBranch.has(wt.branch)) continue;
    const mtime = worktreeMtimeMs(wt.path);
    if (typeof mtime === 'number' && mtime > activityByBranch.get(wt.branch)) {
      activityByBranch.set(wt.branch, mtime);
    }
  }
  for (const branch of branches) {
    const lastActivity = activityByBranch.get(branch.name);
    if (Number.isFinite(lastActivity)) {
      branch.activityHours = Math.floor((now - lastActivity) / 3600000);
    }
    branch.stale = branch.state === 'active' && branch.activityHours >= staleHours;
  }

  saveCherryCache(cherryCache);

  const due = branches.filter((b) => b.state === 'due');
  const landed = branches.filter((b) => b.state === 'landed');
  const active = branches.filter((b) => b.state === 'active');
  const stale = active.filter((b) => b.stale);
  const strandedWorktrees = worktrees.filter((w) => w.stranded);
  return {
    base,
    ttlDays,
    staleHours,
    branches,
    worktrees,
    strandedWorktrees,
    summary: {
      unlanded: branches.length,
      active: active.length,
      due: due.length,
      landed: landed.length,
      stale: stale.length,
      worktrees: worktrees.length,
      stranded: strandedWorktrees.length,
    },
  };
}

// One landing board per process per repo. Boot, stream, and the team view
// each ask for the board more than once in a single command; the first call
// pays for git, later calls within BOARD_MEMO_MAX_AGE_MS share the result.
// A full board also answers light requests (light is a subset). Long-lived
// callers (stream follow) clear the memo before each poll.
const BOARD_MEMO_MAX_AGE_MS = 10000;
const boardMemo = new Map();

function boardMemoKey(root, { ttlDays = DEFAULT_TTL_DAYS, staleHours = DEFAULT_STALE_HOURS, base = '' } = {}) {
  return JSON.stringify([canonicalPath(root), ttlDays, staleHours, base]);
}

function sharedBoard(root, opts = {}) {
  const key = boardMemoKey(root, opts);
  const light = Boolean(opts.light);
  const nowMs = Date.now();
  const hit = boardMemo.get(key);
  if (hit && nowMs - hit.at < BOARD_MEMO_MAX_AGE_MS && (light || !hit.light)) return hit.board;
  const board = collectBoard(root, { ...opts, light });
  boardMemo.set(key, { board, light, at: Date.now() });
  return board;
}

function clearBoardMemo() {
  boardMemo.clear();
}

// Counts for the boot banner and digest. This intentionally pays the same
// classification cost as the landing board so "in the air" never includes
// merged branch residue.
function landSummary(cwd = process.cwd(), ttlDays = DEFAULT_TTL_DAYS) {
  const root = repoRoot(cwd);
  if (!root || !hasCommits(root)) return null;
  try {
    const board = sharedBoard(root, { ttlDays, light: true });
    return {
      branches: board.summary.active + board.summary.due,
      due: board.summary.due,
      stale: board.summary.stale,
      ttlDays,
    };
  } catch {
    return null;
  }
}

function salvageDir(root) {
  // Local calendar day; toISOString is UTC and files an evening backup
  // under tomorrow anywhere west of Greenwich.
  const now = new Date();
  const stamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const dir = path.join(root, '.atris', 'salvage', stamp);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function timeStamp() {
  return new Date().toISOString().slice(11, 19).replace(/:/g, '');
}

function remoteHeads(root) {
  const result = runGit(['ls-remote', '--heads', 'origin'], { cwd: root, check: false });
  if (result.status !== 0) return null;
  const heads = new Set();
  for (const line of result.stdout.split(/\r?\n/).filter(Boolean)) {
    const ref = line.split(/\s+/)[1] || '';
    if (ref.startsWith('refs/heads/')) heads.add(ref.slice('refs/heads/'.length));
  }
  return heads;
}

// Everything a force-remove would destroy: staged + unstaged tracked changes
// (git diff HEAD) and untracked files (copied verbatim). Returns false if any
// piece could not be saved, the caller then keeps the worktree.
function salvageWorktree(w, dir, receipt) {
  try {
    // git writes the patch file itself: routing the diff through spawnSync
    // stdout hits Node's 1MB default maxBuffer, so any worktree more than
    // ~1MB dirty read as "salvage failed" and was kept on every reap pass.
    const patchPath = path.join(dir, `${path.basename(w.path)}.dirty.patch`);
    const diff = runGit(['diff', 'HEAD', `--output=${patchPath}`], { cwd: w.path, check: false });
    if (diff.status !== 0) {
      fs.rmSync(patchPath, { force: true });
      return false;
    }
    if (fs.statSync(patchPath).size > 0) receipt.patches.push(patchPath);
    else fs.rmSync(patchPath, { force: true });
    const untracked = runGit(['ls-files', '--others', '--exclude-standard', '-z'], { cwd: w.path, check: false, maxBuffer: 64 * 1024 * 1024 });
    if (untracked.status !== 0) return false;
    const files = untracked.stdout.split('\0').filter(Boolean);
    if (files.length > 0) {
      const destRoot = path.join(dir, `${path.basename(w.path)}.untracked`);
      for (const rel of files) {
        const dest = path.join(destRoot, rel);
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.copyFileSync(path.join(w.path, rel), dest);
      }
      receipt.untracked.push(destRoot);
    }
    return true;
  } catch (err) {
    return false;
  }
}

function reapReason(w, board, ttlDays, force) {
  const state = (board.branches.find((b) => b.name === w.branch) || {}).state;
  if (state === 'landed') return 'branch_landed';
  if (state === 'due') return 'branch_past_ttl';
  if (w.state === 'detached') return 'detached_head';
  if (typeof w.ageDays === 'number' && w.ageDays > ttlDays) return 'worktree_past_ttl';
  return force ? 'forced' : 'unlanded_commits';
}

// Reap: salvage then delete everything landed (residue) or past TTL.
// Salvage first, always: unlanded commits go into a git bundle, dirty
// worktrees into patch files + untracked-file copies, so a reap is never
// a loss of work, and when a backup cannot be written, the work stays.
// includeDetached: detached-HEAD worktrees have no branch, so the salvage
// bundle cannot cover their commits, unattended reaps (autoland) pass false
// and leave them for a human reap.
function reap(root, { ttlDays = DEFAULT_TTL_DAYS, staleHours = DEFAULT_STALE_HOURS, base: baseOverride = '', dryRun = false, remote = true, includeDetached = true, protectCurrent = true, force = false, now = Date.now(), activeCwds: activeCwdsOverride, by = 'atris land --reap' } = {}) {
  const readActiveCwds = () => (Array.isArray(activeCwdsOverride) ? activeCwdsOverride : listActiveProcessPaths());
  let activeCwds;
  const board = collectBoard(root, { ttlDays, staleHours, base: baseOverride, now });
  const targets = board.branches.filter((b) => b.state === 'landed' || b.state === 'due');
  const targetNames = new Set(targets.map((b) => b.name));
  const candidateWorktrees = board.worktrees.filter(
    (w) => targetNames.has(w.branch) || (includeDetached && w.state === 'detached') || (typeof w.ageDays === 'number' && w.ageDays > ttlDays) || w.unlandedCommits > 0
  );
  const protectedWorktrees = [];
  const worktreeTargets = [];
  const current = path.resolve(root);
  for (const w of candidateWorktrees) {
    // Only the fresh-worktree grace protects here. Dirty worktrees are NOT
    // skipped: reap's salvage (bundle + patches + untracked copies below)
    // exists precisely so dirty residue can be cleared loss-free. Blanket
    // dirty protection lives in the janitor's cleanupWorktrees, which has
    // no salvage machinery.
    if (protectCurrent && path.resolve(w.path) === current) {
      protectedWorktrees.push({ ...w, reason: 'current_checkout' });
      continue;
    }
    // A run working inside the folder outranks --force: removing it pulls
    // the floor out from under a live engine.
    if (activeCwds === undefined) activeCwds = readActiveCwds();
    if (worktreeHasActiveProcess(w.path, activeCwds)) {
      protectedWorktrees.push({ ...w, reason: activeCwds ? 'active_process' : 'process_scan_failed' });
      continue;
    }
    if (worktreeWithinReapGrace(w.path, now)) {
      protectedWorktrees.push({ ...w, reason: 'fresh_worktree_grace' });
      continue;
    }
    // Unlanded commits that no branch salvage bundle will cover are lost by a
    // force-remove: a detached worktree's commits ride no branch, and an active
    // branch worktree is not a reap target so its commits are never bundled.
    // Keep the worktree (and name what it holds) unless the operator forces it.
    // A due/landed branch worktree still reaps normally, its commits ride the
    // branch bundle, so removal is loss-free.
    const bundleCovered = w.branch && targetNames.has(w.branch);
    if (w.unlandedCommits > 0 && !force && !bundleCovered) {
      const oldest = typeof w.ageDays === 'number' ? `, oldest ${w.ageDays}d` : '';
      protectedWorktrees.push({ ...w, reason: `unlanded commits: ${w.unlandedCommits} never landed${oldest}, needs landing` });
      continue;
    }
    worktreeTargets.push(w);
  }
  for (const w of protectedWorktrees) {
    if (w.branch) targetNames.delete(w.branch);
  }
  for (const w of worktreeTargets) {
    if (w.branch && !targetNames.has(w.branch)) targetNames.add(w.branch);
  }

  const receipt = {
    base: board.base,
    ttlDays,
    dryRun,
    bundle: null,
    bundleError: null,
    patches: [],
    untracked: [],
    keptWorktrees: protectedWorktrees.map((w) => `${w.path} (${w.reason})`),
    keptMovedBranches: [],
    removedWorktrees: [],
    deletedBranches: [],
    deletedRemote: [],
    kept: board.branches.filter((b) => !targetNames.has(b.name)).map((b) => b.name),
  };
  if (targetNames.size === 0 && worktreeTargets.length === 0) return receipt;
  if (dryRun) {
    // The preview must match the real pass: a branch still checked out in a
    // worktree the board missed is kept, not listed as deleted. A checkout
    // that is itself a removal target would be gone first, so it still reads
    // as deletable here.
    const live = liveCheckouts(root, now);
    const targetPaths = new Set(worktreeTargets.map((w) => canonicalPath(w.path)));
    receipt.removedWorktrees = worktreeTargets.map((w) => w.path);
    receipt.deletedBranches = [...targetNames].filter((name) => {
      const bound = live.bound.get(name);
      if (bound && !(bound.path && targetPaths.has(canonicalPath(bound.path)))) {
        receipt.keptWorktrees.push(checkoutKeepLine(name, bound, now));
        return false;
      }
      if (!bound && live.pendingFresh && branchCreatedWithinGrace(root, name, now)) {
        receipt.keptWorktrees.push(`branch ${name} (fresh_worktree_grace)`);
        return false;
      }
      return true;
    });
    return receipt;
  }

  const dir = salvageDir(root);
  const withCommits = [...targetNames].filter((name) => {
    const entry = board.branches.find((b) => b.name === name);
    return entry && entry.ahead > 0;
  });
  if (withCommits.length > 0) {
    const bundlePath = path.join(dir, `reap-${timeStamp()}.bundle`);
    const result = runGit(['bundle', 'create', bundlePath, ...withCommits, '--not', board.base], {
      cwd: root,
      check: false,
    });
    if (result.status === 0) receipt.bundle = bundlePath;
    else {
      // Salvage-first is a hard promise: no bundle, no deletion of unlanded
      // work. These branches (and their worktrees) survive until a reap can
      // actually back them up.
      receipt.bundleError = String(result.stderr || result.stdout || 'bundle failed').trim().slice(0, 200);
      for (const name of withCommits) targetNames.delete(name);
    }
  }

  const survivingWorktreeTargets = worktreeTargets.filter(
    (w) => targetNames.has(w.branch) || (includeDetached && w.state === 'detached')
  );
  const activeAtRemoval = survivingWorktreeTargets.length ? readActiveCwds() : [];
  for (const w of survivingWorktreeTargets) {
    // A run can start in the folder while the bundle is built; look again.
    if (worktreeHasActiveProcess(w.path, activeAtRemoval)) {
      receipt.keptWorktrees.push(`${w.path} (${activeAtRemoval ? 'active_process' : 'process_scan_failed'})`);
      if (w.branch) targetNames.delete(w.branch);
      continue;
    }
    // The grace check ran at scan time, and a bundle build can sit between it
    // and removal — an engine that booted mid-sweep refreshes the directory
    // mtime in that gap. Stat once more at removal time, the cheapest place
    // to never be wrong about freshness.
    if (worktreeWithinReapGrace(w.path)) {
      receipt.keptWorktrees.push(`${w.path} (fresh_worktree_grace)`);
      if (w.branch) targetNames.delete(w.branch);
      continue;
    }
    // Salvage-then-remove, never keep-because-dirty: patches + untracked
    // copies bank everything force-remove would destroy.
    if (w.dirty > 0 && !salvageWorktree(w, dir, receipt)) {
      // could not fully back up what force-remove would destroy, keep it,
      // and say why: a bare path in the receipt reads as an unexplained
      // no-op (the exact silence BCK-1232 was about).
      receipt.keptWorktrees.push(`${w.path} (salvage incomplete: patch/copy failed, kept to avoid losing work)`);
      if (w.branch) targetNames.delete(w.branch);
      continue;
    }
    const removed = runGit(['worktree', 'remove', '--force', w.path], { cwd: root, check: false });
    if (removed.status === 0) {
      receipt.removedWorktrees.push(w.path);
      recordWorktreeRemoval(root, { path: w.path, branch: w.branch, by, reason: reapReason(w, board, ttlDays, force) });
    } else {
      // A locked worktree fails here and, unreported, reap re-salvages the
      // same patches every pass forever. Say what blocked it so a human can
      // unlock (or a dead lock can be challenged) instead of looping.
      const reason = String(removed.stderr || removed.stdout || 'remove failed').trim().slice(0, 160);
      receipt.keptWorktrees.push(`${w.path} (${reason})`);
      if (w.branch) targetNames.delete(w.branch);
    }
  }

  // Re-scan after removals: worktrees just removed freed their branches, and
  // anything still bound is checked out in a directory that exists — the
  // board snapshot may have missed it entirely (a `worktree add` mid-flight),
  // and git's own -D refusal only reads fully wired registrations.
  const live = liveCheckouts(root, now);
  for (const name of targetNames) {
    const bound = live.bound.get(name);
    if (bound) {
      receipt.keptWorktrees.push(checkoutKeepLine(name, bound, now));
      continue;
    }
    if (live.pendingFresh && branchCreatedWithinGrace(root, name, now)) {
      receipt.keptWorktrees.push(`branch ${name} (fresh_worktree_grace)`);
      continue;
    }
    const entry = board.branches.find((b) => b.name === name);
    // the board is a snapshot; an agent may have committed since it was
    // taken. A branch that moved is left alone, the next reap sees the
    // new truth and bundles it before touching it.
    if (!entry || aheadCount(root, board.base, name) !== entry.ahead) {
      receipt.keptMovedBranches.push(name);
      continue;
    }
    const deleted = runGit(['branch', '-D', name], { cwd: root, check: false });
    if (deleted.status === 0) {
      receipt.deletedBranches.push(name);
    } else {
      // Same silence class as the worktree-remove path: a branch checked
      // out in a side copy the board never saw makes -D refuse, and an
      // unreported refusal reads as "cleanup done" with nothing cleared.
      const reason = String(deleted.stderr || deleted.stdout || 'branch delete failed').trim().slice(0, 160);
      receipt.keptWorktrees.push(`branch ${name} (${reason})`);
    }
  }

  if (remote && receipt.deletedBranches.length > 0) {
    const heads = remoteHeads(root);
    if (heads) {
      const remoteTargets = receipt.deletedBranches.filter((name) => heads.has(name));
      for (let i = 0; i < remoteTargets.length; i += 25) {
        const batch = remoteTargets.slice(i, i + 25);
        const pushed = runGit(['push', 'origin', '--delete', ...batch], { cwd: root, check: false });
        if (pushed.status === 0) receipt.deletedRemote.push(...batch);
      }
    }
  }

  return receipt;
}

// The story of one piece of work: what it tried to do, whether it made it
// into master some other way, and what would be lost if it were cleared.
function collectStory(root, name, { base: baseOverride = '' } = {}) {
  const base = baseBranch(root, baseOverride);
  if (!base) {
    const err = new Error('no master/main branch found. fix: git checkout -b main');
    err.code = 'LAND_NO_BASE';
    throw err;
  }
  if (!refExists(root, name)) return null;

  const logResult = runGit(
    ['log', '--format=%h%x09%cs%x09%an%x09%s', `${base}..${name}`],
    { cwd: root, check: false }
  );
  const changes = logResult.stdout
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => {
      const [hash, date, author, subject] = line.split('\t');
      return { hash, date, author, subject };
    });

  // git cherry marks a change '-' when an equivalent patch already exists
  // in base, the honest "it landed some other way" signal.
  const cherry = runGit(['cherry', base, name], { cwd: root, check: false });
  const landedHashes = new Set();
  for (const line of cherry.stdout.split(/\r?\n/).filter(Boolean)) {
    if (line.startsWith('- ')) landedHashes.add(line.slice(2).trim());
  }
  const fullHashes = runGit(['log', '--format=%H %h', `${base}..${name}`], { cwd: root, check: false });
  const shortToLanded = new Set();
  for (const line of fullHashes.stdout.split(/\r?\n/).filter(Boolean)) {
    const [full, short] = line.split(' ');
    if (landedHashes.has(full)) shortToLanded.add(short);
  }
  for (const c of changes) c.landedElsewhere = shortToLanded.has(c.hash);

  const stat = runGit(['diff', '--stat', `${base}...${name}`], { cwd: root, check: false });
  const statLines = stat.stdout.split(/\r?\n/).filter(Boolean);
  const files = statLines.slice(0, -1).map((l) => l.split('|')[0].trim());

  const info = listBranches(root).find((b) => b.name === name);
  return {
    name,
    base,
    ageDays: info ? ageDays(info.lastCommitUnix) : null,
    changes,
    landedElsewhere: changes.filter((c) => c.landedElsewhere).length,
    uniqueChanges: changes.filter((c) => !c.landedElsewhere).length,
    files,
  };
}

function printStory(story) {
  console.log('');
  console.log(`what happened in ${story.name}`);
  console.log('');
  if (story.changes.length === 0) {
    console.log(`  everything here is already in ${story.base}. this is an empty leftover,`);
    console.log("  safe to clear. nothing would be lost.");
    console.log('');
    return;
  }
  const who = [...new Set(story.changes.map((c) => c.author))].join(', ');
  const when = story.changes[story.changes.length - 1].date;
  const last = story.changes[0].date;
  const age = story.ageDays === null ? '' : ` (${countLabel(story.ageDays, 'day')} ago)`;
  console.log(`  started ${when}, last touched ${last}${age}, by ${who}.`);
  console.log('');
  console.log('  what it tried to do:');
  for (const c of [...story.changes].reverse()) {
    const mark = c.landedElsewhere ? 'made it in   ' : 'never made it';
    console.log(`    ${mark}  ${c.subject}`);
  }
  console.log('');
  if (story.files.length > 0) {
    const shown = story.files.slice(0, 6).join(', ');
    const more = story.files.length > 6 ? ` and ${story.files.length - 6} more` : '';
    console.log(`  it touched: ${shown}${more}`);
    console.log('');
  }
  if (story.uniqueChanges === 0) {
    console.log(`  bottom line: all ${countLabel(story.changes.length, 'change')} made it into ${story.base}`);
    console.log('  some other way. nothing here would be lost by clearing it.');
  } else if (story.landedElsewhere > 0) {
    console.log(`  bottom line: ${story.landedElsewhere} of ${story.changes.length} changes made it into ${story.base} another`);
    console.log(`  way. ${story.uniqueChanges} exist only here (marked "never made it") - they may have`);
    console.log('  been redone differently, or they may be real lost work. clearing backs');
    console.log('  them up first either way.');
  } else {
    console.log(`  bottom line: none of this is in ${story.base}. this is real work that only`);
    console.log('  exists here. land it or clear it knowing the backup keeps a copy.');
  }
  console.log('');
  console.log(`  see the actual changes: git diff ${story.base}...${story.name}`);
  console.log('');
}

function printBoard(board) {
  console.log('');
  console.log('the landing: what is actually done vs still in the air');
  console.log('');
  if (board.branches.length === 0 && board.worktrees.length === 0) {
    console.log('  everything has landed. nothing in the air, nothing stuck.');
    console.log('');
    return;
  }
  const order = { due: 0, detached: 0, active: 1, landed: 2 };
  const rows = [...board.branches].sort((a, b) => (order[a.state] ?? 3) - (order[b.state] ?? 3) || b.ageDays - a.ageDays);
  const labels = { due: 'overdue', landed: 'landed', active: 'in the air' };
  for (const b of rows) {
    const changes = b.ahead === 1 ? '1 change ' : `${b.ahead} changes`;
    const label = b.stale ? 'stale' : (labels[b.state] || b.state);
    console.log(`  ${label.padEnd(11)} ${String(b.ageDays).padStart(3)}d  ${changes}  ${b.name}`);
  }
  for (const w of board.worktrees) {
    const bits = [];
    if (w.stranded) bits.push(w.unlandedCommits === 1 ? '1 commit never landed' : `${w.unlandedCommits} commits never landed`);
    if (w.dirty > 0) bits.push(w.dirty === 1 ? '1 unsaved edit' : `${w.dirty} unsaved edits`);
    const age = typeof w.ageDays === 'number' ? `, ${countLabel(w.ageDays, 'day')} old` : '';
    const detail = bits.length ? ` (${bits.join(', ')}${age})` : '';
    console.log(`  side copy   ${w.path}${detail}`);
    if (w.stranded) {
      for (const s of w.subjects) console.log(`                - ${s}`);
    }
  }
  console.log('');
  const s = board.summary;
  const stillInAir = s.active + s.due;
  console.log(`  ${s.unlanded} ${s.unlanded === 1 ? 'piece' : 'pieces'} tracked: ${stillInAir} still in the air, ${s.stale} stale, ${s.due} overdue, ${s.landed} landed and safe to clear.`);
  console.log('  work counts as done only when it lands in master.');
  if (s.due + s.landed > 0) {
    const clearable = s.due > 0 && s.landed > 0
      ? `${s.due} overdue and ${s.landed} landed`
      : s.due > 0 ? `${s.due} overdue` : `${s.landed} landed`;
    console.log(`  back up + clear ${clearable}: atris land --reap`);
  }
  console.log('');
}

function printReceipt(receipt) {
  console.log('');
  if (receipt.dryRun) {
    console.log(`landing cleanup preview: would clear ${receipt.deletedBranches.length} pieces of work, ${receipt.removedWorktrees.length} side copies:`);
    for (const b of receipt.deletedBranches) console.log(`  would clear  ${b}`);
    for (const w of receipt.removedWorktrees) console.log(`  would remove ${w}`);
  } else {
    console.log(`landing cleanup done: ${receipt.deletedBranches.length} pieces cleared, ${receipt.removedWorktrees.length} side copies removed`);
    if (receipt.bundle) console.log(`  backed up first, nothing lost: ${receipt.bundle}`);
    if (receipt.bundleError) console.log(`  backup failed: unlanded work left in place: ${receipt.bundleError}`);
    for (const p of receipt.patches) console.log(`  unsaved edits saved: ${p}`);
    for (const u of receipt.untracked || []) console.log(`  new files saved: ${u}`);
    // fresh-grace keeps are healthy active work, not a call to action, 
    // "needs a human" on those trained readers to ignore the real ones.
    for (const k of receipt.keptWorktrees || []) {
      // The receipt keeps the raw codes; the human line speaks in sentences.
      if (String(k).includes('(fresh_worktree_grace)')) console.log(`  in use, left alone: ${k.replace(' (fresh_worktree_grace)', '')}`);
      else if (String(k).includes('(current_checkout)')) console.log(`  you are standing in it, left alone: ${k.replace(' (current_checkout)', '')}`);
      else console.log(`  ✋ kept, needs a human: ${k}`);
    }
    for (const m of receipt.keptMovedBranches || []) console.log(`  moved since scan, left alone: ${m}`);
    if (receipt.deletedRemote.length > 0) console.log(`  also cleared on github: ${receipt.deletedRemote.length}`);
  }
  console.log(`  still flying (recent work, left alone): ${receipt.kept.length}`);
  console.log('');
}

// Preserve split-only parsing and its fallback for missing or falsey values.
function readFollowingFlag(args, name, fallback = '') {
  const idx = args.indexOf(name);
  if (idx === -1) return fallback;
  return args[idx + 1] || fallback;
}

const EMPTY_LAND = {
  not_a_git_repo: 'this folder is not a git repo yet, so there is nothing to land.',
  no_commits: 'nothing is in the air yet because this folder has no commits.',
  no_base: 'no master or main branch yet, so there is nothing to land.',
};

function emptyLandKindFromError(err) {
  if (err && err.code === 'LAND_NO_BASE') return 'no_base';
  const msg = String(err && err.message || err || '');
  if (/not a git/i.test(msg)) return 'not_a_git_repo';
  if (/no commits/i.test(msg)) return 'no_commits';
  if (/no master\/main/i.test(msg)) return 'no_base';
  return '';
}

function printEmptyLand(kind, json) {
  const reason = EMPTY_LAND[kind] ? kind : 'no_base';
  const detail = EMPTY_LAND[reason];
  if (json) {
    const payload = compactErrorPayload({ reason, detail });
    printCliJson(payload, payload, ['--json']);
  } else {
    console.log(detail);
  }
  return 2;
}

function finishLandError(err, json) {
  const kind = emptyLandKindFromError(err);
  if (kind) return printEmptyLand(kind, json);
  console.error(String(err && err.message || err).split('\n')[0]);
  return 2;
}

function showHelp() {
  console.log('');
  console.log('atris land: the landing, what is actually done vs still in the air');
  console.log('');
  console.log('work counts as done only when it lands in master. everything else is');
  console.log('in the air, and this shows it so nothing quietly dies.');
  console.log('');
  console.log('  atris land                     show everything still in the air');
  console.log('  atris land status              show everything still in the air');
  console.log('  atris land <name>              the story of one piece: what it tried,');
  console.log('  atris land status <name>       same story lookup from status mode');
  console.log('                                 whether it landed some other way, what');
  console.log('                                 would be lost by clearing it');
  console.log('  atris land --reap              back up, then clear anything overdue');
  console.log('                                 or already landed (here and on github)');
  console.log('  atris land --reap --dry-run    preview what would be cleared');
  console.log('  atris land --reap --force      also clear side copies holding');
  console.log('                                 commits that never landed (backs up first)');
  console.log('  atris land --auto              land one stale branch that merges clean and');
  console.log('                                 passes the full verify; a red one opens a flag');
  console.log('  atris land --auto --dry-run    show which branch would be tried and why');
  console.log('  atris land --auto --verify "<cmd>" --limit <n>');
  console.log('                                 change the check (default: npm test) or the cap');
  console.log('  atris land --requeue           put member changes github dropped from its');
  console.log('                                 merge line back in, caught up with master');
  console.log('  atris land --ttl <days>        change the 7-day overdue line');
  console.log('  atris land --json              machine-readable output');
  console.log('');
  console.log('backups go to .atris/salvage/<date>/; clearing never loses work.');
  console.log('');
}

function landCommand(args = []) {
  if (args.includes('--help') || args.includes('-h') || args[0] === 'help') {
    showHelp();
    return 0;
  }
  const json = args.includes('--json');
  const root = repoRoot();
  if (!root) return printEmptyLand('not_a_git_repo', json);
  if (!hasCommits(root)) return printEmptyLand('no_commits', json);
  const ttlRaw = readFollowingFlag(args, '--ttl', '');
  const ttlParsed = Number(ttlRaw);
  const ttlDays = ttlRaw !== '' && Number.isFinite(ttlParsed) && ttlParsed >= 0 ? ttlParsed : DEFAULT_TTL_DAYS;
  const base = readFollowingFlag(args, '--base', '');

  if (args.includes('--auto')) {
    try {
      const { landStaleGreenBranches, summaryLine, DEFAULT_VERIFY } = require('../lib/land-green');
      const limitRaw = Number(readFollowingFlag(args, '--limit', ''));
      const result = landStaleGreenBranches(root, {
        ttlDays,
        base,
        dryRun: args.includes('--dry-run'),
        push: !args.includes('--no-remote'),
        verifyCommand: readFollowingFlag(args, '--verify', '') || DEFAULT_VERIFY,
        limit: Number.isFinite(limitRaw) && limitRaw > 0 ? limitRaw : 1,
      });
      if (json) console.log(JSON.stringify(result, null, 2));
      else console.log(`green landing: ${summaryLine(result)}`);
      return 0;
    } catch (err) {
      return finishLandError(err, json);
    }
  }

  if (args.includes('--requeue')) {
    try {
      const result = require('../lib/member-autoland').requeueDroppedAutolands({ cwd: root });
      if (json) console.log(JSON.stringify(result, null, 2));
      else {
        console.log(`merge line: ${result.line}`);
        for (const r of result.results) console.log(`  ${r.line}`);
      }
      return 0;
    } catch (err) {
      return finishLandError(err, json);
    }
  }

  if (args.includes('--reap')) {
    try {
      const receipt = reap(root, { ttlDays, base, dryRun: args.includes('--dry-run'), remote: !args.includes('--no-remote'), force: args.includes('--force') });
      if (json) console.log(JSON.stringify(receipt, null, 2));
      else printReceipt(receipt);
      return 0;
    } catch (err) {
      return finishLandError(err, json);
    }
  }

  const lookupArgs = args[0] === 'status' ? args.slice(1) : args;
  const name = lookupArgs.find((a) => !a.startsWith('-') && a !== readFollowingFlag(lookupArgs, '--ttl') && a !== readFollowingFlag(lookupArgs, '--base'));
  if (name) {
    try {
      const story = collectStory(root, name, { base });
      if (!story) {
        console.error(`nothing called '${name}' is in the air right now`);
        return 1;
      }
      if (json) console.log(JSON.stringify(story, null, 2));
      else printStory(story);
      return 0;
    } catch (err) {
      return finishLandError(err, json);
    }
  }

  try {
    const board = collectBoard(root, { ttlDays, base });
    if (json) console.log(JSON.stringify(board, null, 2));
    else printBoard(board);
    return 0;
  } catch (err) {
    return finishLandError(err, json);
  }
}

module.exports = {
  clearBoardMemo,
  collectBoard,
  countLabel,
  landCommand,
  landSummary,
  reap,
  salvageDir,
  sharedBoard,
};
